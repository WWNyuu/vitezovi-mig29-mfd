VITEZOVI DTC PLANNER
====================
Double-click "Vitezovi DTC Planner.html" to open it in your browser (Chrome or Edge).
Works offline. All map data is built into the file, so you can copy it to squadron mates as-is.

SAVE writes the cartridge to your Downloads folder: NAME.dtc, or NAME.zip when it
has drawings (it holds NAME.dtc and NAME.geo.txt - unzip both).
Move them into:  Saved Games\DCS\DTC

To change a cartridge later, OPEN its .dtc together with its .geo.txt (select both).

DCS CHARTS layer: click it and pick your DCS map's RasterCharts folder
(e.g. D:\DCS World\Mods\terrains\Caucasus\RasterCharts). Read locally, nothing is uploaded.
