-- MiG-29 DL page: tiny debug log, Saved Games\DCS\Logs\mig29dl_<name>.log
--
-- At most LOG_MAX lines per cockpit (the file is rewritten when a new
-- cockpit starts: respawn, new mission). v1.7.2:
--  * the file of the cockpit before is kept as mig29dl_<name>.old.log, so a
--    problem is still there to read after a respawn
--  * the last LOG_ERR lines of the budget are kept for errors (a message
--    with "error" in it, or DL_dbg(name, msg, true)), so an error late in a
--    long session is not lost behind hours of normal messages
DL_DEBUG_LOG = DL_DEBUG_LOG or {}
local LOG_MAX, LOG_ERR = 300, 50

local function log_path(l, name, ext) return l.writedir() .. "Logs/mig29dl_" .. name .. ext end

-- keep the previous file: rename it (Windows cannot rename onto an
-- existing file, so the older copy goes first), else copy it
local function keep_old(l, name)
	local cur, old = log_path(l, name, ".log"), log_path(l, name, ".old.log")
	local fh = io.open(cur, "rb")
	if not fh then return end
	fh:close()
	pcall(os.remove, old)
	local ok, r = pcall(os.rename, cur, old)
	if ok and r then return end
	local fi = io.open(cur, "rb")
	if not fi then return end
	local txt = fi:read("*a"); fi:close()
	local fo = io.open(old, "wb")
	if fo then fo:write(txt or ""); fo:close() end
end

local function write(name, line, first)
	pcall(function()
		local l = require("lfs")
		if first then keep_old(l, name) end
		local f = io.open(log_path(l, name, ".log"), first and "w" or "a")
		if f then f:write(os.date("%H:%M:%S ") .. line .. "\n"); f:close() end
	end)
end

function DL_dbg(name, msg, is_err)
	local c = DL_DEBUG_LOG[name]
	if not c then c = {n = 0, norm = 0}; DL_DEBUG_LOG[name] = c end
	if c.n >= LOG_MAX then return end
	msg = tostring(msg)
	local err = is_err or (msg:lower():find("error", 1, true) ~= nil)
	if not err then
		if c.norm >= LOG_MAX - LOG_ERR then
			-- normal budget used up: say so once, keep the rest for errors
			if not c.full then
				c.full, c.n = true, c.n + 1
				write(name, "(log: " .. c.norm .. " lines, only errors are written from here on)", c.n == 1)
			end
			return
		end
		c.norm = c.norm + 1
	end
	c.n = c.n + 1
	if c.n == LOG_MAX then msg = msg .. "  (log full)" end
	write(name, msg, c.n == 1)
end
