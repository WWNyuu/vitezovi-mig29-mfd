-----------------------------------------------------------------------
-- MiG-29 DL page: flight plans and data cartridges (DTC)
--
-- A plan is {name, pts, wps, ads}:
--   wps  the jet's navigation waypoints (WP-A/D buttons 1-3 in WP)
--   ads  the airfields (WP-A/D buttons 1-3 in A/D)
--   pts  what is drawn: the route (or the waypoints), then the airfields
-- Coordinates are DCS map metres: x = north, z = east.
--
-- Choices (UFCP button 3 steps through them, nothing is loaded on its own):
--   MSN            the mission: a cartridge stored with your jet in the
--                  mission (mission planner), else the mission route
--   <file>.dtc     each MiG-29 cartridge in Saved Games\DCS\DTC made for
--                  the map you are flying
-----------------------------------------------------------------------

DL_PLAN = {}

local function dbg(m) if DL_dbg then DL_dbg("device", "dtc: " .. m) end end
-- v1.7.2: names from cartridges are shown on the MFD / UFCP, whose fonts
-- only have ASCII (DL_ascii in dl_config.lua). Only strings and numbers
-- are names; anything else in a broken file is no name at all.
local function clean(v)
	if type(v) == "number" then return tostring(v) end
	if type(v) ~= "string" then return nil end
	return DL_ascii and DL_ascii(v) or v
end

local JSON = nil
local function json()
	if JSON then return JSON end
	local roots = {"", "./"}
	local ok_lfs, lfs_mod = pcall(require, "lfs")
	if ok_lfs and lfs_mod and lfs_mod.currentdir then
		local r = lfs_mod.currentdir()
		if r:sub(-1) ~= "/" and r:sub(-1) ~= "\\" then r = r .. "/" end
		roots[#roots + 1] = r
		roots[#roots + 1] = r .. "../"
	end
	for _, r in ipairs(roots) do
		local f = loadfile(r .. "Scripts/JSON.lua")
		if f then
			local ok, j = pcall(f)
			if ok and j then JSON = j; return JSON end
		end
	end
	return nil
end

local function short(lbl, prefix, i)
	-- (high bytes go as well: %w can include accented letters in some locales)
	lbl = tostring(lbl or ""):gsub("[^%w]", ""):gsub("[\128-\255]", "")
	lbl = lbl:gsub("^WPT", "W"):gsub("^PNT", "P")
	if lbl == "" or not lbl:find("%a") then lbl = prefix .. tostring(i) end
	return lbl
end

-- build a plan from lists of {x, y(east), num} points
function DL_PLAN.make(name, route, wps, ads)
	-- label = the name in ASCII for the displays (name itself stays the
	-- file name: the .geo.txt next to the cartridge is found by it). It can
	-- still be number-like ("2024"): use DL_text when it is shown alone.
	local p = {name = name, label = DL_ascii and DL_ascii(name) or name, pts = {}, wps = {}, ads = {}}
	-- a cartridge with only a route: its points are the nav waypoints
	if (not wps or #wps == 0) and route and #route > 0 then wps, route = route, nil end
	for i, w in ipairs(wps or {}) do
		p.wps[#p.wps + 1] = {x = w.x, z = w.z, lbl = "W" .. i, name = clean(w.name or w.lbl)}
	end
	for i, a in ipairs(ads or {}) do
		p.ads[#p.ads + 1] = {x = a.x, z = a.z, lbl = "A" .. i, ad = true, name = clean(a.name or a.lbl)}
	end
	local line = (route and #route > 0) and route or wps or {}
	for i, w in ipairs(line) do
		p.pts[#p.pts + 1] = {x = w.x, z = w.z, lbl = (line == wps) and ("W" .. i) or short(w.lbl, "W", i), name = clean(w.name), rt = i, tags = w.tags}
	end
	p.nrt = #p.pts            -- route points first, then the airfields
	for _, a in ipairs(p.ads) do p.pts[#p.pts + 1] = a end
	return p
end

-- a plan with only some of its route points, in the order given (the
-- RTE page): sel = list of route indices of the full plan
function DL_PLAN.route_view(plan, sel)
	local p = {}
	for k, v in pairs(plan) do p[k] = v end
	p.pts, p._rt, p.full = {}, nil, plan
	for _, i in ipairs(sel) do
		local w = plan.pts[i]
		if w and i <= (plan.nrt or #plan.pts) then p.pts[#p.pts + 1] = w end
	end
	p.nrt = #p.pts
	for i = (plan.nrt or #plan.pts) + 1, #plan.pts do p.pts[#p.pts + 1] = plan.pts[i] end
	return p
end
-- "ALL" = the whole route exactly in the cartridge's order. nil = no
-- route selection (the route as it is). v1.7.2: a route with member tags
-- used to be re-sorted by point number here, which dropped repeated points
-- (a DCS route P1 P5 P3 P4 P1 became P1 P3 P4 P5). Member tags only decide
-- which points each member flies (RTE page left 1-4, cartridge choice).
function DL_PLAN.all_order(plan)
	return nil
end
-- the flight member numbers used in a plan's route tags (sorted)
function DL_PLAN.members(plan)
	local seen, out = {}, {}
	for i = 1, (plan and plan.nrt) or 0 do
		for m in pairs(plan.pts[i].tags or {}) do if not seen[m] then seen[m] = true; out[#out + 1] = m end end
	end
	table.sort(out)
	return out
end

-- flight member tags at the start of a cartridge note: "12 TGT" = for
-- members 1 and 2, "5 R1 IP" = member 5 only (the planner's X column),
-- "12" alone = tagged point without a name. A tag is 1-5 different digits
-- 1-5, followed by a space or the end of the note; anything else is part
-- of the name ("250 KTS": 0 is no member, "112 X": a digit twice).
-- Returns tags (nil = none) and the rest of the note (nil = empty).
local function member_tags(note)
	local t, rest = note:match("^(%S+)%s+(.*)$")
	if not t then t, rest = note, "" end
	if #t > 5 or t:find("[^1-5]") then return nil, note end
	local tags = {}
	for c in t:gmatch("%d") do
		local m = tonumber(c)
		if tags[m] then return nil, note end
		tags[m] = true
	end
	return tags, (rest ~= "") and rest or nil
end

local function pts_of(list)
	local out = {}
	if type(list) ~= "table" then return out end
	for i, w in ipairs(list) do
		-- v1.7.2: a broken file may hold numbers / strings instead of points
		if type(w) == "table" then
			local x, y = tonumber(w.x), tonumber(w.y)
			-- name: the cartridge note ("RV", "TGT") when there is one
			local note = (type(w.note) == "string" and w.note ~= "") and w.note or nil
			local tags = nil
			if note then tags, note = member_tags(note) end
			local lbl = w.num
			if type(lbl) ~= "string" and type(lbl) ~= "number" then lbl = w.name end
			if type(lbl) ~= "string" and type(lbl) ~= "number" then lbl = i end
			if x and y then out[#out + 1] = {x = x, z = y, lbl = lbl, name = clean(note or w.unit_name or w.name), tags = tags} end
		end
	end
	return out
end

-- plan from a decoded cartridge (its selected program)
local function build(name, data)
	if type(data) ~= "table" then data = {} end
	local prog = data[data.SelectedProgram or "Program_1"]
	if type(prog) ~= "table" then prog = data.Program_1 end
	if type(prog) ~= "table" then local p = DL_PLAN.make(name, {}, {}, {}); p.radio, p.rsbn, p.adf = {}, {}, {}; return p end
	local p = DL_PLAN.make(name, pts_of(prog.Route), pts_of(prog.Waypoints), pts_of(prog.Airdromes))
	-- radio presets (Channel_0 = channel 1), RSBN and ADF channels
	p.radio = {}
	for k, c in pairs(type(prog.Radio) == "table" and prog.Radio or {}) do
		local n = tonumber(tostring(k):match("(%d+)$"))
		if n and type(c) == "table" and tonumber(c.freq) then p.radio[n + 1] = tonumber(c.freq) end
	end
	p.rsbn = {}
	for _, r in ipairs(type(prog.RSBN) == "table" and prog.RSBN or {}) do
		if type(r) == "table" then
			p.rsbn[#p.rsbn + 1] = {name = clean(r.name) or clean(r.unit_name) or "?", channel = tonumber(r.channel), x = tonumber(r.x), z = tonumber(r.y)}
		end
	end
	p.adf = {}
	for k, c in pairs(type(prog.ADF) == "table" and prog.ADF or {}) do
		if type(c) == "table" and tonumber(c.freq) then p.adf[#p.adf + 1] = {key = tostring(k), freq = tonumber(c.freq)} end
	end
	table.sort(p.adf, function(a, b) return a.key < b.key end)
	return p
end
-- v1.7.2: never throws (it runs in the start-up tick and in button
-- handling): a cartridge that cannot be read gives an empty plan
local bad_logged = {}
function DL_PLAN.from_cartridge(name, data)
	local ok, p = pcall(build, name, data)
	if ok and type(p) == "table" then return p end
	if not bad_logged[tostring(name)] then
		bad_logged[tostring(name)] = true
		dbg(tostring(name) .. ": cartridge error, loaded as empty: " .. tostring(p))
	end
	p = DL_PLAN.make(name, {}, {}, {})
	p.radio, p.rsbn, p.adf = {}, {}, {}
	return p
end

-- theatre names: DCS ids (missions, .dtc files) and terrain folder names
-- mean the same map (dl_theatres.lua); "" or nil = not known
local function known_map(n)
	if DL_theatre_id then return DL_theatre_id(n) ~= nil end
	return type(n) == "string" and n ~= ""
end
local function same_map(a, b)
	if DL_same_theatre then return DL_same_theatre(a, b) end
	return tostring(a):lower() == tostring(b):lower()
end

-- v1.7.2: what was read from each file, by file name. Valid while the
-- file's size and modification time stay the same, so a boot (BIT, then
-- the cartridge choice) and the NAV page do not decode every file again.
--   {key = "size:time", data = decoded MiG-29 cartridge}  or
--   {key = ..., skip = true}  another aircraft's file   or
--   {key = ..., err = "..."}  a broken file (logged once, then skipped)
local CACHE = {}
DL_PLAN.cache = CACHE
local BOM = "\239\187\191"
local function read_file(J, lfs_mod, dir, name)
	local path = dir .. name
	local key = nil
	if lfs_mod.attributes then
		local ok, a = pcall(lfs_mod.attributes, path)
		if ok and type(a) == "table" then key = tostring(a.size) .. ":" .. tostring(a.modification) end
	end
	local c = CACHE[name]
	if c and key and c.key == key then return c end
	c = {key = key}
	local fh = io.open(path, "r")
	if not fh then c.err = "cannot be opened"; return c end
	local txt = fh:read("*a"); fh:close()
	txt = txt or ""
	-- every .dtc of every aircraft is in this folder: only MiG-29 ones are
	-- worth decoding (~8 ms per 120 KB file)
	if not txt:find("MiG-29", 1, true) then c.skip = true; return c end
	-- a UTF-8 byte order mark (some editors write one) is not JSON
	if txt:sub(1, 3) == BOM then txt = txt:sub(4) end
	local J_ok, d = pcall(function() return J:decode(txt) end)
	if not J_ok or type(d) ~= "table" then c.err = "not readable as JSON (" .. tostring(d):sub(1, 120) .. ")"; return c end
	local data = (type(d.data) == "table") and d.data or d
	if not tostring(data.type or d.type or ""):find("MiG%-29") then c.skip = true; return c end
	-- a file that cannot be turned into a plan is skipped, not loaded later
	local okp, e = pcall(build, name, data)
	if not okp then c.err = "cartridge error (" .. tostring(e):sub(1, 120) .. ")"; return c end
	c.data = data
	return c
end

-- MiG-29 cartridges for this map, sorted by name
function DL_PLAN.list_files(theatre)
	local files = {}
	local ok_lfs, lfs_mod = pcall(require, "lfs")
	if not ok_lfs or not lfs_mod then return files end
	local dir = lfs_mod.writedir() .. "DTC/"
	local J = json()
	if not J then return files end
	local filter = known_map(theatre)
	local seen = {}
	pcall(function()
		for name in lfs_mod.dir(dir) do
			if type(name) == "string" and name:lower():match("%.dtc$") then
				-- one bad file must not hide the others
				local ok, c = pcall(read_file, J, lfs_mod, dir, name)
				if not ok then c = {err = "read error (" .. tostring(c):sub(1, 120) .. ")"} end
				if c.key then CACHE[name] = c end
				seen[name] = true
				if c.err and not c.logged then c.logged = true; dbg(name .. " skipped: " .. c.err) end
				if c.data then
					local terr = c.data.terrain
					if not filter or not known_map(terr) or same_map(terr, theatre) then
						files[#files + 1] = {name = name:gsub("%.[dD][tT][cC]$", ""), data = c.data}
					end
				end
			end
		end
	end)
	for k in pairs(CACHE) do if not seen[k] then CACHE[k] = nil end end
	table.sort(files, function(a, b) return a.name:lower() < b.name:lower() end)
	return files
end

-- plan from the hook's "MSN DTC" packet lines (R / W / A)
function DL_PLAN.from_lines(name, lines)
	return DL_PLAN.make(name, lines.R or {}, lines.W or {}, lines.A or {})
end

-----------------------------------------------------------------------
-- coordinates: WGS84 UTM / MGRS (for typed-in waypoints on the NAV page)
-----------------------------------------------------------------------
local WA, WF, K0 = 6378137.0, 1 / 298.257223563, 0.9996
local WE2 = WF * (2 - WF)
local WEP2 = WE2 / (1 - WE2)

function DL_PLAN.utm_zone(lat, lon)
	local z = math.floor((lon + 180) / 6) + 1
	if lat >= 56 and lat < 64 and lon >= 3 and lon < 12 then z = 32 end     -- Norway
	return math.max(1, math.min(60, z))
end
function DL_PLAN.ll_to_utm(lat, lon, zone)
	zone = zone or DL_PLAN.utm_zone(lat, lon)
	local phi, lam = math.rad(lat), math.rad(lon)
	local lam0 = math.rad((zone - 1) * 6 - 180 + 3)
	local sp, cp, tp = math.sin(phi), math.cos(phi), math.tan(phi)
	local N = WA / math.sqrt(1 - WE2 * sp * sp)
	local T, Cc = tp * tp, WEP2 * cp * cp
	local A = cp * (lam - lam0)
	local e4, e6 = WE2 * WE2, WE2 * WE2 * WE2
	local Mm = WA * ((1 - WE2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi - (3 * WE2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * math.sin(2 * phi)
		+ (15 * e4 / 256 + 45 * e6 / 1024) * math.sin(4 * phi) - (35 * e6 / 3072) * math.sin(6 * phi))
	local e = K0 * N * (A + (1 - T + Cc) * A ^ 3 / 6 + (5 - 18 * T + T * T + 72 * Cc - 58 * WEP2) * A ^ 5 / 120) + 500000
	local n = K0 * (Mm + N * tp * (A * A / 2 + (5 - T + 9 * Cc + 4 * Cc * Cc) * A ^ 4 / 24 + (61 - 58 * T + T * T + 600 * Cc - 330 * WEP2) * A ^ 6 / 720))
	if lat < 0 then n = n + 10000000 end
	return zone, e, n
end
function DL_PLAN.utm_to_ll(zone, e, n, north)
	local x, y = e - 500000, north and n or (n - 10000000)
	local Mm = y / K0
	local mu = Mm / (WA * (1 - WE2 / 4 - 3 * WE2 ^ 2 / 64 - 5 * WE2 ^ 3 / 256))
	local e1 = (1 - math.sqrt(1 - WE2)) / (1 + math.sqrt(1 - WE2))
	local phi1 = mu + (3 * e1 / 2 - 27 * e1 ^ 3 / 32) * math.sin(2 * mu) + (21 * e1 ^ 2 / 16 - 55 * e1 ^ 4 / 32) * math.sin(4 * mu)
		+ (151 * e1 ^ 3 / 96) * math.sin(6 * mu) + (1097 * e1 ^ 4 / 512) * math.sin(8 * mu)
	local s1, c1, t1 = math.sin(phi1), math.cos(phi1), math.tan(phi1)
	local N1 = WA / math.sqrt(1 - WE2 * s1 * s1)
	local T1, C1 = t1 * t1, WEP2 * c1 * c1
	local R1 = WA * (1 - WE2) / (1 - WE2 * s1 * s1) ^ 1.5
	local D = x / (N1 * K0)
	local lat = phi1 - (N1 * t1 / R1) * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * WEP2) * D ^ 4 / 24
		+ (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * WEP2 - 3 * C1 * C1) * D ^ 6 / 720)
	local lon = (D - (1 + 2 * T1 + C1) * D ^ 3 / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * WEP2 + 24 * T1 * T1) * D ^ 5 / 120) / c1
	return math.deg(lat), (zone - 1) * 6 - 180 + 3 + math.deg(lon)
end
-- "38T KM": grid zone and the 100 km square letters
function DL_PLAN.mgrs_square(lat, zone, e, n)
	local bands = "CDEFGHJKLMNPQRSTUVWX"
	local b = math.max(1, math.min(20, math.floor((lat + 80) / 8) + 1))
	local sets = {"ABCDEFGH", "JKLMNPQR", "STUVWXYZ"}
	local set = sets[(zone - 1) % 3 + 1]
	local col = math.max(1, math.min(8, math.floor(e / 100000)))
	local rows = "ABCDEFGHJKLMNPQRSTUV"
	local r = (math.floor(n / 100000) + ((zone % 2 == 0) and 5 or 0)) % 20
	return string.format("%d%s %s%s", zone, bands:sub(b, b), set:sub(col, col), rows:sub(r + 1, r + 1))
end
