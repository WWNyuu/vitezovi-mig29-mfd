-----------------------------------------------------------------------
-- MiG-29 DL add-on: the MFD page font (loaded at the end of materials.lua)
--
-- A thin monospaced font in the style of western glass cockpits, one
-- cockpit font per colour: DL_F_WHITE, DL_F_GREEN, ... (see dl_page.lua).
-- Set font_style = "dcs" in dl_config.lua to go back to DCS's Arial.
-----------------------------------------------------------------------
if not DL_CFG then dofile(LockOn_Options.script_path .. "DL/dl_config.lua") end
dofile(LockOn_Options.script_path .. "DL/dl_font_desc.lua")
DL_FONT_DESC.texture = LockOn_Options.script_path .. "../Textures/IndicationTextures/mig29_dl_font.dds"

local COLOURS = {
	WHITE  = {235, 235, 235},
	GREEN  = {120, 230, 150},
	RED    = {240, 100, 100},
	PINK   = {242, 160, 160},
	YELLOW = {240, 230, 110},
	AMBER  = {255, 170,  60},
	CYAN   = {90, 215, 255},
	BLUE   = {70, 130, 255},
	GREY   = {170, 185, 175},
	DIM    = {105, 110, 108},   -- v1.7 start-up log text
	BLACK  = {0, 0, 0},
}
for name, c in pairs(COLOURS) do
	materials["DL_TXT_" .. name] = {c[1], c[2], c[3], 255}
	fonts["DL_F_" .. name] = {DL_FONT_DESC, 10, materials["DL_TXT_" .. name]}
end
