-- Theatre recognition for the MiG-29 DL page.
-- Each entry: a DCS world point (x north, z east, metres) and the lat/lon it must map to
-- on that theatre. terrain.convertMetersToLatLon() tells us which theatre is loaded.
-- MarianasWWII uses the same projection as MarianaIslands; see marianas_variant() below.
DL_THEATRES = {
	{name = "Afghanistan", x = 62027.05, z = -24694.80, lat = 34.5, lon = 66.0},
	{name = "Caucasus", x = -197826.86, z = 634263.66, lat = 43.0, lon = 42.0},
	{name = "Falklands", x = 85851.38, z = 9429.48, lat = -51.7, lon = -59.0},
	{name = "GermanyColdWar", x = -303744.69, z = -692470.75, lat = 51.5, lon = 10.5},
	{name = "Iraq", x = -28326.03, z = -21127.78, lat = 33.0, lon = 44.0},
	{name = "Kola", x = 71255.16, z = 223084.19, lat = 68.5, lon = 28.0},
	{name = "MarianaIslands", x = 56798.69, z = 22397.44, lat = 14.0, lon = 145.0},
	{name = "Nevada", x = -369573.86, z = -59659.39, lat = 36.5, lon = -115.5},
	{name = "PersianGulf", x = -18387.56, z = -74371.13, lat = 26.0, lon = 55.5},
	{name = "Sinai", x = -6527.65, z = 169222.00, lat = 30.0, lon = 33.0},
	{name = "Syria", x = -4995.37, z = 100284.91, lat = 35.0, lon = 37.0},
}

-- v1.7.2: theatre names. Missions, the hook (T line) and .dtc files use
-- DCS's theatre id; the terrain folders (Mods\terrains\<folder>), the
-- chart files (DL\charts\<folder>.lua) and DL_detect_theatre() use the
-- folder name. They differ on three maps.
DL_THEATRE_ID_OF_FOLDER = {GermanyColdWar = "GermanyCW", Sinai = "SinaiMap", MarianasWWII = "MarianaIslandsWWII"}
DL_THEATRE_FOLDER_OF_ID = {GermanyCW = "GermanyColdWar", SinaiMap = "Sinai", MarianaIslandsWWII = "MarianasWWII"}
local function lc_lookup(t, name)
	local l = name:lower()
	for k, v in pairs(t) do if k:lower() == l then return v end end
	return nil
end
-- DCS theatre id for a theatre id or folder name ("" / nil -> nil)
function DL_theatre_id(name)
	if type(name) ~= "string" then return nil end
	name = name:gsub("^%s+", ""):gsub("%s+$", "")
	if name == "" then return nil end
	return lc_lookup(DL_THEATRE_ID_OF_FOLDER, name) or name
end
-- terrain folder name for a theatre id or folder name ("" / nil -> nil)
function DL_theatre_folder(name)
	if type(name) ~= "string" then return nil end
	name = name:gsub("^%s+", ""):gsub("%s+$", "")
	if name == "" then return nil end
	return lc_lookup(DL_THEATRE_FOLDER_OF_ID, name) or name
end
-- true when two names (id or folder, any case) mean the same theatre
function DL_same_theatre(a, b)
	local ia, ib = DL_theatre_id(a), DL_theatre_id(b)
	return ia ~= nil and ib ~= nil and ia:lower() == ib:lower()
end

-- MarianaIslands and MarianasWWII share one projection, so the reference
-- point cannot tell them apart. Ask the terrain (newer DCS), else go by
-- which of the two terrains is installed.
local function marianas_variant(terr)
	if type(terr.GetTerrainConfig) == "function" then
		local ok, id = pcall(terr.GetTerrainConfig, "id")
		if ok and type(id) == "string" and id ~= "" then
			if id:lower():find("wwii") then return "MarianasWWII" end
			return "MarianaIslands"
		end
	end
	local okl, lfs = pcall(require, "lfs")
	if okl and type(lfs) == "table" and lfs.attributes then
		local has = function(d)
			local ok, a = pcall(lfs.attributes, "Mods/terrains/" .. d)
			return ok and type(a) == "table" and a.mode == "directory"
		end
		if not has("MarianaIslands") and has("MarianasWWII") then return "MarianasWWII" end
	end
	return "MarianaIslands"
end

-- returns the theatre name (terrain folder name) or nil
function DL_detect_theatre()
	if DL_CFG and DL_CFG.force_theatre and DL_CFG.force_theatre ~= "" then
		return DL_CFG.force_theatre
	end
	local ok, terr = pcall(require, "terrain")
	if not ok or type(terr) ~= "table" or not terr.convertMetersToLatLon then
		return nil
	end
	for _, t in ipairs(DL_THEATRES) do
		local ok2, lat, lon = pcall(terr.convertMetersToLatLon, t.x, t.z)
		if ok2 and lat and lon and math.abs(lat - t.lat) < 0.05 and math.abs(lon - t.lon) < 0.05 then
			if t.name == "MarianaIslands" then
				local okm, v = pcall(marianas_variant, terr)
				return okm and v or t.name
			end
			return t.name
		end
	end
	return nil
end

-- loads DL/charts/<theatre>.lua into DL_CHART (nil if there is none)
function DL_load_chart(theatre)
	DL_CHART = nil
	if not theatre then return nil end
	local path = LockOn_Options.script_path .. "DL/charts/" .. theatre .. ".lua"
	local ok = pcall(dofile, path)
	if ok and DL_CHART and DL_CHART.tiles then return DL_CHART end
	DL_CHART = nil
	return nil
end
