-- Vitezovi MiG-29 MFD add-on: SNAKE (easter egg, v1.7.4)
--
-- Typed on the UFCP keypad as on an old button phone: S N A K E =
-- 7777 66 2 55 33 (77776625533) opens it (page 16), from any page.
-- Keypad: 2 up, 4 left, 6 right, 8 down, 5 pause, ENT start / again,
-- CLR back to the page you came from; MENU (MFD-8) to the MENU.
--
-- Drawn with what the MFD can do: up to MAX small squares that move
-- (DLP_SNK_X/Y/V<i>), a filled head square and a red food diamond. The
-- body is a ring of MAX slots: each step only the new head slot and the
-- old tail slot change, so a step writes a handful of parameters.
-- Runs in the cockpit device (dl_device.lua loads it); the elements are
-- in dl_pages.lua (root "dlp_snk").

DL_SNAKE = {}
local S = DL_SNAKE

S.CODE = "77776625533"
S.COLS, S.ROWS = 20, 20
S.MAX = (DL_SNAKE_MAX or 100)
-- grid on the page (page units): left edge, top edge, cell size
S.X0, S.Y0, S.CELL = -0.76, 0.84, 0.08

local seq = ""
local st = nil          -- the game (nil until opened)
local hi = nil          -- best score (kept in Saved Games\DCS\Vitezovi-MFD-Addon\snake.txt)
local H = nil           -- parameter handles

local function P(n)
	local h = get_param_handle(n)
	local last = nil
	return {set = function(_, v) if v ~= last then last = v; h:set(v) end end}
end
local function handles()
	if H then return H end
	H = {x = {}, y = {}, v = {},
	     hx = P("DLP_SNK_HX"), hy = P("DLP_SNK_HY"), hv = P("DLP_SNK_HV"),
	     fx = P("DLP_SNK_FX"), fy = P("DLP_SNK_FY"), fv = P("DLP_SNK_FV"),
	     score = P("DLP_SNK_SCORE"), hi = P("DLP_SNK_HI"), len = P("DLP_SNK_LEN"),
	     ban = P("DLP_SNK_BAN"), b1 = P("DLP_SNK_B1"), b2 = P("DLP_SNK_B2")}
	for i = 1, S.MAX do
		H.x[i] = P("DLP_SNK_X" .. i); H.y[i] = P("DLP_SNK_Y" .. i); H.v[i] = P("DLP_SNK_V" .. i)
	end
	return H
end

-- the best score: a small text file next to settings.lua (best effort)
local function hi_file()
	local ok, lfs_mod = pcall(require, "lfs")
	if not ok or type(lfs_mod) ~= "table" or not lfs_mod.writedir then return nil end
	local okw, wd = pcall(lfs_mod.writedir)
	return okw and wd and (wd .. "Vitezovi-MFD-Addon/snake.txt") or nil
end
local function load_hi()
	if hi then return hi end
	hi = 0
	pcall(function()
		local f = io.open(hi_file(), "r")
		if f then local v = tonumber(f:read("*l") or ""); f:close(); if v and v >= 0 and v < 100000 then hi = math.floor(v) end end
	end)
	return hi
end
local function save_hi()
	pcall(function()
		local ok, lfs_mod = pcall(require, "lfs")
		if ok and type(lfs_mod) == "table" and lfs_mod.mkdir and lfs_mod.writedir then pcall(lfs_mod.mkdir, lfs_mod.writedir() .. "Vitezovi-MFD-Addon") end
		local f = io.open(hi_file(), "w")
		if f then f:write(string.format("%d\n", hi)); f:close() end
	end)
end

-- page units of a cell's centre
local function px(c) return S.X0 + (c + 0.5) * S.CELL end
local function py(r) return S.Y0 - (r + 0.5) * S.CELL end

-- a digit typed on the UFCP keypad; true = the code is complete
function S.digit(d)
	seq = (seq .. d):sub(-#S.CODE)
	if seq == S.CODE then seq = ""; return true end
	return false
end
function S.forget() seq = "" end

local function place_food()
	local free = {}
	for c = 0, S.COLS - 1 do
		for r = 0, S.ROWS - 1 do
			if not st.occ[c * 100 + r] then free[#free + 1] = {c, r} end
		end
	end
	if #free == 0 then st.food = nil; return end
	st.food = free[math.random(#free)]
end

-- a new game (shown as READY until a direction, 5 or ENT)
function S.new(now)
	local h = handles()
	load_hi()
	for i = 1, S.MAX do h.v[i]:set(0) end
	local r = math.floor(S.ROWS / 2)
	st = {slots = {}, head = 0, len = 0, occ = {}, dir = {1, 0}, nxt = {1, 0},
	      score = 0, step = 0.16, t_next = (now or 0), over = false, ready = true, paused = false, won = false}
	-- 4 segments, tail first
	for c = 3, 6 do
		st.head = st.head % S.MAX + 1
		st.slots[st.head] = {c, r}
		st.len = st.len + 1
		st.occ[c * 100 + r] = (st.occ[c * 100 + r] or 0) + 1
		h.x[st.head]:set(px(c)); h.y[st.head]:set(py(r)); h.v[st.head]:set(1)
	end
	place_food()
end

local function tail_slot() return (st.head - st.len) % S.MAX + 1 end

local function finish(won)
	st.over, st.won = true, won
	if st.score > load_hi() then hi = st.score; save_hi() end
end

local function advance()
	st.dir = st.nxt
	local cur = st.slots[st.head]
	local c, r = cur[1] + st.dir[1], cur[2] + st.dir[2]
	if c < 0 or r < 0 or c >= S.COLS or r >= S.ROWS then finish(false); return end
	local eat = st.food and st.food[1] == c and st.food[2] == r
	local h = handles()
	if not eat then
		-- the tail moves away first (the head may take its cell)
		local t = tail_slot()
		local tc = st.slots[t]
		local k = tc[1] * 100 + tc[2]
		st.occ[k] = (st.occ[k] or 1) - 1
		if st.occ[k] <= 0 then st.occ[k] = nil end
		h.v[t]:set(0)
		st.len = st.len - 1
	end
	if st.occ[c * 100 + r] then finish(false); return end
	st.head = st.head % S.MAX + 1
	st.slots[st.head] = {c, r}
	st.len = st.len + 1
	st.occ[c * 100 + r] = 1
	h.x[st.head]:set(px(c)); h.y[st.head]:set(py(r)); h.v[st.head]:set(1)
	if eat then
		st.score = st.score + 1
		st.step = math.max(0.075, st.step - 0.004)
		if st.len >= S.MAX then finish(true); return end
		place_food()
	end
end

-- a button on the snake page; returns what to do with the page:
-- "back" (to where it was opened), "menu", or nil (stay)
function S.key(b, now)
	if not st then S.new(now) end
	if b == "CLR" then return "back" end
	if b == "M8" then return "menu" end
	if st.over then
		if b == "ENT" or b == "K5" then S.new(now) end
		return nil
	end
	local d = ({K2 = {0, -1}, K8 = {0, 1}, K4 = {-1, 0}, K6 = {1, 0}})[b]
	if st.ready then
		if d or b == "ENT" or b == "K5" then st.ready, st.paused, st.t_next = false, false, (now or 0) + st.step end
		if not d then return nil end
	elseif b == "K5" or (b == "ENT" and st.paused) then
		st.paused = not st.paused
		st.t_next = (now or 0) + st.step
		return nil
	end
	if d and not (d[1] == -st.dir[1] and d[2] == -st.dir[2]) then st.nxt = d end
	return nil
end

-- every cockpit update while the page is shown
function S.update(now)
	if not st then S.new(now) end
	now = now or 0
	if not (st.over or st.ready or st.paused) then
		-- a long gap (pause menu, power) does not fast-forward the snake
		if now - st.t_next > 1.0 then st.t_next = now end
		local n = 0
		while now >= st.t_next and not st.over and n < 4 do
			advance()
			st.t_next = st.t_next + st.step
			n = n + 1
		end
	end
	local h = handles()
	local hd = st.slots[st.head]
	h.hx:set(px(hd[1])); h.hy:set(py(hd[2])); h.hv:set(1)
	if st.food then h.fx:set(px(st.food[1])); h.fy:set(py(st.food[2])); h.fv:set(1) else h.fv:set(0) end
	h.score:set(string.format("SCORE %03d", st.score))
	h.hi:set(string.format("HI %03d", math.max(load_hi(), st.score)))
	h.len:set(string.format("LEN %d / %d", st.len, S.MAX))
	if st.ready then
		h.ban:set(1); h.b1:set("READY"); h.b2:set("2 4 6 8 OR ENT TO START")
	elseif st.over then
		h.ban:set(st.won and 1 or 2); h.b1:set(st.won and "MAX LENGTH" or "SPLASH ONE"); h.b2:set(string.format("SCORE %d   ENT AGAIN", st.score))
	elseif st.paused then
		h.ban:set(3); h.b1:set("PAUSED"); h.b2:set("5 TO GO ON")
	else
		h.ban:set(0)
	end
end

-- for tests
function S.state() return st end
