-----------------------------------------------------------------------
-- MiG-29 DL page: geo drawings (threat rings, FLOT, borders, areas)
--
-- Read from an optional sidecar file next to a cartridge:
--     Saved Games\DCS\DTC\<cartridge>.geo.txt
-- written by the Vitezovi DTC Planner (DRAWINGS tab) or by hand.
-- A cartridge works the same without one.
--
-- One drawing per line, "#" starts a comment, coordinates in decimal
-- degrees (lat lon), radius in km:
--   RING    <name> <radius km> <lat> <lon>        confirmed threat, red
--   RING?   <name> <radius km> <lat> <lon>        suspected threat, pink dashed
--   FLOT    <name> <lat lon> / <lat lon> / ...    cyan dashed line
--   BORDER  <name> <lat lon> / <lat lon> / ...    grey dash-dot-dot line
--   AREA    <name> <lat lon> / <lat lon> / ...    cyan dashed, closed
-- The name is every word before the first number (may be empty).
-- v1.7.2: a number is written like  12  -3.5  .25  +40.1250  (optional
-- sign, digits, optional decimal point; no exponent, no hex, no INF / NAN).
-- The DTC Planner uses the same rule, so both read a file the same way.
-- Latitude -90..90, longitude -180..180, radius above 0 (decimals are fine,
-- e.g. 0.5) up to 10000 km; a line breaking a rule is skipped (and logged).
--
-- These are planning drawings only: the threats seen over the datalink
-- (export script) are drawn separately and are not affected by the
-- SA page GEO button (right 1), which shows / hides only these.
-----------------------------------------------------------------------

DL_GEO = {on = true, shapes = nil, name = nil, n = 0}

local CFG = DL_CFG or {}
-- pools of line pieces per colour (must match dl_page.lua: both read DL_GEO_POOLS)
DL_GEO_POOLS = DL_GEO_POOLS or {r = 72, p = 56, c = 150, g = 110}
DL_GEO_LABELS = DL_GEO_LABELS or 12

local STYLES = {
	["RING"]   = {pool = "r", ring = true, col = 1},
	["RING?"]  = {pool = "p", ring = true, col = 2, dash = {0.045, 0.032}},
	["FLOT"]   = {pool = "c", col = 3, dash = {0.07, 0.045}},
	["BORDER"] = {pool = "g", col = 4, dash = {0.085, 0.026, 0.012, 0.026, 0.012, 0.026}},
	["AREA"]   = {pool = "c", col = 3, closed = true, dash = {0.05, 0.04}},
}
DL_GEO.STYLES = STYLES

-- v1.7.2: the one number rule (see the top). Lua's tonumber() also takes
-- "INF", "NAN", "0x10" and "1e999", which the planner does not, and an
-- infinite radius locked the draw loop up.
local function num(s)
	s = s:gsub("/", "")
	if not s:find("^[-+]?%d*%.?%d+$") then return nil end
	return tonumber(s)
end
DL_GEO.num = num
local function lat_lon_ok(la, lo) return la >= -90 and la <= 90 and lo >= -180 and lo <= 180 end

-- parse the text of a .geo.txt; returns list of {kw, name, r_km, pts = {{lat, lon}, ...}}, bad line numbers
function DL_GEO.parse(txt)
	local out, bad, ln = {}, {}, 0
	txt = txt:gsub("^\239\187\191", "")          -- UTF-8 BOM (Notepad)
	for raw in (txt .. "\n"):gmatch("([^\n]*)\n") do
		ln = ln + 1
		local line = raw:gsub("\r", ""):gsub("#.*$", "")
		local tok = {}
		for w in line:gmatch("%S+") do if w ~= "/" then tok[#tok + 1] = w end end
		if #tok > 0 then
			local kw = tok[1]:upper()
			local st = STYLES[kw]
			if not st then bad[#bad + 1] = ln
			else
				local k, name = 2, {}
				while tok[k] and not num(tok[k]) do name[#name + 1] = tok[k]; k = k + 1 end
				local nums, okn = {}, true
				for j = k, #tok do
					local v = num(tok[j])
					if v then nums[#nums + 1] = v elseif tok[j]:gsub("/", "") ~= "" then okn = false end
				end
				local nm = table.concat(name, " ")
				if not okn then bad[#bad + 1] = ln
				elseif st.ring then
					if #nums == 3 and nums[1] > 0 and nums[1] <= 10000 and lat_lon_ok(nums[2], nums[3]) then
						out[#out + 1] = {kw = kw, name = nm, r_km = nums[1], pts = {{nums[2], nums[3]}}}
					else bad[#bad + 1] = ln end
				else
					local pts = {}
					if #nums >= 4 and #nums % 2 == 0 then
						for j = 1, #nums - 1, 2 do
							if lat_lon_ok(nums[j], nums[j + 1]) then pts[#pts + 1] = {nums[j], nums[j + 1]} else pts = nil; break end
						end
					else pts = nil end
					if pts then out[#out + 1] = {kw = kw, name = nm, pts = pts} else bad[#bad + 1] = ln end
				end
			end
		end
	end
	return out, bad
end

local function fin(v) return type(v) == "number" and v == v and v > -math.huge and v < math.huge end
local HUGE = math.huge

-- printable ASCII for the labels (the MFD font has nothing else): the
-- page module's transliteration (accented letters -> plain ones) when it
-- is there, else "?"; and never a number-like text (DCS would store it as a
-- number and the "%s" text format then crashes)
local function ascii_txt(s)
	s = tostring(s or "")
	if DL_PAGES and DL_PAGES.ascii then return DL_PAGES.ascii(s) end
	return (s:gsub("[\192-\255][\128-\191]*", "?"):gsub("[^\10\32-\126]", "?"))
end
local function label_txt(s)
	s = ascii_txt(s)
	if s == "" then return " " end
	if tonumber(s) then s = s .. " -" end
	return s
end
DL_GEO.label_txt = label_txt

-- shapes in DCS map metres (x = north, z = east)
local function to_world(list)
	local ok, terr = pcall(require, "terrain")
	if not ok or type(terr) ~= "table" or not terr.convertLatLonToMeters then return nil end
	local res = {}
	for _, s in ipairs(list) do
		local w = {kw = s.kw, st = STYLES[s.kw], name = ascii_txt(s.name), r = s.r_km and s.r_km * 1000 or nil, x = {}, z = {}}
		local good = true
		for j, p in ipairs(s.pts) do
			local ok2, x, z = pcall(terr.convertLatLonToMeters, p[1], p[2])
			if ok2 and fin(x) and fin(z) then w.x[j], w.z[j] = x, z else good = false end
		end
		if good then res[#res + 1] = w end
	end
	return res
end

-- the sidecar's size and modification time (nil = no file / no lfs)
local function stamp(lfs_mod, path)
	if not (lfs_mod and lfs_mod.attributes) then return nil end
	local ok, a = pcall(lfs_mod.attributes, path)
	if not ok or type(a) ~= "table" then return nil end
	return tostring(a.size) .. ":" .. tostring(a.modification)
end
local function clock()
	local ok, t = pcall(get_model_time)
	if ok and type(t) == "number" then return t end
	return os.clock()
end

-- load the sidecar for a cartridge name (nil / "" = none). Cached by name;
-- v1.7.2: also read again when the file changed (size / modification
-- time, looked at every 2 s) or after DL_GEO.reload() (a cartridge LOAD):
-- v1.7.1 kept an edited .geo.txt until the end of the mission.
function DL_GEO.load(name)
	local ok_lfs, lfs_mod = pcall(require, "lfs")
	if not ok_lfs or type(lfs_mod) ~= "table" then lfs_mod = nil end
	local path = (lfs_mod and name and name ~= "") and (lfs_mod.writedir() .. "DTC/" .. name .. ".geo.txt") or nil
	if name == DL_GEO.name and not DL_GEO.stale then
		local t = clock()
		if not path or (DL_GEO.chk_t and t >= DL_GEO.chk_t and t - DL_GEO.chk_t < 2) then return DL_GEO.shapes end
		DL_GEO.chk_t = t
		if stamp(lfs_mod, path) == DL_GEO.stamp then return DL_GEO.shapes end
	end
	local same = (name == DL_GEO.name)
	DL_GEO.name, DL_GEO.shapes, DL_GEO.n, DL_GEO.stale = name, nil, 0, nil
	DL_GEO.chk_t, DL_GEO.stamp = clock(), nil
	if not same then DL_GEO.on = true end          -- GEO shown again for a new cartridge (kept on a re-read)
	if not path then return nil end
	DL_GEO.stamp = stamp(lfs_mod, path)
	local fh = io.open(path, "r")
	if not fh then return nil end
	local txt = fh:read("*a"); fh:close()
	local list, bad = DL_GEO.parse(txt or "")
	DL_GEO.shapes = to_world(list)
	DL_GEO.n = DL_GEO.shapes and #DL_GEO.shapes or 0
	if DL_dbg then
		DL_dbg("device", "geo: " .. name .. ".geo.txt " .. DL_GEO.n .. " drawings" ..
			(#bad > 0 and (", skipped lines " .. table.concat(bad, " ")) or ""))
	end
	return DL_GEO.shapes
end
-- read the sidecar again on the next DL_GEO.load (the cartridge was loaded)
function DL_GEO.reload() DL_GEO.stale = true end

-----------------------------------------------------------------------
-- drawing: pieces of line written into the pools (screen units relative
-- to the ownship frame dl_own), clipped to the scope area
-----------------------------------------------------------------------
local HC = {}
local function P(n)
	local h = HC[n]
	if not h then h = {h = get_param_handle(n), v = nil}; HC[n] = h end
	return h
end
local function set(n, v)
	local h = P(n)
	if h.v ~= v then h.v = v; h.h:set(v) end
end

local used = {}          -- pieces used this frame per pool
local last_used = {}     -- pieces used last frame (to hide the rest)
local nlbl, last_lbl = 0, 0
local CLIP = {x0 = -0.86, x1 = 0.86, y0 = -1.15, y1 = 0.82}

local function piece(pool, x1, y1, x2, y2)
	local i = (used[pool] or 0) + 1
	if i > DL_GEO_POOLS[pool] then return end
	used[pool] = i
	local pre = "DL_GEO_" .. pool .. i .. "_"
	set(pre .. "X1", x1); set(pre .. "Y1", y1); set(pre .. "X2", x2); set(pre .. "Y2", y2)
	set(pre .. "V", 1)
end

-- Liang-Barsky clip of a segment to CLIP (y in ownship frame, shifted by oy)
local function clip(x1, y1, x2, y2, oy)
	local yl, yh = CLIP.y0 - oy, CLIP.y1 - oy
	local dx, dy = x2 - x1, y2 - y1
	local t0, t1 = 0, 1
	local p = {-dx, dx, -dy, dy}
	local q = {x1 - CLIP.x0, CLIP.x1 - x1, y1 - yl, yh - y1}
	for i = 1, 4 do
		if p[i] == 0 then
			if q[i] < 0 then return nil end
		else
			local r = q[i] / p[i]
			if p[i] < 0 then if r > t1 then return nil elseif r > t0 then t0 = r end
			else if r < t0 then return nil elseif r < t1 then t1 = r end end
		end
	end
	return t0, t1
end

-- a polyline in screen units with a dash pattern running on along it
-- returns the visible length and the point halfway along it (label spot)
local function polyline(st, xs, ys, oy)
	local pat = st.dash
	local pi, prem, on = 1, pat and pat[1] or 0, true       -- pattern index, rest of it, drawing?
	local vis = {}
	for j = 1, #xs - 1 do
		local ax, ay, bx, by = xs[j], ys[j], xs[j + 1], ys[j + 1]
		local L = math.sqrt((bx - ax) ^ 2 + (by - ay) ^ 2)
		local t0, t1 = clip(ax, ay, bx, by, oy)
		-- (an edge that is not a real length is skipped: walking a dash
		-- pattern along an infinite one never ends)
		if L > 0 and L < HUGE then
			if t0 and t1 > t0 then vis[#vis + 1] = {ax + (bx - ax) * t0, ay + (by - ay) * t0, ax + (bx - ax) * t1, ay + (by - ay) * t1} end
			if not pat then
				if t0 and t1 > t0 then piece(st.pool, ax + (bx - ax) * t0, ay + (by - ay) * t0, ax + (bx - ax) * t1, ay + (by - ay) * t1) end
			else
				-- walk the dash pattern along this edge, only over its visible part
				-- (whole pattern periods before it are skipped, the phase after
				-- it is carried on to the next edge)
				local per = 0
				for _, d in ipairs(pat) do per = per + d end
				local s = 0
				local stop = t0 and t1 * L or 0
				if t0 and t0 * L - prem > per then
					-- finish the current piece, then whole periods (same phase)
					s = prem
					pi = pi % #pat + 1; prem = pat[pi]; on = (pi % 2 == 1)
					s = s + math.floor((t0 * L - s) / per) * per
				end
				while s < stop do
					local e = math.min(L, s + prem)
					if e <= s then break end                 -- no progress (huge coordinates): stop
					if on then
						local a, b = math.max(s / L, t0), math.min(e / L, t1)
						if b > a then piece(st.pool, ax + (bx - ax) * a, ay + (by - ay) * a, ax + (bx - ax) * b, ay + (by - ay) * b) end
					end
					prem = prem - (e - s)
					s = e
					if prem <= 1e-9 then pi = pi % #pat + 1; prem = pat[pi]; on = (pi % 2 == 1) end
				end
				-- the rest of the edge: advance the pattern by its length
				local rest = (L - s) % per
				if L - s > 0 then
					while rest > 1e-9 do
						local d = math.min(rest, prem)
						prem = prem - d; rest = rest - d
						if prem <= 1e-9 then pi = pi % #pat + 1; prem = pat[pi]; on = (pi % 2 == 1) end
					end
				end
			end
		end
	end
	-- label spot: half way along the visible part
	local tot = 0
	for _, v in ipairs(vis) do v.l = math.sqrt((v[3] - v[1]) ^ 2 + (v[4] - v[2]) ^ 2); tot = tot + v.l end
	if tot <= 0 then return 0 end
	local h = tot / 2
	for _, v in ipairs(vis) do
		if h <= v.l then local f = (v.l > 0) and h / v.l or 0; return tot, v[1] + (v[3] - v[1]) * f, v[2] + (v[4] - v[2]) * f end
		h = h - v.l
	end
	return tot
end

local function label(x, y, txt, col, oy)
	if x < CLIP.x0 or x > CLIP.x1 or y + oy < CLIP.y0 or y + oy > CLIP.y1 then return end
	if nlbl >= DL_GEO_LABELS then return end
	nlbl = nlbl + 1
	local pre = "DL_GEO_L" .. nlbl .. "_"
	set(pre .. "X", x); set(pre .. "Y", y); set(pre .. "T", label_txt(txt)); set(pre .. "C", col)
end

local function finish()
	for pool, n in pairs(DL_GEO_POOLS) do
		local u = used[pool] or 0
		for i = u + 1, (last_used[pool] or n) do set("DL_GEO_" .. pool .. i .. "_V", 0) end
		last_used[pool] = u
	end
	for i = nlbl + 1, math.max(last_lbl, nlbl) do set("DL_GEO_L" .. i .. "_C", 0) end
	last_lbl = nlbl
end

-- right 1 label: 0 none (no drawings), 1 GEO shown, 2 GEO hidden
local function btn_label()
	set("DL_GEO_BTN", (DL_GEO.n > 0) and (DL_GEO.on and 1 or 2) or 0)
end

function DL_GEO.hide()
	used, nlbl = {}, 0
	finish()
	btn_label()
end

function DL_GEO.toggle()
	if DL_GEO.n > 0 then DL_GEO.on = not DL_GEO.on end
	btn_label()
end

-- the optional DL_CFG.geo_clip: 4 numbers {x min, x max, y min, y max},
-- else it is ignored (logged once)
local function clip_cfg()
	local c = CFG.geo_clip
	if c == nil then return nil end
	local good = type(c) == "table"
	if good then for i = 1, 4 do if not fin(c[i]) then good = false end end end
	if good and (c[1] >= c[2] or c[3] >= c[4]) then good = false end
	if good then return c end
	if not DL_GEO.clip_logged then
		DL_GEO.clip_logged = true
		if DL_dbg then pcall(DL_dbg, "device", "geo_clip ignored: it needs 4 numbers {x min, x max, y min, y max}") end
	end
	return nil
end

local draw_body
-- v = {cx, cz (view centre, metres), ch, sh (heading cos / sin), k (units per metre),
--      oy (ownship frame y on the page), sym (declutter level), unit_m, unit_lbl}
-- v1.7.2: dl_device's update() calls this without a pcall, so an error here
-- would stop the whole SA page every frame: the body runs protected; on an
-- error the drawings are hidden for that frame (logged once)
function DL_GEO.draw(v)
	local ok, err = pcall(draw_body, v)
	if ok then return end
	if not DL_GEO.err_logged then
		DL_GEO.err_logged = true
		if DL_dbg then pcall(DL_dbg, "device", "geo draw error: " .. tostring(err)) end
	end
	-- hide every piece and label, also those set before the error
	last_used, last_lbl = {}, DL_GEO_LABELS or 12
	pcall(DL_GEO.hide)
end
draw_body = function(v)
	used, nlbl = {}, 0
	btn_label()
	local shapes = DL_GEO.shapes
	if not shapes or not DL_GEO.on or (v.sym or 1) >= 5 then finish(); return end
	local c = clip_cfg()
	if c then CLIP.x0, CLIP.x1, CLIP.y0, CLIP.y1 = c[1], c[2], c[3], c[4] end
	local ch, sh, k, oy = v.ch, v.sh, v.k, v.oy
	local labels = (v.sym or 1) < 4
	local NS = CFG.geo_ring_segments or 40
	for _, s in ipairs(shapes) do
		local st = s.st
		if st.ring then
			local dE, dN = s.z[1] - v.cz, s.x[1] - v.cx
			local cx, cy = (dE * ch - dN * sh) * k, (dE * sh + dN * ch) * k
			local rs = s.r * k
			-- skip rings entirely off the scope
			if cx + rs > CLIP.x0 and cx - rs < CLIP.x1 and cy + rs > CLIP.y0 - oy and cy - rs < CLIP.y1 - oy then
				local xs, ys = {}, {}
				for j = 0, NS do
					local a = 2 * math.pi * j / NS
					xs[j + 1], ys[j + 1] = cx + rs * math.cos(a), cy + rs * math.sin(a)
				end
				polyline(st, xs, ys, oy)
				-- centre cross
				local q = 0.016
				if clip(cx - q, cy, cx + q, cy, oy) then
					piece(st.pool, cx - q, cy, cx + q, cy); piece(st.pool, cx, cy - q, cx, cy + q)
				end
				if labels then
					-- small rings with one decimal (0.5KM), else whole units (75KM)
					local rv = s.r / (v.unit_m or 1000)
					local r_txt = (rv < 9.95 and (rv < 0.95 or math.abs(rv - math.floor(rv + 0.5)) >= 0.05)) and string.format("%.1f%s", rv, v.unit_lbl or "KM")
						or string.format("%d%s", math.floor(rv + 0.5), v.unit_lbl or "KM")
					local nm = (s.name ~= "" and s.name ~= s.kw) and (s.name .. "\n" .. r_txt) or r_txt
					label(cx + 0.03, cy + ((nm:find("\n")) and 0.12 or 0.045), nm, st.col, oy)
				end
			end
		else
			local xs, ys = {}, {}
			local n = #s.x
			for j = 1, n do
				local dE, dN = s.z[j] - v.cz, s.x[j] - v.cx
				xs[j], ys[j] = (dE * ch - dN * sh) * k, (dE * sh + dN * ch) * k
			end
			if st.closed and n > 2 then xs[n + 1], ys[n + 1] = xs[1], ys[1] end
			local tot, lx, ly = polyline(st, xs, ys, oy)
			if labels and tot > 0.05 and lx and s.name ~= "" then
				-- an area's name in its middle when that is on the scope
				if st.closed then
					local mx, my = 0, 0
					for j = 1, n do mx, my = mx + xs[j], my + ys[j] end
					mx, my = mx / n, my / n
					if mx > CLIP.x0 and mx < CLIP.x1 and my + oy > CLIP.y0 and my + oy < CLIP.y1 then lx, ly = mx, my end
					label(lx, ly, s.name, st.col, oy)
				else
					label(lx, ly + 0.035, s.name, st.col, oy)
				end
			end
		end
	end
	finish()
end
