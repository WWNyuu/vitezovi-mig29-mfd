-----------------------------------------------------------------------
-- MiG-29 DL add-on (v1.7): display power and the start-up sequence
--
-- The MFD runs on the jet's DC power and has its own POWER button (the
-- top-left bezel rocker, command 1127: press = on; hold, then release =
-- off).
--
--   OFF      dark. Power + a press of POWER -> BOOT.
--   BOOT     screen test (white flash, test grid), boot ROM, software
--            boot log, squadron badge, built-in test checklist, then the
--            cartridge choice. Ends on the MENU page.
--   ON       normal pages.
-- A power gap shorter than power_blink_s keeps everything (the screen is
-- only dark meanwhile). A longer one switches the display off; with the
-- POWER switch still on it boots again from the start when power returns
-- (v1.7.2: if a plan was in use before the cut, the boot ends on the page
-- that was shown, with the plan, typed-in points, route and steerpoint
-- kept, instead of on the cartridge choice).
-- Hot / air start (power within boot_spawn_s of spawning): straight ON.
--
-- Cockpit parameter DL_BOOT (read by dl_boot_page.lua):
--   0 normal pages   1 dark   2 white flash   3 test grid   4 boot ROM
--   5 software boot  6 badge  7 BIT           8 cartridge choice
-- Used by dl_device.lua (DL_BOOT.tick from update, DL_BOOT.command from
-- SetCommand). Everything else in here is private.
-----------------------------------------------------------------------

DL_BOOT = {state = nil, sw = false}

local CFG = DL_CFG or {}
local B = DL_BOOT
local CMD_PWR = CFG.power_cmd or 1127
B.CMD_PWR = CMD_PWR
-- layout shared with dl_boot_page.lua (dl_config.lua)
local BC = DL_BOOT_CONST or {NROM = 14, NCON = 18, CON_COLS = 36, NCARD = 4, NRS = 40, NRP = 40, NGS = 60,
                             PV = {x0 = 0.12, x1 = 0.84, y0 = 0.30, y1 = 0.98}, PROG = 20, HOLD = 10}

-- text parameters: ASCII only, never "" and never number-like - DCS
-- stores a number-like string ("2024", also "2024." of v1.7.1) as a
-- number and the "%s" text format then crashes DCS (DL_text, dl_config)
local TXT = DL_text or function(v)
	if v == "" then return " " end
	if tonumber(v) then return v .. " -" end
	return v
end
local HC = {}
local function S(n, v)
	local h = HC[n]
	if not h then h = {h = get_param_handle(n), v = nil}; HC[n] = h end
	if h.v ~= v then
		h.v = v
		if type(v) == "string" then v = TXT(v) end
		h.h:set(v)
	end
end
local function dbg(m) if DL_dbg then DL_dbg("device", "boot: " .. m) end end

-----------------------------------------------------------------------
-- jet power: the BAT / GROUND switch (arg 510) and the cockpit voltmeter
-- (arg 308, 0..30 V). Once the meter has moved: volts >= power_min_volt
-- with the switch on, or generator volts (power_gen_volt) without it.
-- A meter that never moves: the switch alone.
-----------------------------------------------------------------------
local ARG_VOLT, ARG_BAT = CFG.power_volt_arg or 308, CFG.power_bat_arg or 510
local function arg(n)
	if not get_cockpit_draw_argument_value then return nil end
	local ok, v = pcall(get_cockpit_draw_argument_value, n)
	return ok and tonumber(v) or nil
end
B.volt_seen = false
local function jet_power()
	if CFG.power_mode == "always" then return true, 28 end
	local v = (arg(ARG_VOLT) or 0) * 30
	local bat = (arg(ARG_BAT) or 0) > 0.5
	if v > 9 then B.volt_seen = true end
	-- with BAT / GROUND off only a generator's voltage counts (in case the
	-- meter shows the battery itself)
	if B.volt_seen then return v >= (CFG.power_min_volt or 15) and (bat or v >= (CFG.power_gen_volt or 26.5)), v end
	return bat, v
end

-----------------------------------------------------------------------
-- the screens' contents
-----------------------------------------------------------------------
local NROM, NCON = BC.NROM, BC.NCON
B.NROM, B.NCON = NROM, NCON
local rom, con = {}, {}          -- lines {a = dim, b = white, w = white whole line, c = white after the clock}

local function clear_lines()
	for i = 1, NROM do rom[i] = nil end
	for i = 1, NCON do con[i] = nil end
end
local function put_lines()
	for i = 1, NROM do
		local l = rom[i] or {}
		-- the white part follows the dim part: same x, led by spaces (monospaced font)
		S("DL_BR_A" .. i, l.a or " "); S("DL_BR_W" .. i, l.w or " ")
		S("DL_BR_B" .. i, l.b and (string.rep(" ", #(l.a or "")) .. l.b) or " ")
	end
	for i = 1, NCON do
		local l = con[i] or {}
		S("DL_BC_A" .. i, l.a or " "); S("DL_BC_B" .. i, l.b or " "); S("DL_BC_W" .. i, l.w or " ")
		S("DL_BC_C" .. i, l.c and (string.rep(" ", #(l.a or "")) .. l.c) or " ")
	end
end

-- latitude / longitude of the jet, "N43 10.62  E041 00.18"
local function latlon(x, z, sep)
	local ok, terr = pcall(require, "terrain")
	if not ok or type(terr) ~= "table" or not terr.convertMetersToLatLon or not x then return "NO POSITION" end
	local ok2, la, lo = pcall(terr.convertMetersToLatLon, x, z)
	if not ok2 or not la then return "NO POSITION" end
	local function dm(v, w)
		v = math.abs(v)
		local d = math.floor(v)
		local m = (v - d) * 60
		if m >= 59.995 then d, m = d + 1, 0 end
		return string.format("%0" .. w .. "d %05.2f", d, m)
	end
	return (la >= 0 and "N" or "S") .. dm(la, 2) .. (sep or "  ") .. (lo >= 0 and "E" or "W") .. dm(lo, 3)
end

-- the boot ROM text (small, top left): {time, line, {a =, b =, w =}}
local ROM_SCRIPT = {
	{0.00, 1, {w = "MFD-1 BOOTROM V2.04  (C) 1991"}},
	{0.30, 2, {a = "HW REV C  S/N 29-0417"}},
	{0.55, 4, {a = "PANEL  ", b = "768X1024 OK"}},
	{0.70, 5, {a = "BKLT   ", b = "100%"}},
	{0.85, 6, {a = "CLK    ", b = "20.000 MHZ"}},
	{1.00, 7, {a = "RAM    ", b = "0000K"}},
	{1.07, 7, {a = "RAM    ", b = "0256K"}},
	{1.14, 7, {a = "RAM    ", b = "0768K"}},
	{1.21, 7, {a = "RAM    ", b = "1536K"}},
	{1.28, 7, {a = "RAM    ", b = "2304K"}},
	{1.35, 7, {a = "RAM    ", b = "3072K"}},
	{1.42, 7, {a = "RAM    ", b = "3840K"}},
	{1.49, 7, {a = "RAM    ", b = "4096K"}},
	{1.64, 7, {a = "RAM    ", b = "4096K OK"}},
	{1.82, 8, {a = "ROM    ", b = "0000-7FFF CRC 7F3A OK"}},
	{2.00, 9, {a = "NVRAM  ", b = "CONFIG OK"}},
	{2.25, 11, {a = "BOOT FROM FLASH ", b = "A"}},
	{2.60, 12, {w = "JUMP 4000:0000"}},
}
local ROM_END = 3.05

-- the software boot log: header, then checks ticking in with the boot clock
local CON_CHECKS = {
	{"CPU", "OK"}, {"MEMORY TEST", "4096K OK"}, {"ROM CHECKSUM", "7F3A OK"}, {"VIDEO", "768X1024 OK"},
	{"BUS MIL-STD-1553", "OK"}, {"ARINC 429", "OK"}, {"LINK UFCP", "UP"}, {"LINK DATALINK", "UP"},
	{"LINK RWR", "UP"}, {"LINK SMS", "UP"}, {"DTC SLOT", "CARD FOUND"},
}
local CON_CLOCK = {0.004, 0.011, 0.023, 0.048, 0.090, 0.011, 0.004, 0.023, 0.048, 0.011, 0.090}
local CON_PAUSE = {0.06, 0.09, 0.04, 0.06, 0.09, 0.04, 0.06, 0.04, 0.09, 0.06, 0.04}
local function dots(name, res, width)
	return name .. " " .. string.rep(".", math.max(2, width - #name - #res - 2)) .. " "
end
local CON = {}                    -- {t, row, line}
local CON_END
do
	local t, clk = 0.25, 0.0
	CON[#CON + 1] = {0.00, 1, {w = "VITEZOVI MFD-1  BOOT MONITOR  REV " .. tostring(DL_VERSION or "")}}
	CON[#CON + 1] = {0.10, 2, {a = "(C) 127 FAS  WILD WOLVES"}}
	for k, c in ipairs(CON_CHECKS) do
		clk = clk + CON_CLOCK[k]
		-- the clock is 9 columns, the result ends on column CON_COLS
		local pre = string.format("[%6.3f] ", clk) .. dots(c[1], c[2], BC.CON_COLS - 9)
		CON[#CON + 1] = {t, 3 + k, {a = pre}}
		t = t + CON_PAUSE[k]
		CON[#CON + 1] = {t, 3 + k, {a = pre, b = c[2]}}
		t = t + CON_PAUSE[(k % #CON_PAUSE) + 1] + 0.03
	end
	clk = clk + 0.06
	CON[#CON + 1] = {t, 16, {a = string.format("[%6.3f] ", clk), c = "LOADING MFD.SYS"}}
	B.CON_LOAD_T = t + 0.12
	CON_END = B.CON_LOAD_T + 0.75 + 0.40
end

-- BIT rows (names drawn by dl_boot_page.lua from DL_BIT_ROWS)
local NBIT = #(DL_BIT_ROWS or {})
local BIT_STEP, BIT_HOLD = 0.26, 0.9

-----------------------------------------------------------------------
-- timeline
-----------------------------------------------------------------------
-- stage, start, end (seconds since the boot started)
local T_FLASH, T_GRID, T_GAP1 = 0.0, 0.16, 1.06
local T_ROM = 1.21
local T_GAP2 = T_ROM + ROM_END
local T_CON = T_GAP2 + 0.20
local T_GAP3 = T_CON + CON_END
local T_BADGE = T_GAP3 + 0.25
local T_BIT = T_BADGE + (CFG.badge_s or 4.0)
local T_BIT_END = T_BIT + NBIT * BIT_STEP + BIT_HOLD
B.TIMES = {flash = T_FLASH, grid = T_GRID, rom = T_ROM, con = T_CON, badge = T_BADGE, bit = T_BIT, bit_end = T_BIT_END}

-- keep = after a power cut with a plan in use: no cartridge choice at the end
local function start_boot(t, keep)
	B.state, B.t0 = "boot", t
	B.dtc, B.bit = nil, nil
	B.keep_plan = keep or nil
	clear_lines()
	dbg("start" .. (keep and " (power back: the plan in use stays loaded)" or ""))
end
local function go_on(why)
	B.state = "on"
	B.was_on = true
	clear_lines(); put_lines()
	dbg("on (" .. why .. ")")
end
-- display off (POWER by hand, or a cut longer than power_blink_s). A
-- running intercept stops as with the INTC button: it must not come back
-- with the display.
local function go_off()
	B.state = "off"
	if DL_TAC and DL_TAC.intc_stop then pcall(DL_TAC.intc_stop) end
end

-- the info column of the BIT and its result: {status, info}; status 3 GO, 4 NO-GO
local function bit_results(C)
	local r = {}
	local v = B.volt or 0
	r[1] = {3, (v > 1) and string.format("%.1fV DC", v) or "DC BUS"}
	r[2] = {3, ""}
	r[3] = {3, ""}
	r[4] = {C.ox and 3 or 4, latlon(C.ox, C.oz, " ")}
	r[5] = {3, (CFG.opt_map == false) and "MAP OFF" or (C.chart_tiles and (C.chart_tiles .. " CHART TILES") or "NO CHARTS")}
	if CFG.opt_datalink == false then
		r[6] = {3, "OFF"}
	elseif C.dl_ok then
		r[6] = {3, string.format("%d TRACKS", C.ncontacts or 0)}
	else
		r[6] = {4, ""}
	end
	r[7] = {3, (CFG.opt_rwr == false) and "OFF" or "SPO-15"}
	r[8] = {3, C.nstations and string.format("%d STA", C.nstations) or ""}
	r[9] = {3, (C.binds == true) and "HOTAS BINDS" or (C.binds == false) and "NO HOTAS BINDS" or ""}   -- v1.7.4
	local nc = 0
	for _, o in ipairs(C.dtc_opts and C.dtc_opts() or {}) do if type(o) == "table" then nc = nc + 1 end end
	r[10] = {3, string.format("%d CARTRIDGES", nc)}
	r[11] = {C.be and 3 or 4, ""}
	return r
end

-----------------------------------------------------------------------
-- cartridge choice
-----------------------------------------------------------------------
local NCARD, NRS, NRP, NGS = BC.NCARD, BC.NRS, BC.NRP, BC.NGS
B.NCARD, B.NRS, B.NRP, B.NGS = NCARD, NRS, NRP, NGS
local PV = BC.PV   -- preview drawing area (page units, see dl_boot_page.lua)
B.PV = PV

local function geo_peek(name)
	local ok_lfs, lfs_mod = pcall(require, "lfs")
	if not ok_lfs or not lfs_mod or not DL_GEO or not DL_GEO.parse then return nil end
	local fh = io.open(lfs_mod.writedir() .. "DTC/" .. name .. ".geo.txt", "r")
	if not fh then return nil end
	local txt = fh:read("*a"); fh:close()
	local list = DL_GEO.parse(txt or "")
	local ok, terr = pcall(require, "terrain")
	if not ok or type(terr) ~= "table" or not terr.convertLatLonToMeters then return {n = #list, shapes = {}, list = list} end
	local shapes = {}
	for _, s in ipairs(list) do
		local w = {kw = s.kw, x = {}, z = {}, r = s.r_km and s.r_km * 1000}
		for j, p in ipairs(s.pts) do
			local ok2, x, z = pcall(terr.convertLatLonToMeters, p[1], p[2])
			if ok2 and x then w.x[j], w.z[j] = x, z end
		end
		if #w.x == #s.pts then shapes[#shapes + 1] = w end
	end
	return {n = #list, shapes = shapes, list = list}
end

local function geo_summary(g)
	if not g or g.n == 0 then return "NONE" end
	local c = {}
	for _, s in ipairs(g.list) do c[s.kw] = (c[s.kw] or 0) + 1 end
	local parts = {}
	local function add(k, one, many)
		local n = (k == "RING") and ((c.RING or 0) + (c["RING?"] or 0)) or (c[k] or 0)
		if n == 1 then parts[#parts + 1] = one elseif n > 1 then parts[#parts + 1] = n .. " " .. many end
	end
	add("FLOT", "FLOT", "FLOTS"); add("AREA", "1 AREA", "AREAS"); add("RING", "1 RING", "RINGS"); add("BORDER", "BORDER", "BORDERS")
	return table.concat(parts, " + ")
end

local function cart_info(o)
	if o.info then return o end
	local p = DL_PLAN.from_cartridge(o.name, o.data)     -- never throws (dl_plan.lua)
	o.plan = p
	o.members = DL_PLAN.members(p)
	-- the card's name: ASCII (the MFD font), upper case
	o.label = string.upper(DL_ascii and DL_ascii(o.name) or tostring(o.name))
	local okg, g = pcall(geo_peek, o.name)
	o.geo = okg and g or nil
	local nr, ch1 = 0, nil
	for k, f in pairs(p.radio or {}) do nr = nr + 1; if k == 1 then ch1 = f end end
	o.radio = nr; o.ch1 = ch1
	local s = string.format("%d PTS", p.nrt or 0)
	if #o.members > 0 then s = s .. string.format("  %d FLT", #o.members) end
	if o.geo and o.geo.n > 0 then s = s .. "  GEO" end
	o.info = s
	return o
end

local function dtc_open(C)
	local opts = C.dtc_opts and C.dtc_opts() or {}
	local list = {}
	for i, o in ipairs(opts) do
		if type(o) == "table" then list[#list + 1] = {name = o.name, data = o.data, opt_i = i} end
	end
	local sel = 1
	local cur = C.dtc_sel and C.dtc_sel()
	for k, o in ipairs(list) do if o.opt_i == cur then sel = k end end
	B.dtc = {list = list, sel = sel, top = 1, mem = 0, opts = opts}
	dbg(#list .. " cartridges for this map")
end

local function opt_index(opts, name)
	for i, o in ipairs(opts) do if o == name then return i end end
end

local function dtc_finish(C, how)
	local d = B.dtc
	if how == "LOAD" then
		local o = d.list[d.sel]
		if not o then return end
		C.dtc_load(o.opt_i)
		local m = o.members and o.members[d.mem]
		if m and C.dtc_route and o.plan then
			local sel = {}
			for i = 1, o.plan.nrt do
				local tg = o.plan.pts[i].tags
				if not tg or tg[m] then sel[#sel + 1] = i end
			end
			C.dtc_route(sel)
		end
		dbg("loaded " .. o.name .. (m and (" FLT " .. m) or ""))
	else
		local i = opt_index(d.opts, how == "MSN" and "MSN" or "OFF")
		if i then C.dtc_load(i) end
		dbg("cartridge choice: " .. how)
	end
	-- v1.7.2: a plan was loaded: read its drawings (.geo.txt) again, as the
	-- NAV page's LOAD does, so a file edited since is not shown from the cache
	if how ~= "NONE" and DL_GEO and DL_GEO.reload then pcall(DL_GEO.reload) end
	if DL_PAGES then DL_PAGES.mode = 0; DL_PAGES.dirty = true end
	go_on("cartridge " .. how)
end

local function draw_dtc(C)
	local d = B.dtc
	local n = #d.list
	S("DL_BD_ALIGN", "ALIGNED  " .. latlon(C.ox, C.oz))
	S("DL_BD_EMPTY", (n == 0) and 1 or 0)
	if d.sel < d.top then d.top = d.sel end
	if d.sel > d.top + NCARD - 1 then d.top = d.sel - NCARD + 1 end
	for k = 1, NCARD do
		local o = d.list[d.top + k - 1]
		if o then
			cart_info(o)
			S("DL_BD_N" .. k, o.label:sub(1, 19))
			S("DL_BD_I" .. k, o.info)
			S("DL_BD_V" .. k, (d.top + k - 1 == d.sel) and 2 or 1)
		else
			S("DL_BD_N" .. k, " "); S("DL_BD_I" .. k, " "); S("DL_BD_V" .. k, 0)
		end
	end
	local more = n - (d.top + NCARD - 1)
	S("DL_BD_MORE", (more > 0) and string.format("+%d MORE", more) or ((d.top > 1) and string.format("%d ABOVE", d.top - 1) or " "))
	local o = d.list[d.sel]
	-- preview: route (white), points (blue), drawings (pink), fitted into the box
	local nseg, npt, ngs = 0, 0, 0
	if o then
		local p = o.plan
		local xs, zs = {}, {}
		for i = 1, p.nrt do xs[#xs + 1] = p.pts[i].x; zs[#zs + 1] = p.pts[i].z end
		if #xs == 0 then for _, w in ipairs(p.wps) do xs[#xs + 1] = w.x; zs[#zs + 1] = w.z end end
		if #xs > 0 then
			local x0, x1, z0, z1 = math.huge, -math.huge, math.huge, -math.huge
			for i = 1, #xs do
				x0, x1 = math.min(x0, xs[i]), math.max(x1, xs[i]); z0, z1 = math.min(z0, zs[i]), math.max(z1, zs[i])
			end
			local w, h = PV.x1 - PV.x0 - 0.10, PV.y1 - PV.y0 - 0.10
			local k = math.min(w / math.max(z1 - z0, 1000), h / math.max(x1 - x0, 1000))
			local cx, cz = (x0 + x1) / 2, (z0 + z1) / 2
			local mx, my = (PV.x0 + PV.x1) / 2, (PV.y0 + PV.y1) / 2
			local function sp(x, z) return mx + (z - cz) * k, my + (x - cx) * k end
			local function inside(a, b) return a > PV.x0 + 0.01 and a < PV.x1 - 0.01 and b > PV.y0 + 0.01 and b < PV.y1 - 0.01 end
			-- the selected member's points (else all) joined in flying order
			local m = o.members[d.mem]
			local prev = nil
			for i = 1, p.nrt do
				local tg = p.pts[i].tags
				if not m or not tg or tg[m] then
					local a, b = sp(p.pts[i].x, p.pts[i].z)
					if prev and nseg < NRS then
						nseg = nseg + 1
						local q = "DL_BD_RS" .. nseg .. "_"
						S(q .. "X1", prev[1]); S(q .. "Y1", prev[2]); S(q .. "X2", a); S(q .. "Y2", b); S(q .. "V", 1)
					end
					prev = {a, b}
				end
			end
			for i = 1, #xs do
				if npt < NRP then
					local a, b = sp(xs[i], zs[i])
					npt = npt + 1
					S("DL_BD_RP" .. npt .. "_X", a); S("DL_BD_RP" .. npt .. "_Y", b); S("DL_BD_RP" .. npt .. "_V", 1)
				end
			end
			for _, s in ipairs((o.geo and o.geo.shapes) or {}) do
				local pts = {}
				if s.r then
					for j = 0, 16 do
						local an = j / 16 * 2 * math.pi
						pts[#pts + 1] = {sp(s.x[1] + s.r * math.cos(an), s.z[1] + s.r * math.sin(an))}
					end
				else
					for j = 1, #s.x do pts[#pts + 1] = {sp(s.x[j], s.z[j])} end
					if s.kw == "AREA" then pts[#pts + 1] = pts[1] end
				end
				for j = 2, #pts do
					local a, b = pts[j - 1], pts[j]
					if ngs < NGS and inside(a[1], a[2]) and inside(b[1], b[2]) then
						ngs = ngs + 1
						local q = "DL_BD_GS" .. ngs .. "_"
						S(q .. "X1", a[1]); S(q .. "Y1", a[2]); S(q .. "X2", b[1]); S(q .. "Y2", b[2]); S(q .. "V", 1)
					end
				end
			end
		end
		S("DL_BD_PN", o.label:sub(1, 17))
		local mem = (#o.members > 0) and ("FLT " .. table.concat(o.members, "-")) or "NO FLT TAGS"
		S("DL_BD_P1", mem)
		local names = {}
		for _, a in ipairs(p.ads) do if #names < 4 and a.name then names[#names + 1] = string.upper(DL_ascii and DL_ascii(a.name) or tostring(a.name)):sub(1, 3) end end
		S("DL_BD_P2", (#names > 0) and table.concat(names, " ") or " ")
		local mm = o.members[d.mem]
		S("DL_BD_D1", (#o.members > 0) and ("MEMBERS " .. table.concat(o.members, " ")) or "NO MEMBER TAGS")
		S("DL_BD_D2", string.format("%d PRESETS", o.radio) .. (o.ch1 and string.format("   CH1 %.3f", o.ch1 / ((o.ch1 > 1e5) and 1e6 or 1)) or ""))
		S("DL_BD_D3", string.format("%d WPT  %d A/D  %d RSBN", #p.wps, #p.ads, #(p.rsbn or {})))
		S("DL_BD_D4", geo_summary(o.geo))
		S("DL_BD_LOAD", 1)
	else
		for _, k in ipairs({"PN", "P1", "P2", "D1", "D2", "D3", "D4"}) do S("DL_BD_" .. k, " ") end
		S("DL_BD_LOAD", 0)
	end
	for i = nseg + 1, NRS do S("DL_BD_RS" .. i .. "_V", 0) end
	for i = npt + 1, NRP do S("DL_BD_RP" .. i .. "_V", 0) end
	for i = ngs + 1, NGS do S("DL_BD_GS" .. i .. "_V", 0) end
end

-----------------------------------------------------------------------
-- v1.7.2: one press / release tracker per command. What arrives depends on
-- the clickable (clickabledata.lua) and on the PC: a press comes as 1 (or
-- -1), on some PCs as 517.375 (518.375 ... the next time); a release as
-- 0.25 or 0, or as 517.25 on those PCs.
-- Commands whose clickable sends a release (releasing = true; the device's
-- list, see dl_device.lua RELEASING):
--   release  |value| < 0.5, or a value already learned as this command's
--            release, or (while a press is open) any other value than the
--            press had - that value is then learned as the release
--   repeat   the open press's value again within button_repeat_s of the
--            PRESS (not of the last message: a repeat must not stretch the
--            window), or any press within MIN_GAP_S of the last accepted one
--            (a click that arrives as two press / release pairs)
--   press    anything else; a press whose release never came is forgotten
--            after its expiry time, so the next press always works
-- Press-only commands (KRN's default_button: use_release_message false,
-- so nothing marks the end of a press and the press values may change from
-- click to click): every message with |value| >= 0.5 is a press, unless it
-- comes within button_bounce_s of the last accepted press of that command
-- (the same click, "repeat"); |value| < 0.5 is never a press ("release").
-- Returns "press" / "release" / "repeat", plus for a release the time of
-- the press it ends (nil: none was open), for a press whether an older
-- press was still open.
-----------------------------------------------------------------------
local TRK = {}            -- [command] = {pt = open press time, pv = its value, lt = last message, rv = release value, acc = last accepted press}
B.trk = TRK
local REPEAT_S, BOUNCE_S, MIN_GAP_S = CFG.button_repeat_s or 0.3, CFG.button_bounce_s or 0.15, 0.1
local function edge(command, value, t, expire, releasing)
	local v = tonumber(value) or 0
	local s = TRK[command]
	if not s then s = {}; TRK[command] = s end
	-- (a clock that went back - new mission - forgets the old times)
	if s.acc and t < s.acc then s.acc, s.pt = nil, nil end
	if not releasing then
		if math.abs(v) < 0.5 then return "release" end
		if s.acc and (t - s.acc) < BOUNCE_S then return "repeat" end
		s.acc = t
		return "press"
	end
	-- the release of the open press never came
	if s.pt and (t - s.lt > expire or t < s.lt) then s.pt = nil end
	local rel = math.abs(v) < 0.5 or v == s.rv
	if not rel and s.pt and v ~= s.pv then
		rel = true
		-- learn it (not a plain +-1: that is another press of a two-way control)
		if math.abs(math.abs(v) - 1) > 1e-6 then s.rv = v end
	end
	if rel then
		local pt = s.pt
		s.pt, s.lt = nil, t
		return "release", pt
	end
	s.lt = t
	if s.pt and (t - s.pt) < REPEAT_S then return "repeat" end
	if s.acc and (t - s.acc) < MIN_GAP_S then return "repeat" end
	local had = s.pt ~= nil
	s.pt, s.pv, s.acc = t, v, t
	return "press", had
end
B.edge = edge

-----------------------------------------------------------------------
-- per frame (called from the device's update before anything else).
-- Returns true while the normal pages are not to be updated.
-----------------------------------------------------------------------
local PWR_EXPIRE = CFG.power_press_expire_s or 10
local HOLD_S = CFG.power_hold_s or 2
function B.tick(C)
	local t = C.t
	local on, v = jet_power()
	B.volt = v
	if not B.t_first then
		B.t_first = t
		dbg(string.format("first frame: power %s (%.1f V, bat %s, mode %s)", tostring(on), v, tostring(arg(ARG_BAT)), tostring(CFG.power_mode)))
	end
	if on ~= B.last_on then
		dbg(string.format("jet power %s (%.1f V)", on and "ON" or "OFF", v))
		B.last_on = on
	end
	-- spawn: powered at once = hot / air start, else cold and dark
	if B.state == nil then
		if on then
			B.sw = true
			go_on("hot start")
		elseif (t - B.t_first) > (CFG.boot_spawn_s or 3) or CFG.power_mode == "always" then
			B.state = "off"
			dbg("cold start: display off")
		end
	end
	-- power gaps
	if on then
		if B.cut_t then
			if B.state == "off" and B.sw then
				-- a real cut: the whole start-up again. After a dip (engine start,
				-- shorter than power_keep_plan_s) the plan that was in use stays
				-- loaded; after a real shutdown (rearm: engines and battery off)
				-- the MFD restarts completely, with the cartridge choice.
				local keep = B.was_on and (t - B.cut_t) < (CFG.power_keep_plan_s or 30) and C.plan_in_use and C.plan_in_use()
				if CFG.boot_skip then go_on("power back, no boot") else start_boot(t, keep) end
			end
			B.cut_t = nil
		end
	elseif B.state ~= nil and B.state ~= "off" then
		B.cut_t = B.cut_t or t
		if (t - B.cut_t) > (CFG.power_blink_s or 1.5) then
			go_off()
			dbg("power lost: display off" .. (B.sw and " (switch stays on: boots again with power)" or ""))
		end
	elseif B.state == "off" then
		B.cut_t = B.cut_t or t
	end
	-- POWER held: the bar fills; once it is full (power_hold_s) the RELEASE
	-- switches the display off (B.command). v1.7.2: a timer alone never
	-- switches off - a press whose release message got lost used to turn
	-- the display off 2 s after a short click.
	local ps = TRK[CMD_PWR]
	if ps and ps.pt and (t - ps.lt > PWR_EXPIRE or t < ps.lt) then
		-- no release within power_press_expire_s: forget the press. With no
		-- release ever seen this PC sends none: no bar from now on
		ps.pt, B.press_on = nil, nil
		if not B.rel_seen then B.no_rel = true end
		B.nforget = (B.nforget or 0) + 1
		if B.nforget <= 5 then dbg("POWER press without a release: forgotten") end
	end
	local live = B.state ~= "off" and B.state ~= nil
	local held = (ps and ps.pt) and (t - ps.pt) or 0
	-- (shown until power_hold_s + 2 s: a lost release must not leave
	-- "RELEASE TO SWITCH OFF" up until the press expires)
	if live and ps and ps.pt and not B.press_on and not B.no_rel and held > 0.25 and held < HOLD_S + 2 then
		local full = held >= HOLD_S
		-- 1 .. HOLD-1 while held, HOLD (full) exactly when a release switches off
		S("DL_PWR_HOLD", full and BC.HOLD or math.max(1, math.min(BC.HOLD - 1, math.floor(held / HOLD_S * (BC.HOLD - 1)) + 1)))
		S("DL_PWR_TXT", full and "RELEASE TO SWITCH OFF" or "KEEP HOLDING POWER")
	else
		S("DL_PWR_HOLD", 0)
	end

	-- what the screen shows
	local stage = 0
	if B.state == nil or B.state == "off" or not on then
		stage = 1
	elseif B.state == "boot" then
		local e = t - B.t0
		if e < T_GRID then stage = 2
		elseif e < T_GAP1 then stage = 3
		elseif e < T_ROM then stage = 1
		elseif e < T_GAP2 then
			stage = 4
			local re = e - T_ROM
			for i = 1, NROM do rom[i] = nil end
			for _, s in ipairs(ROM_SCRIPT) do if re >= s[1] then rom[s[2]] = s[3] end end
			local last = 1
			for i = 1, NROM do if rom[i] then last = i end end
			S("DL_BR_CUR", (re > 2.6 and math.floor(re * 4) % 2 == 0) and (last + 1) or 0)
		elseif e < T_CON then stage = 1
		elseif e < T_GAP3 then
			stage = 5
			local ce = e - T_CON
			for i = 1, NCON do con[i] = nil end
			local last = 1
			for _, s in ipairs(CON) do if ce >= s[1] then con[s[2]] = s[3]; last = math.max(last, s[2]) end end
			if ce >= B.CON_LOAD_T then
				local f = math.min(1, (ce - B.CON_LOAD_T) / 0.75)
				local nb = math.floor(f * 24 + 0.5)
				con[17] = {w = "[" .. string.rep("#", nb) .. string.rep(".", 24 - nb) .. "]  " .. math.floor(f * 100 + 0.5) .. "%"}
				last = 17
			end
			S("DL_BC_CUR", (math.floor(ce * 4) % 2 == 0) and math.min(NCON, last + 1) or 0)
		elseif e < T_BADGE then stage = 1
		elseif e < T_BIT then
			stage = 6
			S("DL_BS_PROG", math.min(BC.PROG, math.floor((e - T_BADGE) / (T_BIT - T_BADGE - 0.3) * BC.PROG)))
		elseif e < T_BIT_END then
			stage = 7
			if not B.bit then B.bit = bit_results(C) end
			local be = e - T_BIT
			local go, ng = 0, 0
			for i = 1, NBIT do
				local st = 1
				local done = be >= i * BIT_STEP
				if done then st = B.bit[i][1]
				elseif be >= (i - 1) * BIT_STEP then st = 2 end
				if st == 3 then go = go + 1 elseif st == 4 then ng = ng + 1 end
				S("DL_BIT_S" .. i, st)
				S("DL_BIT_I" .. i, (st >= 3) and B.bit[i][2] or " ")
			end
			S("DL_BIT_SUM", string.format("%d / %d GO   %d NO-GO", go, NBIT, ng))
			S("DL_BIT_DONE", (go + ng == NBIT) and 1 or 0)
		else
			stage = 8
			if B.keep_plan then
				-- power back after a cut: the plan, typed-in points, route and
				-- steerpoint are still loaded (the device kept them) - back to
				-- the page that was shown, no cartridge choice
				B.keep_plan, B.bit = nil, nil
				if DL_PAGES then DL_PAGES.dirty = true end
				go_on("power back, plan kept")
			elseif not B.dtc then
				dtc_open(C)
				B.bit = nil
				if CFG.boot_skip_dtc then dtc_finish(C, "MSN") end
			end
			if B.state == "boot" then draw_dtc(C) end
		end
	end
	if stage == 4 or stage == 5 then put_lines() end
	if B.state == "on" and on then stage = 0 end
	S("DL_BOOT", stage)
	S("DL_BS_VER", "UPGRADE PROGRAM  V" .. tostring(DL_VERSION or ""))
	return stage ~= 0
end

-----------------------------------------------------------------------
-- buttons (called first in SetCommand). Returns true = handled here.
-----------------------------------------------------------------------
local BEZEL = {[1101] = "M1", [1102] = "M2", [1103] = "M3", [1104] = "M4", [1105] = "M5", [1108] = "M8",
               [1111] = "R1", [1112] = "R2", [1113] = "R3", [1114] = "R4", [1115] = "R5"}

-- POWER: press = on (with jet power); a release that comes power_hold_s
-- or more after its press = off. The press that switched the display on
-- never switches it off again, however long it is held.
local function power_cmd(value, t)
	local e, x = edge(CMD_PWR, value, t, PWR_EXPIRE, true)
	B.ndiag = (B.ndiag or 0) + 1
	if B.ndiag <= 20 then dbg(string.format("POWER command value %s (%s), state %s", tostring(value), e, tostring(B.state))) end
	if e == "release" then
		B.rel_seen, B.no_rel = true, nil
		local live = B.state ~= "off" and B.state ~= nil
		if x and not B.press_on and live and (t - x) >= HOLD_S then
			go_off()
			B.sw, B.cut_t = false, nil
			dbg(string.format("switched off (POWER held %.1f s)", t - x))
		end
		B.press_on = nil
		return true
	end
	if e == "repeat" then return true end
	-- a new press. The one before never got its release and none was
	-- ever seen: this PC sends no releases (then no hold bar either)
	if x and not B.rel_seen then B.no_rel = true end
	B.press_on = nil
	if B.state == "off" or B.state == nil then
		if jet_power() then
			B.sw, B.cut_t, B.press_on = true, nil, true
			if CFG.boot_skip then go_on("POWER, no boot") else start_boot(t) end
		else
			dbg("POWER pressed without jet power")
		end
	end
	return true
end

-- C.buttons = the commands with press / release tracking (the device's
-- bezel, keypad, STP and UFCP commands): [command] = "release" for those
-- whose clickable sends a release, "press" for press-only ones. Their
-- releases and repeats end here on every page; only a new press goes on.
function B.command(command, value, C, stp_cmds)
	local t = C.now()
	if command == CMD_PWR then return power_cmd(value, t) end
	local kind = C.buttons and C.buttons[command]
	if kind then
		if edge(command, value, t, CFG.button_expire_s or 5, kind == "release") ~= "press" then return true end
	end
	if B.state == "on" then return false end
	-- display off or starting: the bezel and keypad do nothing ...
	if stp_cmds and stp_cmds[command] then return false end
	local b = BEZEL[command]
	if B.state ~= "boot" or not b then return true end
	-- ... except SKIP on the BIT and the cartridge choice
	local e = C.now() - (B.t0 or 0)
	if e >= T_BIT and e < T_BIT_END - BIT_HOLD and b == "M8" then
		-- SKIP: the whole list at once, shown for a moment
		B.t0 = C.now() - (T_BIT_END - BIT_HOLD)
		return true
	end
	local d = B.dtc
	if not d then return true end
	local n = #d.list
	if b == "M2" and n > 0 then d.sel = (d.sel - 2) % n + 1; d.mem = 0
	elseif b == "M3" and n > 0 then d.sel = d.sel % n + 1; d.mem = 0
	elseif b == "M8" and n > 0 then dtc_finish(C, "LOAD")
	elseif b == "R1" then dtc_finish(C, "MSN")
	elseif b == "R5" then dtc_finish(C, "NONE")
	end
	return true
end
