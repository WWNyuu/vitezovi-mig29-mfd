-----------------------------------------------------------------------
-- MiG-29 DL add-on: menu line on the KRN UFCP display (under the HUD)
--
-- Loaded at the end of UFCP\base_page.lua (one pcall(dofile) line).
-- While the DTC menu is open (MFD-1 on the DL page) the top line of the
-- UFCP is covered and shows the cartridge being chosen, e.g. <CAUCASUS 2/4>.
-- Values come from DL/dl_device.lua: DL_UFCP_MENU (0/1), DL_UFCP_L1 (text).
-----------------------------------------------------------------------
do
	local Y1   = 62.5275          -- the UFCP's top line (same place as KRN's)
	local X0   = -45.031
	local DEFS = {-0.0087, 0.00865, 0.0003, 0}   -- KRN's UFCP text size

	local root = CreateElement "ceSimple"
	root.name           = "dl_ufcp_menu"
	root.init_pos       = {0, 0, 0}
	root.element_params = {"DL_UFCP_MENU", "UFCP_POWER"}
	root.controllers    = {{"parameter_in_range", 0, 0.5, 1.5}, {"parameter_in_range", 1, 0.5, 1.5}}
	Add(root)

	-- cover KRN's top line
	local mask = CreateElement "ceMeshPoly"
	mask.name           = "dl_ufcp_mask"
	mask.primitivetype  = "triangles"
	mask.vertices       = {{-48, Y1 + 11}, {49, Y1 + 11}, {49, Y1 - 11}, {-48, Y1 - 11}}
	mask.indices        = {0, 1, 2, 0, 2, 3}
	mask.material       = MakeMaterial(nil, (DL_CFG and DL_CFG.ufcp_mask_color) or {0, 0, 0, 255})
	mask.init_pos       = {0, 0, 0.4}
	mask.parent_element = root.name
	Add(mask)

	local txt = CreateElement "ceStringPoly"
	txt.name            = "dl_ufcp_l1"
	txt.material        = "PHONK_UFCP"
	txt.init_pos        = {X0, Y1, 0.5}
	txt.alignment       = "LeftCenter"
	txt.stringdefs      = DEFS
	txt.formats         = {"%s"}
	txt.element_params  = {"DL_UFCP_L1"}
	txt.controllers     = {{"text_using_parameter", 0}}
	txt.parent_element  = root.name
	Add(txt)
end

-- steerpoint lines while a cartridge is loaded (DL_UFCP_NAV = 1): KRN's
-- steerpoint line (bottom) and the distance on the line above it only know
-- the mission route, so they are covered with our own values.
do
	local DEFS = {-0.0087, 0.00865, 0.0003, 0}
	local YS, YD = -63, -32            -- KRN's BL_STP line and distance line
	local XL, XR = -45.031, 45.931
	local col = (DL_CFG and DL_CFG.ufcp_mask_color) or {0, 0, 0, 255}

	local root = CreateElement "ceSimple"
	root.name           = "dl_ufcp_nav"
	root.init_pos       = {0, 0, 0}
	root.element_params = {"DL_UFCP_NAV", "UFCP_POWER"}
	root.controllers    = {{"parameter_in_range", 0, 0.5, 1.5}, {"parameter_in_range", 1, 0.5, 1.5}}
	Add(root)

	local function mask(name, x0, x1, y)
		local m = CreateElement "ceMeshPoly"
		m.name           = name
		m.primitivetype  = "triangles"
		m.vertices       = {{x0, y + 11}, {x1, y + 11}, {x1, y - 11}, {x0, y - 11}}
		m.indices        = {0, 1, 2, 0, 2, 3}
		m.material       = MakeMaterial(nil, col)
		m.init_pos       = {0, 0, 0.4}
		m.parent_element = root.name
		Add(m)
	end
	mask("dl_ufcp_nav_m1", -48, 49, YS)     -- whole steerpoint line
	mask("dl_ufcp_nav_m2", -48, 49, YD)      -- whole line: bearing + distance

	local function text(name, x, y, align, fmt, param, ctrl)
		local t = CreateElement "ceStringPoly"
		t.name            = name
		t.material        = "PHONK_UFCP"
		t.init_pos        = {x, y, 0.5}
		t.alignment       = align
		t.stringdefs      = DEFS
		t.formats         = {fmt}
		t.element_params  = ctrl and {param, ctrl[1]} or {param}
		t.controllers     = ctrl and {{"text_using_parameter", 0}, {"parameter_in_range", 1, ctrl[2] - 0.5, ctrl[2] + 0.5}}
		                         or {{"text_using_parameter", 0}}
		t.parent_element  = root.name
		Add(t)
	end
	-- line 1 "STP W3"; line 2 bearing in KRN's heading place, then the distance
	text("dl_ufcp_nav_stp",  XL, YS, "LeftCenter",  "%s",     "DL_UFCP_STP")
	text("dl_ufcp_nav_brg",  -1.331, YD, "RightCenter", "%03.0fT", "DL_UFCP_BRG")
	text("dl_ufcp_nav_d1",   XR, YD, "RightCenter", "%.1f",   "DL_UFCP_DIST", {"DL_UFCP_DSEL", 1})
	text("dl_ufcp_nav_d2",   XR, YD, "RightCenter", "%.0f",   "DL_UFCP_DIST", {"DL_UFCP_DSEL", 2})
end
