-----------------------------------------------------------------------
-- MiG-29 DL add-on (v1.7): start-up screens and the display-off mask
-- (indicator elements). Loaded from dl_pages.lua after every page, so it
-- covers them (and KRN's pages underneath). Values: dl_boot.lua.
--   DL_BOOT  0 normal pages   1 dark   2 white flash   3 test grid
--            4 boot ROM   5 software boot   6 badge   7 BIT   8 cartridge choice
--   DL_PWR_HOLD 1..10  "DISPLAY POWER OFF" bar while POWER is held
--               (10 = full: DL_PWR_TXT then says RELEASE TO SWITCH OFF)
-- v1.7.2: row / card / pool counts and the preview box come from
-- DL_BOOT_CONST (dl_config.lua), the same table dl_boot.lua uses. (This
-- runs in the display's Lua state, where DL_BOOT does not exist, so the
-- old "DL_BOOT and DL_BOOT.X or default" always took its own copies.)
-----------------------------------------------------------------------
do
	local D = DLH
	local BC = DL_BOOT_CONST or {NROM = 14, NCON = 18, CON_COLS = 36, NCARD = 4, NRS = 40, NRP = 40, NGS = 60,
	                             PV = {x0 = 0.12, x1 = 0.84, y0 = 0.30, y1 = 0.98}, PROG = 20, HOLD = 10}
	local text, text1, mesh, simple, line_obj = D.text1, D.text1, D.mesh, D.simple, D.line_obj
	local M, F, G, LW, CFG = D.M, D.F, D.G, D.LW, D.CFG
	local col = D.col
	local BX, BY, BYR, ROW, YB = D.BX, D.BY, D.BYR, D.ROWB, D.YB8
	local RX = -BX
	local function defs(h) return {h, h * 0.3, 0, -h * 0.36} end
	local TXT, TXS, TXT_T = D.TXT, D.TXT_SMALL, {0.0028, 0.00085, 0, -0.0010}
	local TXL = {0.0060, 0.0018, 0, -0.0022}
	local SBS = CFG.sub_btn_label_scale or 0.72
	local TXT_SB = {D.TXT_BTN[1] * SBS, D.TXT_BTN[2] * SBS, D.TXT_BTN[3] * SBS, D.TXT_BTN[4] * SBS}
	local function cw(d) return (D.char_w and D.TEXF) and D.char_w(d) or 0.5 * d[1] / G end
	local dim = F.dim or F.grey
	local FULL = {{-1.2, 1.7}, {1.2, 1.7}, {1.2, -1.7}, {-1.2, -1.7}}
	local Q = {0, 1, 2, 0, 2, 3}

	local function quad(name, parent, x0, y0, x1, y1, mat, params, ctrls)
		return mesh(name, parent, "triangles", {{x0, y1}, {x1, y1}, {x1, y0}, {x0, y0}}, Q, mat, nil, params, ctrls)
	end
	-- straight line as a thin quad
	local function bar(name, parent, x1, y1, x2, y2, w, mat)
		local dx, dy = x2 - x1, y2 - y1
		local l = math.sqrt(dx * dx + dy * dy)
		local nx, ny = -dy / l * w / 2, dx / l * w / 2
		return mesh(name, parent, "triangles", {{x1 + nx, y1 + ny}, {x2 + nx, y2 + ny}, {x2 - nx, y2 - ny}, {x1 - nx, y1 - ny}}, Q, mat)
	end
	-- thick segments {x1, y1, x2, y2} in one mesh
	local function segs(name, parent, list, w, mat, params, ctrls)
		local v, idx = {}, {}
		for _, sg in ipairs(list) do
			local x1, y1, x2, y2 = sg[1], sg[2], sg[3], sg[4]
			local dx, dy = x2 - x1, y2 - y1
			local l = math.sqrt(dx * dx + dy * dy)
			local nx, ny = -dy / l * w / 2, dx / l * w / 2
			local b = #v
			v[b + 1] = {x1 + nx, y1 + ny}; v[b + 2] = {x2 + nx, y2 + ny}; v[b + 3] = {x2 - nx, y2 - ny}; v[b + 4] = {x1 - nx, y1 - ny}
			for _, k in ipairs(Q) do idx[#idx + 1] = b + k end
		end
		return mesh(name, parent, "triangles", v, idx, mat, nil, params, ctrls)
	end
	-- outlined box
	local function frame(name, parent, x0, y0, x1, y1, mat, w, params, ctrls)
		local t = w or LW
		local v = {{x0, y1}, {x1, y1}, {x1, y1 - t}, {x0, y1 - t},  {x0, y0 + t}, {x1, y0 + t}, {x1, y0}, {x0, y0},
		           {x0, y1}, {x0 + t, y1}, {x0 + t, y0}, {x0, y0},  {x1 - t, y1}, {x1, y1}, {x1, y0}, {x1 - t, y0}}
		local idx = {}
		for q = 0, 3 do local b = q * 4; for _, k in ipairs(Q) do idx[#idx + 1] = b + k end end
		return mesh(name, parent, "triangles", v, idx, mat, nil, params, ctrls)
	end
	local function ring(name, parent, cx, cy, r, w, mat, n)
		n = n or 48
		local v, idx = {}, {}
		for i = 0, n - 1 do
			local a = 2 * math.pi * i / n
			v[#v + 1] = {cx + (r + w / 2) * math.cos(a), cy + (r + w / 2) * math.sin(a)}
			v[#v + 1] = {cx + (r - w / 2) * math.cos(a), cy + (r - w / 2) * math.sin(a)}
		end
		for i = 0, n - 1 do
			local a, b, c, d = 2 * i, 2 * i + 1, (2 * i + 2) % (2 * n), (2 * i + 3) % (2 * n)
			idx[#idx + 1] = a; idx[#idx + 1] = c; idx[#idx + 1] = b
			idx[#idx + 1] = b; idx[#idx + 1] = c; idx[#idx + 1] = d
		end
		return mesh(name, parent, "triangles", v, idx, mat)
	end
	local function root(name, stage)
		simple(name, nil, {0, 0, 0}, {"DL_BOOT"}, {{"parameter_in_range", 0, stage - 0.1, stage + 0.1}})
		mesh(name .. "_bg", name, "triangles", FULL, Q, M.black)
	end
	local function boxed(r, n, cx, cy, s, f, d, mat)
		local w = #s * cw(d) + 0.07
		text1(r .. "_" .. n, r, {cx, cy, 0}, f, d, "CenterCenter", s)
		local h = d[1] / G * 1.0 + 0.035
		frame(r .. "_" .. n .. "_box", r, cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, mat)
	end
	local function hline(r, n, y, x0, x1) quad(r .. "_" .. n, r, x0 or -0.86, y - LW / 2, x1 or 0.88, y + LW / 2, M.blue) end
	local VER = "V" .. tostring(DL_VERSION or "")

	-------------------------------------------------------------------
	-- 1 dark (display off, power gap, between the screens)
	-------------------------------------------------------------------
	root("dlb_off", 1)

	-------------------------------------------------------------------
	-- 2 white flash, 3 test grid (panel / backlight test)
	-------------------------------------------------------------------
	root("dlb_flash", 2)
	mesh("dlb_flash_w", "dlb_flash", "triangles", FULL, Q, col(215, 215, 215, 255))
	root("dlb_grid", 3)
	do
		local gm, wm = col(90, 90, 90, 255), col(230, 230, 230, 255)
		local k = 0
		for x = -1.2, 1.21, 0.2 do k = k + 1; quad("dlb_grid_v" .. k, "dlb_grid", x - 0.004, -1.6, x + 0.004, 1.6, gm) end
		k = 0
		for y = -1.5, 1.61, 0.2 do k = k + 1; quad("dlb_grid_h" .. k, "dlb_grid", -1.2, y - 0.004, 1.2, y + 0.004, gm) end
		bar("dlb_grid_d1", "dlb_grid", -1.1, -1.4, 1.1, 1.5, 0.008, gm)
		bar("dlb_grid_d2", "dlb_grid", -1.1, 1.5, 1.1, -1.4, 0.008, gm)
		for i, c in ipairs({{-0.98, 1.36}, {0.98, 1.36}, {-0.98, -1.26}, {0.98, -1.26}}) do
			quad("dlb_grid_ch" .. i, "dlb_grid", c[1] - 0.07, c[2] - 0.006, c[1] + 0.07, c[2] + 0.006, wm)
			quad("dlb_grid_cv" .. i, "dlb_grid", c[1] - 0.006, c[2] - 0.07, c[1] + 0.006, c[2] + 0.07, wm)
		end
		ring("dlb_grid_c", "dlb_grid", 0, 0.05, 0.72, 0.008, wm)
		for i = 0, 7 do
			local g = 30 + i * 30
			quad("dlb_grid_s" .. i, "dlb_grid", -0.80 + i * 0.2, -0.95, -0.60 + i * 0.2, -0.80, col(g, g, g, 255))
		end
	end

	-------------------------------------------------------------------
	-- 4 boot ROM: small text, top left
	-------------------------------------------------------------------
	root("dlb_rom", 4)
	do
		local d = defs(0.0026)
		local x0, y0, dy = -0.95, 1.30, 0.088
		local c = cw(d)
		for i = 1, BC.NROM do
			local y = y0 - (i - 1) * dy
			text1("dlb_rom_a" .. i, "dlb_rom", {x0, y, 0}, dim, d, "LeftCenter", nil, "DL_BR_A" .. i)
			text1("dlb_rom_b" .. i, "dlb_rom", {x0, y, 0}, F.white, d, "LeftCenter", nil, "DL_BR_B" .. i)
			text1("dlb_rom_w" .. i, "dlb_rom", {x0, y, 0}, F.white, d, "LeftCenter", nil, "DL_BR_W" .. i)
		end
		for i = 1, BC.NROM + 1 do
			local y = y0 - (i - 1) * dy
			quad("dlb_rom_cur" .. i, "dlb_rom", x0, y - dy * 0.38, x0 + c * 0.8, y + dy * 0.38, M.white, {"DL_BR_CUR"}, {{"parameter_in_range", 0, i - 0.1, i + 0.1}})
		end
	end

	-------------------------------------------------------------------
	-- 5 software boot log: dim clock and text, white results (right
	-- aligned on column CON_COLS = 36), header / loading line / bar white
	-------------------------------------------------------------------
	root("dlb_con", 5)
	do
		local d = defs(0.0033)
		local c = cw(d)
		local x0 = -0.92
		local x1 = x0 + BC.CON_COLS * c
		local y0, dy = 1.27, 0.118
		local n = BC.NCON
		for i = 1, n do
			local y = y0 - (i - 1) * dy
			text1("dlb_con_a" .. i, "dlb_con", {x0, y, 0}, dim, d, "LeftCenter", nil, "DL_BC_A" .. i)
			text1("dlb_con_b" .. i, "dlb_con", {x1, y, 0}, F.white, d, "RightCenter", nil, "DL_BC_B" .. i)
			text1("dlb_con_c" .. i, "dlb_con", {x0, y, 0}, F.white, d, "LeftCenter", nil, "DL_BC_C" .. i)
			text1("dlb_con_w" .. i, "dlb_con", {x0, y, 0}, F.white, d, "LeftCenter", nil, "DL_BC_W" .. i)
		end
		for i = 1, n + 1 do
			local y = y0 - (i - 1) * dy
			quad("dlb_con_cur" .. i, "dlb_con", x0, y - dy * 0.36, x0 + c * 0.8, y + dy * 0.36, M.white, {"DL_BC_CUR"}, {{"parameter_in_range", 0, i - 0.1, i + 0.1}})
		end
	end

	-------------------------------------------------------------------
	-- 6 badge: the MENU page's title and badge, version, start-up bar
	-------------------------------------------------------------------
	root("dlb_badge", 6)
	boxed("dlb_badge", "t1", 0, 1.13, "MIG-29 WW", F.white, TXL, M.white)
	text1("dlb_badge_ver", "dlb_badge", {0, 0.96, 0}, F.amber, TXS, "CenterCenter", nil, "DL_BS_VER")
	do
		local half = (CFG.logo_size or 1.5) / 2
		local cy = CFG.logo_center_y or -0.02
		local e = CreateElement "ceTexPoly"
		e.name            = "dlb_badge_logo"
		e.primitivetype   = "triangles"
		e.vertices        = {{-half, cy + half}, {half, cy + half}, {half, cy - half}, {-half, cy - half}}
		e.indices         = Q
		e.tex_coords      = {{0, 0}, {1, 0}, {1, 1}, {0, 1}}
		e.material        = "MIG29_DL_LOGO"
		e.init_pos        = {0, 0, 0}
		e.parent_element  = "dlb_badge"
		e.h_clip_relation = D.CLIP
		e.level           = D.LVL
		Add(e)
		local bx0, bx1, by = -0.62, 0.62, -0.98
		frame("dlb_badge_bar", "dlb_badge", bx0, by - 0.035, bx1, by + 0.035, M.white, 0.006)
		local w = (bx1 - bx0 - 0.02) / BC.PROG
		for k = 1, BC.PROG do
			quad("dlb_badge_p" .. k, "dlb_badge", bx0 + 0.01 + (k - 1) * w, by - 0.022, bx0 + 0.01 + k * w + 0.001, by + 0.022, M.amber,
				{"DL_BS_PROG"}, {{"parameter_in_range", 0, k - 0.5, 99}})
		end
		text1("dlb_badge_st", "dlb_badge", {0, by - 0.11, 0}, F.grey, TXT_T, "CenterCenter", "STARTING")
	end

	-------------------------------------------------------------------
	-- 7 built-in test checklist
	--   DL_BIT_S<i>: 1 waiting (dim)  2 in test (amber)  3 GO (white tick)  4 NO-GO (pink cross)
	-------------------------------------------------------------------
	root("dlb_bit", 7)
	boxed("dlb_bit", "title", 0, 1.22, "BUILT-IN TEST", F.white, TXT, M.white)
	text1("dlb_bit_mode", "dlb_bit", {-0.92, 1.06, 0}, F.amber, TXT_T, "LeftCenter", "IBIT  AUTO")
	text1("dlb_bit_ver", "dlb_bit", {0.92, 1.06, 0}, F.grey, TXT_T, "RightCenter", "MIG-29 WW  " .. VER)
	hline("dlb_bit", "h1", 0.99, -0.94, 0.94)
	do
		local rows = DL_BIT_ROWS or {}
		local y0, dy = 0.87, 0.118
		local d = TXT_T
		local di = defs(0.0026)
		local pink = F.pink or F.red
		local wm, am, pm, dm = M.white, M.amber, col(242, 160, 160, 255), col(70, 72, 71, 255)
		for i, name in ipairs(rows) do
			local y = y0 - (i - 1) * dy
			local r = "dlb_bit_r" .. i
			simple(r, "dlb_bit", {0, y, 0})
			local S = "DL_BIT_S" .. i
			local function vis(a, b) return {S}, {{"parameter_in_range", 0, a, b}} end
			local x, h = -0.895, 0.032
			for k, m in ipairs({dm, am, wm, pm}) do
				local p, c = vis(k - 0.1, k + 0.1)
				frame(r .. "_box" .. k, r, x - h, -h, x + h, h, m, 0.006, p, c)
			end
			-- tick / cross / running square
			local p3, c3 = vis(2.9, 3.1)
			segs(r .. "_tick", r, {{x - 0.020, 0.0, x - 0.006, -0.016}, {x - 0.006, -0.016, x + 0.022, 0.022}}, 0.010, wm, p3, c3)
			local p4, c4 = vis(3.9, 4.1)
			segs(r .. "_x", r, {{x - 0.018, -0.018, x + 0.018, 0.018}, {x - 0.018, 0.018, x + 0.018, -0.018}}, 0.009, pm, p4, c4)
			local p2, c2 = vis(1.9, 2.1)
			quad(r .. "_run", r, x - 0.014, -0.014, x + 0.014, 0.014, am, p2, c2)
			-- name: dim while waiting, white once tested
			text1(r .. "_n0", r, {-0.83, 0, 0}, dim, d, "LeftCenter", name, nil, {S, 0.5, 1.5})
			text1(r .. "_n1", r, {-0.83, 0, 0}, F.white, d, "LeftCenter", name, nil, {S, 1.5, 4.5})
			text1(r .. "_st1", r, {-0.13, 0, 0}, dim, d, "LeftCenter", "--", nil, {S, 0.5, 1.5})
			text1(r .. "_st2", r, {-0.13, 0, 0}, F.amber, d, "LeftCenter", "IN TEST", nil, {S, 1.5, 2.5})
			text1(r .. "_st3", r, {-0.13, 0, 0}, F.white, d, "LeftCenter", "GO", nil, {S, 2.5, 3.5})
			text1(r .. "_st4", r, {-0.13, 0, 0}, pink, d, "LeftCenter", "NO-GO", nil, {S, 3.5, 4.5})
			text1(r .. "_inf", r, {0.92, 0, 0}, (i == 4) and F.amber or F.grey, di, "RightCenter", nil, "DL_BIT_I" .. i)
		end
		local yb = y0 - #rows * dy + 0.03
		hline("dlb_bit", "h2", yb, -0.94, 0.94)
		text1("dlb_bit_sum", "dlb_bit", {-0.92, yb - 0.10, 0}, F.white, TXS, "LeftCenter", nil, "DL_BIT_SUM")
		text1("dlb_bit_done", "dlb_bit", {0.92, yb - 0.10, 0}, F.amber, TXS, "RightCenter", "BIT COMPLETE", nil, {"DL_BIT_DONE", 0.5, 1.5})
	end
	text1("dlb_bit_skip", "dlb_bit", {ROW[3], YB, 0}, F.white, TXS, "CenterCenter", "SKIP")

	-------------------------------------------------------------------
	-- 8 cartridge choice
	-------------------------------------------------------------------
	root("dlb_dtc", 8)
	boxed("dlb_dtc", "title", 0, 1.22, "SELECT CARTRIDGE", F.white, TXT, M.white)
	text1("dlb_dtc_align", "dlb_dtc", {0, 1.08, 0}, F.amber, TXT_T, "CenterCenter", nil, "DL_BD_ALIGN")
	do
		local dm = col(70, 72, 71, 255)
		local cx0, cx1, hh = -0.72, 0.06, 0.105
		for k = 1, BC.NCARD do
			local y = 0.88 - (k - 1) * 0.29
			local r = "dlb_dtc_c" .. k
			simple(r, "dlb_dtc", {0, y, 0}, {"DL_BD_V" .. k}, {{"parameter_in_range", 0, 0.5, 2.5}})
			frame(r .. "_f1", r, cx0, -hh, cx1, hh, dm, 0.005, {"DL_BD_V" .. k}, {{"parameter_in_range", 0, 0.5, 1.5}})
			quad(r .. "_fill", r, cx0, -hh, cx1, hh, col(18, 26, 48, 255), {"DL_BD_V" .. k}, {{"parameter_in_range", 0, 1.5, 2.5}})
			frame(r .. "_f2", r, cx0, -hh, cx1, hh, M.amber, 0.009, {"DL_BD_V" .. k}, {{"parameter_in_range", 0, 1.5, 2.5}})
			mesh(r .. "_ptr", r, "triangles", {{cx0 - 0.065, 0.03}, {cx0 - 0.02, 0}, {cx0 - 0.065, -0.03}}, {0, 1, 2}, M.amber, nil,
				{"DL_BD_V" .. k}, {{"parameter_in_range", 0, 1.5, 2.5}})
			text1(r .. "_n", r, {cx0 + 0.04, 0.035, 0}, F.white, defs(0.0026), "LeftCenter", nil, "DL_BD_N" .. k)
			text1(r .. "_i1", r, {cx0 + 0.04, -0.045, 0}, F.grey, defs(0.0024), "LeftCenter", nil, "DL_BD_I" .. k, {"DL_BD_V" .. k, 0.5, 1.5})
			text1(r .. "_i2", r, {cx0 + 0.04, -0.045, 0}, F.amber, defs(0.0024), "LeftCenter", nil, "DL_BD_I" .. k, {"DL_BD_V" .. k, 1.5, 2.5})
		end
		text1("dlb_dtc_more", "dlb_dtc", {(cx0 + cx1) / 2, 0.88 - 3 * 0.29 - 0.17, 0}, F.grey, TXT_T, "CenterCenter", nil, "DL_BD_MORE")
		text1("dlb_dtc_empty", "dlb_dtc", {(cx0 + cx1) / 2, 0.60, 0}, F.grey, TXT_T, "CenterCenter", "NO CARTRIDGES", nil, {"DL_BD_EMPTY", 0.5, 1.5})
		text1("dlb_dtc_empty2", "dlb_dtc", {(cx0 + cx1) / 2, 0.50, 0}, F.grey, TXT_T, "CenterCenter", "FOR THIS MAP", nil, {"DL_BD_EMPTY", 0.5, 1.5})

		-- preview of the selected cartridge
		local PV = BC.PV
		frame("dlb_dtc_pv", "dlb_dtc", PV.x0, 0.02, PV.x1, PV.y1 + 0.03, M.blue, 0.006)
		local pk = col(242, 160, 160, 255)
		local function seg_pool(pre, n, mat, w)
			for i = 1, n do
				local q = pre .. i .. "_"
				line_obj("dlb_dtc_" .. pre .. i, "dlb_dtc", mat, w, {q .. "X1", q .. "Y1", q .. "X2", q .. "Y2", q .. "V"},
					{{"line_object_set_point_using_parameters", 0, 0, 1, G, G},
					 {"line_object_set_point_using_parameters", 1, 2, 3, G, G},
					 {"parameter_in_range", 4, 0.5, 1.5}})
			end
		end
		seg_pool("DL_BD_GS", BC.NGS, pk, 0.004)
		seg_pool("DL_BD_RS", BC.NRS, M.white, 0.005)
		local lb = col(120, 160, 225, 255)
		for i = 1, BC.NRP do
			local q = "DL_BD_RP" .. i .. "_"
			local r = "dlb_dtc_rp" .. i
			simple(r, "dlb_dtc", {0, 0, 0}, {q .. "X", q .. "Y", q .. "V"},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}, {"parameter_in_range", 2, 0.5, 1.5}})
			ring(r .. "_o", r, 0, 0, 0.016, 0.006, lb, 12)
		end
		local mx = (PV.x0 + PV.x1) / 2
		text1("dlb_dtc_pn", "dlb_dtc", {mx, 0.24, 0}, F.amber, TXT_T, "CenterCenter", nil, "DL_BD_PN")
		text1("dlb_dtc_p1", "dlb_dtc", {mx, 0.155, 0}, F.grey, defs(0.0024), "CenterCenter", nil, "DL_BD_P1")
		text1("dlb_dtc_p2", "dlb_dtc", {mx, 0.08, 0}, F.grey, defs(0.0024), "CenterCenter", nil, "DL_BD_P2")

		-- what it holds
		hline("dlb_dtc", "h1", -0.24, -0.86, 0.86)
		local pink = F.pink or F.red
		for i, k in ipairs({"FLIGHT", "RADIOS", "NAV", "DRAWINGS"}) do
			local y = -0.35 - (i - 1) * 0.11
			text1("dlb_dtc_k" .. i, "dlb_dtc", {-0.82, y, 0}, F.amber, defs(0.0024), "LeftCenter", k)
			text1("dlb_dtc_d" .. i, "dlb_dtc", {-0.42, y, 0}, (i == 4) and pink or F.white, TXT_T, "LeftCenter", nil, "DL_BD_D" .. i)
		end
		hline("dlb_dtc", "h2", -0.80, -0.86, 0.86)
	end
	text1("dlb_dtc_l2", "dlb_dtc", {BX, BY[2], 0}, F.white, TXT_SB, "LeftCenter", "UP")
	text1("dlb_dtc_l3", "dlb_dtc", {BX, BY[3], 0}, F.white, TXT_SB, "LeftCenter", "DOWN")
	text1("dlb_dtc_r1", "dlb_dtc", {RX, BYR[1], 0}, F.white, TXT_SB, "RightCenter", "MSN")
	text1("dlb_dtc_r5", "dlb_dtc", {RX, BYR[5], 0}, F.white, TXT_SB, "RightCenter", "NONE")
	text1("dlb_dtc_load", "dlb_dtc", {ROW[3], YB, 0}, F.white, TXS, "CenterCenter", "LOAD", nil, {"DL_BD_LOAD", 0.5, 1.5})

	-------------------------------------------------------------------
	-- POWER held: "DISPLAY POWER OFF" and a bar filling up (over any page)
	-------------------------------------------------------------------
	simple("dlb_hold", nil, {0, 0, 0}, {"DL_PWR_HOLD"}, {{"parameter_in_range", 0, 0.5, BC.HOLD + 0.5}})
	quad("dlb_hold_bg", "dlb_hold", -0.66, -0.12, 0.66, 0.44, M.black)
	frame("dlb_hold_f", "dlb_hold", -0.66, -0.12, 0.66, 0.44, M.amber, 0.009)
	text1("dlb_hold_t", "dlb_hold", {0, 0.31, 0}, F.amber, TXT, "CenterCenter", "DISPLAY POWER OFF")
	frame("dlb_hold_bar", "dlb_hold", -0.50, 0.12, 0.50, 0.20, M.amber, 0.006)
	local hw = 0.98 / BC.HOLD                      -- segment width (0.098 for 10)
	for k = 1, BC.HOLD do
		quad("dlb_hold_p" .. k, "dlb_hold", -0.49 + (k - 1) * hw, 0.13, -0.49 + k * hw - 0.004, 0.19, M.amber,
			{"DL_PWR_HOLD"}, {{"parameter_in_range", 0, k - 0.5, BC.HOLD + 0.5}})
	end
	text1("dlb_hold_k", "dlb_hold", {0, 0.0, 0}, F.white, TXT_T, "CenterCenter", nil, "DL_PWR_TXT")
end
