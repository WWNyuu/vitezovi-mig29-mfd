@echo off
setlocal
title Vitezovi MiG-29 MFD add-on - uninstall
rem started from inside the zip, Windows unpacks only this file: the
rem installer next to it is missing then
if exist "%~dp0installer\vitezovi_install.ps1" goto have_files
echo.
echo  Unzip the whole folder first, then run UNINSTALL.bat from there.
echo  (Windows started UNINSTALL.bat from inside the zip - the rest of the add-on is not next to it.)
echo.
pause
exit /b 1
:have_files
echo.
echo  Removes the Vitezovi MiG-29 MFD add-on and puts KRN's original files back.
echo  KRN's mod itself stays installed. Close DCS before continuing.
echo.
pause
rem options are passed on to the installer, e.g. UNINSTALL.bat -SavedGames "D:\Saved Games\DCS"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\vitezovi_install.ps1" -Uninstall %*
echo.
pause
