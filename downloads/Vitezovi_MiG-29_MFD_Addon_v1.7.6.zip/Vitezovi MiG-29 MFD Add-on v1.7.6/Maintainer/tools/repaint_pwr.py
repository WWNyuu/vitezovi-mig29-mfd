"""Bezel power rocker: KRN's cog rocker (top left) -> 'PWR' + power symbol.
The texture is mirrored left-right on the model (see the SYM label), so the
text is drawn mirrored. Usage: python repaint_pwr.py <Buttons.png> <out.png>"""
import sys, numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
SRC, DST = sys.argv[1], sys.argv[2]
FONT = '/tmp/claude-0/fonts/package/files/open-sans-latin-700-normal.woff'
im = np.array(Image.open(SRC).convert('RGB'))
X0, Y0, X1, Y1 = 1130, 2780, 1430, 3270            # the cog rocker
reg = im[Y0:Y1, X0:X1].copy()
lum = reg.astype(np.float32).mean(axis=2)
mask = (lum > 110).astype(np.uint8)
# symbols only (inside the dark rocker face)
face = np.zeros_like(mask); face[60:430, 80:236] = 1
mask &= face
n, lab, st, _ = cv2.connectedComponentsWithStats(mask, 8)
keep = np.zeros_like(mask)
for k in range(1, n):
    if st[k, cv2.CC_STAT_AREA] >= 40: keep[lab == k] = 1
m = cv2.dilate(keep * 255, np.ones((7, 7), np.uint8))
col = reg[keep.astype(bool)].mean(axis=0)
clean = cv2.inpaint(reg, m, 7, cv2.INPAINT_TELEA)
# symbol colour: the old symbols' bright core
core = reg[(lum > 200) & face.astype(bool)]
ink = core.mean(axis=0) if len(core) else np.array([235, 235, 235])
S = 4                                              # supersampling
W, H = reg.shape[1], reg.shape[0]
alpha = Image.new('L', (W * S, H * S), 0); d = ImageDraw.Draw(alpha)
cx = 158
# power symbol where the cog was (cog centre y 247, outer radius ~62)
cy, r, w = 252, 47, 13
d.arc([(cx - r) * S, (cy - r) * S, (cx + r) * S, (cy + r) * S], start=-58, end=238, fill=255, width=w * S)
d.rounded_rectangle([(cx - w / 2) * S, (cy - r - 14) * S, (cx + w / 2) * S, (cy - 2) * S], radius=w * S / 2, fill=255)
# PWR above it, same size as the SYM label, mirrored
f = ImageFont.truetype(FONT, 44 * S)
txt = Image.new('L', (W * S, 70 * S), 0); dt = ImageDraw.Draw(txt)
tw = f.getlength('PWR')
dt.text(((W * S - tw) / 2, 4 * S), 'PWR', font=f, fill=255)
txt = txt.transpose(Image.FLIP_LEFT_RIGHT)
bb = txt.getbbox(); th = bb[3] - bb[1]
ty = 125 - th / S / 2                               # where the up arrow was
alpha.paste(txt.crop((0, bb[1], W * S, bb[3])), (int((cx - W / 2) * S + (W * S - W * S) / 2) + int((158 - W / 2) * S) * 0, int(ty * S)), txt.crop((0, bb[1], W * S, bb[3])))
a = np.array(alpha.resize((W, H), Image.LANCZOS)).astype(np.float32)[..., None] / 255
out = clean.astype(np.float32) * (1 - a) + ink[None, None, :] * a
im[Y0:Y1, X0:X1] = np.clip(out, 0, 255).astype(np.uint8)
Image.fromarray(im).save(DST, optimize=True)
Image.fromarray(im[Y0:Y1, X0:X1]).save(DST + '.crop.png')
print('ink', ink, 'erased px', int(keep.sum()))
