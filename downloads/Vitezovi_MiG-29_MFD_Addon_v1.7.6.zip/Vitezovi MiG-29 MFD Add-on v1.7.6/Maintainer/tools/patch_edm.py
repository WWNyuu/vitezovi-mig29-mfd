"""Add click-box connectors for the MFD bezel buttons to KRN's UFCP.edm.
Appends TransformNodes (parented to the button bones) at the end of the node
list and Connectors at the end of the connector list; nothing existing moves
or is renumbered. Updates: node count, parent list, connector count and the
TransformNode count in index A."""
import struct, sys
src, dst = sys.argv[1], sys.argv[2]
b = bytearray(open(src, 'rb').read())

def u32(o): return struct.unpack_from('<I', b, o)[0]
st_len = u32(5)
strings = bytes(b[9:9 + st_len]).split(b'\x00')
TID = {s.decode(): i for i, s in enumerate(strings) if s.startswith(b'model::')}

# --- index A (type counts)
o = 9 + st_len
na = u32(o); o += 4
idxA = {}
for _ in range(na):
    k, v = struct.unpack_from('<II', b, o); idxA[strings[k].decode()] = o + 4; o += 8
# --- locate the node list / parents / connectors (layout checked by hand)
NODE_COUNT_POS = 28686
N = u32(NODE_COUNT_POS)
assert N == 162, N
first_conn = 73112
assert u32(first_conn - 8) == strings.index(b'CONNECTORS') and u32(first_conn - 12) == 2
NCONN = u32(first_conn - 4); assert NCONN == 55
par_start = first_conn - 12 - 4 * N
par_end = first_conn - 12
assert struct.unpack_from('<i', b, par_start)[0] == -1
nodes_end = par_start
# end of the connector list
o = first_conn
conn = []
for _ in range(NCONN):
    t, L = struct.unpack_from('<II', b, o); assert t == TID['model::Connector'], (o, t)
    name = bytes(b[o + 8:o + 8 + L]).decode()
    parent = u32(o + 8 + L + 8)
    conn.append((name, parent))
    o += 8 + L + 16
conn_end = o
names = [c[0] for c in conn]

def matrix_of(tname):
    i = bytes(b).find(tname.encode() + b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert i > 0, tname
    return list(struct.unpack_from('<16d', b, i + len(tname) + 8))

M_SIDE = matrix_of('MFD-1transform')      # left column orientation
M_BOT  = matrix_of('MFD-8transform')      # bottom row orientation
def with_t(m, t):
    m = list(m); m[12], m[13], m[14] = t; return m

# new click boxes: (connector name, bone node index, matrix)
NEW = []
# node indices of the button bones (checked in the cockpit by hovering):
# (bone node k = "Bone.(k-2)"; node 30 = cog rocker, 31-35 left 1-5, 36 SYM,
#  37 BRT, 38-42 right 1-5, 43 D/N, 44-48 top, 49-53 bottom - v1.7 check of the
#  bones' positions and animation args, see clickabledata)
# bottom row left->right: 49, 50, (51 = MFD-8), 52, 53;  top row left->right: 44..48;
# right column top->bottom: 38..42
for name, node in [('MFD-B1', 49), ('MFD-B2', 50), ('MFD-B4', 52), ('MFD-B5', 53)]:
    NEW.append((name, node, M_BOT))
for k, node in enumerate([38, 39, 40, 41, 42]):
    NEW.append(('MFD-R%d' % (k + 1), node, with_t(M_SIDE, (0.0013, 0.0009, 0.0005))))
for k, node in enumerate([44, 45, 46, 47, 48]):
    NEW.append(('MFD-T%d' % (k + 1), node, with_t(M_BOT, (M_BOT[12], -M_BOT[13], M_BOT[14]))))
# right column extras: brightness rocker (top, node 37) and D/N switch (bottom, node 43)
# (two click boxes each: upper and lower half). Bone local +y points DOWN the
# bezel; the box's height is set by matrix row 0 (local x of the box -> -y).
def half_box(center_dy, half_h, k=0.7):
    m = list(M_SIDE)
    for i in range(4, 12): m[i] *= k               # depth / width as before
    for i in range(0, 4): m[i] *= half_h / 0.005   # height
    m[12], m[13], m[14] = 0.0013, 0.0009 + center_dy, 0.0005
    return m
# one click box over the whole control: left click / right click
NEW.append(('MFD-BRT', 37, half_box(-0.001, 0.0125, 0.8)))   # brightness rocker
NEW.append(('MFD-DN', 43, half_box(+0.001, 0.0115, 0.8)))    # D/N switch
# left column bottom: SYM rocker (node 36) - same size as the D/N switch, centred
_sym = half_box(+0.001, 0.0115, 0.8); _sym[12] = 0.0
NEW.append(('MFD-SYM', 36, _sym))
# v1.7: left column top: KRN's cog rocker (node 30, animation arg 101) is the
# display POWER button (press = on, hold 2 s = off) - same size as the
# brightness rocker on the right, centred like SYM
_pwr = half_box(-0.001, 0.0125, 0.8); _pwr[12] = 0.0
NEW.append(('MFD-PWR', 30, _pwr))
for n, _, _ in NEW: assert n not in names

tn_recs, par_recs, cn_recs = b'', b'', b''
for j, (cname, bone, m) in enumerate(NEW):
    tname = (cname + 'transform').encode()
    tn_recs += struct.pack('<II', TID['model::TransformNode'], len(tname)) + tname + struct.pack('<II', 0, 0) + struct.pack('<16d', *m)
    par_recs += struct.pack('<i', bone)
    new_index = N + j
    cn = cname.encode()
    cn_recs += struct.pack('<II', TID['model::Connector'], len(cn)) + cn + struct.pack('<IIII', 0, 0, new_index, 0)

# v1.7 add-on: the same change as a list of operations on the ORIGINAL file
# (offsets in the original): overwrite 4-byte counts, insert the new records.
# Written to <output>.ops.json when OPS=1 is set - the installer applies them.
import os, json
if os.environ.get("OPS"):
    ow = [(first_conn - 4, struct.pack('<I', NCONN + len(NEW))),
          (NODE_COUNT_POS, struct.pack('<I', N + len(NEW)))]
    pos = idxA['model::TransformNode']
    ow.append((pos, struct.pack('<I', u32(pos) + len(NEW))))
    ins = [(conn_end, cn_recs), (par_end, par_recs), (nodes_end, tn_recs)]
    json.dump({"overwrite": [[o, d.hex()] for o, d in ow], "insert": [[o, d.hex()] for o, d in ins]},
              open(dst + ".ops.json", "w"))
# apply back to front so earlier offsets stay valid
out = bytearray(b)
out[conn_end:conn_end] = cn_recs
struct.pack_into('<I', out, first_conn - 4, NCONN + len(NEW))
out[par_end:par_end] = par_recs
out[nodes_end:nodes_end] = tn_recs
struct.pack_into('<I', out, NODE_COUNT_POS, N + len(NEW))
pos = idxA['model::TransformNode']
struct.pack_into('<I', out, pos, u32(pos) + len(NEW))
open(dst, 'wb').write(out)
print('added', len(NEW), 'connectors:', [n for n, _, _ in NEW])
print('nodes', N, '->', N + len(NEW), '| connectors', NCONN, '->', NCONN + len(NEW), '| size', len(b), '->', len(out))
