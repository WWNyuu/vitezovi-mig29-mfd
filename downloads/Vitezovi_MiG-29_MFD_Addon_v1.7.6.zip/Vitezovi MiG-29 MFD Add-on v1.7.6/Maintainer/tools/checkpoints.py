import importlib, json
from pyproj import Transformer
P = {}
def tm(cm, fe, fn, k=0.9996):
    return Transformer.from_crs('EPSG:4326', f'+proj=tmerc +lat_0=0 +lon_0={cm} +k_0={k} +x_0={fe} +y_0={fn} +ellps=WGS84 +units=m +no_defs', always_xy=True)
mods = {'Afghanistan': ('afghanistan', 'Afghanistan', 34.5, 66.0), 'Caucasus': ('caucasus', 'Caucasus', 43.0, 42.0),
        'Falklands': ('falklands', 'Falklands', -51.7, -59.0), 'GermanyColdWar': ('germany', 'Germany', 51.5, 10.5),
        'Kola': ('kola', 'Kola', 68.5, 28.0), 'MarianaIslands': ('marianaislands', 'MarianaIslands', 14.0, 145.0),
        'Nevada': ('nevada', 'Nevada', 36.5, -115.5), 'PersianGulf': ('persiangulf', 'PersianGulf', 26.0, 55.5),
        'Sinai': ('sinai', 'Sinai', 30.0, 33.0), 'Syria': ('syria', 'Syria', 35.0, 37.0)}
out = {}
for name, (m, cls, lat, lon) in mods.items():
    t = getattr(importlib.import_module('dcs.terrain.' + m), cls)()
    pp = t.projection_parameters
    z, x = tm(pp.central_meridian, pp.false_easting, pp.false_northing, pp.scale_factor).transform(lon, lat)
    out[name] = dict(x=x, z=z, lat=lat, lon=lon)
# from dcs-mcp (ED data) for the two pydcs lacks
out['Iraq'] = dict(x=-28326.02588762343, z=-21127.778207761003, lat=33.0, lon=44.0)
out['MarianasWWII'] = dict(x=56798.68856959557, z=22397.444872426975, lat=14.0, lon=145.0)
for k, v in out.items(): print(k, round(v['x']), round(v['z']), v['lat'], v['lon'])
json.dump(out, open('/home/claude/charts/checkpoints.json', 'w'), indent=1)
