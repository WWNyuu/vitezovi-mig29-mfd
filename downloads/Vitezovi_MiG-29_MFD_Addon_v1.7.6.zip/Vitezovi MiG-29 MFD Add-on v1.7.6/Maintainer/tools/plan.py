import json, math, collections
tiles = json.load(open('tiles.json'))
RANGES = [20, 40, 80, 160, 320]
def plan(name):
    T = tiles[name]
    byw = collections.defaultdict(list)
    for t in T: byw[round(t['x1'] - t['x0'])].append(t)
    widths = sorted(byw)
    choice = []
    for R in RANGES:
        need = R * 2.62
        cands = [w for w in widths if ((2.8 * R * 1000) / w + 1) ** 2 <= 64]
        if not cands: choice.append(None); continue
        ok = [w for w in cands if w / 1024 <= need * 1.3]
        choice.append(max(ok) if ok else min(cands))
    quads = sum(len(byw[w]) for w in choice if w)
    # cap
    while quads > 8000:
        # drop the range with most quads
        i = max(i for i in range(len(choice)) if choice[i])
        choice[i] = None
        quads = sum(len(byw[w]) for w in choice if w)
    used = sorted(set(w for w in choice if w))
    return choice, used, quads, sum(len(byw[w]) for w in used)
for n in sorted(tiles):
    c, u, q, nt = plan(n)
    print(f"{n:15s} ranges->mpp {[w//1024 if w else None for w in c]}  tiles {nt}  quads {q}")
