import re, struct, glob, json, collections, sys
def parse(path):
    d = open(path, 'rb').read()
    out = []
    for m in re.finditer(rb'[0-9a-zA-Z_\-]{2,}_x\d+_z\d+\.tif', d):
        off = m.start()
        # length-prefixed? check the 4 bytes before name
        f = lambda o: struct.unpack('<f', d[off + o: off + o + 4])[0]
        x0, z0, x1, z1 = f(-214), f(-206), f(-202), f(-194)
        y0, y1 = f(-210), f(-198)
        out.append(dict(name=m.group().decode(), x0=x0, z0=z0, x1=x1, z1=z1, y0=y0, y1=y1))
    return out
if __name__ == '__main__':
    res = {}
    for p in sorted(glob.glob('/mnt/user-data/uploads/terrains/*/RasterCharts/rasterCharts.sup5')):
        t = p.split('/')[-3]
        tiles = parse(p)
        bad = [x for x in tiles if not (x['x1'] > x['x0'] and x['z1'] > x['z0'])]
        widths = collections.Counter(round(x['x1'] - x['x0']) for x in tiles)
        widthz = collections.Counter(round(x['z1'] - x['z0']) for x in tiles)
        print(t, len(tiles), 'bad', len(bad), 'wx', dict(widths.most_common(6)), 'wz', dict(widthz.most_common(4)))
        if bad[:2]: print('   bad eg', bad[:2])
        res[t] = tiles
    json.dump(res, open('/home/claude/charts/tiles.json', 'w'))
