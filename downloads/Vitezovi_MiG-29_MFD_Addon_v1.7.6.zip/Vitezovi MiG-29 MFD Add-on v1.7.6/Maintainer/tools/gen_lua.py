import json, collections, os, re
exec(open('plan.py').read().split("for n in sorted(tiles):")[0])
cps = json.load(open('checkpoints.json'))
FOLDER = {16384: '0.25M', 32768: '0.5M', 65536: '1M', 131072: '2M', 262144: '5M'}
FOLDER_BASED = {'Caucasus', 'Nevada'}
OUT = '/home/claude/work/new/Cockpit/Scripts/DL/charts'
os.makedirs(OUT, exist_ok=True)
summary = []
for name in sorted(tiles):
    choice, used, quads, nt = plan(name)
    cls_index = {w: i + 1 for i, w in enumerate(used)}
    T = [t for t in tiles[name] if round(t['x1'] - t['x0']) in cls_index]
    T.sort(key=lambda t: (round(t['x1'] - t['x0']), t['name']))
    if name in FOLDER_BASED:
        zips = sorted(set(f"Mods/terrains/{name}/RasterCharts/{FOLDER[round(t['x1']-t['x0'])]}/{re.sub(r'_x\d+_z\d+\.tif$', '', t['name'])}.zip" for t in T))
    else:
        zips = [f"Mods/terrains/{name}/RasterCharts/rasterCharts.zip"]
    L = []
    L.append(f"-- generated from Mods\\terrains\\{name}\\RasterCharts\\rasterCharts.sup5 (DCS's own aeronautical charts)")
    L.append("-- tile = {texture, x_south, z_west, x_north, z_east, class}   (DCS metres, x = north, z = east)")
    L.append("DL_CHART = {")
    L.append(f'\ttheatre = "{name}",')
    L.append("\tzips = {")
    for z in zips: L.append(f'\t\t"{z}",')
    L.append("\t},")
    L.append("\tclasses = {" + ", ".join(str(w) for w in used) + "},   -- tile size in metres (1024 px tiles)")
    L.append("\trange_class = {" + ", ".join(str(cls_index[w]) if w else "0" for w in choice) + "},   -- class used for range step 1..5 (0 = no chart)")
    L.append("\ttiles = {")
    for t in T:
        L.append(f'\t\t{{"{t["name"]}.dds", {t["x0"]:.1f}, {t["z0"]:.1f}, {t["x1"]:.1f}, {t["z1"]:.1f}, {cls_index[round(t["x1"]-t["x0"])]}}},')
    L.append("\t},")
    L.append("}")
    open(f"{OUT}/{name}.lua", "w").write("\n".join(L) + "\n")
    summary.append((name, len(T), quads, os.path.getsize(f"{OUT}/{name}.lua")))
for s in summary: print(s)
# theatre index
L = ["-- Theatre recognition for the MiG-29 DL page.",
     "-- Each entry: a DCS world point (x north, z east, metres) and the lat/lon it must map to",
     "-- on that theatre. terrain.convertMetersToLatLon() tells us which theatre is loaded.",
     "-- MarianasWWII uses the same projection as MarianaIslands, so it shows the MarianaIslands charts.",
     "DL_THEATRES = {"]
for name in sorted(tiles):
    if name == 'MarianasWWII': continue
    c = cps[name]
    L.append(f'\t{{name = "{name}", x = {c["x"]:.2f}, z = {c["z"]:.2f}, lat = {c["lat"]}, lon = {c["lon"]}}},')
L.append("}")
L.append("""
-- returns the theatre name or nil
function DL_detect_theatre()
	if DL_CFG and DL_CFG.force_theatre and DL_CFG.force_theatre ~= "" then
		return DL_CFG.force_theatre
	end
	local ok, terr = pcall(require, "terrain")
	if not ok or type(terr) ~= "table" or not terr.convertMetersToLatLon then
		return nil
	end
	for _, t in ipairs(DL_THEATRES) do
		local ok2, lat, lon = pcall(terr.convertMetersToLatLon, t.x, t.z)
		if ok2 and lat and lon and math.abs(lat - t.lat) < 0.05 and math.abs(lon - t.lon) < 0.05 then
			return t.name
		end
	end
	return nil
end

-- loads DL/charts/<theatre>.lua into DL_CHART (nil if there is none)
function DL_load_chart(theatre)
	DL_CHART = nil
	if not theatre then return nil end
	local path = LockOn_Options.script_path .. "DL/charts/" .. theatre .. ".lua"
	local f = io and io.open and io.open(path, "r")
	if f then f:close() end
	local ok = pcall(dofile, path)
	if ok and DL_CHART and DL_CHART.tiles then return DL_CHART end
	DL_CHART = nil
	return nil
end
""")
open('/home/claude/work/new/Cockpit/Scripts/DL/dl_theatres.lua', 'w').write("\n".join(L))
print(open('/home/claude/work/new/Cockpit/Scripts/DL/charts/Caucasus.lua').read()[:900])
