import sys, numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
SRC, DST = sys.argv[1], sys.argv[2]
FONT = '/tmp/claude-0/fonts/package/files/open-sans-latin-700-normal.woff'
im = np.array(Image.open(SRC).convert('RGB'))
# (box x0,y0,x1,y1), old text lines, new text lines
# the DVR labels first: their font size is used for NAV on the same set
JOBS = [((990, 880, 1080, 1040), ["DVR"], ["DIR"], "A"),
        ((1440, 880, 1560, 1040), ["FLT/", "MENU"], ["NAV"], "A"),
        ((890, 316, 995, 365), ["DVR"], ["DIR"], "B"),
        ((480, 330, 620, 410), ["FLT/", "MENU"], ["NAV"], "B"),
        ((40, 200, 110, 300), ["DVR"], ["DIR"], "C")]
SETPX = {}
TF = {  # the 8 orientations
 'id': lambda a: a, 'r90': lambda a: np.rot90(a, 1), 'r180': lambda a: np.rot90(a, 2), 'r270': lambda a: np.rot90(a, 3),
 'fx': lambda a: a[:, ::-1], 'fy': lambda a: a[::-1, :], 'tr': lambda a: a.T, 'atr': lambda a: np.rot90(a, 2).T}
def render(lines, px):
    f = ImageFont.truetype(FONT, px)
    lh = int(px * 1.05)
    w = max(int(f.getlength(l)) for l in lines) + 8
    h = lh * len(lines) + 8
    img = Image.new('L', (w, h), 0); d = ImageDraw.Draw(img)
    for i, l in enumerate(lines):
        lw = f.getlength(l)
        d.text(((w - lw) / 2, 4 + i * lh), l, font=f, fill=255)
    a = np.array(img)
    ys, xs = np.nonzero(a > 40)
    return a[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
def bbox(m):
    ys, xs = np.nonzero(m)
    return ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
for (x0, y0, x1, y1), old, new, setn in JOBS:
    reg = im[y0:y1, x0:x1].astype(np.float32)
    lum = reg.mean(axis=2)
    mask = lum > 120
    # drop scratches: keep the bigger bright blobs only
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    keep = np.zeros_like(mask)
    for k in range(1, n):
        if st[k, cv2.CC_STAT_AREA] >= 25: keep |= (lab == k)
    mask = keep
    ya, yb, xa, xb = bbox(mask)
    tm = mask[ya:yb, xa:xb]
    best = None
    for name, fn in TF.items():
        for px in range(10, 60):
            r = fn(render(old, px)) > 100
            if abs(r.shape[0] - tm.shape[0]) > 6 or abs(r.shape[1] - tm.shape[1]) > 6: continue
            hh, ww = min(r.shape[0], tm.shape[0]), min(r.shape[1], tm.shape[1])
            a, b = r[:hh, :ww], tm[:hh, :ww]
            iou = (a & b).sum() / max(1, (a | b).sum())
            if not best or iou > best[0]: best = (iou, name, px)
    iou, name, px = best
    if len(old) == 1: SETPX[setn] = px
    npx = SETPX.get(setn, px)
    col = reg[mask].mean(axis=0)
    # erase the old label
    m8 = cv2.dilate(mask.astype(np.uint8) * 255, np.ones((5, 5), np.uint8))
    full = im[y0:y1, x0:x1].copy()
    clean = cv2.inpaint(full, m8, 5, cv2.INPAINT_TELEA)
    # the new label, same font size and orientation, centred on the old one
    nl = TF[name](render(new, npx)).astype(np.float32) / 255.0
    cy, cx = (ya + yb) / 2, (xa + xb) / 2
    ty, tx = int(round(cy - nl.shape[0] / 2)), int(round(cx - nl.shape[1] / 2))
    out = clean.astype(np.float32)
    sub = out[ty:ty + nl.shape[0], tx:tx + nl.shape[1]]
    al = nl[:sub.shape[0], :sub.shape[1], None]
    out[ty:ty + nl.shape[0], tx:tx + nl.shape[1]] = sub * (1 - al) + col * al
    im[y0:y1, x0:x1] = np.clip(out, 0, 255).astype(np.uint8)
    print(f"{old} -> {new}: orientation {name}, font px {px}, match {iou:.2f}, colour {col.round()}")
Image.fromarray(im).save(DST, optimize=True)
