// Vitezovi MiG-29 MFD add-on: binary helpers for the installer (compiled by
// PowerShell's Add-Type on the player's PC; plain C# 5 / .NET Framework 4.5).
//  * PNG read / write (8-bit RGB or RGBA, not interlaced - KRN's textures)
//  * PNG header check and pixel fingerprint (v1.7.2: a PNG the installer
//    wrote is recognised by its pixels - its bytes depend on the PC's .NET)
//  * pasting the add-on's label tiles into a texture
//  * the UFCP.edm splice (click boxes of the MFD bezel buttons)
using System;
using System.IO;
using System.IO.Compression;
using System.Collections.Generic;

public static class VitezoviPatch
{
	static uint BE(byte[] b, int o) { return (uint)(b[o] << 24 | b[o + 1] << 16 | b[o + 2] << 8 | b[o + 3]); }
	static void PutBE(Stream s, uint v) { s.WriteByte((byte)(v >> 24)); s.WriteByte((byte)(v >> 16)); s.WriteByte((byte)(v >> 8)); s.WriteByte((byte)v); }

	static uint[] crcTable;
	static uint Crc(byte[] type, byte[] data)
	{
		if (crcTable == null)
		{
			crcTable = new uint[256];
			for (uint n = 0; n < 256; n++)
			{
				uint c = n;
				for (int k = 0; k < 8; k++) c = ((c & 1) != 0) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
				crcTable[n] = c;
			}
		}
		uint crc = 0xFFFFFFFFu;
		foreach (byte b in type) crc = crcTable[(crc ^ b) & 0xFF] ^ (crc >> 8);
		foreach (byte b in data) crc = crcTable[(crc ^ b) & 0xFF] ^ (crc >> 8);
		return crc ^ 0xFFFFFFFFu;
	}

	// returns the pixels (rows of w * ch bytes), w, h, ch (3 or 4)
	public static byte[] PngRead(string path, out int w, out int h, out int ch)
	{
		byte[] f = File.ReadAllBytes(path);
		if (f.Length < 33 || f[1] != 'P' || f[2] != 'N' || f[3] != 'G') throw new Exception("not a PNG file: " + path);
		w = h = ch = 0;
		int depth = 0, ctype = 0, inter = 0;
		MemoryStream idat = new MemoryStream();
		int o = 8;
		while (o + 8 <= f.Length)
		{
			int len = (int)BE(f, o);
			// a cut-off or damaged file: a clear message, not "index out of range"
			if (len < 0 || o + 12 + (long)len > f.Length) throw new Exception("the PNG file is damaged or cut short: " + path);
			string t = System.Text.Encoding.ASCII.GetString(f, o + 4, 4);
			if (t == "IHDR")
			{
				w = (int)BE(f, o + 8); h = (int)BE(f, o + 12);
				depth = f[o + 16]; ctype = f[o + 17]; inter = f[o + 20];
			}
			else if (t == "IDAT") idat.Write(f, o + 8, len);
			else if (t == "IEND") break;
			o += 12 + len;
		}
		if (depth != 8 || inter != 0 || (ctype != 2 && ctype != 6)) throw new Exception("not an 8-bit RGB / RGBA PNG (" + Why(depth, ctype, inter) + "): " + path);
		ch = (ctype == 6) ? 4 : 3;
		int stride = w * ch;
		byte[] raw = new byte[(stride + 1) * h];
		idat.Position = 2;                                     // zlib header
		using (DeflateStream ds = new DeflateStream(idat, CompressionMode.Decompress))
		{
			int got = 0, n;
			while (got < raw.Length && (n = ds.Read(raw, got, raw.Length - got)) > 0) got += n;
			if (got != raw.Length) throw new Exception("PNG data too short: " + path);
		}
		byte[] pix = new byte[stride * h];
		for (int y = 0; y < h; y++)
		{
			int ft = raw[y * (stride + 1)];
			int src = y * (stride + 1) + 1, dst = y * stride, prev = dst - stride;
			for (int x = 0; x < stride; x++)
			{
				int a = x >= ch ? pix[dst + x - ch] : 0;
				int b = y > 0 ? pix[prev + x] : 0;
				int c = (x >= ch && y > 0) ? pix[prev + x - ch] : 0;
				int v = raw[src + x];
				switch (ft)
				{
					case 1: v += a; break;
					case 2: v += b; break;
					case 3: v += (a + b) >> 1; break;
					case 4:
						int p = a + b - c, pa = Math.Abs(p - a), pb = Math.Abs(p - b), pc = Math.Abs(p - c);
						v += (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c); break;
				}
				pix[dst + x] = (byte)v;
			}
		}
		return pix;
	}

	public static void PngWrite(string path, byte[] pix, int w, int h, int ch)
	{
		int stride = w * ch;
		MemoryStream z = new MemoryStream();
		z.WriteByte(0x78); z.WriteByte(0x9C);
		uint s1 = 1, s2 = 0;
		using (DeflateStream ds = new DeflateStream(z, CompressionLevel.Optimal, true))
		{
			byte[] row = new byte[stride + 1], best = new byte[stride + 1];
			for (int y = 0; y < h; y++)
			{
				// pick the filter (Sub / Up / Paeth) with the smallest sum - good compression, still quick
				long bestSum = long.MaxValue;
				for (int ft = 1; ft <= 4; ft++)
				{
					if (ft == 3) continue;
					row[0] = (byte)ft;
					long sum = 0;
					int dst = y * stride, prev = dst - stride;
					for (int x = 0; x < stride; x++)
					{
						int a = x >= ch ? pix[dst + x - ch] : 0;
						int b = y > 0 ? pix[prev + x] : 0;
						int c = (x >= ch && y > 0) ? pix[prev + x - ch] : 0;
						int pr = 0;
						if (ft == 1) pr = a; else if (ft == 2) pr = b;
						else { int p = a + b - c, pa = Math.Abs(p - a), pb = Math.Abs(p - b), pc = Math.Abs(p - c); pr = (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c); }
						byte v = (byte)(pix[dst + x] - pr);
						row[x + 1] = v;
						sum += v < 128 ? v : 256 - v;
					}
					if (sum < bestSum) { bestSum = sum; Buffer.BlockCopy(row, 0, best, 0, row.Length); }
				}
				ds.Write(best, 0, best.Length);
				for (int i = 0; i < best.Length; i++) { s1 = (s1 + best[i]) % 65521; s2 = (s2 + s1) % 65521; }
			}
		}
		PutBE(z, (s2 << 16) | s1);
		using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write))
		{
			fs.Write(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 }, 0, 8);
			MemoryStream hd = new MemoryStream();
			PutBE(hd, (uint)w); PutBE(hd, (uint)h);
			hd.WriteByte(8); hd.WriteByte((byte)(ch == 4 ? 6 : 2)); hd.WriteByte(0); hd.WriteByte(0); hd.WriteByte(0);
			Chunk(fs, "IHDR", hd.ToArray());
			Chunk(fs, "IDAT", z.ToArray());
			Chunk(fs, "IEND", new byte[0]);
		}
	}
	static void Chunk(Stream s, string type, byte[] data)
	{
		byte[] t = System.Text.Encoding.ASCII.GetBytes(type);
		PutBE(s, (uint)data.Length); s.Write(t, 0, 4); s.Write(data, 0, data.Length); PutBE(s, Crc(t, data));
	}

	// v1.7.2: what PngRead can read, from the header only. null = fine, else
	// a short reason for the player (the installer then leaves the texture
	// alone instead of stopping with a raw error). w / h = the picture size.
	public static string PngCheck(string path, out int w, out int h)
	{
		w = h = 0;
		byte[] f = new byte[33];
		int got = 0, n;
		using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
			while (got < f.Length && (n = fs.Read(f, got, f.Length - got)) > 0) got += n;
		if (got < 33 || f[0] != 137 || f[1] != 'P' || f[2] != 'N' || f[3] != 'G' || System.Text.Encoding.ASCII.GetString(f, 12, 4) != "IHDR")
			return "not a PNG file";
		w = (int)BE(f, 16); h = (int)BE(f, 20);
		int depth = f[24], ctype = f[25], inter = f[28];
		if (depth == 8 && inter == 0 && (ctype == 2 || ctype == 6)) return null;
		return Why(depth, ctype, inter);
	}
	static string Why(int depth, int ctype, int inter)
	{
		if (inter != 0) return "an interlaced PNG";
		if (ctype == 3) return "a palette PNG";
		if (ctype == 0 || ctype == 4) return "a greyscale PNG";
		if (depth != 8) return "a " + depth + "-bit PNG";
		return "an unknown kind of PNG";
	}

	static string Sha(byte[] b)
	{
		using (System.Security.Cryptography.SHA256 s = System.Security.Cryptography.SHA256.Create())
			return BitConverter.ToString(s.ComputeHash(b)).Replace("-", "");
	}
	// fingerprint of the pixels (the bytes PngRead returns), upper-case hex
	public static string PngPixelSha(string path)
	{
		int w, h, ch;
		return Sha(PngRead(path, out w, out h, out ch));
	}

	// paste tiles (PNG files) at x / y into the texture, write the result to
	// outPath. Returns the pixel fingerprint of the result (v1.7.2), so the
	// installer can check it without reading the file again.
	public static string PasteTiles(string texPath, string[] tiles, int[] xs, int[] ys, string outPath)
	{
		int w, h, ch;
		byte[] pix = PngRead(texPath, out w, out h, out ch);
		for (int k = 0; k < tiles.Length; k++)
		{
			int tw, th, tc;
			byte[] t = PngRead(tiles[k], out tw, out th, out tc);
			for (int y = 0; y < th; y++)
				for (int x = 0; x < tw; x++)
				{
					int dx = xs[k] + x, dy = ys[k] + y;
					if (dx < 0 || dy < 0 || dx >= w || dy >= h) continue;
					for (int c = 0; c < 3; c++) pix[(dy * w + dx) * ch + c] = t[(y * tw + x) * tc + c];
				}
		}
		PngWrite(outPath, pix, w, h, ch);
		return Sha(pix);
	}

	static byte[] Hex(string s)
	{
		byte[] b = new byte[s.Length / 2];
		for (int i = 0; i < b.Length; i++) b[i] = Convert.ToByte(s.Substring(2 * i, 2), 16);
		return b;
	}

	// overwrite then insert (offsets in the original file); the inserts are
	// applied from the back so the earlier offsets stay valid
	public static void EdmSplice(string src, string dst, long[] owOff, string[] owHex, long[] insOff, string[] insHex)
	{
		byte[] b = File.ReadAllBytes(src);
		for (int i = 0; i < owOff.Length; i++)
		{
			byte[] d = Hex(owHex[i]);
			Buffer.BlockCopy(d, 0, b, (int)owOff[i], d.Length);
		}
		List<KeyValuePair<long, byte[]>> ins = new List<KeyValuePair<long, byte[]>>();
		for (int i = 0; i < insOff.Length; i++) ins.Add(new KeyValuePair<long, byte[]>(insOff[i], Hex(insHex[i])));
		ins.Sort(delegate (KeyValuePair<long, byte[]> x, KeyValuePair<long, byte[]> y) { return x.Key.CompareTo(y.Key); });
		using (FileStream fs = new FileStream(dst, FileMode.Create, FileAccess.Write))
		{
			long at = 0;
			foreach (KeyValuePair<long, byte[]> kv in ins)
			{
				fs.Write(b, (int)at, (int)(kv.Key - at));
				fs.Write(kv.Value, 0, kv.Value.Length);
				at = kv.Key;
			}
			fs.Write(b, (int)at, (int)(b.Length - at));
		}
	}

	// the reverse of EdmSplice (to recover KRN's original from an earlier add-on install)
	public static void EdmUnsplice(string src, string dst, long[] owOff, string[] owOrigHex, long[] insOff, string[] insHex)
	{
		byte[] b = File.ReadAllBytes(src);
		List<KeyValuePair<long, int>> ins = new List<KeyValuePair<long, int>>();
		for (int i = 0; i < insOff.Length; i++) ins.Add(new KeyValuePair<long, int>(insOff[i], insHex[i].Length / 2));
		ins.Sort(delegate (KeyValuePair<long, int> x, KeyValuePair<long, int> y) { return x.Key.CompareTo(y.Key); });
		MemoryStream ms = new MemoryStream();
		long at = 0, shift = 0;
		foreach (KeyValuePair<long, int> kv in ins)
		{
			ms.Write(b, (int)(at + shift), (int)(kv.Key - at));
			shift += kv.Value;
			at = kv.Key;
		}
		ms.Write(b, (int)(at + shift), (int)(b.Length - at - shift));
		byte[] o = ms.ToArray();
		for (int i = 0; i < owOff.Length; i++)
		{
			byte[] d = Hex(owOrigHex[i]);
			Buffer.BlockCopy(d, 0, o, (int)owOff[i], d.Length);
		}
		File.WriteAllBytes(dst, o);
	}
}
