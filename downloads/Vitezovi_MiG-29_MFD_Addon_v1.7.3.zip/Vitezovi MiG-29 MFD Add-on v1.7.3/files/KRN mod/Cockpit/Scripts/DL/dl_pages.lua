-----------------------------------------------------------------------
-- MiG-29 DL add-on: MFD pages (indicator elements)
-- Loaded from the end of dl_page.lua, which shares its drawing helpers in
-- DLH. One root per page, shown while DL_MODE has that page's number:
--   0 MENU  4 FPAS  5 COM/NAV  6 PLAN (+ DTC)  8 HSI  9 FLT  10 RWR  11 SMS  12 NAV  13 RTE  14 PICTURE
--   15 EDIT (route editor, v1.7.2)
-- (1 is the DL situation page in dl_page.lua). Values: dl_pages_dev.lua.
-----------------------------------------------------------------------
do
	local D = DLH
	local text, text1, mesh, simple = D.text, D.text1, D.mesh, D.simple
	local M, F, TXT, TXS, G, LW, CFG = D.M, D.F, D.TXT, D.TXT_SMALL, D.G, D.LW, D.CFG
	local BX, BY, BYR = D.BX, D.BY, D.BYR       -- left / right button rows
	local RX = -BX
	local ROW = D.ROWB                          -- bottom row x
	local ROWT = D.ROWT                         -- top row x
	local YB = D.YB8                            -- bottom row labels
	local YT = D.YT8                            -- top row labels
	local TXL = {0.0060, 0.0018, 0, -0.0022}     -- large
	local TXT_T = {0.0028, 0.00085, 0, -0.0010}  -- tiny (lists)
	local LX = -0.80                            -- left edge of page text
	-- side button labels on these pages: smaller than on the SA page
	local SBS = CFG.sub_btn_label_scale or 0.72
	local TXT_SB = {D.TXT_BTN[1] * SBS, D.TXT_BTN[2] * SBS, D.TXT_BTN[3] * SBS, D.TXT_BTN[4] * SBS}
	-- with the smaller labels the rows sat a little off the buttons (measured
	-- in the cockpit): left labels up, right labels down
	-- (per row, top to bottom; + = up)
	-- (v1.6: the base rows in dl_config are measured on the buttons; these
	-- per-row nudges are 0 unless set in dl_config)
	local DYL = CFG.sub_btn_dy_left or {0, 0, 0, 0, 0}
	local DYR = CFG.sub_btn_dy_right or {0, 0, 0, 0, 0}
	local BYS, BYRS = {}, {}
	for k = 1, 5 do
		BYS[k]  = BY[k] + (DYL[k] or 0)
		BYRS[k] = BYR[k] + (DYR[k] or 0)
	end

	local function root(name, mode)
		simple(name, nil, {0, 0, 0}, {"DL_PAGE", "DL_MODE"},
			{{"parameter_in_range", 0, 0.5, 2.5}, {"parameter_in_range", 1, mode - 0.1, mode + 0.1}})
		mesh(name .. "_bg", name, "triangles", {{-1.1, 1.6}, {1.1, 1.6}, {1.1, -1.6}, {-1.1, -1.6}}, {0, 1, 2, 0, 2, 3}, M.black)
	end
	local function lbl_left(r, k, s, f) text(r .. "_l" .. k, r, {BX, BYS[k], 0}, f or F.white, TXT_SB, "LeftCenter", s) end
	local function lbl_right(r, k, s, f) text(r .. "_r" .. k, r, {RX, BYRS[k], 0}, f or F.white, TXT_SB, "RightCenter", s) end
	local function menu_btn(r) text(r .. "_menu", r, {ROW[3], YB, 0}, F.white, TXS, "CenterCenter", "MENU") end
	-- Eurofighter-style framing: thin outlined boxes around titles and headers
	local function cw(defs) return (D.char_w and D.TEXF) and D.char_w(defs) or 0.062 end
	local function box(r, n, cx, cy, w, h, mat)
		local t = LW
		local x0, x1, y0, y1 = cx - w / 2, cx + w / 2, cy - h / 2, cy + h / 2
		local v = {{x0, y1}, {x1, y1}, {x1, y1 - t}, {x0, y1 - t},  {x0, y0 + t}, {x1, y0 + t}, {x1, y0}, {x0, y0},
		           {x0, y1}, {x0 + t, y1}, {x0 + t, y0}, {x0, y0},  {x1 - t, y1}, {x1, y1}, {x1, y0}, {x1 - t, y0}}
		local idx = {}
		for q = 0, 3 do local b = q * 4; for _, k in ipairs({0, 1, 2, 0, 2, 3}) do idx[#idx + 1] = b + k end end
		mesh(r .. "_" .. n, r, "triangles", v, idx, mat or M.white)
	end
	-- text in a box; align "LeftCenter" (x = left edge of the box) or "CenterCenter"
	local function boxed(r, n, x, y, s, f, defs, mat, align)
		defs = defs or TXS
		local w = #s * cw(defs) + 0.07
		local cx = (align == "LeftCenter") and (x + w / 2) or x
		text(r .. "_" .. n, r, {cx, y, 0}, f or F.white, defs, "CenterCenter", s)
		box(r, n .. "_box", cx, y, w, defs[1] / G * 1.0 + 0.035, mat)
	end
	local function title(r, s) boxed(r, "title", 0, 1.22, s, F.white, TXT, M.white) end
	local function line(r, n, x, y, param, f, defs, align, vis)
		return text1(r .. "_" .. n, r, {x, y, 0}, f or F.white, defs or TXS, align or "LeftCenter", nil, param, vis)
	end
	-- a parameter text shown with its own format (fmt, e.g. "%.0f" for a
	-- number). text1 always uses "%s" and adds the element at once, and DCS
	-- takes the element as it is when it is added, so changing e.formats
	-- afterwards does nothing: the format has to be set before Add. Font,
	-- size, alignment and position are copied from "like", a text1 element
	-- made the same way (text1's size table is private to dl_page.lua).
	local function num_text(like, name, parent, param, vis, fmt)
		local e = CreateElement "ceStringPoly"
		e.name            = name
		e.material        = like.material
		e.init_pos        = {like.init_pos[1], like.init_pos[2], like.init_pos[3]}
		e.alignment       = like.alignment
		e.stringdefs      = like.stringdefs
		e.parent_element  = parent
		e.h_clip_relation = like.h_clip_relation
		e.level           = like.level
		e.formats         = {fmt}
		local params, ctrls = {param}, {{"text_using_parameter", 0}}
		if vis then
			params[2] = vis[1]
			ctrls[2] = {"parameter_in_range", 1, vis[2], vis[3]}
		end
		e.element_params = params
		e.controllers    = ctrls
		Add(e)
		return e
	end
	local function hline(r, n, y, x0, x1)
		x0, x1 = x0 or -0.8, x1 or 0.8
		mesh(r .. "_" .. n, r, "triangles", {{x0, y + LW / 2}, {x1, y + LW / 2}, {x1, y - LW / 2}, {x0, y - LW / 2}}, {0, 1, 2, 0, 2, 3}, M.blue)
	end

	-------------------------------------------------------------------
	-- 0 MENU
	-------------------------------------------------------------------
	root("dlp_menu", 0)
	boxed("dlp_menu", "t1", 0, 1.13, "MIG-29 WW", F.white, TXL, M.white)
	text("dlp_menu_t2", "dlp_menu", {0, 0.96, 0}, F.amber, TXS, "CenterCenter", "UPGRADE PROGRAM")
	-- squadron badge (127th Vitezovi FAS "Wild Wolves"), green MFD rendition
	do
		local half = (CFG.logo_size or 1.5) / 2
		local cy = CFG.logo_center_y or -0.02
		local e = CreateElement "ceTexPoly"
		e.name            = "dlp_menu_logo"
		e.primitivetype   = "triangles"
		e.vertices        = {{-half, cy + half}, {half, cy + half}, {half, cy - half}, {-half, cy - half}}
		e.indices         = {0, 1, 2, 0, 2, 3}
		e.tex_coords      = {{0, 0}, {1, 0}, {1, 1}, {0, 1}}
		e.material        = "MIG29_DL_LOGO"
		e.init_pos        = {0, 0, 0}
		e.parent_element  = "dlp_menu"
		e.h_clip_relation = D.CLIP
		e.level           = D.LVL
		Add(e)
	end
	text1("dlp_menu_stat", "dlp_menu", {0, -1.18, 0}, F.white, TXS, "CenterCenter", nil, "DLP_MENU_STAT")
	-- left: navigation, right: aircraft / combat (4 + 4)
	lbl_left("dlp_menu", 1, "SA"); lbl_left("dlp_menu", 2, "NAV"); lbl_left("dlp_menu", 3, "HSI"); lbl_left("dlp_menu", 4, "COM/NAV")
	lbl_right("dlp_menu", 1, "FPAS"); lbl_right("dlp_menu", 2, "SMS"); lbl_right("dlp_menu", 3, "FLT")
	local RWR_ON = CFG.opt_rwr ~= false                    -- DCS Options > Special
	local LAUNCH_ON = RWR_ON and CFG.opt_launch ~= false
	if RWR_ON then lbl_right("dlp_menu", 4, "RWR") end

	-------------------------------------------------------------------
	-- 6 PLAN: the flight plan (view 0) and the data cartridges (view 1,
	-- left 1 LOAD). DLP_PLAN_VIEW picks the view.
	-------------------------------------------------------------------
	local function sub(name, parent, param, lo, hi)
		simple(name, parent, {0, 0, 0}, {param}, {{"parameter_in_range", 0, lo, hi}})
	end
	root("dlp_fpl", 6)
	sub("dlp_fplv", "dlp_fpl", "DLP_PLAN_VIEW", -0.5, 0.5)
	sub("dlp_dtc", "dlp_fpl", "DLP_PLAN_VIEW", 0.5, 1.5)
	-- route view
	title("dlp_fplv", "FLIGHT PLAN")
	line("dlp_fplv", "src", 0, 1.08, "DLP_FPL_SRC", F.grey, TXS, "CenterCenter")
	text("dlp_fplv_hd", "dlp_fplv", {LX, 0.92, 0}, F.blue, TXT_T, "LeftCenter", "PT  NAME          ETA         FUEL")
	for i = 1, 10 do
		local y = 0.80 - (i - 1) * 0.12
		line("dlp_fplv", "w" .. i, LX, y, "DLP_FPL_L" .. i, F.white, TXS, "LeftCenter", {"DLP_FPL_A" .. i, 0.5, 1.5})
		line("dlp_fplv", "wy" .. i, LX, y, "DLP_FPL_L" .. i, F.amber, TXS, "LeftCenter", {"DLP_FPL_A" .. i, 1.5, 2.5})
		line("dlp_fplv", "wc" .. i, LX, y, "DLP_FPL_L" .. i, F.cyan, TXS, "LeftCenter", {"DLP_FPL_A" .. i, 2.5, 3.5})
		line("dlp_fplv", "wg" .. i, LX, y, "DLP_FPL_L" .. i, F.grey, TXS, "LeftCenter", {"DLP_FPL_A" .. i, 3.5, 4.5})
		-- DLP_FPL_T: 1 = has a TOT, 2 = PT cursor, 3 = both
		text("dlp_fplv_tot" .. i, "dlp_fplv", {0.66, y, 0}, F.red, TXT_T, "LeftCenter", "TOT", nil, {"DLP_FPL_T" .. i, 0.5, 1.5})
		text("dlp_fplv_totc" .. i, "dlp_fplv", {0.66, y, 0}, F.red, TXT_T, "LeftCenter", "TOT", nil, {"DLP_FPL_T" .. i, 2.5, 3.5})
		text("dlp_fplv_cur" .. i, "dlp_fplv", {0.86, y, 0}, F.white, TXS, "LeftCenter", "<", nil, {"DLP_FPL_T" .. i, 1.5, 3.5})
	end
	-------------------------------------------------------------------
	-- time on target: TOT line, required / ground speed, speed cue
	-- (box = speed for the TOT, caret = ground speed), fuel at the TOT
	-- point and at the last steerpoint. Hint / keypad entry when no TOT.
	-------------------------------------------------------------------
	local function tot_block(PR, DY)
		hline(PR, "tsep", (-0.38 + DY), -0.85, 0.85)
		line(PR, "thint", LX, (-0.46 + DY), "DLP_TOT_HINT", F.grey, TXS, "LeftCenter", {"DLP_TOT_ON", -0.5, 0.5})
		sub("dlp_tot", PR, "DLP_TOT_ON", 0.5, 1.5)
		line("dlp_tot", "l1", LX, (-0.46 + DY), "DLP_TOT_L1", F.red, TXS)
		for c, f in ipairs({F.green, F.amber, F.red}) do
			line("dlp_tot", "st" .. c, -LX, (-0.46 + DY), "DLP_TOT_ST", f, TXS, "RightCenter", {"DLP_TOT_C", c - 0.5, c + 0.5})
		end
		line("dlp_tot", "spd", LX, (-0.57 + DY), "DLP_TOT_SPD", F.white, TXS)
		do
			local x0, x1, yb = -0.70, 0.70, (-0.76 + DY)
			mesh("dlp_tot_scale", "dlp_tot", "triangles", {{x0, yb + LW / 2}, {x1, yb + LW / 2}, {x1, yb - LW / 2}, {x0, yb - LW / 2}}, {0, 1, 2, 0, 2, 3}, M.white)
			local tv, ti = {}, {}
			for k = 0, 8 do
				local x = x0 + (x1 - x0) * k / 8
				local h = (k % 2 == 0) and 0.045 or 0.025
				local b = #tv
				tv[b + 1] = {x - LW / 2, yb}; tv[b + 2] = {x + LW / 2, yb}; tv[b + 3] = {x + LW / 2, yb + h}; tv[b + 4] = {x - LW / 2, yb + h}
				for _, q in ipairs({0, 1, 2, 0, 2, 3}) do ti[#ti + 1] = b + q end
			end
			mesh("dlp_tot_ticks", "dlp_tot", "triangles", tv, ti, M.white)
			text("dlp_tot_slow", "dlp_tot", {x0, (-0.66 + DY), 0}, F.grey, TXT_T, "LeftCenter", "SLOW")
			text("dlp_tot_fast", "dlp_tot", {x1, (-0.66 + DY), 0}, F.grey, TXT_T, "RightCenter", "FAST")
			-- required speed: green box above the scale
			simple("dlp_tot_req", "dlp_tot", {0, 0, 0}, {"DLP_TOT_RX", "DLP_TOT_RV"}, {{"move_left_right_using_parameter", 0, G}, {"parameter_in_range", 1, 0.5, 1.5}})
			box("dlp_tot_req", "box", 0, yb + 0.055, 0.05, 0.07, M.friend or M.white)
			-- ground speed: cyan caret under the scale
			simple("dlp_tot_gs", "dlp_tot", {0, 0, 0}, {"DLP_TOT_GX", "DLP_TOT_GV"}, {{"move_left_right_using_parameter", 0, G}, {"parameter_in_range", 1, 0.5, 1.5}})
			mesh("dlp_tot_caret", "dlp_tot_gs", "triangles", {{0, yb - 0.01}, {0.035, yb - 0.075}, {-0.035, yb - 0.075}}, {0, 1, 2}, M.own)
		end
		line("dlp_tot", "then", LX, (-0.91 + DY), "DLP_TOT_THEN", F.white, TXS)
		line("dlp_tot", "fuel", LX, (-1.01 + DY), "DLP_TOT_FUEL", F.white, TXS, "LeftCenter", {"DLP_TOT_FC", 0.5, 1.5})
		line("dlp_tot", "fuela", LX, (-1.01 + DY), "DLP_TOT_FUEL", F.amber, TXS, "LeftCenter", {"DLP_TOT_FC", 1.5, 2.5})
	end
	lbl_left("dlp_fplv", 1, "LOAD"); lbl_left("dlp_fplv", 2, "TOT"); lbl_left("dlp_fplv", 3, "PT"); lbl_left("dlp_fplv", 4, "CLR")
	-- cartridge view: R1-R5 load (then back to the route), B1/B2 page
	line("dlp_dtc", "title", 0, 1.22, "DLP_DTC_TITLE", F.white, TXS, "CenterCenter")
	hline("dlp_dtc", "tl", 1.14, -0.85, 0.85)
	for k = 1, 5 do
		line("dlp_dtc", "i" .. k, RX - 0.1, BYRS[k], "DLP_DTC_I" .. k, F.white, TXS, "RightCenter", {"DLP_DTC_M" .. k, 0.5, 1.5})
		line("dlp_dtc", "iy" .. k, RX - 0.1, BYRS[k], "DLP_DTC_I" .. k, F.amber, TXS, "RightCenter", {"DLP_DTC_M" .. k, 1.5, 2.5})
		text("dlp_dtc_ar" .. k, "dlp_dtc", {RX, BYRS[k], 0}, F.white, TXS, "RightCenter", "<", nil, {"DLP_DTC_M" .. k, 0.5, 2.5})
	end
	hline("dlp_dtc", "bl", -0.84, -0.85, 0.85)
	for i = 1, 3 do line("dlp_dtc", "d" .. i, LX, -0.91 - (i - 1) * 0.09, "DLP_DTC_D" .. i, (i == 1) and F.amber or F.white) end
	line("dlp_dtc", "pg", (ROW[4] + ROW[5]) / 2, YB, "DLP_DTC_PAGE", F.grey, TXS, "CenterCenter")
	text("dlp_dtc_b1", "dlp_dtc", {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "PREV")
	text("dlp_dtc_b2", "dlp_dtc", {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "NEXT")
	lbl_left("dlp_dtc", 1, "BACK"); lbl_left("dlp_dtc", 2, "RFSH")
	menu_btn("dlp_fpl")

	-------------------------------------------------------------------
	-- 4 FPAS: fuel (like the Hornet's FPAS), bingo / home, engines
	-------------------------------------------------------------------
	root("dlp_fuel", 4)
	title("dlp_fuel", "FPAS")
	do
		local FX = -0.62                      -- clear of the BINGO / HOME labels
		local y = 1.02
		local function L(n, param, f, d, vis) line("dlp_fuel", n, FX, y, param, f, d, nil, vis); y = y - 0.10 end
		local function H(n, s) y = y - 0.02; boxed("dlp_fuel", n, FX, y, s, F.amber, TXS, M.amber, "LeftCenter"); hline("dlp_fuel", n .. "_hl", y, FX + #s * cw(TXS) + 0.1, 0.84); y = y - 0.13 end
		L("tot", "DLP_FUEL_TOT", F.white, TXL); y = y - 0.03
		L("int", "DLP_FUEL_INT", F.grey)
		L("flow", "DLP_FUEL_FLOW", F.white)
		H("cur", "CURRENT")
		L("to", "DLP_FUEL_TO", F.amber)
		L("torng", "DLP_FUEL_TO_RNG", F.white)
		L("sr", "DLP_FUEL_SR", F.white)
		H("best", "BEST RANGE   (ESTIMATE)")
		L("b1", "DLP_FUEL_B1", F.white)
		L("b2", "DLP_FUEL_B2", F.white)
		L("b4", "DLP_FUEL_B4", F.grey)
		H("end", "BEST ENDURANCE")
		L("b3", "DLP_FUEL_B3", F.white)
		L("res", "DLP_FUEL_RES", F.grey)
		H("bngh", "BINGO / HOME")
		line("dlp_fuel", "bngr", FX, y, "DLP_FUEL_BNG", F.red, TXS, nil, {"DLP_BINGO_WARN", 0.5, 1.5})
		L("bng", "DLP_FUEL_BNG", F.white, nil, {"DLP_BINGO_WARN", -0.5, 0.5})
		L("home", "DLP_FUEL_HOME", F.white)
		L("need", "DLP_FUEL_NEED", F.white)
		L("harr", "DLP_FUEL_HARR", F.grey)
	end
	-- engines, top right next to the fuel total: what the sim gives on this jet
	-- (RPM, EGT left / right); EGT red when it is over egt_warn
	line("dlp_fuel", "rpm", 0.84, 1.03, "DLP_FUEL_ENG", F.white, TXS, "RightCenter")
	line("dlp_fuel", "egt", 0.84, 0.93, "DLP_FUEL_EGT", F.white, TXS, "RightCenter", {"DLP_FUEL_EGTW", -0.5, 0.5})
	line("dlp_fuel", "egtr", 0.84, 0.93, "DLP_FUEL_EGT", F.red, TXS, "RightCenter", {"DLP_FUEL_EGTW", 0.5, 1.5})
	lbl_left("dlp_fuel", 1, "BINGO"); lbl_left("dlp_fuel", 2, "HOME")
	menu_btn("dlp_fuel")

	-------------------------------------------------------------------
	-- 5 COM / NAV: R-862 and its presets, RSBN / ILS / ADF / GCI channels,
	-- the nearest RSBN / PRMG stations (all read from the jet's own knobs)
	-------------------------------------------------------------------
	root("dlp_rdo", 5)
	title("dlp_rdo", "COM / NAV")
	line("dlp_rdo", "freq", 0, 1.08, "DLP_RDO_FREQ", F.amber, TXS, "CenterCenter")
	line("dlp_rdo", "src", 0, 0.99, "DLP_RDO_SRC", F.grey, TXT_T, "CenterCenter")
	hline("dlp_rdo", "sep", 0.92)
	for i = 1, 20 do
		local x = (i <= 10) and -0.72 or 0.06
		local y = 0.84 - ((i - 1) % 10) * 0.088
		line("dlp_rdo", "c" .. i, x, y, "DLP_RDO_C" .. i, F.white, TXS, "LeftCenter", {"DLP_RDO_S" .. i, -0.5, 0.5})
		line("dlp_rdo", "cy" .. i, x, y, "DLP_RDO_C" .. i, F.amber, TXS, "LeftCenter", {"DLP_RDO_S" .. i, 0.5, 1.5})
	end
	hline("dlp_rdo", "sep2", -0.03)
	line("dlp_rdo", "rsbn", LX, -0.12, "DLP_RSBN_SEL", F.amber, TXS)
	line("dlp_rdo", "ils", LX, -0.22, "DLP_RSBN_ILS", F.amber, TXS)
	line("dlp_rdo", "adf", LX, -0.32, "DLP_RDO_ADF", F.white, TXS)
	line("dlp_rdo", "kru", LX, -0.42, "DLP_RDO_KRU", F.white, TXS)
	hline("dlp_rdo", "sep3", -0.50)
	text("dlp_rdo_hd", "dlp_rdo", {LX, -0.58, 0}, F.blue, TXT_T, "LeftCenter", "NEAREST  CH ID  STATION       BRG DIST")
	for i = 1, 5 do
		local y = -0.68 - (i - 1) * 0.095
		line("dlp_rdo", "r" .. i, LX, y, "DLP_RSBN_L" .. i, F.white, TXT_T, "LeftCenter", {"DLP_RSBN_A" .. i, 0.5, 1.5})
		line("dlp_rdo", "ry" .. i, LX, y, "DLP_RSBN_L" .. i, F.amber, TXT_T, "LeftCenter", {"DLP_RSBN_A" .. i, 1.5, 2.5})
	end
	menu_btn("dlp_rdo")

	-------------------------------------------------------------------
	-- 8 HSI (NATO style): rose, heading bug, course + deviation bar,
	-- pointer 1 = steerpoint (green), pointer 2 = TACAN (yellow)
	-------------------------------------------------------------------
	root("dlp_hsi", 8)
	do
		local CY = CFG.hsi_center_y or -0.05
		local R = CFG.hsi_radius or 0.74
		simple("dlp_hsi_c", "dlp_hsi", {0, CY, 0})
		-- rose: ring and ticks, turned with heading
		local v, i = D.circle_ring(R, LW, 96)
		mesh("dlp_hsi_ring", "dlp_hsi_c", "triangles", v, i, M.white)
		simple("dlp_hsi_rot", "dlp_hsi_c", {0, 0, 0}, {"DLP_HSI_ROT"}, {{"rotate_using_parameter", 0, 1}})
		do
			local tv, ti = {}, {}
			for deg = 0, 355, 5 do
				local len = (deg % 30 == 0) and 0.09 or ((deg % 10 == 0) and 0.06 or 0.035)
				local a = math.rad(90 - deg)
				local ca, sa = math.cos(a), math.sin(a)
				local px, py = -sa * LW / 2, ca * LW / 2
				local r0, r1 = R - len, R
				local k = #tv
				tv[k + 1] = {r0 * ca + px, r0 * sa + py}; tv[k + 2] = {r1 * ca + px, r1 * sa + py}
				tv[k + 3] = {r1 * ca - px, r1 * sa - py}; tv[k + 4] = {r0 * ca - px, r0 * sa - py}
				ti[#ti + 1] = k; ti[#ti + 1] = k + 1; ti[#ti + 1] = k + 2
				ti[#ti + 1] = k; ti[#ti + 1] = k + 2; ti[#ti + 1] = k + 3
			end
			mesh("dlp_hsi_ticks", "dlp_hsi_rot", "triangles", tv, ti, M.white)
		end
		local names = {"N", "3", "6", "E", "12", "15", "S", "21", "24", "W", "30", "33"}
		for k = 0, 11 do
			simple("dlp_hsi_lb" .. k, "dlp_hsi_c", {0, 0, 0}, {"DLP_HSI_L" .. k .. "_X", "DLP_HSI_L" .. k .. "_Y"},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})
			text("dlp_hsi_lt" .. k, "dlp_hsi_lb" .. k, {0, 0, 0}, (k % 3 == 0) and F.white or F.grey, TXS, "CenterCenter", names[k + 1])
		end
		-- lubber line, heading box, aircraft
		mesh("dlp_hsi_lub", "dlp_hsi_c", "triangles", {{-0.03, R + 0.06}, {0.03, R + 0.06}, {0, R + 0.005}}, {0, 1, 2}, M.white)
		line("dlp_hsi", "hdg", 0, CY + R + 0.15, "DLP_HSI_HDG", F.white, TXT, "CenterCenter")
		do
			local av, ai = D.poly_lines({{0, 0.09}, {0.012, 0.03}, {0.07, 0.0}, {0.07, -0.014}, {0.01, -0.005},
				{0.008, -0.05}, {0.03, -0.065}, {0, -0.06}, {-0.03, -0.065}, {-0.008, -0.05},
				{-0.01, -0.005}, {-0.07, -0.014}, {-0.07, 0.0}, {-0.012, 0.03}})
			mesh("dlp_hsi_ac", "dlp_hsi_c", "lines", av, ai, M.own)
		end
		-- heading bug (yellow notch on the rose)
		simple("dlp_hsi_bug", "dlp_hsi_c", {0, 0, 0}, {"DLP_HSI_BUGR"}, {{"rotate_using_parameter", 0, 1}})
		mesh("dlp_hsi_bugm", "dlp_hsi_bug", "triangles",
			{{-0.05, R + 0.01}, {-0.02, R + 0.01}, {-0.02, R - 0.04}, {0.02, R - 0.04}, {0.02, R + 0.01}, {0.05, R + 0.01}, {0.05, R - 0.07}, {-0.05, R - 0.07}},
			{0, 1, 7, 1, 2, 7, 2, 6, 7, 2, 3, 6, 3, 5, 6, 3, 4, 5}, M.unknown)
		-- course arrow with the deviation bar
		simple("dlp_hsi_crs", "dlp_hsi_c", {0, 0, 0}, {"DLP_HSI_CRSR"}, {{"rotate_using_parameter", 0, 1}})
		local w = LW * 1.4
		local function rect(n, par, x0, y0, x1, y1, mat, params, ctrls)
			mesh(n, par, "triangles", {{x0, y1}, {x1, y1}, {x1, y0}, {x0, y0}}, {0, 1, 2, 0, 2, 3}, mat, nil, params, ctrls)
		end
		rect("dlp_hsi_crs_h", "dlp_hsi_crs", -w, 0.36, w, R - 0.12, M.wing)
		mesh("dlp_hsi_crs_a", "dlp_hsi_crs", "triangles", {{0, R - 0.04}, {0.05, R - 0.13}, {-0.05, R - 0.13}}, {0, 1, 2}, M.wing)
		rect("dlp_hsi_crs_t", "dlp_hsi_crs", -w, -(R - 0.12), w, -0.36, M.wing)
		for _, dx in ipairs({-0.30, -0.15, 0.15, 0.30}) do
			local dv, di = D.circle_ring(0.018, LW, 12)
			for _, p in ipairs(dv) do p[1] = p[1] + dx end
			mesh("dlp_hsi_dot" .. tostring(dx), "dlp_hsi_crs", "triangles", dv, di, M.white)
		end
		simple("dlp_hsi_cdi", "dlp_hsi_crs", {0, 0, 0}, {"DLP_HSI_CDI"}, {{"move_left_right_using_parameter", 0, G * 0.30}})
		rect("dlp_hsi_cdib", "dlp_hsi_cdi", -w, -0.33, w, 0.33, M.wing)
		-- bearing pointers
		local function pointer(n, rot, vis, mat, double)
			simple(n, "dlp_hsi_c", {0, 0, 0}, {rot, vis},
				{{"rotate_using_parameter", 0, 1}, {"parameter_in_range", 1, 0.5, 1.5}})
			local off = double and {-0.025, 0.025} or {0}
			for j, ox in ipairs(off) do
				rect(n .. "_h" .. j, n, ox - LW / 2, R - 0.30, ox + LW / 2, R - 0.06, mat)
				rect(n .. "_t" .. j, n, ox - LW / 2, -(R - 0.06), ox + LW / 2, -(R - 0.25), mat)
			end
			mesh(n .. "_a", n, "triangles", {{0, R - 0.02}, {0.05, R - 0.10}, {-0.05, R - 0.10}}, {0, 1, 2}, mat)
		end
		pointer("dlp_hsi_p1", "DLP_HSI_B1R", "DLP_HSI_B1V", M.friend, false)
		pointer("dlp_hsi_p2", "DLP_HSI_B2R", "DLP_HSI_B2V", M.unknown, true)
		-- readouts
		line("dlp_hsi", "stp1", LX, 1.2, "DLP_HSI_STP1", F.green, TXS)
		line("dlp_hsi", "stp2", LX, 1.1, "DLP_HSI_STP2", F.green, TXS)
		line("dlp_hsi", "tcn1", -LX, 1.2, "DLP_HSI_TCN1", F.amber, TXS, "RightCenter")
		line("dlp_hsi", "tcn2", -LX, 1.1, "DLP_HSI_TCN2", F.amber, TXS, "RightCenter")
		line("dlp_hsi", "bugt", -LX, -1.02, "DLP_HSI_BUG", F.amber, TXS, "RightCenter")
		line("dlp_hsi", "crst", -LX, -1.12, "DLP_HSI_CRS", F.cyan, TXS, "RightCenter")
		line("dlp_hsi", "entry", LX, -1.07, "DLP_HSI_ENTRY", F.amber, TXT, "LeftCenter")
	end
	lbl_left("dlp_hsi", 1, "HDG"); lbl_left("dlp_hsi", 2, "CRS"); lbl_left("dlp_hsi", 3, "TCN")
	lbl_left("dlp_hsi", 4, "STP"); lbl_left("dlp_hsi", 5, "SYNC")
	-- right 1: TACAN off (only while a channel is set)
	text("dlp_hsi_r1", "dlp_hsi", {RX, BYRS[1], 0}, F.white, TXT_SB, "RightCenter", "TCN\nOFF", nil, {"DLP_HSI_TCNON", 0.5, 1.5})
	menu_btn("dlp_hsi")

	-------------------------------------------------------------------
	-- 12 NAV: steering to the selected steerpoint (route leg, cross-track,
	-- command track), the route list with TOTs, the TOT block and the
	-- cartridge loading (R1 LOAD -> the cartridge list of page 6).
	-- Values: upd_nav / upd_tot in dl_pages_dev.
	-------------------------------------------------------------------
	root("dlp_nav", 12)
	do
		local r = "dlp_nav"
		title(r, "NAV")
		line(r, "src", 0, 1.10, "DLP_NAV_SRC", F.grey, TXS, "CenterCenter")
		line(r, "stp", LX, 1.00, "DLP_NAV_STP", F.green, TXS)
		line(r, "brg", LX, 0.91, "DLP_NAV_BRG", F.white, TXS)
		line(r, "time", LX, 0.82, "DLP_NAV_TIME", F.white, TXS)
		line(r, "leg", LX, 0.73, "DLP_NAV_LEG", F.cyan, TXS)
		-- steering bar: scale = +-45 deg from the nose, diamond = command track
		local SY, SW = 0.55, 0.60
		mesh(r .. "_sbar", r, "triangles", {{-SW, SY + LW / 2}, {SW, SY + LW / 2}, {SW, SY - LW / 2}, {-SW, SY - LW / 2}}, {0, 1, 2, 0, 2, 3}, M.white)
		do
			local tv, ti = {}, {}
			for k = -4, 4 do
				local x = SW * k / 4
				local hh = (k == 0) and 0.07 or ((k % 2 == 0) and 0.045 or 0.028)
				local b = #tv
				tv[b + 1] = {x - LW / 2, SY - hh}; tv[b + 2] = {x + LW / 2, SY - hh}; tv[b + 3] = {x + LW / 2, SY}; tv[b + 4] = {x - LW / 2, SY}
				for _, q in ipairs({0, 1, 2, 0, 2, 3}) do ti[#ti + 1] = b + q end
			end
			mesh(r .. "_sticks", r, "triangles", tv, ti, M.white)
		end
		-- fixed nose marker under the centre, moving command diamond above the bar
		mesh(r .. "_snose", r, "triangles", {{0, SY - 0.075}, {0.04, SY - 0.13}, {-0.04, SY - 0.13}}, {0, 1, 2}, M.white)
		simple(r .. "_sdia", r, {0, SY, 0}, {"DLP_NAV_STEER", "DLP_NAV_SV"},
			{{"move_left_right_using_parameter", 0, G * SW}, {"parameter_in_range", 1, 0.5, 1.5}})
		mesh(r .. "_sdiam", r .. "_sdia", "triangles", {{0, 0.11}, {0.04, 0.06}, {0, 0.01}, {-0.04, 0.06}}, {0, 1, 2, 0, 2, 3}, M.friend)
		text(r .. "_sl", r, {-SW, SY + 0.07, 0}, F.grey, TXT_T, "LeftCenter", "L")
		text(r .. "_sr", r, {SW, SY + 0.07, 0}, F.grey, TXT_T, "RightCenter", "R")
		line(r, "cmd", 0, 0.36, "DLP_NAV_CMD", F.green, TXS, "CenterCenter")
		hline(r, "sep1", 0.29, -0.85, 0.85)
		-- same font as the rows so the columns line up (row format "%-4s %-8s %s %6s %s")
		text(r .. "_hd", r, {LX, 0.21, 0}, F.blue, TXS, "LeftCenter", "PT   NAME     BRG    DIST  ETA")
		for i = 1, 5 do
			local y = 0.12 - (i - 1) * 0.10
			for c, f in ipairs({F.white, F.green, F.cyan, F.grey}) do
				line(r, "w" .. i .. "_" .. c, LX, y, "DLP_NAV_L" .. i, f, TXS, "LeftCenter", {"DLP_NAV_C" .. i, c - 0.5, c + 0.5})
			end
			-- DLP_NAV_T: 1 = has a TOT, 2 = PT cursor, 3 = both
			text(r .. "_tot" .. i, r, {0.62, y, 0}, F.red, TXT_T, "LeftCenter", "TOT", nil, {"DLP_NAV_T" .. i, 0.5, 1.5})
			text(r .. "_totc" .. i, r, {0.62, y, 0}, F.red, TXT_T, "LeftCenter", "TOT", nil, {"DLP_NAV_T" .. i, 2.5, 3.5})
			text(r .. "_cur" .. i, r, {0.80, y, 0}, F.white, TXS, "LeftCenter", "<", nil, {"DLP_NAV_T" .. i, 1.5, 3.5})
		end
		-- bottom block (R5 switches): time on target, or RSBN stations
		sub("dlp_nav_tb", r, "DLP_NAV_VIEW", -0.5, 0.5)
		tot_block("dlp_nav_tb", 0.03)
		sub("dlp_nav_rb", r, "DLP_NAV_VIEW", 0.5, 1.5)
		hline("dlp_nav_rb", "rsep", -0.35, -0.85, 0.85)
		text("dlp_nav_rb_hd", "dlp_nav_rb", {LX, -0.43, 0}, F.blue, TXS, "LeftCenter", "STN CH STATION    BRG  RNG")
		for i = 1, 4 do
			local y = -0.53 - (i - 1) * 0.10
			for c, f in ipairs({F.white, F.green, F.cyan, F.grey}) do
				line("dlp_nav_rb", "r" .. i .. "_" .. c, LX, y, "DLP_NAV_R" .. i, f, TXS, "LeftCenter", {"DLP_NAV_RC" .. i, c - 0.5, c + 0.5})
			end
		end
		line("dlp_nav_rb", "rsel", LX, -0.97, "DLP_NAV_RSEL", F.green, TXS)
		-- sequencing mode, or (amber) the ADD waypoint entry / a message
		line(r, "seq", LX, -1.08, "DLP_NAV_SEQ", F.grey, TXS, "LeftCenter", {"DLP_NAV_ADD", -0.5, 0.5})
		line(r, "seqa", LX, -1.08, "DLP_NAV_SEQ", F.amber, TXS, "LeftCenter", {"DLP_NAV_ADD", 0.5, 1.5})
	end
	lbl_left("dlp_nav", 1, "PREV"); lbl_left("dlp_nav", 2, "NEXT")
	text("dlp_nav_l3a", "dlp_nav", {BX, BYS[3], 0}, F.white, TXT_SB, "LeftCenter", "AUTO", nil, {"DLP_NAV_AUTO", 0.5, 1.5})
	text("dlp_nav_l3m", "dlp_nav", {BX, BYS[3], 0}, F.amber, TXT_SB, "LeftCenter", "MAN", nil, {"DLP_NAV_AUTO", -0.5, 0.5})
	lbl_left("dlp_nav", 4, "DIR"); lbl_left("dlp_nav", 5, "RTE")
	lbl_right("dlp_nav", 1, "LOAD"); lbl_right("dlp_nav", 2, "TOT"); lbl_right("dlp_nav", 3, "PT"); lbl_right("dlp_nav", 4, "CLR")
	text("dlp_nav_r5r", "dlp_nav", {RX, BYRS[5], 0}, F.white, TXT_SB, "RightCenter", "RSBN", nil, {"DLP_NAV_VIEW", -0.5, 0.5})
	text("dlp_nav_r5t", "dlp_nav", {RX, BYRS[5], 0}, F.white, TXT_SB, "RightCenter", "TOT", nil, {"DLP_NAV_VIEW", 0.5, 1.5})
	-- bottom 1 ADD (typed-in waypoint: lat/long, again = MGRS), bottom 2 DEL
	text("dlp_nav_b1", "dlp_nav", {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "ADD")
	text("dlp_nav_b2", "dlp_nav", {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "DEL")
	text("dlp_nav_b4", "dlp_nav", {ROW[4], YB, 0}, F.white, TXS, "CenterCenter", "EDIT")
	menu_btn("dlp_nav")

	-------------------------------------------------------------------
	-- 13 RTE: pick the route points to fly (from NAV left 5). Right 1-5
	-- add / remove a point (flown in the order picked), left 1-4 flight
	-- member routes (note tags), left 5 DONE, bottom PREV NEXT CLR ALL.
	-------------------------------------------------------------------
	root("dlp_rte", 13)
	do
		local r = "dlp_rte"
		line(r, "title", 0, 1.22, "DLP_RTE_TITLE", F.white, TXS, "CenterCenter")
		hline(r, "tl", 1.14, -0.85, 0.85)
		line(r, "sum", LX, 1.05, "DLP_RTE_SUM", F.green, TXS)
		line(r, "mem", LX, 0.95, "DLP_RTE_MEM", F.grey, TXS)
		for k = 1, 5 do
			line(r, "r" .. k, RX - 0.1, BYRS[k], "DLP_RTE_R" .. k, F.white, TXS, "RightCenter", {"DLP_RTE_C" .. k, 0.5, 1.5})
			line(r, "rg" .. k, RX - 0.1, BYRS[k], "DLP_RTE_R" .. k, F.green, TXS, "RightCenter", {"DLP_RTE_C" .. k, 1.5, 2.5})
			text(r .. "_ar" .. k, r, {RX, BYRS[k], 0}, F.white, TXS, "RightCenter", "<", nil, {"DLP_RTE_C" .. k, 0.5, 2.5})
		end
		for k = 1, 4 do
			text1(r .. "_m" .. k, r, {BX, BYS[k], 0}, F.white, TXT_SB, "LeftCenter", nil, "DLP_RTE_M" .. k)
		end
		hline(r, "bl", -0.84, -0.85, 0.85)
		text(r .. "_help", r, {LX, -0.92, 0}, F.grey, TXT_T, "LeftCenter", "PICK IN FLYING ORDER - DONE TO USE IT")
		line(r, "pg", (ROW[3] + ROW[4]) / 2 + 0.05, -1.03, "DLP_RTE_PG", F.grey, TXS, "CenterCenter")
		text(r .. "_b1", r, {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "PREV")
		text(r .. "_b2", r, {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "NEXT")
		text(r .. "_b4", r, {ROW[4], YB, 0}, F.white, TXS, "CenterCenter", "CLR")
		text(r .. "_b5", r, {ROW[5], YB, 0}, F.white, TXS, "CenterCenter", "ALL")
	end
	lbl_left("dlp_rte", 5, "DONE")
	menu_btn("dlp_rte")

	-------------------------------------------------------------------
	-- 15 EDIT (v1.7.2): the working route with its own cursor (the
	-- active steerpoint stays). Right 1-5 put the cursor on a point, left
	-- 1 / 2 move it a place up / down, 3 POS new position, 4 ADD a point
	-- after it, 5 DONE; bottom PREV / NEXT page, DEL (twice), STP.
	-------------------------------------------------------------------
	root("dlp_wed", 15)
	do
		local r = "dlp_wed"
		line(r, "title", 0, 1.22, "DLP_WED_TITLE", F.white, TXS, "CenterCenter")
		hline(r, "tl", 1.14, -0.85, 0.85)
		-- the point under the cursor: name, MGRS, lat / long
		line(r, "sel", LX, 1.05, "DLP_WED_SEL", F.green, TXS)
		line(r, "mg", -LX, 1.05, "DLP_WED_MG", F.white, TXS, "RightCenter")
		line(r, "ll", LX, 0.96, "DLP_WED_LL", F.white, TXS)
		for k = 1, 5 do
			for c, f in ipairs({F.white, F.green, F.cyan}) do
				line(r, "r" .. k .. "_" .. c, RX - 0.1, BYRS[k], "DLP_WED_R" .. k, f, TXS, "RightCenter", {"DLP_WED_C" .. k, c - 0.5, c + 0.5})
			end
			text(r .. "_ar" .. k, r, {RX, BYRS[k], 0}, F.white, TXS, "RightCenter", "<", nil, {"DLP_WED_C" .. k, 0.5, 3.5})
		end
		hline(r, "bl", -0.90, -0.85, 0.85)
		line(r, "msg", LX, -0.97, "DLP_WED_MSG", F.grey, TXS, "LeftCenter", {"DLP_WED_MSGC", -0.5, 0.5})
		line(r, "msga", LX, -0.97, "DLP_WED_MSG", F.amber, TXS, "LeftCenter", {"DLP_WED_MSGC", 0.5, 1.5})
		line(r, "pg", (ROW[3] + ROW[4]) / 2 + 0.05, -1.07, "DLP_WED_PG", F.grey, TXS, "CenterCenter")
		text(r .. "_b1", r, {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "PREV")
		text(r .. "_b2", r, {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "NEXT")
		text(r .. "_b4", r, {ROW[4], YB, 0}, F.white, TXS, "CenterCenter", "DEL")
		text(r .. "_b5", r, {ROW[5], YB, 0}, F.white, TXS, "CenterCenter", "STP")
	end
	lbl_left("dlp_wed", 1, "MV UP"); lbl_left("dlp_wed", 2, "MV DN"); lbl_left("dlp_wed", 3, "POS")
	lbl_left("dlp_wed", 4, "ADD"); lbl_left("dlp_wed", 5, "DONE")
	menu_btn("dlp_wed")

	-------------------------------------------------------------------
	-- 14 PICTURE (SA page right 2): hostile contacts grouped into
	-- formations, bullseye / BRAA per group, the call written out and a
	-- small north-up plot around the bullseye (dl_tac.lua groups them)
	-------------------------------------------------------------------
	root("dlp_pic", 14)
	do
		local r = "dlp_pic"
		title(r, "PICTURE")
		line(r, "hdr", LX, 1.05, "DLP_PIC_HDR", F.green, TXS)
		line(r, "show", -LX, 1.05, "DLP_PIC_SORT", F.grey, TXS, "RightCenter")
		text(r .. "_cols", r, {LX, 0.95, 0}, F.blue, TXT_T, "LeftCenter", "GRP BULLS   BRAA        ALT SIZE     ASPECT")
		hline(r, "cl", 0.905, -0.82, 0.82)
		for k = 1, 5 do
			local y = 0.85 - (k - 1) * 0.085
			line(r, "row" .. k, LX, y, "DLP_PIC_R" .. k, F.red, TXT_T, nil, {"DLP_PIC_C" .. k, 0.5, 1.5})
			line(r, "rowf" .. k, LX, y, "DLP_PIC_R" .. k, F.green, TXT_T, nil, {"DLP_PIC_C" .. k, 1.5, 2.5})
			simple(r .. "_sb" .. k, r, {0, 0, 0}, {"DLP_PIC_S" .. k}, {{"parameter_in_range", 0, 0.5, 1.5}})
			box(r .. "_sb" .. k, "b", 0, y, 1.68, 0.075, M.white)
			text(r .. "_rl" .. k, r, {RX, BYRS[k], 0}, F.white, TXT_SB, "RightCenter", "GRP " .. k, nil, {"DLP_PIC_RV" .. k, 0.5, 1.5})
		end
		-- the call for the selected group (2 lines)
		text(r .. "_callh", r, {LX, 0.30, 0}, F.blue, TXT_T, "LeftCenter", "CALL")
		for k = 1, 2 do line(r, "call" .. k, LX, 0.23 - (k - 1) * 0.075, "DLP_PIC_K" .. k, F.white, TXS) end
		-- plot: north up, around the bullseye (CALL BULL) or the jet (CALL BRAA)
		local PCY, PR = CFG.pic_plot_y or -0.52, CFG.pic_plot_r or 0.40
		simple(r .. "_plot", r, {0, PCY, 0})
		local dim = D.col(60, 95, 70, 255)
		local cv, ci = D.circle_ring(PR, LW * 0.6, 64)
		mesh(r .. "_ring1", r .. "_plot", "triangles", cv, ci, dim)
		cv, ci = D.circle_ring(PR / 2, LW * 0.6, 48)
		mesh(r .. "_ring2", r .. "_plot", "triangles", cv, ci, dim)
		line(r, "scale", PR + 0.02, PCY + PR - 0.02, "DLP_PIC_PR", F.grey, TXT_T, "LeftCenter")
		simple(r .. "_be", r .. "_plot", {0, 0, 0}, {"DLP_PIC_BX", "DLP_PIC_BY", "DLP_PIC_BE"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}, {"parameter_in_range", 2, 0.5, 1.5}})
		do
			local bv, bi = D.circle_ring(0.018, LW * 0.6, 16)
			mesh(r .. "_be_c", r .. "_be", "triangles", bv, bi, M.friend)
			mesh(r .. "_be_x", r .. "_be", "lines", {{-0.035, 0}, {0.035, 0}, {0, -0.035}, {0, 0.035}}, {0, 1, 2, 3}, M.friend)
			text(r .. "_be_l", r .. "_be", {0.03, -0.045, 0}, F.green, TXT_T, "LeftCenter", "BE")
		end
		-- the jet
		simple(r .. "_own", r .. "_plot", {0, 0, 0}, {"DLP_PIC_OX", "DLP_PIC_OY", "DLP_PIC_OV"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}, {"parameter_in_range", 2, 0.5, 1.5}})
		simple(r .. "_own_r", r .. "_own", {0, 0, 0}, {"DLP_PIC_OH"}, {{"rotate_using_parameter", 0, 1}})
		do
			local f = 0.6
			local ov, oi = D.poly_lines({{0, 0.06 * f}, {0.010 * f, 0.026 * f}, {0.048 * f, 0.0}, {0.048 * f, -0.010 * f}, {0.009 * f, 0.0},
				{0.007 * f, -0.034 * f}, {0.022 * f, -0.047 * f}, {0, -0.043 * f}, {-0.022 * f, -0.047 * f}, {-0.007 * f, -0.034 * f},
				{-0.009 * f, 0.0}, {-0.048 * f, -0.010 * f}, {-0.048 * f, 0.0}, {-0.010 * f, 0.026 * f}})
			mesh(r .. "_own_s", r .. "_own_r", "lines", ov, oi, M.own)
		end
		-- groups: hostile = red triangle along the track, friendly = green
		-- circle; white ring = selected. DLP_PIC_G<k>_V: 1 hostile, 2 hostile
		-- selected, 3 friendly, 4 friendly selected
		for k = 1, 5 do
			local g = r .. "_g" .. k
			local gv = "DLP_PIC_G" .. k .. "_V"
			simple(g, r .. "_plot", {0, 0, 0}, {"DLP_PIC_G" .. k .. "_X", "DLP_PIC_G" .. k .. "_Y", gv},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}, {"parameter_in_range", 2, 0.5, 4.5}})
			simple(g .. "_r", g, {0, 0, 0}, {"DLP_PIC_G" .. k .. "_H"}, {{"rotate_using_parameter", 0, 1}})
			local q = 0.026
			local tv, ti = D.band({{0, q * 1.2}, {q * 0.9, -q * 0.75}, {-q * 0.9, -q * 0.75}},
				{{0, q * 1.2 - LW * 2.2}, {q * 0.9 - LW * 1.6, -q * 0.75 + LW}, {-q * 0.9 + LW * 1.6, -q * 0.75 + LW}})
			mesh(g .. "_s", g .. "_r", "triangles", tv, ti, M.hostile, nil, {gv}, {{"parameter_in_range", 0, 0.5, 2.5}})
			local fv, fi = D.circle_ring(0.022, LW * 0.7, 20)
			mesh(g .. "_f", g, "triangles", fv, fi, M.friend, nil, {gv}, {{"parameter_in_range", 0, 2.5, 4.5}})
			mesh(g .. "_fl", g .. "_r", "lines", {{0, 0.022}, {0, 0.06}}, {0, 1}, M.friend, nil, {gv}, {{"parameter_in_range", 0, 2.5, 4.5}})
			local sv, si = D.circle_ring(0.05, LW * 0.6, 24)
			mesh(g .. "_sel", g, "triangles", sv, si, M.white, nil, {gv}, {{"parameter_in_range", 0, 1.5, 2.5}})
			mesh(g .. "_self", g, "triangles", sv, si, M.white, nil, {gv}, {{"parameter_in_range", 0, 3.5, 4.5}})
			text(g .. "_n", g, {0.05, 0.035, 0}, F.red, TXT_T, "LeftCenter", tostring(k), nil, {gv, 0.5, 2.5})
			text(g .. "_nf", g, {0.05, 0.035, 0}, F.green, TXT_T, "LeftCenter", tostring(k), nil, {gv, 2.5, 4.5})
		end
		-- bottom row: plot range +/- and AUTO (fit), SHOW hostile / friendly / all
		text(r .. "_b1", r, {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "RNG+")
		text(r .. "_b2", r, {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "RNG-")
		text(r .. "_b4", r, {ROW[4], YB, 0}, F.white, TXS, "CenterCenter", "AUTO", nil, {"DLP_PIC_AUTO", -0.5, 0.5})
		text(r .. "_b4g", r, {ROW[4], YB, 0}, F.green, TXS, "CenterCenter", "AUTO", nil, {"DLP_PIC_AUTO", 0.5, 1.5})
		line(r, "b5", ROW[5], YB, "DLP_PIC_SHOW", F.white, TXS, "CenterCenter")
		text1(r .. "_l2", r, {BX, BYS[2], 0}, F.white, TXT_SB, "LeftCenter", nil, "DLP_PIC_L2")
		lbl_left(r, 4, "INTC")
		lbl_left(r, 5, "SA")
	end
	menu_btn("dlp_pic")

	-------------------------------------------------------------------
	-- 9 FLIGHT: designated flight members (R1-R5), details of the selected
	-- one on the left; ADD view lists the friendly aircraft in range
	-------------------------------------------------------------------
	root("dlp_flt", 9)
	line("dlp_flt", "title", 0, 1.22, "DLP_FLT_TITLE", F.white, TXS, "CenterCenter")
	hline("dlp_flt", "tl", 1.14, -0.85, 0.85)
	for k = 1, 5 do
		local y = BYRS[k]
		line("dlp_flt", "r" .. k, RX - 0.1, y + 0.03, "DLP_FLT_R" .. k, F.white, TXS, "RightCenter", {"DLP_FLT_M" .. k, 0.5, 1.5})
		line("dlp_flt", "ry" .. k, RX - 0.1, y + 0.03, "DLP_FLT_R" .. k, F.amber, TXS, "RightCenter", {"DLP_FLT_M" .. k, 1.5, 2.5})
		line("dlp_flt", "rs" .. k, RX - 0.1, y - 0.06, "DLP_FLT_S" .. k, F.grey, TXT_T, "RightCenter", {"DLP_FLT_M" .. k, 0.5, 2.5})
		text("dlp_flt_ar" .. k, "dlp_flt", {RX, y + 0.03, 0}, F.white, TXS, "RightCenter", "<", nil, {"DLP_FLT_M" .. k, 0.5, 2.5})
	end
	-- left buttons: ADD / BACK, REM
	text1("dlp_flt_l1", "dlp_flt", {BX, BYS[1], 0}, F.white, TXT_SB, "LeftCenter", nil, "DLP_FLT_L1")
	text1("dlp_flt_l2", "dlp_flt", {BX, BYS[2], 0}, F.white, TXT_SB, "LeftCenter", nil, "DLP_FLT_L2")
	-- details of the selected member (list view) / hints (add view)
	for i = 1, 14 do
		local y = 0.6 - (i - 1) * 0.095
		for c, f in ipairs({F.white, F.green, F.red, F.amber, F.grey}) do
			line("dlp_flt", "d" .. i .. "_" .. c, -0.66, y, "DLP_FLT_D" .. i, f, TXS, "LeftCenter", {"DLP_FLT_C" .. i, c - 1.5, c - 0.5})
		end
	end
	-- paging in the add view
	simple("dlp_flt_add", "dlp_flt", {0, 0, 0}, {"DLP_FLT_VIEW"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	text("dlp_flt_b1", "dlp_flt_add", {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "PREV")
	text("dlp_flt_b2", "dlp_flt_add", {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "NEXT")
	line("dlp_flt_add", "pg", (ROW[4] + ROW[5]) / 2, YB, "DLP_FLT_PG", F.grey, TXS, "CenterCenter")
	menu_btn("dlp_flt")

	-------------------------------------------------------------------
	-- 10 RWR: emitters around the jet (stronger = nearer the centre),
	-- green scan, amber track, red lock, blinking ring = missile launch
	-------------------------------------------------------------------
	if RWR_ON then
	root("dlp_rwr", 10)
	title("dlp_rwr", "RWR")
	line("dlp_rwr", "stat", LX, 1.08, "DLP_RWR_STAT", F.white, TXS)
	line("dlp_rwr", "cm", -LX, 1.08, "DLP_RWR_CM", F.grey, TXS, "RightCenter")
	do
		local CY = CFG.rwr_center_y or 0.12
		local R = CFG.rwr_radius or 0.68
		simple("dlp_rwr_c", "dlp_rwr", {0, CY, 0})
		local v, i = D.circle_ring(R + 0.04, LW, 96)
		mesh("dlp_rwr_ring", "dlp_rwr_c", "triangles", v, i, M.white)
		v, i = D.circle_ring(R * 0.5, LW, 64)
		mesh("dlp_rwr_ring2", "dlp_rwr_c", "triangles", v, i, M.blue)
		local tv, ti = {}, {}
		for deg = 0, 330, 30 do
			local a = math.rad(90 - deg)
			local ca, sa = math.cos(a), math.sin(a)
			local px, py = -sa * LW / 2, ca * LW / 2
			local r0, r1 = R + 0.04, R + ((deg % 90 == 0) and 0.12 or 0.08)
			local k = #tv
			tv[k + 1] = {r0 * ca + px, r0 * sa + py}; tv[k + 2] = {r1 * ca + px, r1 * sa + py}
			tv[k + 3] = {r1 * ca - px, r1 * sa - py}; tv[k + 4] = {r0 * ca - px, r0 * sa - py}
			for _, q in ipairs({0, 1, 2, 0, 2, 3}) do ti[#ti + 1] = k + q end
		end
		mesh("dlp_rwr_ticks", "dlp_rwr_c", "triangles", tv, ti, M.white)
		local av, ai = D.poly_lines({{0, 0.06}, {0.010, 0.026}, {0.048, 0.0}, {0.048, -0.010}, {0.009, 0.0},
			{0.007, -0.034}, {0.022, -0.047}, {0, -0.043}, {-0.022, -0.047}, {-0.007, -0.034},
			{-0.009, 0.0}, {-0.048, -0.010}, {-0.048, 0.0}, {-0.010, 0.026}})
		mesh("dlp_rwr_ac", "dlp_rwr_c", "lines", av, ai, M.own)
		for k = 1, 12 do
			local n = "dlp_rw" .. k
			simple(n, "dlp_rwr_c", {0, 0, 0}, {"DLP_RW" .. k .. "_X", "DLP_RW" .. k .. "_Y", "DLP_RW" .. k .. "_S"},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
				 {"parameter_in_range", 2, 0.5, 4.5}})
			-- symbol: a number ("11", "29", shown with %.0f: number-like text
			-- must not go through %s) or letters ("U", "EW") -- DLP_RW<k>_K picks
			simple(n .. "_num", n, {0, 0, 0}, {"DLP_RW" .. k .. "_K"}, {{"parameter_in_range", 0, 0.5, 1.5}})
			simple(n .. "_str", n, {0, 0, 0}, {"DLP_RW" .. k .. "_K"}, {{"parameter_in_range", 0, -0.5, 0.5}})
			for c, cf in ipairs({{F.green, 0.5, 1.5}, {F.amber, 1.5, 2.5}, {F.red, 2.5, 4.5}}) do
				local vis = {"DLP_RW" .. k .. "_S", cf[2], cf[3]}
				local et = text1(n .. "_t" .. c, n .. "_str", {0, 0, 0}, cf[1], TXS, "CenterCenter", nil, "DLP_RW" .. k .. "_T", vis)
				num_text(et, n .. "_n" .. c, n .. "_num", "DLP_RW" .. k .. "_N", vis, "%.0f")
			end
			v, i = D.circle_ring(0.06, LW, 24)
			mesh(n .. "_lk", n, "triangles", v, i, M.hostile, nil, {"DLP_RW" .. k .. "_S"}, {{"parameter_in_range", 0, 2.5, 4.5}})
			if LAUNCH_ON then
				v, i = D.circle_ring(0.085, LW * 1.5, 28)
				mesh(n .. "_ln", n, "triangles", v, i, M.hostile, nil, {"DLP_RW" .. k .. "_S"}, {{"parameter_in_range", 0, 3.5, 4.5}})
			end
		end
	end
	hline("dlp_rwr", "sep", -0.62)
	for k = 1, 6 do
		local y = -0.70 - (k - 1) * 0.09
		for c, cf in ipairs({{F.green, -0.5, 0.5}, {F.amber, 0.5, 1.5}, {F.red, 1.5, 2.5}}) do
			line("dlp_rwr", "l" .. k .. "_" .. c, LX, y, "DLP_RWR_L" .. k, cf[1], TXS, "LeftCenter", {"DLP_RWR_C" .. k, cf[2], cf[3]})
		end
	end
	menu_btn("dlp_rwr")
	end

	-------------------------------------------------------------------
	-- 11 SMS: stores per station, gun, chaff / flares
	-------------------------------------------------------------------
	root("dlp_sms", 11)
	title("dlp_sms", "STORES")
	for k = 1, 8 do
		local y = 0.98 - (k - 1) * 0.13
		line("dlp_sms", "s" .. k, LX, y, "DLP_SMS_L" .. k, F.white, TXS, "LeftCenter", {"DLP_SMS_A" .. k, 0.5, 1.5})
		line("dlp_sms", "sy" .. k, LX, y, "DLP_SMS_L" .. k, F.amber, TXS, "LeftCenter", {"DLP_SMS_A" .. k, 1.5, 2.5})
	end
	hline("dlp_sms", "sep", -0.10)
	line("dlp_sms", "gun", LX, -0.22, "DLP_SMS_GUN", F.white, TXS)
	line("dlp_sms", "cm", LX, -0.34, "DLP_SMS_CM", F.white, TXS)
	line("dlp_sms", "tot", LX, -0.46, "DLP_SMS_TOT", F.grey, TXS)
	text("dlp_sms_note", "dlp_sms", {0, -1.12, 0}, F.grey, TXT_T, "CenterCenter", "AMBER = SELECTED STATION")
	menu_btn("dlp_sms")

	-------------------------------------------------------------------
	-- v1.7 start-up screens and display-off mask: over every page above
	-------------------------------------------------------------------
	do
		local ok_b, err_b = pcall(dofile, LockOn_Options.script_path .. "DL/dl_boot_page.lua")
		if not ok_b and DL_dbg then DL_dbg("page", "dl_boot_page.lua: " .. tostring(err_b)) end
	end

	-------------------------------------------------------------------
	-- short alerts on every page: MISSILE LAUNCH (blinks), BINGO FUEL
	-- (not while the display is off or starting up)
	-------------------------------------------------------------------
	simple("dlp_alert", nil, {0, 0, 0}, {"DL_PAGE", "DL_BOOT"}, {{"parameter_in_range", 0, 0.5, 2.5}, {"parameter_in_range", 1, -0.5, 0.5}})
	if LAUNCH_ON then
		simple("dlp_launch", "dlp_alert", {0, 0, 0}, {"DLP_LAUNCH"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		mesh("dlp_launch_bg", "dlp_launch", "triangles", {{-0.55, 0.80}, {0.55, 0.80}, {0.55, 0.64}, {-0.55, 0.64}}, {0, 1, 2, 0, 2, 3}, M.black)
		box("dlp_launch", "box", 0, 0.72, 1.1, 0.16, M.hostile)
		text("dlp_launch_t", "dlp_launch", {0, 0.72, 0}, F.red, TXT, "CenterCenter", "MISSILE LAUNCH")
	end
	simple("dlp_bingo", "dlp_alert", {0, 0, 0}, {"DLP_BINGO_SHOW"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	mesh("dlp_bingo_bg", "dlp_bingo", "triangles", {{-0.6, 0.56}, {0.6, 0.56}, {0.6, 0.40}, {-0.6, 0.40}}, {0, 1, 2, 0, 2, 3}, M.black)
	box("dlp_bingo", "box", 0, 0.48, 1.2, 0.16, M.amber)
	line("dlp_bingo", "txt", 0, 0.48, "DLP_BINGO_TXT", F.amber, TXT, "CenterCenter")

	-- MENU label on the DL page too
	text("dlp_dl_menu", "dl_root", {ROW[3], YB, 0}, F.white, TXS, "CenterCenter", "MENU")

	-------------------------------------------------------------------
	-- brightness: a black see-through layer over every page (drawn last),
	-- one layer per step; DLP_DIM 0 = full brightness .. 9 = darkest
	-------------------------------------------------------------------
	simple("dlp_dim", nil, {0, 0, 0}, {"DL_PAGE"}, {{"parameter_in_range", 0, 0.5, 2.5}})
	for k = 1, 9 do
		local a = math.floor(255 * k / 10 + 0.5)
		mesh("dlp_dim_" .. k, "dlp_dim", "triangles", {{-1.1, 1.6}, {1.1, 1.6}, {1.1, -1.6}, {-1.1, -1.6}}, {0, 1, 2, 0, 2, 3},
			D.col(0, 0, 0, a), nil, {"DLP_DIM"}, {{"parameter_in_range", 0, k - 0.5, k + 0.5}})
	end
	-- "DAY BRT 7/10" for a moment after the rocker / switch is used (not dimmed)
	simple("dlp_brt", "dlp_dim", {0, 0, 0}, {"DLP_BRT_SHOW"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	mesh("dlp_brt_bg", "dlp_brt", "triangles", {{-0.5, 1.03}, {0.5, 1.03}, {0.5, 0.87}, {-0.5, 0.87}}, {0, 1, 2, 0, 2, 3}, M.black)
	box("dlp_brt", "box", 0, 0.95, 1.0, 0.16, M.amber)
	line("dlp_brt", "txt", 0, 0.95, "DLP_BRT_TXT", F.amber, TXS, "CenterCenter")
end
