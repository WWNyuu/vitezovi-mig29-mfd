VITEZOVI MiG-29 MFD ADD-ON  v1.8.0
==================================
by the 127th Vitezovi FAS "Wild Wolves"

An add-on for "MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3".

REQUIRED - install these first, this add-on does not work without them:
  * DCS: MiG-29A Fulcrum (the full-fidelity module, unit "MiG-29 Fulcrum")
  * "MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3" by KRN MODS,
    downloaded from KRN's own release and installed as KRN describes
    (unzipped into Saved Games\DCS\Mods\tech):
    https://files.digitalcombatsimulator.com/en/files/3350140/
    The physical MFD, its buttons and the UFCP in the cockpit are KRN's
    work; this add-on only adds to them and is published with KRN's agreement. Please support
    KRN's mod where it is published.

What it is
----------
A set of MFD pages and a start-up sequence for KRN's modernized MiG-29
cockpit:

  MENU     squadron logo, page selection
           left:  SA, NAV, HSI, COM/NAV      right: FPAS, SMS, FLT, RWR
  SA       situational awareness / datalink picture (F-15 SIT style)
  NAV      navigation: steering to the selected steerpoint (leg course,
           cross-track, command heading), the route list with ETAs, times
           on target (TOT) per steerpoint with the speed to fly on each
           leg, RSBN stations; LOAD picks a data cartridge
           (Saved Games\DCS\DTC) or the mission plan
  HSI      NATO-style HSI, heading bug, course, TACAN (UFCP keypad entry)
  COM/NAV  R-862 channel, frequency and the 20 presets (channels 0-19),
           RSBN / ILS / ADF / GCI channels, the nearest RSBN / PRMG stations
  FPAS     fuel: time / range to 500 kg, best range / endurance (estimates),
           bingo and fuel to home; engine RPM and EGT
  SMS      stores: what is on each station, gun rounds, chaff and flares
  FLT      your flight: add members, see where they are, radar / jammer,
           alive or lost
  RWR      the SPO-15 picture on the MFD: threat direction, type, strength,
           lock and missile launch

New in v1.8.0
-------------
Update by running INSTALL.bat from the add-on package (over any earlier version).
- Metric or imperial units on the whole MFD. By default the MFD follows
  the MiG-29's own setting: DCS Options > Special > MiG-29 > Avionics
  Units (Metric (Native) / Imperial; the NATO and English presets pick
  Imperial). Imperial = ranges and distances in NM, altitudes in feet,
  speeds in knots, fuel in pounds (MENU, FPAS, bingo, NAV fuel, INTC);
  metric = km, metres, km/h, kg as before. Restart the mission after
  changing it. Settings (settings.lua): units = "auto" / "metric" /
  "imperial", and range_units ("km" / "nm"), alt_units ("km" / "kft"),
  fuel_units ("kg" / "lb") to change one part only. The bingo you type
  on FPAS is in the units shown; settings ending in _kg stay in kg.
  Saved Games\DCS\Logs\mig29dl_device.log says which units were used
  and where the choice came from ("units: ...").

New in v1.7.9
-------------
Update by running INSTALL.bat from the add-on package (over any earlier version).
- Map dimming: the SA page's MAP button (bottom right) now steps the
  moving map MAP -> MAP DIM -> MAP DARK -> OFF -> MAP; the step is shown
  for a moment at the top of the MFD. Only the chart gets darker, the
  symbols on it stay as they are. With the D/N switch at N the chart is
  a little darker still. Settings (settings.lua): map_dim_steps (default
  {0, 3, 6}: tenths of black over the chart, 0-9), map_dim_night
  (default 2, 0 = no extra dimming at night).
- EWR picture: reports in metric units are read too - range in km or m,
  altitude in m or km, speed in km/h (also written kph / kmh), mph or m/s,
  next to NM / ft / knots as before. A row with a unit the add-on does
  not know is left out instead of being drawn in the wrong place.
- INSTALL builds the moving-map textures as its last step, after
  everything else is in place: closing the window while it builds no
  longer leaves the add-on without its Export.lua line.

New in v1.7.8
-------------
Update by running INSTALL.bat from the add-on package (over any earlier version).
- EWR picture on the SA page: some servers block export (so the datalink
  picture stays empty) but send an "EWR | Picture Report" and an
  "EWR | Friendly Picture Report" text message (top right). The add-on
  reads those messages and draws their aircraft on the SA page: hostiles
  red, friendlies as friendlies, placed by bearing and range from your
  jet when the report arrived. Between reports they move along the
  reported heading and speed; a report is shown for 3 minutes or until
  the next one. Used only while there is no datalink picture from export.
  Settings (settings.lua): ewr_enabled, ewr_bearing ("true" or
  "magnetic"), ewr_keep_s, ewr_extrapolate_s, ewr_with_datalink.
- Crash fix at spawn: the MFD now waits 6 seconds after you get into the
  jet before it shows anything. DCS builds the MFD pages in the
  background at that moment, and writing to them at the same time could
  crash DCS (CockpitBase.dll). Setting: start_hold_s in settings.lua.
- Crash fix when the cockpit loads: the add-on no longer mounts DCS's
  chart archives a second time (DCS already does it; doing it again while
  the cockpit was loading crashed DCS). Setting: mount_chart_archives.
- Moving map built around the jet: the MFD page held one piece per chart
  tile and range step (1024 on Syria, up to 6720 on Kola), and DCS crashed
  while building such a page at spawn. Now only the chart within 300 km of
  the jet (map_radius_km) is built, for every range step, at most 600
  pieces (map_max_quads; Syria about 350, Caucasus about 130). The page
  takes the jet's position from where you flew last on that map (saved
  every 30 s in Vitezovi-MFD-Addon\map_pos.txt); without one the chart is
  shown only at range steps 2-3. map_max_quads = 0 = the old full map.
- Whole moving map at every range step: INSTALL now joins DCS's chart
  tiles of each map you have into a few big textures (2048 px, one set
  per sharpness the range steps need) and the MFD uses those. The page
  then has a few dozen pieces for the whole map (Syria about 90) instead
  of hundreds or thousands, with about the same sharpness on the MFD
  screen. The first INSTALL takes a while (it reads DCS's chart files);
  the files go into KRN's mod folder, Cockpit\Scripts\DL\charts_gen
  (about 50-500 MB per map; UNINSTALL removes them). Run INSTALL again
  after a DCS update that changes the charts. INSTALL.bat -NoCharts skips
  it; settings.lua map_built = false uses DCS's own tiles as before.
- Export script: while DCS loads a mission it no longer hooks itself into
  the export chain again and again. With another export tool that does the
  same (many do), that tool ended up running about 40 times every frame.

New in v1.7.7
-------------
Update by running INSTALL.bat from the add-on package (over any earlier version).
- Night colours (the fix for v1.7.6): with the D/N switch at N the MFD
  uses a night palette - softer text, threats stay bright - instead of the
  day colours dimmed. Night brightness starts at 5 (about the light of the
  old 4). The night palette is off by default (day colours, dimmed);
  put night_palette = true in settings.lua to use it.
- STORES page: the selected stations are shown again. The External Stores
  switch picks a pair: INBD = stations 3 and 5; OUTBD = the middle pair
  2 and 6, and the outer pair 1 and 7 once the middle pair is empty. The
  selected pair is amber, and the SELECTED line names the stations and
  stores ("SELECTED  ST2+6  R-73"). Tanks are never selected.
- All four switches in Options > Special > MIG-29AM are on by default now,
  the moving map too. DCS keeps the choice you saved before: if you had
  the map off, tick it once yourself.

Corrections in the v1.7.7 package of 10 November 2026 (same version
number; run INSTALL.bat from this package over the earlier one):
- Player list (FLT page names, the mission's cartridge, route and radio
  presets from the hook): when you took a MiG-29 from a mission's slot
  list in single player and the first look at the slot came too early or
  you changed to another jet, nothing was sent for the rest of the flight.
  The slot is now checked again for every jet you take.
- Datalink picture in big missions: when the line-of-sight budget of a
  refresh ran out, the remaining hostile aircraft counted as seen, so
  aircraft behind mountains showed up. They now keep the answer of the
  last refresh, and the next refresh carries on where this one stopped.
- A mobile SAM that drove on stayed drawn at the place it was first found.
  Its ring now moves to the new place once it is seen there (until then
  it stays at the last known place).
- UFCP MRK (overhead) and DIR on a page other than SA used the position
  of the last time the SA page was shown. The same for PICTURE putting
  the SA cursor on a group. All three use the jet's position now.
- SA page, EXP: the line to the active steerpoint started at the centre of
  the screen instead of at the aircraft symbol.
- Going from a cartridge back to MSN left no steerpoint selected until
  STP was pressed.
- FLT / own-flight colour of a member flickered in busy missions; LOST
  was not remembered for members picked by player name unless the FLIGHT
  page was open.
- Intercept steering: the dashed lines stopped part of the way on long
  ranges.
- always_on = false in settings.lua (an old setting) left the MFD empty.
  It is ignored now.
- Installer: UNINSTALL takes the Vitezovi block out of the MiG-29's
  controls also when the rest was removed before; another mod's button
  texture is kept before the labels go on and put back by UNINSTALL; an
  example cartridge or mission you edited is kept in
  Vitezovi-MFD-Addon\replaced_examples before the package's one replaces
  it (save your own cartridges under another name).

New in v1.7.6
-------------
- STORES page redrawn like the stores page of the upgraded MiG-29: the jet
  seen from behind, a line from each pylon down to its store, the store's
  symbol (missile, bomb, rocket pod, tank ...) and its name under it. The
  centre tank hangs right under the jet. The selected station is amber.
  Under the picture: the selected station and store, gun rounds, chaff and
  flares, and how many stores are on how many stations.
- SA page, SYM 2 GROUP and SYM 3 ALT: contacts of one colour drawn on top
  of each other share one label ("3X 8 .81", on the one nearest you), and
  a label that would cover another label or symbol moves beside or under
  its own symbol. SYM 2 used to be SHORT labels; SYM 1, 4 and 5 are as
  before.
- SA cursor: a full square (was two short bars), a little smaller than the
  radar lock box (cursor_box in settings.lua).
- HSI page: the steerpoint and the next two route points under the rose,
  with bearing, distance and ETA as on the NAV list. The heading bug and
  course readouts moved to the right side.

New in v1.7.5
-------------
- Lighter MFD: the SA picture (contacts, threat rings, route symbols) is
  only worked out while the SA page is on the screen; route steering,
  waypoint sequencing and a running intercept carry on on every page.
  NAV, MENU and the other pages cost much less than before.
- Less garbage: the MFD makes 4-5 times less throw-away Lua memory per
  update on SA and HSI (fewer small clean-ups by Lua's collector).
- Export without long frames: the work for one datalink packet (world
  scan, line-of-sight checks) is spread over several frames instead of
  all in one. In a big mission (300 aircraft, 3000 ground units) the
  longest frame of the export went from about 6 ms to about 1 ms; small
  missions are as before. The packets are the same.
- Busy servers: when DCS's own list of all objects in the mission takes
  3 ms or more to read (a busy server), the add-on reads it only every
  2 s. The datalink packet still comes every second (fuel, engines,
  stores, your own radar's contacts fresh); in between, the other
  contacts are moved on by their speed, as the MFD always does between
  packets. AWACS reports stay every 6 s. Small missions: every second as
  before. The export log notes when it switches.
- Timing log: the add-on can measure how much time its MFD pages, the
  export script and the hook take in your sim. Off by default, it costs
  nothing then. To switch it on, add this line to
  Saved Games\DCS\Vitezovi-MFD-Addon\settings.lua:
      perf_log = true
  then fly as usual. Every 30 s a block goes to Saved Games\DCS\Logs\
  mig29dl_perf.log (the MFD, per page), mig29dl_export_perf.log (the
  export script, which also shows your frames per second; "dl scan" =
  the frames with the world scan) and mig29dl_hook_perf.log. Remove the
  line (or set false) to switch it off.

New in v1.7.4
-------------
Update by running INSTALL.bat from the add-on package (over any earlier version).
- HOTAS binds: every MFD and UFCP button of the add-on can now be bound in
  DCS: Options > Controls > MiG-29 > category "Vitezovi MFD" (56 controls:
  MFD POWER, all bezel buttons, BRT, DAY / NIGHT, SYM, the UFCP keypad,
  MRK / DIR / NAV, the STP switch and KRN's other UFCP buttons). They act
  exactly like a click on the button.
  The add-on's INSTALL.bat writes them into the MiG-29's own controls file
  in the DCS install (Mods\aircraft\MiG-29-Fulcrum\Input\MiG-29-Fulcrum,
  joystick and keyboard default.lua: one marked block, ED's lines are not
  touched; UNINSTALL.bat takes the block out again).
  A DCS update or repair puts ED's file back and the binds disappear from
  the list: run INSTALL.bat again (the MFD's start-up test shows
  "NO HOTAS BINDS" on the UFCP LINK line). Your own key assignments are
  kept by DCS in Saved Games and come back with them.
  DCS under C:\Program Files: right-click INSTALL.bat > Run as
  administrator for the binds. DCS somewhere the installer does not find:
  INSTALL.bat -DcsPath "D:\DCS World" from a command prompt.
- SA page: the cursor no longer listens to the jet's radar cursor (TDC)
  controls (they never reached it in the MiG-29); it jumps with H1-H5
  (nearest .. 5th nearest hostile) and NEXT.
- There is an easter egg. Hint: type a five-letter word on the UFCP keypad
  the way you would on an old button phone.

New in v1.7.3
-------------
- Route editing: the route you fly is now your own working copy of the
  cartridge (or mission) route. NAV PREV / NEXT, AUTO and the UFCP STP
  switch step through every point, typed-in ones included (before, NEXT
  could stay on point 1). NAV DEL deletes the active steerpoint, cartridge
  point or typed-in. New EDIT page (NAV bottom 4): move points up / down,
  give a point a new position, add or delete points - with its own cursor,
  so the active steerpoint stays while you edit. The .dtc file is never
  changed: LOAD or a new mission starts from the cartridge again.
- EDIT page: PREV / NEXT (bottom 1 / 2) turn a page of 5 points; pick a
  point with the right buttons.
- The UFCP is powered by the Aircraft Systems Supply switch (System Power
  Panel, battery or ground power first) and takes a few seconds to come
  on; the add-on's UFCP lines follow it.

New in v1.7.2
-------------
A reliability update after a full code review. Update by running
INSTALL.bat from this version over v1.7 or v1.7.1.
- POWER: hold until the bar is full ("RELEASE TO SWITCH OFF"), then let
  go - the display switches off when you release. A press whose release
  gets lost can no longer switch the display off by itself.
- All MFD buttons and the UFCP STP switch act exactly once per click on
  every PC (some PCs send different button values). The added bezel
  buttons now animate when pressed and right-click does nothing.
- Your settings go into Saved Games\DCS\Vitezovi-MFD-Addon\settings.lua
  (made by the installer, never touched by an update or uninstall).
  If you had changed dl_config.lua, the installer keeps a copy as
  Vitezovi-MFD-Addon\dl_config_before_update.lua.
- Multiplayer: the mission cartridge (MSN) and radio presets come from
  your own slot, not from the first MiG-29 slot in the mission; FLT page
  player names also work after a mission change.
- Late-activation and static units no longer show as live contacts,
  flight members or threats.
- Sinai, Germany Cold War, Marianas WWII: TACAN / RSBN / PRMG stations and
  cartridges now show; Marianas WWII uses its own charts.
- A damaged or unusual cartridge file can no longer stop the MFD; it is
  skipped. A long power blip (over 1.5 s) replays the start-up but keeps
  your loaded plan, typed-in points and steerpoint.
- The UFCP no longer shows a frozen steerpoint line while the MFD is off.
- INTC: never switches to a friendly; shows LOST when the datalink stops.
  PICTURE drops groups once the datalink has been gone for 20 s.
- NAV: time on target with two points at the same place (a hold), routes
  that end where they start, MGRS entry display; point notes starting
  with a number ("250 KTS") stay names.
- PICTURE uses your nm / kft settings like the SA page.
- Drawings: names with numbers, small rings and re-reading an edited
  .geo.txt.
- Export script: lighter on big servers, idle in other aircraft, safe
  next to other export tools (SRS, Tacview, DCS-BIOS ...), smaller packets.
- Installer: finds Saved Games wherever Windows keeps it (also OneDrive,
  another drive, DCS.openbeta), handles folder names with [ ], never
  writes KRN V1.0.3 files over a newer KRN version, keeps Export.lua
  exactly as it was apart from its own line, and explains what to do
  when something blocks it.
- DTC Planner: names are kept to letters the MFD can show; empty
  coordinate fields no longer move a point; a cartridge with drawings
  saves as one .zip (unzip it into Saved Games\DCS\DTC); more precise
  positions at the map edges.

New in v1.7.1
-------------
- POWER button fix: on some PCs DCS sends the button's press and release
  with different values than on others, and the display switched itself
  off right after switching on (as if POWER were still held). The press
  and its release are now told apart on every PC. Nothing else changed;
  install over v1.7 with INSTALL.bat.

New in v1.7
-----------
The MFD now has its own power and a start-up, like a real retrofit display.
- POWER button: the top-left rocker on the MFD bezel (was the cog symbol,
  now "PWR" with a power symbol). Press = on. Hold it for 2 seconds = off
  (a "DISPLAY POWER OFF" bar fills while you hold; let go early and
  nothing happens), so it cannot be switched off by accident.
  (v1.7.2: when the bar is full let go - the display switches off on
  release.)
- The MFD runs on the jet's DC power (battery / generator). Cold start:
  the screen is dark until there is power and you press POWER.
  Hot start and air start: it is already on, as before.
- Start-up after POWER (about 16 s):
    1. screen test: a short flash, then a test grid with grey steps
    2. boot ROM: the display's own hardware check (small text)
    3. software boot log: the checks tick in with their boot clock
    4. squadron badge with the program version and a start-up bar
    5. BUILT-IN TEST checklist: every line ticks from IN TEST to GO
       (white) or NO-GO (red); the right column shows real values -
       DC volts, your position (latitude / longitude) as the nav
       alignment, datalink tracks, SPO-15, stations, cartridges.
       Bottom middle SKIP shows the result at once.
    6. SELECT CARTRIDGE: the cartridges for this map as cards, a preview
       of the selected one (route, points, drawings) and what it holds
       (flight members, radio presets, waypoints / airfields / RSBN,
       drawings).
         left 2 / 3   UP / DOWN       bottom 3 LOAD
                                      right 1 MSN (the mission plan)
                                      right 5 NONE (no flight plan)
       Then the MENU page.
- Power cuts: a short blink (under 1.5 s) keeps the page you were on. A
  longer cut (engines and battery off for a rearm, say) switches the MFD
  off; with POWER still on it starts up again from the beginning as soon
  as power comes back.
- While the screen is off or starting up, the MFD buttons and the UFCP
  keypad do nothing on the MFD (the UFCP STP switch still works).
- The MFD buttons now animate the button you pressed (some moved their
  neighbour before, KRN's left buttons included).
- Settings (settings.lua, see "Good to know"): power_mode = "always"
  brings back the old behaviour (always on, no start-up); boot_skip = true
  keeps the power logic but skips the start-up screens.

New in v1.6
-----------
Both are advisory, on the MFD only - like a bolt-on mission computer they
read what the jet and the datalink already know and never touch the stock
avionics (autopilot, HUD, radar and weapons are unchanged).
- PICTURE page (SA page right 2 PIC): the contacts grouped into
  formations (hostile, friendly or both), up to 5 groups, nearest first:
    GRP  BULLS (from the bullseye)  BRAA (from you)  ALT  SIZE + type  ASPECT
  (HOT / FLANK / BEAM / DRAG with their direction of travel), the call for
  the selected group written out ("BULLS 045/62, 8000, HOT, / HOSTILE,
  2 SHIP F-16.") and a small north-up plot: around the bullseye with CALL
  BULL, around your own jet with CALL BRAA.
    right 1-5  pick a group
    left 2     CALL BULL / BRAA (call + plot centre)
    left 4     INTC on that group (back to SA)
    left 5     SA, cursor on that group
    bottom 1 / 2  plot range + / -     bottom 4  AUTO range (fits all)
    bottom 5   SHOW HOST / FRND / ALL (hostile red, friendly green)
  Ejected pilots / parachutes are no longer shown as aircraft.
- INTC intercept steering (SA page right 3 INTC): on the contact under the
  cursor (or the nearest hostile; or left 4 on PICTURE). Shows:
    * a heading tape at the very top (under H1-H5): the green diamond is
      the collision course (CC) - put it under the centre mark and you meet
      the target head-on; amber at the end of the tape = more than 20 deg
      to turn
    * a yellow X where you will meet, dashed lines from you and from the
      target to it, a white ring on the target (amber = track lost)
    * bottom right, in place of the cursor datablock: target and aspect,
      CC and time to X, bearing / range / altitude and closure, fuel at X
      (amber / red against your FPAS bingo)
    * over the moving map the readouts and the tape get a dark backing
  If the target is faster and running, there is no collision course: the
  diamond points at it and the readout says TAIL CHASE. INTC again = off.
- The type of hostile aircraft now comes over the datalink (PICTURE, INTC).
- One steering solution for every display: the SA "TO ..", NAV page, HSI
  and UFCP line 2 all show the same true bearing (T) and distance to the
  active steerpoint. The NAV route list shows bearing and distance from the
  jet to each point (ETA still along the route). Before, the UFCP and NAV
  converted to magnetic with a KRN heading value that is not a usable
  magnetic heading (up to 150 deg off in flight).
- EXP keeps its own zoom: RNG +/- while expanded only zooms the expanded
  view; NORM brings back the range you had before, and the next EXP comes
  back at the zoom you used last time.
- HSI page right 1 TCN OFF: switches the TACAN pointer off again (shown
  while a channel is set).
- Smaller side button labels on the SA page and on the other pages, and
  every button label (sides, top and bottom rows) re-aligned with its
  button, measured in the cockpit.
- SA page header tidied: own bullseye top left, range and steerpoint top
  right. Heading, source, contact count and DTC lines are gone; a NO DL /
  DL OFF warning appears under the steerpoint only when there is a problem.
- The bottom datablocks (cursor bearing, contact under the cursor) are
  outlined and get a dark backing panel over the moving map.

New in v1.5
-----------
- Geo drawings on the SA page: threat rings, suspected threat rings, FLOT,
  borders and areas (CAP boxes, orbit tracks) drawn with the cartridge.
  They come from an optional file next to the cartridge with the same
  name: DTC\<name>.dtc + DTC\<name>.geo.txt. The Vitezovi DTC Planner
  (DRAWINGS tab, SAVE) writes both. A cartridge without one works as before.
    RING    red ring + name and radius      (confirmed threat)
    RING?   pink dashed ring                (suspected threat)
    FLOT    cyan dashed line
    BORDER  grey dash-dot-dot line
    AREA    cyan dashed outline, name in the middle
- SA page right 1 GEO: white = drawings shown, grey = hidden, no label =
  the cartridge has none. It only hides the drawings - threats seen over
  the datalink stay. SYM 4 CLEAN hides their names, SYM 5 MIN hides them.
- "LOADED <name>  +GEO" when a cartridge with drawings is loaded.
- Example: DTC\VITEZOVI GCI NETWORK.dtc (+ .geo.txt): VUK 1-4 intercept /
  escort routes (RTE FLT 1-4) and ranges R1-R3, with the main ridge FLOT
  and the four probe orbit tracks A-D (Vitezovi_GCI_Network_Caucasus.miz).
- Writing one by hand (Notepad is fine), one drawing per line, lat / long
  in decimal degrees, radius in km, "#" = comment:
    RING    SA-11       35  42.9000 42.9000
    RING?   SA-8?       12  42.5500 42.3500
    FLOT    MAIN RIDGE  43.5500 40.1000 / 43.5800 40.5500 / 43.5500 41.0000
    BORDER  GEO-RUS     42.85 41.0 / 42.7 41.6 / 42.75 42.2
    AREA    CAP SOUTH   41.95 42.3 / 41.95 42.9 / 41.75 42.9 / 41.75 42.3

New in v1.4
-----------
- NAV page (replaces PLAN; MENU left 2, or the UFCP NAV button):
  * top: selected steerpoint and its note, bearing / range, time to go
    and ETA, the leg course (DTK) or DIR, cross-track error, and a
    steering bar - the green diamond is the command heading (CMD), which
    flies you back onto the planned leg when you are off it.
  * route list: the cartridge's whole route (not only the 3 jet
    waypoints) plus its airfields, with leg course, distance along the
    route and ETA (TOT speeds included).
  * bottom: the time on target block (as on PLAN before), or with R5 the
    RSBN view: the cartridge's RSBN 1-3 and the nearest map stations,
    bearing / range, "NO RX" beyond the radio horizon, the jet's RSBN
    knob channel in green.
  * left: PREV / NEXT steerpoint, AUTO / MAN sequencing (next point when
    within 3 km or passed abeam), DIR (direct from here), RTE (pick the
    route to fly).
    right: LOAD, TOT, PT, CLR, RSBN / TOT.
    bottom: ADD a typed-in waypoint (lat / long or MGRS), DEL the active
    steerpoint, EDIT (the route editor).
- One cartridge for the whole flight: tag route points with flight member
  numbers at the start of the point note in DCS's DTC editor ("1 IP",
  "12 TGT", "1234 RV"; untagged = everyone). NAV left 5 RTE: left 1-4 pick
  member 1-4's route, or pick points by hand with the right buttons (flown
  in the order picked), ALL = every point. Example: DTC\VITEZOVI FLIGHT 40.dtc
  (member 1: P2 P4 P5 P6 P9, member 2: P1 P4 P5 P3 P6, then a shared route).
- The SA page draws up to 40 plan points (route, typed-in points, airfields).
- Typed-in waypoints: NAV bottom 1 ADD, type on the UFCP keypad, the point
  goes into the route after the selected steerpoint (U1, U2 ...) and is
  flown to directly. Works with cartridges and the mission plan.
- EDIT page (NAV bottom 4): the route you fly, 5 points a page, with its
  own cursor (green); the active steerpoint is cyan with "STP" and does
  not change while you edit. Top lines: the cursor point's name, MGRS and
  lat / long.
    right 1-5: put the cursor on that point; bottom 1 / 2 PREV / NEXT:
      the page before / after (the cursor keeps its row).
    left 1 MV UP / 2 MV DN: move the point one place earlier / later.
    left 3 POS: a new position for the point (lat / long; POS again = MGRS,
      a third time = cancel), typed as for ADD. Moved points get a "*".
    left 4 ADD: a new point after the cursor (same entry).
    bottom 4 DEL: press twice to delete the point under the cursor.
    bottom 5 STP: fly to the point under the cursor.
    left 5 DONE: back to NAV.
  TOTs stay with their points when points move. Edits are for this flight
  only: the cartridge file is never changed, LOAD (even the same
  cartridge), a new route choice on RTE or a mission restart start from
  the cartridge again. A short power cut keeps them.
- Cartridges loaded with LOAD now drive the UFCP: line 1 "STP P3", line 2
  bearing and distance (true since v1.6, the same numbers as SA / NAV). The UFCP STP switch steps through the
  cartridge's steerpoints; the newest input wins between the STP switch,
  NAV page and the jet's NAV panel WP-A/D buttons. In MSN the STP switch
  stays KRN's own (mission route).
- One cartridge works for both worlds: its 3 waypoints / 3 airfields /
  3 RSBN drive the jet's own navigation (also with this mod off), its
  route (any length) drives the NAV page. Example: DTC\VITEZOVI ROUTE 20.dtc
  (Caucasus, 20 points).
- UFCP buttons: MRK = markpoint on the SA page, DIR (was DVR) = fly direct
  to the selected steerpoint, NAV (was FLT/MENU) = NAV page, again = back.
- Fuel along the route uses a drag / fuel-flow model per leg speed and
  altitude (fast legs burn more, AB is flagged).
- Side button labels on the sub-pages are smaller (SA page unchanged).

New in v1.3
-----------
- Time on target on the PLAN page: ETA and fuel on arrival for every
  steerpoint (along the route, from where you are), a TOT on as many
  steerpoints as you like (each leg between two TOTs gets its own speed -
  e.g. a fast last leg over hostile ground), early / late for the next
  TOT, the ground speed needed with a speed cue (box = speed needed,
  caret = your ground speed), the next leg's speed (THEN line), and fuel at
  the next TOT point and at the last steerpoint (amber when below bingo /
  reserve).

New in v1.2
-----------
- Fewer, fuller pages: ENG is part of FPAS, DTC is part of PLAN (LOAD),
  RADIO and RSBN are one COM/NAV page. Menu split 4 + 4.
- Quick return: MENU, then MENU again = back to the page you came from.
- SYM rocker (bottom left) declutters the SA page in 5 steps:
  1 FULL  2 SHORT labels (7 .8)  3 ALT only (H7)  4 CLEAN (no labels, no
  route)  5 MIN (contacts and threats only). Left click less, right click more.
  (v1.7.6: 2 is GROUP, see "New in v1.7.6".)
- EXP centres on the contact / SAM under the cursor, ignores DCTR while
  expanded, and follows a contact picked with H1-H5 or NEXT.
- SA page tidied: no theatre / chart debug text (v1.6: the DTC line is gone;
  the loaded cartridge shows on the NAV page).
- Cleaned up: the hook script does nothing on dedicated servers / for
  spectators, logs stay small, old unused code and the add-on's own
  Caucasus map texture (22 MB, hidden under the DCS charts) were removed.

New in v1.1
-----------
- RWR page and SMS / stores page.
- Markpoints on the SA page (bottom 1 MARK, bottom 2 DEL), listed on PLAN.
- Bingo fuel and fuel-to-home on the FPAS page.
- MISSILE LAUNCH and BINGO FUEL alerts on every page.
- Switches in DCS Options > Special > MIG-29AM (see below).
- Moving map (DCS charts) behind the SA page, with a MAP button on it.

Install
-------
1. Install KRN's mod first (see REQUIRED above, from
   https://files.digitalcombatsimulator.com/en/files/3350140/) and close DCS.
2. Unzip this add-on anywhere (not into the Mods folder) and double-click
   INSTALL.bat.
   It finds your Saved Games folder (also when Windows keeps it in
   OneDrive or on another drive) and KRN's mod in every DCS folder there
   (Saved Games\DCS, DCS.openbeta ...), checks that it is
   V1.0.3, keeps a copy of every KRN file it touches
   (Saved Games\DCS\Vitezovi-MFD-Addon\krn_backup) and then:
     - adds a few lines to KRN's cockpit scripts and options (to load the
       add-on's pages and its device, and its four Special options),
     - adds click areas for the rest of the MFD bezel buttons to KRN's
       MFD model (Shapes\UFCP.edm),
     - changes three button labels on KRN's textures (UFCP DVR -> DIR,
       FLT/MENU -> NAV, the MFD cog rocker -> PWR power button),
     - copies the add-on's own files: the MFD pages
       (Cockpit\Scripts\DL in KRN's folder), the datalink export
       (Scripts\MiG29DL_Export.lua), the hook (Scripts\Hooks\MiG29DL_Hook.lua),
       example cartridges (DTC) and two test missions (Missions),
     - adds one line to Saved Games\DCS\Scripts\Export.lua (your other
       export scripts - SRS, Tacview, etc. - are kept).
   No KRN files are included in this add-on; everything is done to your own
   copy of KRN's mod. Windows PowerShell does the work (part of Windows).
3. Start DCS, take a MiG-29. Cold start: press the PWR rocker (top left of
   the MFD) once the battery is on.

If INSTALL says KRN's files are not V1.0.3 originals or KRN's mod has
changed: delete KRN's folder, unzip KRN's mod V1.0.3 again, run INSTALL
again. That also applies when you had the old all-in-one Vitezovi package
(v1.0 - v1.7) and it cannot be converted automatically. If KRN has
released a newer version, this add-on needs an update for it - it never
writes its V1.0.3 files over a newer KRN mod.

If something stops the installer (antivirus, a file in use, OneDrive
syncing, a company PC), it says what happened and what to do; running
INSTALL (or UNINSTALL) again afterwards finishes or undoes the job.

Uninstall: double-click UNINSTALL.bat. KRN's original files are put back
and the add-on's files removed; KRN's mod keeps working on its own. Your
settings.lua stays (delete Saved Games\DCS\Vitezovi-MFD-Addon yourself
if you want it gone).

Updating KRN's mod later: uninstall this add-on first, update KRN, then
install the add-on version made for that KRN version.

Using it
--------
- MFD bottom-centre button (MFD-8) = back to MENU from any page; on the
  MENU it returns to the page you came from.
- Brightness: top-right rocker, left click brighter, right click darker.
  D/N switch bottom right: left click day, right click night (separate levels).
- HSI: left 1 HDG / 2 CRS / 3 TCN, then type on the UFCP keypad;
  ENT applies, CLR deletes. Right 1 TCN OFF switches the TACAN off.
- SA page: left 1 flight plan on/off, 2 decentre, 3/4 range, 5 next contact,
  right 1 GEO drawings on/off (when the cartridge has a .geo.txt),
  right 2 PIC picture page, right 3 INTC intercept steering,
  top row H1-H5 = nearest .. 5th nearest hostile, bottom 4 = expand,
  SYM rocker = declutter (see above).
- NAV: right 1 LOAD opens the cartridge list (right buttons load, BACK,
  RFSH, PREV / NEXT), then it returns to NAV. That is the only place to
  change cartridges in flight.
- NAV steering: put the green diamond on the centre mark (fly the CMD
  heading). Off the leg it brings you back onto it at up to 45 deg; DIR
  (NAV page left 4 or the UFCP DIR button) makes it a straight line from
  where you are. PREV / NEXT, the UFCP STP switch or the NAV panel
  WP-A/D buttons pick the steerpoint - whatever you used last wins.
- NAV time on target: right 3 PT moves the cursor ("<") along the route,
  right 2 TOT sets the time for that point - type it on the UFCP keypad as
  HHMMSS (or HHMM, then ENT), mission time as on the cockpit clock. Points
  with a TOT get a red "TOT" tag; set as many as you need. Right 4 CLR
  removes the TOT under the cursor. The cue always shows the next TOT
  ahead; fly the cyan caret into the green box to arrive on time. The THEN
  line shows the following TOT and its leg speed.
  Ground speed needs ~2 s after opening the page; fuel figures use the
  measured fuel flow and settle ~20 s after a big speed change.
- NAV RTE (left 5): the cartridge's whole route, 5 lines a page (bottom 1 /
  2 PREV / NEXT page). Right 1-5 add / remove that point - the number in
  [ ] is its place in the route, flown in the order picked. Left 1-4
  FLT 1-4: that member's route (points tagged with the number + untagged
  points). Bottom 4 CLR, bottom 5 ALL. Left 5 DONE uses the picked route
  (nothing picked = ALL). ALL: the route as planned; with member tags
  every point once, by point number. Changing the route clears TOTs and
  edits (DONE without a change keeps them); loading a cartridge starts on
  ALL.
  Tags: digits 1-5 at the start of the note, each once, then a space or
  the end of the note (notes hold 7 characters: "1234 RV", "12"). 5 = the
  planner's X column. "250 KTS" is a name, not a tag. The DTC Planner
  writes tags for you.
- NAV typed-in waypoints: bottom 1 ADD = lat / long entry, ADD again = MGRS,
  ADD a third time = cancel. CLR deletes the last digit.
    lat / long: 13 digits DDMMmm DDDMMmm (degrees, minutes, hundredths of a
      minute), e.g. 4155850415172 = N 41 55.85  E 041 51.72. N/S and E/W
      are taken from where the jet is.
    MGRS: easting + northing in the jet's own 100 km square (shown on the
      line, e.g. 37T GG): 10 digits, or 4 / 6 / 8 digits + ENT.
  The point is inserted after the selected steerpoint and selected (DIR).
  Bottom 2 DEL removes the active steerpoint (any route point; v1.7.1:
  typed-in points only). Loading a cartridge clears the edits. A point
  within 3 km is "passed" at once in AUTO.
- FLT page: ADD lists friendly aircraft (players first); pick up to 5.
  Members are remembered between flights.
- Markpoints: SA page bottom 1 MARK (or the UFCP MRK button) drops a mark at
  the cursor (or under the jet when the cursor is off), bottom 2 DEL
  removes the newest. Up to 5.
- FPAS: left 1 BINGO, type kg on the UFCP keypad, ENT. Left 2 HOME cycles
  through the plan's airfields and your markpoints. Shows fuel needed to get
  home (estimate at the current altitude) and fuel on arrival.
- RWR page: the main threat sits in its direction, nearer the centre the
  stronger it is, with its SPO-15 type letter (P Z H N F S). Amber = main
  threat, red ring = locked on you, flashing ring + banner = missile launch.
  Other threats show their direction on the outer ring.

Options (DCS Options > Special > MIG-29AM > "MiG-29 WW MFD")
----------------------------------------------------------
Read when a mission loads - restart the mission after changing them.
All four are on by default (since v1.7.7).
  Datalink        off = SA page shows only your own radar, FLT page is off,
                  and the export does not scan the mission's units (saves CPU)
  RWR page        off = no RWR page, no launch alerts
  Launch warnings off = launches show as a normal lock, no banner
  Moving map      on  = DCS's own charts behind the SA page; the SA page's
                  bottom-right button (MAP) steps it in flight: MAP, MAP DIM,
                  MAP DARK, OFF (v1.7.9).
                  Charts exist for: Caucasus, Syria, Persian Gulf, Sinai, Iraq,
                  Afghanistan, Nevada, Mariana Islands, Marianas WWII,
                  South Atlantic, Germany Cold War, Kola. Other maps: black.
Leave KRN's own "MiG29" box on that page ticked - it switches the whole
cockpit mod on.

Good to know
------------
- The SA page and FLT positions use the unit list DCS exports. Servers that
  switch off "export of world objects" leave only your own radar.
- The SA datalink is a simulation built from that list (sensor ranges,
  radar horizon, terrain) - DCS has no real Link 16 for the MiG-29.
- Fuel and weapons of other jets are only available to the host / in single
  player, so the FLT page shows radar / jammer / alive status instead.
- Settings (brightness, text size, keypad mapping, ranges, units, power ...):
  put your changes into Saved Games\DCS\Vitezovi-MFD-Addon\settings.lua,
  one per line, e.g.  range_units = "nm". The names and defaults are listed
  in dl_config.lua (Saved Games\DCS\Mods\tech\MiG-29A(M) Cockpit
  Modernization - KRN MODS V1.0.3\Cockpit\Scripts\DL\dl_config.lua) -
  read it, but don't edit it: updates replace it. Restart the mission after
  a change.
- Logs if something does not work: Saved Games\DCS\Logs\mig29dl_*.log
  (the previous flight's log is kept as mig29dl_*.old.log)

Test missions (Saved Games\DCS\Missions):
  MiG29_DL_Test_Flight.miz  4 MiG-29 player slots at Kutaisi + dynamic spawn
  MiG29_RWR_Test.miz        air start with a full load, an SA-6 site and an
                            armed Su-27 - for the RWR and stores pages

Credits
-------
MiG-29A(M) Cockpit Modernization (the MFD, UFCP and their model and
textures): KRN MODS. MFD pages, start-up, datalink and DTC planner: the
127th Vitezovi FAS. MFD font: Share Tech Mono (SIL Open Font License).
DCS World and the MiG-29A Fulcrum module: Eagle Dynamics.
