-----------------------------------------------------------------------
-- MiG-29 DL page: tactical helpers (v1.6)
--   * PICTURE: hostile contacts grouped into formations (dl_pages_dev
--     upd_pic uses DL_TAC.groups)
--   * INTC: intercept steering on the SA page against one track
--     (collision course, time to the meeting point, closure, fuel there)
-- Everything here is advisory and drawn on the MFD only: nothing goes to
-- the jet's autopilot, HUD, radar or weapons.
-- Contacts are the device's list: c[0] type code, c[1] x, c[2] z, c[3] alt,
-- c[4] vx, c[5] vz, c.t = time of the position, c.nm = aircraft type.
-----------------------------------------------------------------------

DL_TAC = {intc = nil}
local CFG = DL_CFG or {}

local function cpos(c, t)
	local age = t - (c.t or t)
	if age < 0 then age = 0 end
	local mx = CFG.max_extrapolate_s or 20
	if age > mx then age = mx end
	return (c[1] or 0) + (c[4] or 0) * age, (c[2] or 0) + (c[5] or 0) * age
end
DL_TAC.cpos = cpos

-- v1.7.2: a number that can be drawn / printed (not nil, nan or inf)
local function fin(v) return type(v) == "number" and v == v and v > -math.huge and v < math.huge end
-- a contact we may follow: position and velocity are real numbers, and it is
-- not older than max_extrapolate_s. When the packets stop the device keeps
-- the last list; cpos() stops moving such contacts, and following them kept
-- the intercept target frozen and "seen" for ever (it never went LOST).
local function usable(c, t)
	if not (fin(c[1] or 0) and fin(c[2] or 0) and fin(c[3] or 0) and fin(c[4] or 0) and fin(c[5] or 0)) then return false end
	return (t - (c.t or t)) <= (CFG.max_extrapolate_s or 20)
end
-- the side of a contact: "H" hostile, "F" friendly (friendly / datalink
-- donor; AWACS and own flight are never intercepted), "U" anything else
local function side_of(c)
	local b = (c[0] or 0) % 10
	if b == 2 then return "H" end
	if b == 1 or b == 6 then return "F" end
	return "U"
end

-- "F-16C_50" -> "F-16", "MiG-29S" -> "MIG-29", "FA-18C_hornet" -> "FA-18"
-- (printable ASCII only: the MFD font has nothing else)
function DL_TAC.short_type(nm)
	if not nm or nm == "" then return nil end
	local u = tostring(nm):gsub("[\192-\255][\128-\191]*", "?"):gsub("[^\32-\126]", "?"):upper()
	local s = u:match("^(%a+%-%d+)") or u:match("^(%a+%d+)") or u:match("^(%S+)")
	return s and s:sub(1, 7) or nil
end

-- v1.7.2: contact altitude for PICTURE / INTC in the SA page's units
-- (alt_units "kft" = thousands of feet "25K", else metres in hundreds "7500")
function DL_TAC.alt_txt(alt_m)
	alt_m = fin(alt_m) and alt_m or 0
	if CFG.alt_units == "kft" then return string.format("%dK", math.floor(alt_m * 3.28084 / 1000 + 0.5)) end
	return tostring(math.floor(alt_m / 100 + 0.5) * 100)
end

local DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"}
local function cardinal(vx, vz)
	local a = math.deg(math.atan2(vz, vx)) % 360
	return DIRS[math.floor((a + 22.5) / 45) % 8 + 1]
end
-- target aspect seen from (ox, oz): HOT / FLANK / BEAM / DRAG (+ direction of travel)
function DL_TAC.aspect(g, ox, oz)
	local sp = math.sqrt(g.vx * g.vx + g.vz * g.vz)
	if sp < 20 then return "SLOW" end
	local dx, dz = ox - g.x, oz - g.z
	local d = math.sqrt(dx * dx + dz * dz)
	if d < 1 then return "MERGED" end
	local ca = (g.vx * dx + g.vz * dz) / (sp * d)
	local a = math.deg(math.acos(math.max(-1, math.min(1, ca))))
	if a <= 30 then return "HOT" end
	if a >= 110 then return "DRAG " .. cardinal(g.vx, g.vz) end
	return ((a <= 70) and "FLANK " or "BEAM ") .. cardinal(g.vx, g.vz)
end

-- contacts of one side -> groups {n, x, z, y (highest), vx, vz, type, d2, closure, friend}
-- side "F" = friendly (friendly, AWACS, own flight, datalink donors), else hostile
local FRIEND = {[1] = true, [4] = true, [5] = true, [6] = true}
function DL_TAC.groups(contacts, t, ox, oz, side)
	local hs = {}
	local want_f = (side == "F")
	for _, c in ipairs(contacts or {}) do
		local b = (c[0] or 0) % 10
		local nm = c.nm and tostring(c.nm):lower() or ""
		local pilot = nm:find("^pilot") or nm:find("parachut")       -- ejected pilots (older export)
		-- v1.7.2: the same rule as the intercept: no contact older than
		-- max_extrapolate_s (when the datalink stops the device keeps its last
		-- list, and PICTURE kept listing those groups as if current) and none
		-- without real numbers (every readout would be garbage)
		if usable(c, t) and not pilot and ((want_f and FRIEND[b]) or (not want_f and b == 2)) then
			local x, z = cpos(c, t)
			hs[#hs + 1] = {x = x, z = z, y = c[3] or 0, vx = c[4] or 0, vz = c[5] or 0, nm = DL_TAC.short_type(c.nm)}
		end
	end
	local R2 = (CFG.pic_group_m or 9300) ^ 2
	local DY = CFG.pic_group_alt_m or 3000
	local done, out = {}, {}
	for i = 1, #hs do
		if not done[i] then
			local g = {i}
			done[i] = true
			local k = 1
			while k <= #g do
				local a = hs[g[k]]
				for j = 1, #hs do
					if not done[j] then
						local b = hs[j]
						if (a.x - b.x) ^ 2 + (a.z - b.z) ^ 2 < R2 and math.abs(a.y - b.y) < DY then
							done[j] = true
							g[#g + 1] = j
						end
					end
				end
				k = k + 1
			end
			local o = {n = #g, x = 0, z = 0, y = -1e9, vx = 0, vz = 0}
			local types, best, bestn = {}, nil, 0
			for _, j in ipairs(g) do
				local h = hs[j]
				o.x, o.z, o.vx, o.vz = o.x + h.x, o.z + h.z, o.vx + h.vx, o.vz + h.vz
				if h.y > o.y then o.y = h.y end
				if h.nm then
					types[h.nm] = (types[h.nm] or 0) + 1
					if types[h.nm] > bestn then best, bestn = h.nm, types[h.nm] end
				end
			end
			local n = #g
			o.x, o.z, o.vx, o.vz = o.x / n, o.z / n, o.vx / n, o.vz / n
			o.type = best
			o.friend = want_f
			o.d2 = (o.x - ox) ^ 2 + (o.z - oz) ^ 2
			local d = math.sqrt(o.d2)
			-- closing speed towards us (m/s, + = closing), ignoring our own motion
			o.closure = (d > 1) and -((o.vx * (o.x - ox) + o.vz * (o.z - oz)) / d) or 0
			out[#out + 1] = o
		end
	end
	return out
end

-----------------------------------------------------------------------
-- intercept
-----------------------------------------------------------------------
-- start on the contact nearest to (x, z) (within 8 km); returns true when found.
-- side ("H" / "F", optional) = only contacts of that side (PICTURE: the
-- group's side, so a friendly next to a hostile group is not picked)
function DL_TAC.intc_start(contacts, t, x, z, n_group, side)
	local best, bd = nil, (CFG.intc_pick_m or 8000) ^ 2
	for _, c in ipairs(contacts or {}) do
		local b = (c[0] or 0) % 10
		if b ~= 5 and b ~= 4 and usable(c, t) and (not side or side_of(c) == side) then   -- not own flight / AWACS
			local cx, cz = cpos(c, t)
			local d = (cx - x) ^ 2 + (cz - z) ^ 2
			if d < bd then best, bd = c, d end
		end
	end
	if not best then return false end
	local cx, cz = cpos(best, t)
	-- side: the side the target is known as (see track(); v1.7.1 could
	-- silently jump from a hostile to a friendly flying close to it)
	DL_TAC.intc = {x = cx, z = cz, y = best[3] or 0, vx = best[4] or 0, vz = best[5] or 0, t = t, seen = t,
	               typ = DL_TAC.short_type(best.nm), hostile = ((best[0] or 0) % 10) == 2, n = n_group, side = side_of(best)}
	return true
end
function DL_TAC.intc_stop() DL_TAC.intc = nil end

-- a contact of side s may continue the track: the same side; an unknown
-- one (a report can downgrade, e.g. only our radar still sees it: H -> U,
-- F -> U); or anything while the target itself is still unknown (U -> H,
-- U -> F, it gets identified). Never hostile <-> friendly directly.
local function side_ok(s, I) return s == I.side or s == "U" or I.side == "U" end
-- follow the track: the contact of an allowed side nearest to where it should be now
local function track(I, contacts, t)
	local dt = t - I.t
	local px, pz = I.x + I.vx * dt, I.z + I.vz * dt
	-- the gate grows with the time since the target was last seen (v1.7.1 used
	-- the frame step, so the gate never grew while the track was coasting)
	local gate = (CFG.intc_gate_m or 6000) + math.sqrt(I.vx * I.vx + I.vz * I.vz) * math.min(t - I.seen, 10) * 0.3
	local best, bd = nil, gate * gate
	for _, c in ipairs(contacts or {}) do
		local b = (c[0] or 0) % 10
		if b ~= 5 and b ~= 4 and side_ok(side_of(c), I) and usable(c, t) then
			local cx, cz = cpos(c, t)
			local d = (cx - px) ^ 2 + (cz - pz) ^ 2
			if d < bd and math.abs((c[3] or 0) - I.y) < 4000 then best, bd = c, d end
		end
	end
	if best then
		I.x, I.z = cpos(best, t)
		I.y, I.vx, I.vz = best[3] or I.y, best[4] or I.vx, best[5] or I.vz
		I.typ = DL_TAC.short_type(best.nm) or I.typ
		I.seen = t
		-- once seen as hostile / friendly that is its side, also while a
		-- later report only says unknown
		local bs = side_of(best)
		if bs ~= "U" then I.side, I.hostile = bs, (bs == "H") end
	else
		I.x, I.z = px, pz
	end
	I.t = t
end

-- collision course: time t > 0 when |D + Vt t| = Vo t. Returns t (s) or nil
local function collision(dx, dz, vx, vz, vo)
	local a = vx * vx + vz * vz - vo * vo
	local b = 2 * (dx * vx + dz * vz)
	local c = dx * dx + dz * dz
	if math.abs(a) < 1e-6 then
		if b < 0 then return -c / b end
		return nil
	end
	local disc = b * b - 4 * a * c
	if disc < 0 then return nil end
	local s = math.sqrt(disc)
	local t1, t2 = (-b - s) / (2 * a), (-b + s) / (2 * a)
	local tt = nil
	if t1 > 0 then tt = t1 end
	if t2 > 0 and (not tt or t2 < tt) then tt = t2 end
	return tt
end
DL_TAC.collision = collision

-----------------------------------------------------------------------
-- drawing on the SA page (parameters DL_INTC_*, see dl_page.lua)
-----------------------------------------------------------------------
local HC = {}
local function set(n, v)
	local h = HC[n]
	if not h then h = {h = get_param_handle(n)}; HC[n] = h end
	if h.v ~= v then h.v = v; h.h:set(v) end
end
DL_INTC_POOL = DL_INTC_POOL or {y = 30, r = 20}
local used, last_used = {}, {}
local CL = {x0 = -0.86, x1 = 0.86, y0 = -1.15, y1 = 0.70}
local function seg_clip(x1, y1, x2, y2, oy)
	local yl, yh = CL.y0 - oy, CL.y1 - oy
	local dx, dy = x2 - x1, y2 - y1
	local t0, t1 = 0, 1
	local p = {-dx, dx, -dy, dy}
	local q = {x1 - CL.x0, CL.x1 - x1, y1 - yl, yh - y1}
	for i = 1, 4 do
		if p[i] == 0 then
			if q[i] < 0 then return nil end
		else
			local r = q[i] / p[i]
			if p[i] < 0 then if r > t1 then return nil elseif r > t0 then t0 = r end
			else if r < t0 then return nil elseif r < t1 then t1 = r end end
		end
	end
	return t0, t1
end
-- dashed line between two scope points into pool "y" / "r"
local function dash(pool, x1, y1, x2, y2, oy, on, off)
	local t0, t1 = seg_clip(x1, y1, x2, y2, oy)
	if not t0 then return end
	local L = math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
	if L < 1e-6 or not fin(L) then return end
	-- only the dash periods over the part on the scope: a long stern chase
	-- runs the line far off the scope, walking it all from the jet cost
	-- thousands of steps per frame (the dashes stay where they were)
	local per = on + off
	local s = math.floor(t0 * L / per) * per
	local stop = t1 * L
	while s < stop do
		local a, b = math.max(s / L, t0), math.min((s + on) / L, t1)
		if b > a then
			local i = (used[pool] or 0) + 1
			if i > DL_INTC_POOL[pool] then return end
			used[pool] = i
			local pre = "DL_INTC_" .. pool .. i .. "_"
			set(pre .. "X1", x1 + (x2 - x1) * a); set(pre .. "Y1", y1 + (y2 - y1) * a)
			set(pre .. "X2", x1 + (x2 - x1) * b); set(pre .. "Y2", y1 + (y2 - y1) * b)
			set(pre .. "V", 1)
		end
		s = s + on + off
	end
end
local function finish()
	for pool, n in pairs(DL_INTC_POOL) do
		local u = used[pool] or 0
		for i = u + 1, (last_used[pool] or n) do set("DL_INTC_" .. pool .. i .. "_V", 0) end
		last_used[pool] = u
	end
end

local function off()
	-- (the target ring only has DL_INTC_TV: v1.7.1 left it on the scope
	-- after the intercept was switched off or dropped)
	set("DL_INTC_ON", 0); set("DL_INTC_XV", 0); set("DL_INTC_TV", 0)
	used = {}
	finish()
end
DL_TAC.hide = off

local function mmss(s)
	if not s or s ~= s or s < 0 or s > 5999 then return "--:--" end
	return string.format("%d:%02d", math.floor(s / 60), math.floor(s % 60))
end

-- the optional DL_CFG.geo_clip (shared with dl_geo.lua): 4 numbers
-- {x min, x max, y min, y max}, else it is ignored
local function clip_cfg()
	local c = CFG.geo_clip
	if type(c) ~= "table" then return nil end
	for i = 1, 4 do if not fin(c[i]) then return nil end end
	if c[1] >= c[2] or c[3] >= c[4] then return nil end
	return c
end

local draw_body
-- v = the device's view (cx, cz, k, ch, sh, ox, oz, oy, unit_m, unit_lbl)
-- hdg = true heading (rad), tas = own speed (m/s), fuel kg, ff kg/h (nil = not measured yet), bingo kg
-- returns the header steering text while an intercept runs
-- v1.7.2: dl_device's update() calls this without a pcall, so an error here
-- would stop the whole SA page every frame: the body runs protected; on an
-- error the intercept is dropped and hidden (logged once)
function DL_TAC.draw(v, contacts, t, hdg, tas, fuel, ff, bingo)
	local ok, r = pcall(draw_body, v, contacts, t, hdg, tas, fuel, ff, bingo)
	if ok then return r end
	if not DL_TAC.err_logged then
		DL_TAC.err_logged = true
		if DL_dbg then pcall(DL_dbg, "device", "INTC draw error (intercept dropped): " .. tostring(r)) end
	end
	DL_TAC.intc = nil
	last_used = {}                 -- hide every piece, also those set before the error
	pcall(off)
	return nil
end
draw_body = function(v, contacts, t, hdg, tas, fuel, ff, bingo)
	local I = DL_TAC.intc
	used = {}
	if not I then off(); return nil end
	-- inputs that are not real numbers would end up in the texts
	hdg = fin(hdg) and hdg or 0
	tas = fin(tas) and tas or 0
	if not fin(fuel) then fuel = nil end
	if not fin(ff) then ff = nil end
	if not fin(bingo) then bingo = nil end
	track(I, contacts, t)
	local lost = (t - I.seen) > (CFG.intc_lost_s or 12)
	if (t - I.seen) > (CFG.intc_drop_s or 60) then DL_TAC.intc = nil; off(); return nil end
	local c = clip_cfg()
	if c then CL.x0, CL.x1, CL.y0 = c[1], c[2], c[3] end
	set("DL_INTC_ON", 1)
	local ch, sh, k, oy = v.ch, v.sh, v.k, v.oy or 0
	local function scr(x, z)
		local dE, dN = z - v.cz, x - v.cx
		return (dE * ch - dN * sh) * k, (dE * sh + dN * ch) * k
	end
	local tx, ty = scr(I.x, I.z)
	set("DL_INTC_TX", tx); set("DL_INTC_TY", ty)
	local inside = tx > CL.x0 and tx < CL.x1 and ty + (v.oy or 0) > CL.y0 and ty + (v.oy or 0) < CL.y1
	set("DL_INTC_TV", (not inside) and 0 or (lost and 2 or 1))
	local ox, oz = v.ox, v.oz
	local vo = math.max(tas or 0, CFG.intc_min_speed or 150)
	local dx, dz = I.x - ox, I.z - oz
	local rng = math.sqrt(dx * dx + dz * dz)
	local tti = collision(dx, dz, I.vx, I.vz, vo)
	local cmd, ix, iz
	if tti and tti < 3600 then
		ix, iz = I.x + I.vx * tti, I.z + I.vz * tti
		cmd = math.atan2(iz - oz, ix - ox)
		local sx, sy = scr(ix, iz)
		local own_x, own_y = scr(ox, oz)
		set("DL_INTC_XX", sx); set("DL_INTC_XY", sy)
		set("DL_INTC_XV", (sx > CL.x0 and sx < CL.x1 and sy + oy > CL.y0 and sy + oy < CL.y1) and 1 or 0)
		dash("y", own_x, own_y, sx, sy, oy, 0.05, 0.03)
		dash("r", tx, ty, sx, sy, oy, 0.03, 0.025)
	else
		tti = nil
		cmd = math.atan2(dz, dx)                         -- cannot cut it off: pure pursuit
		set("DL_INTC_XV", 0)
	end
	finish()
	-- heading bar: +-20 deg, 0.012 page units per degree
	local hd = math.deg(hdg) % 360
	local cd = math.deg(cmd) % 360
	local diff = (cd - hd + 540) % 360 - 180
	local PX = CFG.intc_bar_scale or 0.012
	set("DL_INTC_DX", math.max(-20, math.min(20, diff)) * PX)
	set("DL_INTC_DP", (math.abs(diff) > 20) and 2 or 1)    -- 2 = pegged at the end
	local first = math.ceil((hd - 20) / 10) * 10
	local nl = 0
	for kk = 1, 7 do
		local d = first + (kk - 1) * 10
		local on = (d <= hd + 20)
		set("DL_INTC_K" .. kk .. "_X", (d - hd) * PX)
		set("DL_INTC_K" .. kk .. "_V", on and 1 or 0)
		if on and d % 30 == 0 and nl < 3 then
			nl = nl + 1
			set("DL_INTC_N" .. nl .. "_X", (d - hd) * PX)
			set("DL_INTC_N" .. nl .. "_T", (d % 360 == 0) and 360 or d % 360)   -- a number: the element formats it "%03.0f"
			set("DL_INTC_N" .. nl .. "_V", 1)
		end
	end
	for j = nl + 1, 3 do set("DL_INTC_N" .. j .. "_V", 0) end
	-- readouts
	local unit_m, ul = v.unit_m or 1000, v.unit_lbl or "KM"
	local spd_u, spd_l = (ul == "NM") and 1.94384 or 3.6, (ul == "NM") and "KT" or "KM/H"
	local cbrg = (math.floor(cd + 0.5) + 359) % 360 + 1
	local who = (I.typ or (I.hostile and "HOSTILE" or "TRACK")) .. ((I.n and I.n > 1) and (" X" .. I.n) or "")
	local asp = DL_TAC.aspect(I, ox, oz)
	set("DL_INTC_T1", (lost and "INTC LOST " or "INTC ") .. who .. " " .. asp:match("^(%S+)"))
	-- closure: own velocity along the heading flown
	local ovx, ovz = (tas or 0) * math.cos(hdg), (tas or 0) * math.sin(hdg)
	local vc = (rng > 1) and -(((I.vx - ovx) * dx + (I.vz - ovz) * dz) / rng) or 0
	set("DL_INTC_T2", string.format("CC %03d  X %s", cbrg, tti and mmss(tti) or "NO CUT"))
	local bt = (math.floor(math.deg(math.atan2(dz, dx)) + 0.5) + 359) % 360 + 1
	-- altitude in the SA page's units (alt_units)
	set("DL_INTC_T3", string.format("%03d/%d %s VC %d", bt, math.floor(rng / unit_m + 0.5),
		DL_TAC.alt_txt(I.y), math.floor(vc * spd_u + 0.5)))
	if tti and ff and ff > 50 and fuel then
		local fx = fuel - ff * tti / 3600
		local m = fx - (bingo or 0)
		if (bingo or 0) > 0 then
			set("DL_INTC_T4", string.format("X FUEL %d BNG%s%d", math.floor(fx + 0.5), (m >= 0) and "+" or "", math.floor(m + 0.5)))
		else
			set("DL_INTC_T4", string.format("X FUEL %d", math.floor(fx + 0.5)))
		end
		set("DL_INTC_C4", (m < 0) and 3 or ((m < (CFG.intc_fuel_amber or 500)) and 2 or 1))
	else
		set("DL_INTC_T4", tti and "X FUEL --" or "TAIL CHASE")
		set("DL_INTC_C4", tti and 4 or 2)
	end
	return string.format("INTC %03d %s", cbrg, tti and mmss(tti) or "PURSUIT")
end
