-----------------------------------------------------------------------
-- MiG-29 moving map + datalink page : cockpit device (avLuaDevice)
--
-- * keeps the map under the aircraft: works out which theatre we are on,
--   moves/turns the DCS chart tiles every frame and switches on only the
--   tiles around the jet
-- * draws the route that is loaded in the jet (DTC / mission), sent by
--   Scripts\MiG29DL_Export.lua from LoGetRoute(); falls back to the
--   mission route if the export feed is missing
-- * receives the datalink picture from the same export script
-- * MFD-3 : page  OFF -> MAP + DL -> DL only -> OFF
--   MFD-4 : range scale (cycles)
-----------------------------------------------------------------------

dofile(LockOn_Options.script_path .. "devices.lua")
dofile(LockOn_Options.script_path .. "command_defs.lua")
dofile(LockOn_Options.script_path .. "DL/dl_config.lua")
dofile(LockOn_Options.script_path .. "DL/dl_plan.lua")
dofile(LockOn_Options.script_path .. "DL/dl_pages_dev.lua")
pcall(dofile, LockOn_Options.script_path .. "DL/dl_snake.lua")   -- v1.7.4 easter egg (page 16)
dofile(LockOn_Options.script_path .. "DL/dl_theatres.lua")
dofile(LockOn_Options.script_path .. "DL/dl_geo.lua")
dofile(LockOn_Options.script_path .. "DL/dl_tac.lua")
pcall(dofile, LockOn_Options.script_path .. "DL/dl_ewr.lua")   -- v1.7.8 EWR picture from server text
dofile(LockOn_Options.script_path .. "DL/dl_boot.lua")
pcall(dofile, LockOn_Options.script_path .. "DL/dl_debug.lua")
local function dbg(m) if DL_dbg then DL_dbg("device", m) end end

local dev        = GetSelf()
local UPDATE     = 0.05
make_default_activity(UPDATE)

-- aircraft data: this MiG-29 module has no global sensor_data, the KRN
-- scripts use get_base_data() - use whichever exists
local SD = nil
local function sensors()
	if SD then return SD end
	if get_base_data then
		local ok, d = pcall(get_base_data)
		if ok and d then SD = d end
	end
	if not SD and sensor_data then SD = sensor_data end
	return SD
end

local CFG        = DL_CFG
local NMAX       = DL_MAX_CONTACTS
local NWPT       = DL_MAX_WPTS
local TWO_PI     = 2 * math.pi

-- Left bezel row (top to bottom): MFD-1, MFD-2, MFD-3, MFD-4, MFD-5 (NAV).
-- MFD-3 / MFD-4 are not used by the KRN MFD, so they belong to this page:
--   page off : MFD-4 = "DL" (open the page)
--   page on  : MFD-3 = range up, MFD-4 = range down
-- Any KRN button (MFD-1, 2, 5, 8) closes the page so the KRN page it opens
-- is not hidden underneath.
local function cmd(n, fallback) return (MFCD and MFCD["MFD_" .. n]) or fallback end
local CMD_UP     = cmd(3, 1103)
local CMD_DOWN   = cmd(4, 1104)
local CMD_DCTR   = cmd(2, 1102)    -- centre / decentre the scope
local CMD_MENU   = cmd(1, 1101)    -- DTC menu: open / load the choice
local CMD_EXP    = cmd(8, 1108)    -- expand x4 around the cursor
-- always_on = false used to mean "MFD-4 on the KRN menu opens the page".
-- Nothing opens it that way any more, so false left the display empty for
-- good: the page is always the MFD's page, whatever the setting says.
local ALWAYS_ON  = true
-- with the page always on, the KRN pages underneath are never shown, so
-- their buttons are ours; otherwise MFD-1/5/8 close the page
local CMD_CLOSE  = ALWAYS_ON and {} or {[cmd(1, 1101)] = true, [cmd(5, 1105)] = true, [cmd(8, 1108)] = true}
dev:listen_command(CMD_UP)
dev:listen_command(CMD_DOWN)
dev:listen_command(CMD_DCTR)
dev:listen_command(CMD_MENU)
-- the bezel buttons added to the model (connectors MFD-B*, R*, T*)
local NEWBTN = {[1106] = "B1", [1107] = "B2", [1109] = "B4", [1110] = "B5",
                [1111] = "R1", [1112] = "R2", [1113] = "R3", [1114] = "R4", [1115] = "R5",
                [1116] = "T1", [1117] = "T2", [1118] = "T3", [1119] = "T4", [1120] = "T5",
                [1121] = "BRT+", [1122] = "BRT-", [1123] = "DAY", [1124] = "NIGHT", [1125] = "SYM+", [1126] = "SYM-"}
for c in pairs(NEWBTN) do dev:listen_command(c) end
-- every bezel button by name, and the UFCP keypad (BTN 16-27, see dl_config)
local BTN = {[1101] = "M1", [1102] = "M2", [1103] = "M3", [1104] = "M4", [1105] = "M5", [1108] = "M8"}
for c, n in pairs(NEWBTN) do BTN[c] = n end
local KEYPAD = CFG.ufcp_keypad or {[18] = "K1", [17] = "K2", [16] = "K3", [21] = "K4", [20] = "K5", [19] = "K6",
                                   [24] = "K7", [23] = "K8", [22] = "K9", [26] = "K0", [25] = "CLR", [27] = "ENT"}
for n, k in pairs(KEYPAD) do BTN[6000 + n] = k; dev:listen_command(6000 + n) end
dev:listen_command(CMD_EXP)
dev:listen_command(cmd(5, 1105))
for c in pairs(CMD_CLOSE) do dev:listen_command(c) end

-- (v1.7.4: the TDC slew commands are no longer listened to - they never
-- reach this device in the MiG-29; the cursor jumps with H1-H5 / NEXT)
dev:listen_command(DL_BOOT.CMD_PWR)      -- v1.7 display POWER button (top-left rocker)

-----------------------------------------------------------------------
-- parameters
-----------------------------------------------------------------------
-- parameter handles that only write when the value changed (saves the
-- cockpit a lot of work: most values stay the same between updates)
local function P(n)
	local h = get_param_handle(n)
	local last = nil
	return {
		set = function(_, v) if v ~= last then last = v; h:set(v) end end,
		get = function() return h:get() end,
	}
end

local H = {}   -- cockpit parameter handles
-- the KRN avionics' waypoints (screen positions) and the active one: the
-- active waypoint number is the one whose position matches
local KRN = {act_lr = get_param_handle("MM_MFD_ACT_WPT_LR"), act_ud = get_param_handle("MM_MFD_ACT_WPT_UD"), lr = {}, ud = {}}
for i = 1, 20 do
	KRN.lr[i] = get_param_handle("MM_MFD_WPT_" .. i .. "_LR")
	KRN.ud[i] = get_param_handle("MM_MFD_WPT_" .. i .. "_UD")
end
local function krn_active()
	local ok, n = pcall(function()
		local a, b = KRN.act_lr:get(), KRN.act_ud:get()
		if type(a) ~= "number" or type(b) ~= "number" or (a == 0 and b == 0) then return 0 end
		for i = 1, 20 do
			local x, y = KRN.lr[i]:get(), KRN.ud[i]:get()
			if type(x) == "number" and math.abs(x - a) < 1e-4 and math.abs(y - b) < 1e-4 then return i end
		end
		return 0
	end)
	return ok and n or 0
end
H.dev_id    = P("DL_DEVICE_ID")
H.page      = P("DL_PAGE")          -- 0 off, 1 on
H.rot       = P("DL_MAP_ROT")
H.dx        = P("DL_MAP_DX")
H.dy        = P("DL_MAP_DY")
H.rng_txt   = P("DL_RANGE_TXT")
H.rng_half  = P("DL_RANGE_HALF_TXT")
H.hdg_txt   = P("DL_HDG_TXT")
H.stat_txt  = P("DL_STATUS_TXT")
H.src_txt   = P("DL_SOURCE_TXT")
H.mode_txt  = P("DL_MODE_TXT")
local NTHR = DL_MAX_THREATS or 16
local NSEG = DL_RING_SEGMENTS or 32
local hg = {}
for i = 1, NTHR do
	local g = {x = P("DL_G" .. i .. "_X"), y = P("DL_G" .. i .. "_Y"), vis = P("DL_G" .. i .. "_VIS"),
	           txt = P("DL_G" .. i .. "_TXT"), ring = P("DL_G" .. i .. "_RING"), px = {}, py = {}}
	for k = 1, NSEG do
		g.px[k] = P("DL_G" .. i .. "_P" .. k .. "_X")
		g.py[k] = P("DL_G" .. i .. "_P" .. k .. "_Y")
	end
	hg[i] = g
end
H.own_dy   = P("DL_OWN_DY")
H.own_sx   = P("DL_OWN_SX")
H.own_sy   = P("DL_OWN_SY")
H.exp      = P("DL_EXP")
H.exp_txt  = P("DL_EXP_TXT")
H.map_on   = P("DL_MAP_ON")
H.map_dimp = P("DL_MAP_DIM")   -- v1.7.9: black layers over the chart, 0..9
H.sym_hdr  = P("DL_SYM_HDR")
H.hdg_on   = P("DL_HDG_ON")       -- v1.8.1 heading tape (dl_tac DL_TAC.tape)
H.curs     = P("DL_CURS")
H.curs_x   = P("DL_CURS_X")
H.curs_y   = P("DL_CURS_Y")
H.curs_txt = P("DL_BTN1_TXT")
H.cbra     = P("DL_CURS_BRA")      -- cursor bearing / range from the jet
H.hov_col  = P("DL_HOV_COL")       -- 0 none, 1 green, 2 red, 3 yellow, 4 cyan
H.hov_id   = P("DL_HOV_ID")
H.hov_alt  = P("DL_HOV_ALT")
H.hov_bra  = P("DL_HOV_BRA")
H.hov_be   = P("DL_HOV_BE")
H.own_be   = P("DL_OWN_BE")         -- your own position from bullseye
H.lock_vis = P("DL_LOCK_VIS")
H.act_x    = P("DL_ACT_X")
H.act_y    = P("DL_ACT_Y")
H.act_vis  = P("DL_ACT_VIS")
H.steer_txt = P("DL_STEER_TXT")
H.dtc_txt  = P("DL_DTC_TXT")
H.dtc_ban  = P("DL_DTC_BAN")
H.dtc_ban_txt = P("DL_DTC_BAN_TXT")
H.ufcp_menu = P("DL_UFCP_MENU")
H.ufcp_l1  = P("DL_UFCP_L1")
H.ufcp_nav  = P("DL_UFCP_NAV")      -- 1 = our steerpoint lines cover KRN's (cartridge loaded)
H.ufcp_stp  = P("DL_UFCP_STP")      -- "STP W3"
H.ufcp_brg  = P("DL_UFCP_BRG")      -- true bearing to it (number, line 2), same as SA / NAV
H.ufcp_dist = P("DL_UFCP_DIST")     -- distance in the range units (number)
H.ufcp_dsel = P("DL_UFCP_DSEL")
     -- 1 = "%.1f" (under 100), 2 = "%.0f"
H.lock_x   = P("DL_LOCK_X")
H.lock_y   = P("DL_LOCK_Y")
H.btn2_txt = P("DL_BTN2_TXT")
H.card = {}
for _, c in ipairs({"N", "E", "S", "W"}) do
	H.card[c] = {x = P("DL_CARD_" .. c .. "_X"), y = P("DL_CARD_" .. c .. "_Y")}
end
H.north_x   = P("DL_NORTH_X")
H.north_y   = P("DL_NORTH_Y")
H.wa_x      = P("DL_WA_X")
H.wa_y      = P("DL_WA_Y")
H.wa_vis    = P("DL_WA_VIS")

local hc = {}
for i = 1, NMAX do
	hc[i] = {
		typ = P("DL_C" .. i .. "_TYPE"),
		x   = P("DL_C" .. i .. "_X"),
		y   = P("DL_C" .. i .. "_Y"),
		lx  = P("DL_C" .. i .. "_LX"),
		ly  = P("DL_C" .. i .. "_LY"),
		txt = P("DL_C" .. i .. "_TXT"),
		tx  = P("DL_C" .. i .. "_TX"),    -- v1.7.6 label offset (SYM 2 / 3)
		ty  = P("DL_C" .. i .. "_TY"),
		hdg = P("DL_C" .. i .. "_HDG"),
		mov = P("DL_C" .. i .. "_MOV"),
		col = P("DL_C" .. i .. "_COL"),
	}
end

local hw = {}
for i = 1, NWPT do
	hw[i] = {
		vis = P("DL_W" .. i .. "_VIS"),
		x   = P("DL_W" .. i .. "_X"),
		y   = P("DL_W" .. i .. "_Y"),
		seg = P("DL_W" .. i .. "_SEG"),
		txt = P("DL_W" .. i .. "_TXT"),
	}
end

-- markpoints (SA page B1 MARK / B2 DEL), shared with the pages in DL_PAGES.marks
local NMK = 5
local hm = {}
for i = 1, NMK do
	hm[i] = {vis = P("DL_MK" .. i .. "_VIS"), x = P("DL_MK" .. i .. "_X"), y = P("DL_MK" .. i .. "_Y")}
end
H.mk_any = P("DL_MK_ANY")

-----------------------------------------------------------------------
-- state
-----------------------------------------------------------------------
local page        = 0
local range_idx   = CFG.default_range_index or 3
local ranges      = (CFG.range_units == "nm") and CFG.ranges_nm or CFG.ranges_km
local unit_m      = (CFG.range_units == "nm") and 1852.0 or 1000.0
local unit_lbl    = (CFG.range_units == "nm") and "NM" or "KM"
if range_idx > #ranges then range_idx = #ranges end

local theatre     = nil
local chart       = nil    -- DL_CHART table for this theatre (DCS charts)
local tile_h      = {}     -- param handles DL_T<n>, created on demand
local tile_on     = {}     -- [n] = range step currently shown
local next_tiles  = 0
local last_tile_count = -1
local last_tile_range = -1

local contacts    = {}
local threats     = {}
local decentered  = false
local expanded    = false
local exp_cx, exp_cz = 0, 0   -- world point the expanded view is centred on
local curs_on     = false
local map_on      = CFG.opt_map == true   -- moving map on the SA page (B5 MAP), if enabled in Options > Special
-- v1.7.9: map dim level (B5 steps it), plus map_dim_night with the D/N switch at N
local MAPDIM = {lvl = 1}
function MAPDIM.steps()
	local s = CFG.map_dim_steps
	if type(s) ~= "table" or #s == 0 then s = {0} end
	return s
end
function MAPDIM.tick()
	local s = MAPDIM.steps()
	local v = tonumber(s[math.min(MAPDIM.lvl, #s)]) or 0
	if DL_PAGES.is_night and DL_PAGES.is_night() then v = v + (tonumber(CFG.map_dim_night) or 0) end
	v = math.floor(v + 0.5)
	if v < 0 then v = 0 elseif v > 9 then v = 9 end
	if v ~= MAPDIM.last then MAPDIM.last = v; H.map_dimp:set(v) end
end
local route_on    = CFG.show_route ~= false
-- flight plan choices: MSN, the .dtc files for this map, OFF (no plan drawn)
local PL = {files = {}, opts = {"MSN", "OFF"}, sel = 1, plan = nil, banner_t = -100,
            last_nav = nil, last_krn = nil, src = nil, act = nil, stp_i = nil, navb = {0, 0, 0},
            auto = CFG.nav_auto_seq ~= false}
-- the UFCP STP switch (KRN commands, we listen as well): up = next, down = previous
local CMD_STP_UP   = CFG.ufcp_stp_up or 6028
local CMD_STP_DOWN = CFG.ufcp_stp_down or 6029
-- the MiG-29 NAV panel WP-A/D buttons 1-3 (press animation arguments): a
-- press counts as the newest input even when that button was already lit
local NAV_BTN_ARGS = CFG.nav_btn_args or {424, 425, 426}
dev:listen_command(CMD_STP_UP)
dev:listen_command(CMD_STP_DOWN)
-- UFCP MRK = markpoint, FLT/MENU = NAV page (command numbers in dl_config)
local UFCP_BTN = {}           -- [command] = "MRK" / "NAV"
for k, list in pairs({MRK = CFG.ufcp_mrk_cmd or {6041, 6011}, NAV = CFG.ufcp_nav_cmd or {6042, 6015},
                      DIR = CFG.ufcp_dir_cmd or {6043, 6012}}) do
	if type(list) ~= "table" then list = {list} end
	for _, c in ipairs(list) do UFCP_BTN[c] = k; dev:listen_command(c) end
end
-- v1.7.2: the commands DL_BOOT.command tracks press / release for (every
-- bezel, keypad, STP and UFCP command handled here): only a new press of
-- one of them reaches SetCommand's own handling, whatever values the PC
-- sends. RELEASING = the commands whose clickable sends a release message
-- as well - keep this in step with Cockpit\Scripts\clickabledata.lua:
--   dl_push_button(): MFD-B1 B2 B4 B5 (1106 1107 1109 1110), MFD-R1..R5
--   (1111-1115), MFD-T1..T5 (1116-1120), and KRN's MFD-3 / 4 / 5 / 8
--   (MFCD.MFD_3/4/5/8 = 1103 1104 1105 1108) made again the same way;
--   MFD-PWR (1127, handled in dl_boot.lua) too.
-- Everything else is press-only (use_release_message false, or no
-- stop_action): KRN's MFD-1 / MFD-2 (default_button), the BRT / D-N / SYM
-- rockers, the UFCP keypad and MRK / DIR / NAV (default_button), STP UP
-- (the switch's right click) and the key bindings. STP DOWN (the left
-- click of KRN's default_switch_2_pos) has use_release_message = true
-- with an empty stop_action, so DCS may send a release on the same
-- command - tracked as releasing (it also works if none arrives).
local RELEASING = {[cmd(3, 1103)] = true, [cmd(4, 1104)] = true, [cmd(5, 1105)] = true, [cmd(8, 1108)] = true}
for c = 1106, 1120 do if c ~= 1108 then RELEASING[c] = true end end
local TRACK = {[CMD_STP_UP] = "press", [CMD_STP_DOWN] = "release"}
for c in pairs(BTN) do TRACK[c] = RELEASING[c] and "release" or "press" end
for c in pairs(UFCP_BTN) do TRACK[c] = "press" end
-- UFCP steerpoint lines while a cartridge is loaded (KRN's own lines only
-- know the mission route): "STP W3", then magnetic bearing and distance
-- the leg to the selected route steerpoint starts at the route point before
-- it; for the first point, after DIR (direct-to) or for airfields / NAV
-- panel points it starts where the jet was when it was selected
function PL.leg_start(ox, oz)
	local a, plan = PL.act, PL.cur
	if not a then PL.leg_key = nil; return nil end
	local key = tostring(PL.src) .. ":" .. tostring(PL.stp_i or "") .. ":" .. a.x .. ":" .. a.z
	if PL.leg_key ~= key then PL.leg_key, PL.leg_from = key, {x = ox, z = oz} end
	local i = (PL.src == "stp") and PL.stp_i or nil
	if i and i > 1 and plan and i <= (plan.nrt or 0) and PL.dir_i ~= i then return plan.pts[i - 1] end
	return PL.leg_from
end
-- route picked on the RTE page: PL.rte = route indices of the full plan
-- (nil = the whole route), for the plan named PL.rte_for
PL.rte, PL.rte_for, PL.rte_rev = nil, nil, 0
function PL.apply_rte(plan)
	if not plan or not PL.rte or PL.rte_for ~= plan.name then return plan end
	if PL.rv_base == plan and PL.rv_rev == PL.rte_rev then return PL.rview end
	PL.rv_base, PL.rv_rev = plan, PL.rte_rev
	PL.rview = DL_PLAN.route_view(plan, PL.rte)
	PL.rview.rte_sig = table.concat(PL.rte, ",")
	return PL.rview
end
function PL.set_rte(sel)
	local base = PL.base
	if not base then return end
	sel = (sel and #sel > 0) and sel or nil
	-- the same route again (RTE page DONE without a change): the working
	-- route keeps its edits
	local old = (PL.rte_for == base.name and PL.rte) and table.concat(PL.rte, ",") or ""
	if (sel and table.concat(sel, ",") or "") == old then return end
	PL.rte = sel
	PL.rte_for = base.name
	PL.rte_rev = PL.rte_rev + 1          -- a new route: the working route starts again from it
	PL.reset_work()
	PL.src, PL.stp_i, PL.dir_i = "stp", 1, nil
	DL_PAGES.dirty = true
	dbg("route: " .. (PL.rte and table.concat(PL.rte, " ") or "ALL"))
end
-- v1.7.2 working route: the route in use (MSN or a cartridge, after the
-- RTE choice) is copied once, and NAV ADD / DEL and the EDIT page change
-- only this copy - never the cartridge file. A new plan (LOAD, a slot
-- change, a full restart), a new RTE choice or a mission restart start
-- again from the plan. Typed-in points are labelled U1, U2 ...
PL.wgen, PL.work, PL.wn = 0, nil, 0
-- v1.7.5: a number for a list of route points (count, positions, numbers,
-- labels' lengths): the same points give the same number
function PL.route_sig(r)
	local h = #r
	for i, w in ipairs(r) do
		h = (h * 31 + (w.x or 0) * 0.37 + (w.z or 0) * 0.61 + (w.num or 0) * 7 + #(w.lbl or "") * 3 + i) % 2147483647
	end
	return h
end

function PL.reset_work()
	PL.wgen, PL.work, PL.wn = PL.wgen + 1, nil, 0
end
-- what the working route was copied from: plan name, generation, route
-- choice and the points' places (the MSN plan from the export feed is a
-- new table with every packet, the same route)
local function route_key(view)
	local t = {tostring(view.name), tostring(PL.wgen), tostring(view.rte_sig or "")}
	for i = 1, (view.nrt or #view.pts) do
		local w = view.pts[i]
		t[#t + 1] = string.format("%.0f/%.0f", w.x, w.z)
	end
	return table.concat(t, "|")
end
local function build_plan(view, list)
	local p = {}
	for k, v in pairs(view) do p[k] = v end
	p.pts, p._rt = {}, nil
	for i, w in ipairs(list) do p.pts[i] = w end
	p.nrt = #list
	for i = (view.nrt or #view.pts) + 1, #view.pts do p.pts[#p.pts + 1] = view.pts[i] end
	-- TOTs belong to this route through its edits (dl_pages_dev moves them
	-- with their points); a new working route starts without them
	p.nrt_base = view.nrt or #view.pts
	p.rte_sig = tostring(view.rte_sig or "") .. "#" .. PL.wgen
	return p
end
function PL.route_of(base)
	local view = PL.apply_rte(base)
	if not view then return view end
	local W = PL.work
	if W and W.view == view then return W.plan end
	local key = route_key(view)
	if W and W.key == key then W.view = view; return W.plan end
	local list = {}
	for i = 1, (view.nrt or #view.pts) do
		local c = {}
		for k, v in pairs(view.pts[i]) do c[k] = v end
		list[i] = c
	end
	PL.work = {key = key, view = view, list = list, edited = false}
	PL.work.plan = build_plan(view, list)
	if W then dbg("working route: " .. #list .. " points from " .. tostring(view.name)) end
	return PL.work.plan
end
-- the working route now (made at once after a reset in this same frame)
local function work()
	if PL.base then PL.route_of(PL.base) end
	return PL.work
end
PL.get_work = work
-- change the working route: fn(list) edits the list in place (returns
-- false = nothing done). The active steerpoint stays the same point (its
-- number may change); when it is deleted the next point becomes active.
local function edit_route(fn)
	local W = work()
	if not W then return false end
	local old = W.plan
	local onrt = old.nrt or 0
	local oi = (PL.src == "stp") and PL.stp_i or nil
	local act = (oi and oi <= onrt) and old.pts[oi] or nil
	local dir = PL.dir_i and old.pts[PL.dir_i] or nil
	if fn(W.list) == false then return false end
	W.edited = true
	W.plan = build_plan(W.view, W.list)
	local n = #W.list
	local function pos(w) for i, v in ipairs(W.list) do if v == w then return i end end end
	if act then
		local ni = pos(act)
		if ni then PL.stp_i = ni
		elseif n > 0 then PL.stp_i, PL.dir_i, PL.leg_key = math.min(oi, n), nil, nil
		else PL.src, PL.stp_i, PL.dir_i = nil, nil, nil end
		if dir and PL.dir_i then PL.dir_i = pos(dir) end
	elseif oi and oi > onrt then
		PL.stp_i = oi - onrt + n                    -- an airfield: the same airfield
		PL.dir_i = PL.dir_i and (PL.dir_i - onrt + n) or nil
	end
	PL.cur = W.plan                                 -- (update sets it every frame; now for the pages)
	DL_PAGES.dirty = true
	return true
end
local function new_point(x, z)
	PL.wn = PL.wn + 1
	return {x = x, z = z, lbl = "U" .. PL.wn, name = "MAN", user = true}
end
-- the working route's points (route only, no airfields)
function PL.wp_list() local W = work(); return W and W.list or {} end
-- a typed-in point after route position i (0 = in front, nil = at the
-- end); returns its position
function PL.wp_insert(i, x, z)
	local p, w
	local ok = edit_route(function(L)
		p = math.max(0, math.min(i or #L, #L)) + 1
		w = new_point(x, z)
		table.insert(L, p, w)
	end)
	if not ok then return nil end
	dbg(string.format("waypoint %s added at %.0f %.0f (route position %d)", w.lbl, x, z, p))
	return p
end
function PL.wp_delete(i)
	local lbl
	local ok = edit_route(function(L)
		if not L[i] then return false end
		lbl = L[i].lbl
		table.remove(L, i)
	end)
	if ok then dbg("waypoint " .. tostring(lbl) .. " deleted (route position " .. i .. ")") end
	return ok
end
-- one place earlier (d = -1) or later (d = 1); returns the new position
function PL.wp_move(i, d)
	local j = i + d
	local ok = edit_route(function(L)
		if not L[i] or not L[j] then return false end
		L[i], L[j] = L[j], L[i]
	end)
	if not ok then return nil end
	dbg(string.format("waypoint %s moved to route position %d", tostring(PL.work.list[j].lbl), j))
	return j
end
-- new coordinates for the point at route position i (name and place stay)
function PL.wp_set(i, x, z)
	local ok = edit_route(function(L)
		local w = L[i]
		if not w then return false end
		w.x, w.z, w.moved = x, z, true
	end)
	if ok then PL.leg_key = nil; dbg(string.format("waypoint %s moved to %.0f %.0f", tostring(PL.work.list[i].lbl), x, z)) end
	return ok
end
-- NAV page ADD: a typed-in point after the active steerpoint (else at the
-- end of the route), flown direct to at once; returns its route position
function PL.add_user(x, z)
	local W = work()
	if not W then return nil end
	local L, i = W.list, nil
	if PL.src == "stp" and PL.stp_i and PL.stp_i <= #L then i = PL.stp_i
	elseif PL.act then
		for k, w in ipairs(L) do if w == PL.act or (w.x == PL.act.x and w.z == PL.act.z) then i = k; break end end
	end
	local j = PL.wp_insert(i or #L, x, z)
	if not j then return nil end
	PL.src, PL.stp_i = "stp", j
	PL.dir_i, PL.leg_key = j, nil                  -- direct from here
	return j
end
-- NAV page DEL: the active steerpoint (any route point); returns its
-- route position
function PL.del_user()
	local W = work()
	local i = (PL.src == "stp") and PL.stp_i or nil
	if not (W and i and W.list[i]) then return nil end
	if PL.wp_delete(i) then return i end
	return nil
end
-- DIR: fly direct from here to the selected steerpoint
function PL.direct(ox, oz)
	PL.dir_i = PL.stp_i
	PL.leg_from = {x = ox, z = oz}
end
-- automatic steerpoint sequencing along the route (STP selection only):
-- next point when within 3 km, or flown past abeam within 10 km
function PL.seq(ox, oz)
	if PL.src ~= "stp" or not PL.stp_i or PL.auto == false then return end
	local plan, i = PL.cur, PL.stp_i
	if not plan or i >= (plan.nrt or 0) then return end       -- last route point or an airfield
	local w = plan.pts[i]
	if not w then return end
	local d = math.sqrt((w.x - ox) ^ 2 + (w.z - oz) ^ 2)
	local go = d < (CFG.nav_seq_radius_m or 3000)
	if not go and d < (CFG.nav_seq_abeam_m or 10000) then
		local s = PL.leg_start(ox, oz)
		if s then
			local lx, lz = w.x - s.x, w.z - s.z
			local L = math.sqrt(lx * lx + lz * lz)
			if L > 500 and ((ox - s.x) * lx + (oz - s.z) * lz) / L > L then go = true end
		end
	end
	if go then
		PL.stp_i = i + 1; PL.dir_i = nil
		DL_PAGES.dirty = true
		dbg(string.format("auto sequence: steerpoint %d -> %d (%.1f km)", i, i + 1, d / 1000))
	end
end
-- v1.6: ONE steering solution for every display (SA "TO ..", NAV page,
-- UFCP line 2): true bearing (1..360) and distance (m) from the jet to the
-- active steerpoint. (The UFCP used to convert to magnetic with KRN's
-- MM_AC_HDG_MAG, which turned out not to be a usable magnetic heading -
-- up to 150 deg off in flight - so there is no magnetic conversion anywhere.)
function PL.steer_to(a, ox, oz)
	if not a then return nil end
	local dN, dE = a.x - ox, a.z - oz
	return (math.floor(math.deg(math.atan2(dE, dN)) + 0.5) + 359) % 360 + 1, math.sqrt(dN * dN + dE * dE)
end
function PL.ufcp_nav(ox, oz, hdg, ron)
	local a = (PL.plan or PL.src == "stp") and ron and PL.act
	if not a or CFG.ufcp_nav == false then H.ufcp_nav:set(0); return end
	local brg, dm = PL.steer_to(a, ox, oz)
	local d = dm / unit_m
	H.ufcp_stp:set("STP " .. tostring(a.lbl or "WPT"):sub(1, 4))
	H.ufcp_brg:set(brg)
	H.ufcp_dsel:set((d < 99.95) and 1 or 2)
	H.ufcp_dist:set(d)
	H.ufcp_nav:set(1)
end
function PL.nav_pressed()
	local hit = false
	for k = 1, 3 do
		local ok, v = pcall(get_cockpit_draw_argument_value, NAV_BTN_ARGS[k])
		v = (ok and tonumber(v)) or 0
		if v > 0.3 and (PL.navb[k] or 0) <= 0.3 then hit = true end
		PL.navb[k] = v
	end
	return hit
end
local function plan_opts(th)
	local cur = PL.opts[PL.sel]
	PL.files = DL_PLAN.list_files(th)
	PL.opts = {"MSN"}
	for _, f in ipairs(PL.files) do PL.opts[#PL.opts + 1] = f end
	PL.opts[#PL.opts + 1] = "OFF"
	-- v1.7.2: the list is built again on every boot and NAV page visit;
	-- keep PL.sel on the same choice when files were added or removed
	local want = (type(cur) == "table") and cur.name or cur
	for i, o in ipairs(PL.opts) do
		if ((type(o) == "table") and o.name or o) == want then PL.sel = i; break end
	end
end
local function opt_name(o)
	if type(o) == "table" then return o.name end
	return o
end
local sel_hostile = 0         -- >0: cursor on the n-th nearest hostile (DL page T1-T5)
local sel_rank    = 0         -- >0: cursor sits on the n-th nearest contact (MFD-5 NEXT)
local cur_x, cur_y = 0, 0     -- cursor on the scope (page units from the scope origin)
local last_upd_t  = nil
local view = {cx = 0, cz = 0, k = 1, ch = 1, sh = 0, ox = 0, oz = 0}   -- last frame's view, for the buttons
local last_rx     = -1000
local status_bits = 0

local mission_route = {}
local ex_route    = nil    -- route from the export feed {points = {...}, active = n, t = time}

-----------------------------------------------------------------------
-- helpers
-----------------------------------------------------------------------
local function now()
	if get_model_time then return get_model_time() end
	if get_absolute_model_time then return get_absolute_model_time() end
	return 0
end

local function true_heading()
	-- sensor_data.getHeading() is counter-clockwise from north (the KRN
	-- avionics convert it the same way: 2*pi - getHeading()).
	local h = TWO_PI - (sensors().getHeading() or 0)
	return h % TWO_PI
end

-- SA contact label. SYM level 1 FULL "H7.2 M0.78", 2 GROUP "7 .8", 3 ALT "H7"
-- (2 and 3: close contacts of one colour share one label, "3X 7 .8")
-- (labels are never a bare number: DCS would store it as one)
local function fmt_alt(alt_m, vx, vz, lvl)
	if lvl == 2 or lvl == 3 then
		local k = (CFG.alt_units == "kft") and (alt_m * 3.28084 / 1000) or (alt_m / 1000)
		local a = math.floor(k + 0.5)
		if lvl == 3 then return ((CFG.alt_units == "kft") and (a .. "K") or ("H" .. a)) end
		local hh = math.max(0, math.min(alt_m, 11000))
		local r = math.floor(math.sqrt((vx or 0) ^ 2 + (vz or 0) ^ 2) / math.sqrt(401.874 * (288.15 - 0.0065 * hh)) * 10 + 0.5)
		return a .. " " .. ((r < 10) and ("." .. r) or string.format("%.1f", r / 10))
	end
	local a
	if CFG.alt_units == "kft" then
		a = string.format("%dK", math.floor(alt_m * 3.28084 / 1000 + 0.5))
	else
		a = string.format("H%.1f", alt_m / 1000)
	end
	if CFG.show_mach == false then return a end
	-- Mach from ground speed and the standard-atmosphere speed of sound
	local h = math.max(0, math.min(alt_m, 11000))
	local snd = math.sqrt(401.874 * (288.15 - 0.0065 * h))
	local m = math.sqrt((vx or 0) ^ 2 + (vz or 0) ^ 2) / snd
	return a .. string.format(" M%.2f", m)
end

local function tile_handle(n)
	local h = tile_h[n]
	if not h then
		h = P("DL_T" .. n)
		tile_h[n] = h
	end
	return h
end

local function clear_tiles()
	for n, _ in pairs(tile_on) do
		tile_handle(n):set(0)
	end
	tile_on = {}
end

-- switch on the chart tiles that can appear on screen for this range step
local function update_tiles(ox, oz, range_m)
	local want = {}
	local ci = chart and chart.range_class[range_idx] or 0
	if ci and ci > 0 then
		local reach = 2.0 * range_m      -- screen corner is ~1.9 ranges from the jet
		for n, t in ipairs(chart.tiles) do
			if t[6] == ci then
				-- distance from the jet to the tile rectangle
				local dx = 0
				if ox < t[2] then dx = t[2] - ox elseif ox > t[4] then dx = ox - t[4] end
				local dz = 0
				if oz < t[3] then dz = t[3] - oz elseif oz > t[5] then dz = oz - t[5] end
				if dx * dx + dz * dz < reach * reach then
					want[n] = range_idx
				end
			end
		end
	end
	for n, r in pairs(tile_on) do
		if want[n] ~= r then tile_handle(n):set(0) end
	end
	for n, r in pairs(want) do
		if tile_on[n] ~= r then tile_handle(n):set(r) end
	end
	tile_on = want
	local c = 0
	for _ in pairs(want) do c = c + 1 end
	-- logged once per range change only (the count changes while flying)
	if range_idx ~= last_tile_range then
		last_tile_range = range_idx
		last_tile_count = c
		local names = {}
		for n, _ in pairs(want) do names[#names + 1] = chart.tiles[n][1] end
		dbg("range " .. range_idx .. ": " .. c .. " chart tiles on " .. table.concat(names, " "))
	end
end

local function load_mission_route()
	local ok, r = pcall(get_mission_route)
	mission_route = {}
	if ok and type(r) == "table" then
		-- points are {x = north, y = east}; the first one is where the
		-- flight starts, the KRN avionics number the rest 1, 2, 3 ...
		for i, w in ipairs(r) do
			local wz = w and (w.z or w.y)
			if w and w.x and wz and i > 1 then
				mission_route[#mission_route + 1] = {x = w.x, z = wz, num = i - 1, name = w.name}
			end
		end
	end
end


-----------------------------------------------------------------------
-- export feed over UDP (127.0.0.1:42888, sent by MiG29DL_Export.lua)
-----------------------------------------------------------------------
local DL_PORT   = 42888
local udp       = nil
local udp_state = "init"     -- "ok", "nosocket", "busy"
-- v1.7.2: retry / error bookkeeping of the receiver
local NET = {paths = false, next_open = 0, tries = 0, busy = 0}

local function open_udp()
	if not NET.paths then
		-- once only: this runs again every 5 s while there is no socket
		NET.paths = true
		local ok_lfs, lfs_mod = pcall(require, "lfs")
		local root = (ok_lfs and lfs_mod and lfs_mod.currentdir and lfs_mod.currentdir()) or "."
		package.path  = package.path  .. ";" .. root .. "/LuaSocket/?.lua"
		package.cpath = package.cpath .. ";" .. root .. "/LuaSocket/?.dll"
	end
	NET.tries = NET.tries + 1
	local ok, socket = pcall(require, "socket")
	if not ok or not socket then udp_state = "nosocket"; return end
	-- v1.7.2: the port first on our own (v1.7.1 always used "reuseaddr":
	-- then a second DCS on this PC bound the same port and the packets went
	-- to either one). Busy - e.g. DCS keeps the old cockpit's socket for a
	-- while after a respawn - share it at once with "reuseaddr" as v1.7.1
	-- did, so the datalink is there at once; NO DL BUSY (and a new try every
	-- 5 s) only when even that fails.
	local function bind(share)
		local u = socket.udp()
		if not u then return nil end
		u:settimeout(0)
		if share then pcall(function() u:setoption("reuseaddr", true) end) end
		if u:setsockname("127.0.0.1", DL_PORT) then return u end
		pcall(function() u:close() end)
		return nil
	end
	local u = bind(false)
	if not u then
		NET.busy = NET.busy + 1
		u = bind(true)
		if u then dbg("udp: port busy, sharing it (reuseaddr)") end
	end
	if not u then udp_state = "busy"; return end
	udp = u
	udp_state = "ok"
end

local feed = {own_coal = 0, be = nil, be_all = nil, lock = nil}
local function parse_be(data)
	local bx, by, rx, ry = data:match("B,([^,]*),([^,]*),([^,]*),([^,]*)")
	feed.be_all = {blue = {tonumber(bx), tonumber(by)}, red = {tonumber(rx), tonumber(ry)}}
end
-- v1.7.8: EWR picture report (hook, server trigger text). Placed from the
-- jet's position now; bearings true unless ewr_bearing = "magnetic".
-- The datalink list of the last export packet is kept in feed.dl_list so
-- the EWR contacts can be added to it here and when they expire.
local function ewr_contacts(t)
	local dl = ((t - last_rx) <= (CFG.stale_after_s or 8)) and feed.dl_list or {}
	return DL_EWR and DL_EWR.merge(dl, t) or dl
end
local function parse_ewr(data)
	if not DL_EWR then return end
	local sd = sensors()
	if not sd then return end
	local ox, _, oz = sd.getSelfCoordinates()
	local decl = 0
	if CFG.ewr_bearing == "magnetic" then
		pcall(function()
			local m = sd.getMagneticHeading and sd.getMagneticHeading()
			-- both counter-clockwise from north, like getHeading()
			if m then decl = (TWO_PI - (sd.getHeading() or 0)) - (TWO_PI - m) end
		end)
		decl = (decl + math.pi) % TWO_PI - math.pi
	end
	local t = now()
	if DL_EWR.on_packet(data, t, ox, oz, decl) then
		contacts = ewr_contacts(t)
		if DL_EWR.n == 1 then dbg("EWR picture: " .. #(DL_EWR.fr or {}) .. " friendly, " .. #(DL_EWR.hs or {}) .. " hostile") end
	end
end
local function parse_packet(data)
	if not data then return end
	if data:sub(1, 8) == "MIG29DLB" then return parse_be(data) end
	if data:sub(1, 8) == "MIG29DLE" then return parse_ewr(data) end
	if data:sub(1, 8) == "MIG29DLV" then
		-- RWR: V,azimuth,power,state,level1,name
		local r = {}
		for line in data:gmatch("[^\n]+") do
			-- full-fidelity jet: SPO-15 lamps
			local ms, ss, mt, ts, lk, up, dn, pl, on, ln = line:match("^P,(%d+),(%d+),(%d+),(%d+),(%d),(%d),(%d),(%d+),(%d),(%d)")
			if ms then
				feed.spo = {msec = ms, sec = ss, mtyp = mt, typ = ts, lock = lk == "1", above = up == "1", below = dn == "1",
				            pl = tonumber(pl) or 0, on = on == "1", launch = ln == "1"}
				feed.spo_t = now()
			end
			local az, pw, st, l1, nm = line:match("^V,([^,]*),([^,]*),([^,]*),([^,]*),(.*)$")
			if az and tonumber(az) then
				r[#r + 1] = {az = tonumber(az), pw = tonumber(pw) or 0, st = tonumber(st) or 1, l1 = tonumber(l1) or 0, name = nm}
			end
		end
		if #r > 0 or not feed.spo_t or now() - feed.spo_t > 2 then feed.rwr, feed.rwr_t = r, now() end
		return
	end
	if data:sub(1, 8) == "MIG29DLM" or data:sub(1, 8) == "MIG29DLW" then
		-- who flies which aircraft: unit name|player|type|... (hook script).
		-- M = the mission's client slots (any client), W = live list (single
		-- player / hosting only)
		local w = {}
		for line in data:gmatch("[^\n]+") do
			local un, pl, ty = line:match("^([^|]*)|([^|]*)|([^|]*)")
			if un and un ~= "" and not un:find("^MIG29DL") then w[un] = {player = pl, type = ty} end
		end
		if data:sub(8, 8) == "M" then feed.brief = w else feed.wpn, feed.wpn_t = w, now() end
		return
	end
	if data:sub(1, 8) == "MIG29DLR" then
		-- the cartridge stored with the player's jet in the mission (hook).
		-- v1.7.2: the hook sends it again when the player's slot changes and
		-- "P,<slot>" names the slot: a new P replaces the cartridge AND the
		-- radio presets (v1.7.1 kept the first ones for the whole session).
		-- No P line (no cartridge stored with that jet) counts as P "".
		local lines, src, n, radio = {R = {}, W = {}, A = {}}, nil, 0, {}
		for line in data:gmatch("[^\n]+") do
			local tag = line:sub(1, 1)
			if tag == "C" then
				local ch, fr = line:match("^C,([^,]*),([^,]*)")
				ch, fr = tonumber(ch), tonumber(fr)
				if ch and fr then radio[ch] = fr end
			elseif tag == "T" then
				-- an empty T line (no theatre in the mission) = not known
				local th = line:sub(3):match("^%s*(.-)%s*$")
				feed.theatre = (th ~= "") and th or nil
			elseif tag == "P" then src = line:sub(3)
			elseif lines[tag] then
				local x, z, num = line:match("^%a,([^,]*),([^,]*),([^,]*)")
				x, z = tonumber(x), tonumber(z)
				if x and z then lines[tag][#lines[tag] + 1] = {x = x, z = z, lbl = num}; n = n + 1 end
			end
		end
		local key = src or ""
		if key ~= feed.msn_key then
			local had = feed.msn_key ~= nil
			feed.msn_key = key
			feed.msn_dtc = (src and n > 0) and DL_PLAN.from_lines("MSN DTC", lines) or nil
			feed.msn_radio = next(radio) and radio or nil
			if had and not PL.plan then
				-- the mission plan in use was the old slot's: its route choice,
				-- typed-in points and steerpoint go with it
				PL.rte, PL.rte_rev = nil, PL.rte_rev + 1
				PL.reset_work()
				if PL.src == "stp" then PL.stp_i, PL.dir_i = 1, nil end
				DL_PAGES.dirty = true
			end
			local m = feed.msn_dtc
			dbg((had and "slot changed, mission DTC replaced (" or "mission DTC (") .. tostring(src or "none") .. "): " ..
			    (m and (#m.wps .. " waypoints, " .. #m.ads .. " airfields") or "no cartridge") .. ", " ..
			    (feed.msn_radio and "radio presets" or "no radio presets"))
		end
		return
	end
	if data:sub(1, 7) ~= "MIG29DL" then return end
	local lock = nil
	local t = now()
	local list, pts, active, status, thr = {}, {}, 0, 0, {}
	local fr = {}
	local stores = nil
	local f = {}                          -- v1.7.5: one field table for all lines (was one per line)
	for line in data:gmatch("[^\n]+") do
		local k = line:sub(1, 1)
		for i = #f, 1, -1 do f[i] = nil end
		local nf = 0
		-- (a field that is not a number is skipped, the next one moves up: as before)
		for v in line:gmatch(",([^,]*)") do local n = tonumber(v); if n ~= nil then nf = nf + 1; f[nf] = n end end
		if k == "F" then
			-- F,id,x,z,y,hdg,vx,vz,human,radar,jammer,type,unit name
			local id, x, z, y, hd, vx, vz, hu, rd, jm, ty, un = line:match("^F,([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$")
			if id and tonumber(x) then
				fr[#fr + 1] = {id = id, x = tonumber(x), z = tonumber(z), y = tonumber(y), hdg = tonumber(hd), vx = tonumber(vx),
				               vz = tonumber(vz), human = hu == "1", radar = rd == "1", jam = jm == "1", type = ty, unit = un}
			end
		elseif k == "Y" then
			local st, n, nm = line:match("^Y,([^,]*),([^,]*),(.*)$")
			if tonumber(st) then stores = stores or {}; stores[tonumber(st)] = {n = tonumber(n) or 0, name = nm or ""} end
		elseif k == "Z" and #f >= 3 then
			feed.snares = {gun = f[1], chaff = f[2], flare = f[3], cur = f[4]}
		elseif k == "C" and #f >= 7 then
			-- v1.6: optional 9th field = aircraft type (hostiles; for PICTURE / INTC)
			local nm = line:match("^C" .. string.rep(",[^,]*", 7) .. ",([^,]*)$")
			list[#list + 1] = {[0] = f[1], f[2], f[3], f[4], f[5], f[6], f[7], t = t - (f[7] or 0), nm = (nm ~= "") and nm or nil}
		elseif k == "W" and #f >= 3 then
			pts[#pts + 1] = {x = f[1], z = f[2], num = f[3]}
		elseif k == "A" then
			active = f[1] or 0
		elseif k == "S" then
			status = f[1] or 0
		elseif k == "O" then
			feed.own_coal = f[1] or 0
		elseif k == "N" and #f >= 4 then
			feed.nav = {f[1], f[2], f[3], sw = f[4], ret = f[5]}
		elseif k == "X" and #f >= 8 then
			feed.x = {radio_ch = f[1], radio_disp = f[2], rsbn = f[3], ils = f[4], adf = f[5], kru = f[6], kru_t = f[7], kru_u = f[8]}
			if not feed.x_logged then feed.x_logged = true; dbg("knobs: " .. line) end
		elseif k == "Q" and #f >= 9 then
			feed.q = {hyd_l = f[1], hyd_r = f[2], fint = f[3], fext = f[4], gear = f[5], flaps = f[6], brake = f[7], g = f[8], mach = f[9]}
			if not feed.q_logged then feed.q_logged = true; dbg("systems: " .. line) end
		elseif k == "E" and #f >= 6 then
			feed.e = {rpm_l = f[1], rpm_r = f[2], t_l = f[3], t_r = f[4], ff_l = f[5], ff_r = f[6]}
			if not feed.e_logged then feed.e_logged = true; dbg("engine info: " .. line) end
		elseif k == "L" and #f >= 5 then
			lock = {x = f[1], z = f[2], y = f[3], vx = f[4], vz = f[5], t = t}
		elseif k == "G" then
			local lbl, gx, gz, gr = line:match("^G,([^,]*),([^,]*),([^,]*),([^,]*)")
			gx, gz, gr = tonumber(gx), tonumber(gz), tonumber(gr)
			if lbl and gx and gz then
				-- (shown as text: ASCII, never number-like)
				thr[#thr + 1] = {lbl = DL_text and DL_text(lbl) or lbl, x = gx, z = gz, ring = gr or 0}
			end
		end
	end
	-- designated flight members (FLIGHT page) are drawn as own flight
	local w = feed.wpn or {}
	for _, a in ipairs(fr) do
		local pl = (w[a.unit] and w[a.unit].player) or (feed.brief and feed.brief[a.unit] and feed.brief[a.unit].player)
		if DL_PAGES.in_flight and DL_PAGES.in_flight(a.unit, pl) then
			for _, c in ipairs(list) do
				local b = (c[0] or 0) % 10
				if b == 1 or b == 6 then
					-- the contact where it is now (position + speed * age): in a
					-- busy mission the export sends an older position with its
					-- age, while the F line is already moved on
					local age = c[6] or 0
					if math.abs((c[1] or 0) + (c[4] or 0) * age - a.x) < 30 and math.abs((c[2] or 0) + (c[5] or 0) * age - a.z) < 30 then
						c[0] = (c[0] or 0) - b + 5
					end
				end
			end
		end
	end
	-- datalink switched off (Options > Special): only the own radar picture
	if CFG.opt_datalink == false then
		local own = {}
		for _, c in ipairs(list) do if (c[0] or 0) >= 10 then own[#own + 1] = c end end
		list, fr, thr = own, {}, {}
	end
	feed.fr     = fr
	if stores then feed.stores = stores end
	feed.dl_list = list
	contacts    = DL_EWR and DL_EWR.merge(list, t) or list
	threats     = thr
	feed.lock   = lock
	if last_rx < 0 then                     -- first packet only
		local cnt = {}
		for _, c in ipairs(list) do cnt[c[0]] = (cnt[c[0]] or 0) + 1 end
		local str = ""
		for k, v in pairs(cnt) do str = str .. " type" .. tostring(k) .. "=" .. v end
		dbg("datalink packet: " .. #list .. " contacts (" .. str .. " ), " .. #thr .. " ground threats, " .. #pts .. " route points")
	end
	last_rx     = t
	status_bits = math.floor(status + 0.5)
	if #pts > 0 then
		ex_route = {points = pts, active = math.floor(active + 0.5), t = t}
	end
end

local function poll_udp()
	if not udp then return end
	for _ = 1, 20 do
		local data, err = udp:receive(32768)    -- the export / hook keep packets <= 7500 bytes
		if not data then
			-- "timeout" = nothing waiting; anything else is logged (once)
			if err and err ~= "timeout" and not NET.rx_err then
				NET.rx_err = true
				dbg("datalink receive error: " .. tostring(err))
			end
			if err == "closed" then udp, udp_state = nil, "nosocket" end   -- opened again by net_tick
			break
		end
		parse_packet(data)
	end
end

-- v1.7.2: once per update (outside update: upvalue budget). Without a
-- socket (port busy, e.g. a cockpit not closed yet; LuaSocket missing)
-- try again every 5 s instead of staying without datalink. A packet that
-- breaks the parser is logged (the first one) instead of vanishing.
local function net_tick()
	if not udp then
		local t = now()
		if t >= NET.next_open or t < NET.next_open - 10 then
			NET.next_open = t + 5
			local before = udp_state
			local ok, e = pcall(open_udp)
			if not ok then udp_state = "nosocket" end
			-- logged: the first retry and every change, not each try
			if udp then
				dbg("udp: port " .. DL_PORT .. " open (try " .. NET.tries .. ")")
			elseif udp_state ~= before or not ok or NET.tries == 2 then
				dbg("udp: " .. udp_state .. (ok and "" or (" " .. tostring(e))) .. " - trying again every 5 s")
			end
		end
	end
	local ok, e = pcall(poll_udp)
	if DL_EWR and (DL_EWR.fr or DL_EWR.hs) then
		local t = now()
		if DL_EWR.expire(t) then contacts = ewr_contacts(t) end
	end
	if not ok and not NET.parse_err then
		NET.parse_err = true
		dbg("datalink packet error: " .. tostring(e))
	end
end

-----------------------------------------------------------------------
-- buttons
-----------------------------------------------------------------------
local function set_page(p)
	page = p
	H.page:set(page)
	if page ~= 1 then
		clear_tiles()
	end
end

-- world point under the cursor
local function cursor_world()
	local sx, sy = cur_x / view.k, cur_y / view.k
	-- inverse of the heading-up rotation
	local dE = sx * view.ch + sy * view.sh
	local dN = -sx * view.sh + sy * view.ch
	return view.cx + dN, view.cz + dE
end

-- what the page system may use from here
local CX = {}
-- v1.7.4: are the add-on's HOTAS binds in the MiG-29's controls? INSTALL.bat
-- adds them to DCS's own Input files; a DCS update or repair takes them out
-- again. true / false, nil = cannot tell (shown on the start-up BIT, UFCP LINK)
do
	local ok, r = pcall(function()
		local lfs_mod = require("lfs")
		local root = tostring(lfs_mod.currentdir()):gsub("[/\\]+$", "")
		local f = io.open(root .. "/Mods/aircraft/MiG-29-Fulcrum/Input/MiG-29-Fulcrum/joystick/default.lua", "r")
		if not f then return nil end
		local txt = f:read("*a") or ""
		f:close()
		return txt:find("VITEZOVI MFD ADD-ON BINDS BEGIN", 1, true) ~= nil
	end)
	CX.binds = ok and r or nil
	dbg("HOTAS binds in the MiG-29 controls: " .. ((CX.binds == true) and "yes" or (CX.binds == false) and "NO (run INSTALL.bat again)" or "cannot tell"))
end
-- (feed.theatre: DCS id from the hook, theatre: folder name; dl_plan
-- compares them with DL_same_theatre; nil = not known = every cartridge)
CX.dtc_opts = function() plan_opts(feed.theatre or theatre); return PL.opts end
CX.dtc_sel  = function() return PL.sel end
CX.dtc_load = function(i)
	local o = PL.opts[i]
	if not o then return end
	PL.sel = i
	route_on = (o ~= "OFF")
	PL.plan = (type(o) == "table") and DL_PLAN.from_cartridge(o.name, o.data) or nil
	-- a loaded cartridge starts on its first steerpoint (STP steps from there);
	-- the working route (typed-in points, edits) belonged to the old plan
	PL.reset_work()
	-- a cartridge with member tags starts on ALL = every point by number
	PL.rte = PL.plan and DL_PLAN.all_order(PL.plan) or nil
	PL.rte_for, PL.rte_rev = PL.plan and PL.plan.name, PL.rte_rev + 1
	PL.stp_i = nil
	if PL.plan and #PL.plan.pts > 0 then
		PL.src, PL.stp_i = "stp", 1
	elseif PL.src == "stp" then
		-- back to MSN / OFF: the NAV panel selection, else KRN's own STP
		-- number (it only counts again by itself once it changes)
		PL.src = (PL.last_nav and "nav") or ((PL.last_krn or 0) > 0 and "krn") or nil
	end
	PL.banner_t = now()
	dbg("flight plan: " .. opt_name(o) .. " (map " .. tostring(feed.theatre or theatre) .. ")")
end

-- STP switch with a cartridge loaded (PLAN > LOAD): step through its
-- steerpoints (route, then airfields), starting from the one selected now
-- MARK: the cursor position (SA page cursor on), else overhead
local function make_mark(at_cursor)
	local mk = DL_PAGES.marks
	-- overhead = where the jet is now (CX is set on every update; view is
	-- only as new as the last drawn scope)
	local wx, wz = CX.ox or view.ox, CX.oz or view.oz
	if not wx then return end
	if at_cursor then wx, wz = cursor_world() end
	mk.n = (mk.n % NMK) + 1
	mk[mk.n] = {x = wx, z = wz, t = now(), lbl = "M" .. mk.n, name = at_cursor and "CURSOR" or "OVERHEAD"}
	mk.last = mk.last or {}
	for j = #mk.last, 1, -1 do if mk.last[j] == mk.n then table.remove(mk.last, j) end end
	mk.last[#mk.last + 1] = mk.n
	mk.msg_t = now()
	DL_PAGES.dirty = true
	dbg(string.format("markpoint M%d at %.0f %.0f", mk.n, wx, wz))
end
-- UFCP NAV button: to the NAV page, pressed again back to the page before
local function nav_toggle()
	if DL_PAGES.mode == 12 or DL_PAGES.mode == 6 then
		DL_PAGES.mode = PL.nav_back or 1
	else
		PL.nav_back = DL_PAGES.mode
		DL_PAGES.mode = 12
	end
	DL_PAGES.dirty = true
end

local function stp_step(dir)
	-- v1.7.2: the route in use (RTE choice, typed-in points, edits); v1.7.1
	-- stepped through the cartridge as loaded, so NEXT never reached a
	-- typed-in point and with a short cartridge stayed on steerpoint 1
	local plan = PL.cur or PL.plan
	if not plan or not route_on then return end
	local list = plan.pts
	local n = #list
	if n == 0 then return end
	local i = (PL.src == "stp") and PL.stp_i or nil
	if not i and PL.act then
		local bd = math.huge
		for k, w in ipairs(list) do
			local d = (w.x - PL.act.x) ^ 2 + (w.z - PL.act.z) ^ 2
			if d < bd then i, bd = k, d end
		end
	end
	if i then i = (i - 1 + dir) % n + 1 else i = (dir > 0) and 1 or n end
	PL.src, PL.stp_i = "stp", i
	PL.dir_i = nil                         -- a new steerpoint: the leg comes from the route again
	DL_PAGES.dirty = true
	dbg("STP: steerpoint " .. i .. " of " .. n)
end
CX.stp_step = stp_step
-- v1.7 start-up: the cartridge choice loads a member's route; the clock
CX.dtc_route = function(sel)
	PL.rte = (sel and #sel > 0) and sel or nil
	PL.rte_for = PL.plan and PL.plan.name
	PL.rte_rev = PL.rte_rev + 1
	PL.reset_work()
	PL.src, PL.stp_i, PL.dir_i = "stp", 1, nil
end
CX.now = function() return now() end
-- v1.7.2: a plan is in use (MSN or a cartridge, not OFF): after a power cut
-- the boot then keeps it instead of offering the cartridge choice
CX.plan_in_use = function() local o = PL.opts[PL.sel]; return o ~= nil and o ~= "OFF" end
CX.buttons = TRACK
CX.stp_cmds = {[CMD_STP_UP] = true, [CMD_STP_DOWN] = true}
-- v1.7.2: the start-up code failed (boot_tick / SetCommand): normal pages
-- AND the power state machine to "on" - else DL_BOOT.command keeps every
-- button for the start-up screens (pages shown, buttons dead). Logged once.
local function boot_fail(err)
	local B = DL_BOOT
	if not B.err then B.err = true; dbg("boot error: " .. tostring(err)) end
	B.state, B.sw, B.was_on, B.dtc, B.keep_plan = "on", true, true, nil, nil
	H.boot = H.boot or get_param_handle("DL_BOOT")
	H.boot:set(0)
	H.pwr_hold = H.pwr_hold or get_param_handle("DL_PWR_HOLD")
	H.pwr_hold:set(0)
	DL_PAGES.dirty = true
end
-- PICTURE page: put the SA cursor on a world point (a group)
CX.cursor_to = function(x, z)
	curs_on, sel_rank, sel_hostile = true, 0, 0
	local dE, dN = z - view.cz, x - view.cx
	cur_x = (dE * view.ch - dN * view.sh) * view.k
	cur_y = (dE * view.sh + dN * view.ch) * view.k
end

function SetCommand(command, value)
	-- v1.7: display power; while the display is off or starting up the
	-- bezel and keypad belong to the start-up screens (STP switch excepted).
	-- v1.7.2: DL_BOOT.command also ends every release and repeat of the
	-- tracked buttons (CX.buttons) on every page, so what gets past it is
	-- one new press per click (this replaces the "value == 0" and debounce
	-- filters, which let a 0.25 / 517.25 release through as a press)
	local okb, done = pcall(DL_BOOT.command, command, value, CX, CX.stp_cmds)
	if not okb then
		boot_fail(done)
		return
	end
	if done then
		DL_PAGES.dirty = true
		return
	end
	if UFCP_BTN[command] == "MRK" then
		make_mark(curs_on and DL_PAGES.mode == 1)
		return
	elseif UFCP_BTN[command] == "NAV" then
		nav_toggle()
		return
	elseif UFCP_BTN[command] == "DIR" then
		-- direct to the selected steerpoint from here (as DIR on the NAV page)
		if PL.act then PL.direct(CX.ox or view.ox, CX.oz or view.oz); DL_PAGES.dirty = true end
		return
	end
	if command == CMD_STP_UP or command == CMD_STP_DOWN then
		-- MSN: KRN steps its own mission route (and its HUD follows it)
		if PL.plan then stp_step(command == CMD_STP_UP and 1 or -1) end
		return
	end
	local b = BTN[command]
	if not b then return end
	-- menu, the other pages, MFD-8 (MENU) and the keypad
	DL_PAGES.dirty = true
	if DL_PAGES.command(b, CX) then return end
	-- the DL (situation) page
	if b == "M1" then
		route_on = not route_on
	elseif b == "M2" then
		decentered = not decentered
		view.saved_dctr = nil          -- chosen by hand: keep it after EXP too
	elseif b == "M3" then
		if range_idx < #ranges then range_idx = range_idx + 1; clear_tiles(); next_tiles = 0 end
	elseif b == "M4" then
		if range_idx > 1 then range_idx = range_idx - 1; clear_tiles(); next_tiles = 0 end
	elseif b == "M5" then
		sel_hostile = 0
		if not curs_on then curs_on = true; cur_x, cur_y = 0, 0.3; sel_rank = 1
		else sel_rank = sel_rank + 1 end
	elseif b:match("^T%d$") then
		-- T1..T5: cursor to the nearest .. 5th nearest hostile
		curs_on = true; sel_rank = 0; sel_hostile = tonumber(b:sub(2))
	elseif b == "R1" then
		-- GEO: show / hide the cartridge's drawings (.geo.txt); datalink threats stay
		DL_GEO.toggle()
	elseif b == "R2" then
		DL_PAGES.mode = 14                -- PICTURE
	elseif b == "R3" then
		-- INTC: intercept steering on the contact under the cursor (else the
		-- nearest hostile); again = off
		if DL_TAC.intc then
			DL_TAC.intc_stop()
		else
			local tn = now()
			local px, pz = nil, nil
			if curs_on and view.hov_x then
				px, pz = view.hov_x, view.hov_z
			else
				local bd = nil
				for _, c in ipairs(contacts) do
					if ((c[0] or 0) % 10) == 2 then
						local x, z = DL_TAC.cpos(c, tn)
						local d = (x - view.ox) ^ 2 + (z - view.oz) ^ 2
						if not bd or d < bd then px, pz, bd = x, z, d end
					end
				end
			end
			if px then DL_TAC.intc_start(contacts, tn, px, pz) end
		end
	elseif b == "B5" then
		-- MAP: moving map on / off (only when enabled in Options > Special)
		-- v1.7.9: MAP -> MAP DIM -> MAP DARK (map_dim_steps) -> OFF -> MAP
		if CFG.opt_map == true then
			local steps = MAPDIM.steps()
			if not map_on then map_on, MAPDIM.lvl = true, 1
			elseif MAPDIM.lvl < #steps then MAPDIM.lvl = MAPDIM.lvl + 1
			else map_on = false end
			if not map_on then clear_tiles() end
			next_tiles = 0
			if DL_PAGES.show_toast then
				DL_PAGES.show_toast(map_on and (({"MAP", "MAP DIM", "MAP DARK"})[MAPDIM.lvl] or ("MAP " .. MAPDIM.lvl)) or "MAP OFF", now())
			end
		end
	elseif b == "B1" then
		make_mark(curs_on)
	elseif b == "B2" then
		-- DEL: the newest markpoint
		local mk = DL_PAGES.marks
		local j = mk.last and table.remove(mk.last)
		if j then mk[j] = nil end
	elseif b == "B4" then
		if not expanded then
			-- centre on the contact / SAM under the cursor (else the cursor point,
			-- else the jet). A contact picked with H1-H5 / NEXT is followed.
			if curs_on and view.hov_x then
				exp_cx, exp_cz = view.hov_x, view.hov_z
			elseif curs_on then
				exp_cx, exp_cz = cursor_world()
			else
				exp_cx, exp_cz = view.ox, view.oz
			end
			expanded = true
			cur_x, cur_y = 0, 0
			-- the expanded view is always centred: undo DCTR while expanded
			view.saved_dctr = decentered
			decentered = false
			-- RNG +/- in EXP zooms the expanded view only: the normal range
			-- comes back unchanged afterwards
			view.saved_range = range_idx
			-- and EXP comes back at the zoom it had last time
			if view.exp_range and ranges[view.exp_range] then range_idx = view.exp_range end
		else
			-- keep the cursor over the same spot when going back
			local wx, wz = cursor_world()
			expanded = false
			if view.saved_dctr ~= nil then decentered = view.saved_dctr; view.saved_dctr = nil end
			local f = CFG.expand_factor or 4
			local k = view.k / f
			view.exp_range = range_idx
			if view.saved_range and ranges[view.saved_range] then
				k = k * ranges[range_idx] / ranges[view.saved_range]
				range_idx = view.saved_range
			end
			view.saved_range = nil
			local dE, dN = wz - view.oz, wx - view.ox
			cur_x = (dE * view.ch - dN * view.sh) * k
			cur_y = (dE * view.sh + dN * view.ch) * k
		end
		clear_tiles()
		next_tiles = 0
	end
end

-----------------------------------------------------------------------
-- life cycle
-----------------------------------------------------------------------
function post_initialize()
	H.dev_id:set(devices.MIG29_DL or 0)
	set_page(1)
	if CFG.always_on == false then dbg("always_on = false is no longer supported: the DL page stays on") end
	-- v1.7.2: the export and the hook now cut unit / player names to 24
	-- characters ("start~end", DL_name_cut in dl_config.lua). FLIGHT members
	-- saved by v1.7.1 under the full names get the same cut when flight.txt
	-- is read, so they still match. (The cut is idempotent: harmless if the
	-- pages apply it themselves.)
	if DL_name_cut and DL_PAGES.load_flight and not DL_PAGES.load_flight_cut then
		local load = DL_PAGES.load_flight
		DL_PAGES.load_flight_cut = true
		DL_PAGES.load_flight = function(...)
			local list = load(...)
			if type(list) == "table" then
				for i, n in ipairs(list) do
					local okc, c = pcall(DL_name_cut, n)
					if okc and type(c) == "string" and c ~= "" then list[i] = c end
				end
			end
			return list
		end
	end
	DL_PAGES.init(dbg)

	local src = CFG.map_source or "none"
	local ok, th = pcall(DL_detect_theatre)
	theatre = ok and th or nil
	if src == "dcs" then
		chart = DL_load_chart(theatre)
	end

	load_mission_route()
	local okU, errU = pcall(open_udp)
	NET.next_open = now() + 5                 -- no socket: net_tick tries again
	dbg("theatre=" .. tostring(theatre) .. " chart=" .. tostring(chart and #chart.tiles) ..
	    " udp=" .. tostring(udp_state) .. " " .. tostring(errU) .. " base_data=" .. tostring(sensors() ~= nil))
	dbg("units: " .. (CFG.units_imperial and "imperial" or "metric") .. " from " .. tostring(CFG.units_from) ..
	    " (range " .. tostring(CFG.range_units) .. ", alt " .. tostring(CFG.alt_units) .. ", fuel " .. tostring(CFG.fuel_units) .. ")")
	if DL_SETTINGS and DL_SETTINGS.status ~= "none" then
		dbg("settings.lua " .. DL_SETTINGS.status .. ": " .. tostring(DL_SETTINGS.path) .. (DL_SETTINGS.err and (" - " .. DL_SETTINGS.err) or ""))
	end
	for i = 1, NMAX do hc[i].typ:set(0) end
	for i = 1, NWPT do hw[i].vis:set(0); hw[i].seg:set(0) end
	H.wa_vis:set(0)
end

local function hide_all()
	for i = 1, NMAX do hc[i].typ:set(0) end
	for i = 1, NWPT do hw[i].vis:set(0); hw[i].seg:set(0) end
	H.wa_vis:set(0)
	for i = 1, NTHR do hg[i].vis:set(0); hg[i].ring:set(0) end
	H.hov_col:set(0)
	H.lock_vis:set(0)
	H.ufcp_nav:set(0)                     -- KRN's own UFCP lines (nothing to steer from)
	DL_GEO.hide()
	DL_TAC.hide()
end

-- v1.7.8: the jet's position for the next cockpit load (the moving map is
-- built around it when the page cannot read the position itself), every
-- 30 s: Saved Games\DCS\Vitezovi-MFD-Addon\map_pos.txt "<theatre> x z"
local POS = {next = 0}
local function save_pos(t, ox, oz)
	if not ox or (t < POS.next and t >= POS.next - 60) then return end
	POS.next = t + 30
	pcall(function()
		local okl, l = pcall(require, "lfs")
		if not (okl and type(l) == "table" and l.writedir) then return end
		local dir = l.writedir() .. "Vitezovi-MFD-Addon"
		pcall(l.mkdir, dir)
		local f = io.open(dir .. "/map_pos.txt", "w")
		if f then f:write(string.format("%s %.0f %.0f\n", tostring(theatre or ""), ox, oz)); f:close() end
	end)
end

-- v1.7: what the start-up screens need (outside update: upvalue budget)
local function boot_tick()
	local t = now()
	CX.t = t
	pcall(MAPDIM.tick)
	local sd = sensors()
	local ox, oz = nil, nil
	if sd then local x, _, z = sd.getSelfCoordinates(); ox, oz = x, z end
	save_pos(t, ox, oz)
	CX.ox, CX.oz = ox, oz
	CX.chart_tiles = chart and chart.tiles and #chart.tiles or nil
	CX.dl_ok = (t - last_rx) <= (CFG.stale_after_s or 8) or (DL_EWR and DL_EWR.fresh(t)) or false
	CX.ncontacts = #contacts
	local ns = 0
	for _ in pairs(feed.stores or {}) do ns = ns + 1 end
	CX.nstations = (ns > 0) and ns or nil
	local be = nil
	if feed.be_all then
		local side = (feed.own_coal == 1) and feed.be_all.red or feed.be_all.blue
		if side and side[1] and side[2] and (side[1] ~= 0 or side[2] ~= 0) then be = side end
	end
	CX.be = be
	local ok, r = pcall(DL_BOOT.tick, CX)
	if not ok then
		boot_fail(r)                      -- fail safe: the normal pages, buttons working
		return false
	end
	if r then
		-- v1.7.2: display off / starting: update() stops before our UFCP
		-- steerpoint lines, which would freeze; KRN's own UFCP lines show
		-- meanwhile (update sets them again once the display is on)
		H.ufcp_nav:set(0)
		H.ufcp_menu:set(0)
	end
	return r
end

-- v1.7.5: the SA scope (draw_scope) and what it needs, outside update():
-- update() draws it only while the SA page is shown. Constant tables and
-- reused records: no new tables for every contact on every update.
local CONTACT_COL = {1, 2, 3, 1, 4, 1}
local CONTACT_IDN = {"FRND", "HSTL", "UNKN", "AWCS", "FLT", "DONR"}
local CARDS = {{"N", 0, 1}, {"E", 1, 0}, {"S", 0, -1}, {"W", -1, 0}}
local CAND = {}                      -- candidate records {sx, sy, d2, hostile, base, x, z}
local SORT_HS, SORT_REST = {}, {}
local function by_range(a, b) return a[3] < b[3] end
-- the view of this update: centre, scale, heading. Returns range_m, expf, k.
local function set_view(ox, oz, hdg)
	local range_m = ranges[range_idx] * unit_m
	local expf = expanded and (CFG.expand_factor or 4) or 1
	local k = CFG.range_radius / range_m * expf   -- display units per metre
	-- the scope is centred on the jet, or on the expanded point
	local vx0, vz0 = ox, oz
	if expanded then vx0, vz0 = exp_cx, exp_cz end
	view.cx, view.cz, view.k, view.ch, view.sh, view.ox, view.oz = vx0, vz0, k, math.cos(hdg), math.sin(hdg), ox, oz
	return range_m, expf, k
end
-- heading-up transform of a north-up offset (dE = east, dN = north) in metres
local function to_screen(dE, dN)
	local k, ch, sh = view.k, view.ch, view.sh
	return (dE * ch - dN * sh) * k, (dE * sh + dN * ch) * k
end
local function bra_of(ox, oz, wx, wz)
	local dN, dE = wx - ox, wz - oz
	local brg = (math.floor(math.deg(math.atan2(dE, dN)) + 0.5) + 359) % 360 + 1
	return string.format("%03d/%d%s", brg, math.floor(math.sqrt(dN * dN + dE * dE) / unit_m + 0.5), unit_lbl)
end
local function be_of(be, wx, wz, short)
	if not be then return "BE --" end
	local be_unit_m = (CFG.bullseye_units == "nm" and 1852) or (CFG.bullseye_units == "km" and 1000) or unit_m
	local be_lbl = (CFG.bullseye_units == "nm" and "NM") or (CFG.bullseye_units == "km" and "KM") or unit_lbl
	-- short (SA own position, v1.8.1): no unit when it is the range scale's
	if short and be_lbl == unit_lbl then be_lbl = "" end
	local dN, dE = wx - be[1], wz - be[2]
	local brg = (math.floor(math.deg(math.atan2(dE, dN)) + 0.5) + 359) % 360 + 1
	return string.format("BE %03d/%d%s", brg, math.floor(math.sqrt(dN * dN + dE * dE) / be_unit_m + 0.5), be_lbl)
end

-- v1.7.6 SYM 2 GROUP / 3 ALT: contacts of one colour drawn on top of each
-- other share one label ("3X 8 .81", over the one nearest the jet), and a
-- label that would still cover another label or symbol moves under or
-- beside its own symbol. Worked out when a new contact list comes in, the
-- scale or SYM level changes, and twice a second (turns rotate the scope);
-- in between the labels just ride with their symbols. Records are reused.
local LBL_K  = 0.0033 * (CFG.font_scale or 1.25) / (CFG.move_gain or 0.045)
local LBL_CW = LBL_K * (CFG.font_width or 1.0) * ((CFG.font_style == "dcs") and 0.5 or 0.4922)  -- one character
local LBL_H  = LBL_K * 0.80                                   -- capital height + a little air
local LBL_UP = (CFG.symbol_size or 0.045) * 1.35              -- label bottom above the symbol (dl_page.lua)
local LBL_S  = (CFG.symbol_size or 0.045) * 1.1               -- half size of a symbol box
local GROUP_R2 = (CFG.label_group_dist or 0.11) ^ 2           -- page units between symbols of one group
local LB, ORD = {}, {}                -- [i] = {sx, sy, col, d2, txt, lead, n, ci}
local BX1, BX2, BY1, BY2 = {}, {}, {}, {}   -- label boxes placed so far
-- by index in the contact list: label offset and text; when it was worked out
local LAY = {tx = {}, ty = {}, txt = {}, list = nil, sym = 0, k = 0, t = -1, own_x = 0, own_y = 0}
local LAY_TX, LAY_TY, LAY_TXT = LAY.tx, LAY.ty, LAY.txt
local function by_d2(a, b) return a[4] < b[4] end
-- how much the box x1..x2 / y1..y2 covers: of the labels placed so far
-- (counts three times), of the other symbols and of our own jet's symbol.
-- Written out (no helper calls): this runs up to 6 x 40 x 80 times.
local function hits(nb, nu, self, x1, x2, y1, y2)
	local n = 0
	for i = 1, nb do
		local a1, a2, b1, b2 = BX1[i], BX2[i], BY1[i], BY2[i]
		if x1 < a2 and x2 > a1 and y1 < b2 and y2 > b1 then
			n = n + 3 * (((x2 < a2) and x2 or a2) - ((x1 > a1) and x1 or a1)) * (((y2 < b2) and y2 or b2) - ((y1 > b1) and y1 or b1))
		end
	end
	local S = LBL_S
	for i = 1, nu do
		local r = LB[i]
		local a1, b1 = r[1] - S, r[2] - S
		if x1 < a1 + 2 * S and x2 > a1 and y1 < b1 + 2 * S and y2 > b1 and r ~= self then
			local a2, b2 = a1 + 2 * S, b1 + 2 * S
			n = n + (((x2 < a2) and x2 or a2) - ((x1 > a1) and x1 or a1)) * (((y2 < b2) and y2 or b2) - ((y1 > b1) and y1 or b1))
		end
	end
	local a1, a2, b1, b2 = LAY.own_x - 2 * S, LAY.own_x + 2 * S, LAY.own_y - 2 * S, LAY.own_y + 2 * S
	if x1 < a2 and x2 > a1 and y1 < b2 and y2 > b1 then
		n = n + (((x2 < a2) and x2 or a2) - ((x1 > a1) and x1 or a1)) * (((y2 < b2) and y2 or b2) - ((y1 > b1) and y1 or b1))
	end
	return n
end
-- candidate spots (label offset from its normal spot above the symbol):
-- above, below, right, left, one line higher, one line lower
local function cand_spot(k, w)
	if k == 1 then return 0, 0
	elseif k == 2 then return 0, -(2 * LBL_UP + LBL_H)
	elseif k == 3 then return LBL_S + w / 2 + 0.02, -(LBL_UP + LBL_H / 2)
	elseif k == 4 then return -(LBL_S + w / 2 + 0.02), -(LBL_UP + LBL_H / 2)
	elseif k == 5 then return 0, LBL_H
	else return 0, -(2 * LBL_UP + 2 * LBL_H) end
end
local function layout_labels(nu)
	-- groups: nearest contact first; it takes every contact of its colour
	-- within reach that has no group yet
	for i = 1, nu do ORD[i] = LB[i]; LB[i][6] = false; LB[i][7] = 0 end
	for i = #ORD, nu + 1, -1 do ORD[i] = nil end
	table.sort(ORD, by_d2)
	for i = 1, nu do
		local a = ORD[i]
		if not a[6] then
			a[6], a[7] = a, 1
			for j = i + 1, nu do
				local b = ORD[j]
				if not b[6] and b[3] == a[3] then
					local dx, dy = a[1] - b[1], a[2] - b[2]
					if dx * dx + dy * dy < GROUP_R2 then b[6] = a; a[7] = a[7] + 1 end
				end
			end
		end
	end
	-- spots: nearest first keeps the normal spot; the rest take the first
	-- spot that covers nothing (or the one that covers least)
	local nb = 0
	for i = 1, nu do
		local r = ORD[i]
		local ci = r[8]
		if r[6] ~= r then
			LAY_TXT[ci], LAY_TX[ci], LAY_TY[ci] = " ", 0, 0
		else
			local txt = (r[7] > 1) and string.format("%dX %s", r[7], r[5]) or r[5]
			local w = #txt * LBL_CW
			local best_k, best_n = 1, 1e9
			for k = 1, 6 do
				local ox, oy = cand_spot(k, w)
				local cx, by = r[1] + ox, r[2] + LBL_UP + oy
				local n = hits(nb, nu, r, cx - w / 2, cx + w / 2, by, by + LBL_H)
				if n < best_n then best_k, best_n = k, n end
				if n == 0 then break end
			end
			local ox, oy = cand_spot(best_k, w)
			LAY_TXT[ci], LAY_TX[ci], LAY_TY[ci] = txt, ox, oy
			nb = nb + 1
			local cx, by = r[1] + ox, r[2] + LBL_UP + oy
			BX1[nb], BX2[nb], BY1[nb], BY2[nb] = cx - w / 2, cx + w / 2, by, by + LBL_H
		end
	end
end

-- label text of a drawn contact (record r) at SYM level sym
local function lbl_txt(r, sym)
	return fmt_alt(r[9][3] or 0, r[10], r[11], sym)
end
-- texts and offsets of the labels of the contacts drawn this update
-- (LB[1..nu] go with hc[1..nu])
local function label_pass(nu, sym, t, k, list, own_x, own_y)
	if sym == 2 or sym == 3 then
		if list ~= LAY.list or sym ~= LAY.sym or k ~= LAY.k or t >= LAY.t then
			LAY.own_x, LAY.own_y = own_x, own_y
			for ci in pairs(LAY_TXT) do LAY_TXT[ci] = nil end
			for u = 1, nu do LB[u][5] = lbl_txt(LB[u], sym) end
			layout_labels(nu)
			LAY.list, LAY.sym, LAY.k, LAY.t = list, sym, k, t + 0.5
		end
		for u = 1, nu do
			local r, h = LB[u], hc[u]
			local ci = r[8]
			local txt = LAY_TXT[ci]
			if txt then
				h.txt:set(txt); h.tx:set(LAY_TX[ci]); h.ty:set(LAY_TY[ci])
			else                          -- came onto the scope since: its own label
				LAY_TXT[ci], LAY_TX[ci], LAY_TY[ci] = lbl_txt(r, sym), 0, 0
				h.txt:set(LAY_TXT[ci]); h.tx:set(0); h.ty:set(0)
			end
		end
	else
		for u = 1, nu do
			local h = hc[u]
			h.txt:set((sym <= 3) and lbl_txt(LB[u], sym) or " ")
			h.tx:set(0); h.ty:set(0)
		end
		LAY.list = nil
	end
end

local function draw_scope(t, sd, ox, oz, hdg, plan, stale, be)
	H.own_dy:set(decentered and (CFG.decenter_dy or -0.65) or 0)
	H.btn2_txt:set(decentered and "CNTR" or "DCTR")
	local range_m, expf, k = set_view(ox, oz, hdg)
	local vx0, vz0 = view.cx, view.cz
	H.exp:set(expanded and 1 or 0)
	H.exp_txt:set(expanded and "NORM" or "EXP")


	-- map: everything is placed in world metres * k, so shifting by the
	-- jet's own position and turning by heading keeps it under the jet
	H.rot:set(hdg * (CFG.map_rotation_sign or 1))
	H.dx:set(-vz0 * k)
	H.dy:set(-vx0 * k)
	do
		local sx, sy = to_screen(oz - vz0, ox - vx0)
		H.own_sx:set(sx); H.own_sy:set(sy)
	end
	H.map_on:set(map_on and 1 or 0)
	if page == 1 and (expanded or not map_on) then
		clear_tiles()
	elseif page == 1 and chart and t >= next_tiles then
		update_tiles(ox, oz, range_m)
		next_tiles = t + 0.25
	end

	local nx, ny = to_screen(0, range_m)
	H.north_x:set(nx)
	H.north_y:set(ny)
	-- compass letters on the range circle
	for i = 1, 4 do
		local d = CARDS[i]
		local cx, cy = to_screen(d[2] * range_m, d[3] * range_m)
		H.card[d[1]].x:set(cx)
		H.card[d[1]].y:set(cy)
	end

	-- texts ----------------------------------------------------------
	-- NOTE: every text value must contain a letter. DCS stores number-like
	-- strings ("80") as numbers and the "%s" text format then crashes DCS.
	if expanded then
		H.rng_txt:set(string.format("%g%s EXP", ranges[range_idx] / expf, unit_lbl))
	else
		H.rng_txt:set(string.format("%d%s", ranges[range_idx], unit_lbl))
	end
	H.rng_half:set(string.format("%g%s", ranges[range_idx] / 2, unit_lbl))
	H.hdg_txt:set(string.format("HDG %03d", (math.floor(math.deg(hdg) + 0.5) + 359) % 360 + 1))
	H.mode_txt:set("DL " .. unit_lbl)

	if CFG.opt_datalink == false then
		H.stat_txt:set(stale and "DL OFF" or string.format("DL OFF RDR %d", #contacts))
	elseif stale then
		H.stat_txt:set((udp_state == "ok") and "NO DL" or ("NO DL " .. string.upper(udp_state)))
	else
		H.stat_txt:set(" ")              -- all well: the count is on PICTURE
	end
	local src = ""
	if not stale then
		if status_bits % 2 == 1 then src = src .. "OBJ " else src = src .. "NOEXP " end
		if math.floor(status_bits / 2) % 2 == 1 then src = src .. "AWACS " end
		if math.floor(status_bits / 8) % 2 == 1 then src = src .. "F2F " end
		if math.floor(status_bits / 4) % 2 == 1 then src = src .. "RDR" end
	end
	if src == "" then src = "--" end
	H.src_txt:set(src)

	-- SYM level (SA page declutter): 4 CLEAN / 5 MIN hide the route, 5 also the marks and texts
	local sym = DL_PAGES.sym or 1
	H.sym_hdr:set((sym >= 5) and 0 or 1)
	local pts = (route_on and sym < 4) and plan.pts or {}
	local active = 0
	H.dtc_txt:set(route_on and ("DTC " .. (plan.label or plan.name)) or "FPL OFF")
	-- "LOADED <plan>" for a moment after a cartridge is loaded (PLAN > LOAD)
	H.dtc_ban:set(((t - PL.banner_t) < 3) and 1 or 0)
	H.dtc_ban_txt:set("LOADED  " .. (route_on and (plan.label or plan.name) or "FPL OFF") .. ((DL_GEO.n > 0) and "  +GEO" or ""))
	for i = 1, NWPT do
		local w = pts[i]
		if w then
			local sx, sy = to_screen(w.z - vz0, w.x - vx0)
			hw[i].x:set(sx)
			hw[i].y:set(sy)
			hw[i].vis:set(w.ad and 3 or 1)
			hw[i].seg:set((i > 1 and not w.ad) and 1 or 0)
			local lbl = w._sa_lbl
			if not lbl or w._sa_src ~= w.lbl then
				lbl = w.lbl and tostring(w.lbl):gsub("^WPT", "W") or ("W" .. tostring(math.floor((w.num or i) + 0.5)))
				if not lbl:find("%a") then lbl = "W" .. lbl end
				w._sa_lbl, w._sa_src = lbl, w.lbl
			end
			hw[i].txt:set(lbl)

		else
			hw[i].vis:set(0)
			hw[i].seg:set(0)
		end
	end
	-- markpoints
	do
		local mk = DL_PAGES.marks or {}
		H.mk_any:set((mk.last and #mk.last > 0) and 1 or 0)
		for i = 1, #hm do
			local m = mk[i]
			if m and sym < 5 then
				local sx, sy = to_screen(m.z - vz0, m.x - vx0)
				hm[i].x:set(sx); hm[i].y:set(sy)
				hm[i].vis:set((math.abs(sx) < 1.15 and sy < (CFG.text_top_y or 1.15) - 0.30 - ((CFG.ownship_y or 0) + (decentered and (CFG.decenter_dy or -0.65) or 0))) and 1 or 0)
			else
				hm[i].vis:set(0)
			end
		end
	end
	-- active waypoint marker, line from the jet and "W2 045/32" (v1.8.1: unit only on the range scale)
	local act = (route_on and sym < 4) and PL.act or nil
	if act then
		local ax, ay = to_screen(act.z - vz0, act.x - vx0)
		H.wa_x:set(ax); H.wa_y:set(ay); H.wa_vis:set(1)
		H.act_x:set(ax); H.act_y:set(ay); H.act_vis:set(1)
		local brg, dm = PL.steer_to(act, ox, oz)
		H.steer_txt:set(string.format("%s %03d/%d", act.lbl or "WPT", brg, math.floor(dm / unit_m + 0.5)))
	else
		H.wa_vis:set(0); H.act_vis:set(0); H.steer_txt:set("WPT --")
	end

	-- cursor -----------------------------------------------------------
	local origin_y = (CFG.ownship_y or 0) + (decentered and (CFG.decenter_dy or -0.65) or 0)
	local hover_txt = nil
	if curs_on then
		-- keep it on the screen
		if cur_x > 1.05 then cur_x = 1.05 elseif cur_x < -1.05 then cur_x = -1.05 end
		local ytop, ybot = 1.0 - origin_y, -1.45 - origin_y
		if cur_y > ytop then cur_y = ytop elseif cur_y < ybot then cur_y = ybot end
		H.curs:set(1); H.curs_x:set(cur_x); H.curs_y:set(cur_y)
		-- bearing / range from the jet to the cursor
		local wx, wz = cursor_world()
		local dN, dE = wx - ox, wz - oz
		local brg = (math.floor(math.deg(math.atan2(dE, dN)) + 0.5) + 359) % 360 + 1
		H.cbra:set(string.format("%03d/%d%s", brg, math.floor(math.sqrt(dN * dN + dE * dE) / unit_m + 0.5), unit_lbl))
	else
		H.curs:set(0)
		H.cbra:set("--")
	end
	H.curs_txt:set(route_on and "FPL ON" or "FPL OFF")
	local best_d, best = 0.07, nil      -- hover pick radius (page units)
	view.hov_x, view.hov_z = nil, nil   -- world position of what is under the cursor (for EXP)
	H.own_be:set(be_of(be, ox, oz, true))

	-- geo drawings (under the threats), in the same frame as the route
	view.oy, view.sym, view.unit_m, view.unit_lbl = origin_y, sym, unit_m, unit_lbl
	DL_GEO.draw(view)
	-- intercept steering (SA right 3 INTC)
	do
		local ok_t, tas = pcall(sd.getTrueAirSpeed)
		local ok_f, fuel = pcall(sd.getTotalFuelWeight)
		local st = DL_TAC.draw(view, contacts, t, hdg, ok_t and tonumber(tas) or 0, ok_f and tonumber(fuel) or nil, DL_PAGES.ff, DL_PAGES.bingo)
		-- while an intercept runs its readout takes the place of the cursor
		-- datablock (bottom right); the DTC / source header lines step back
		if st then H.dtc_txt:set(" "); H.src_txt:set(" ") end
		-- v1.8.1 heading tape: always on the SA page (not at SYM 5 / MIN,
		-- not with hdg_tape = false), and while an intercept runs
		local tape = st or (CFG.hdg_tape ~= false and (sym or 1) < 5)
		H.hdg_on:set(tape and 1 or 0)
		if tape and not st then DL_TAC.tape(math.deg(hdg) % 360, nil) end
	end

	-- ground threats ---------------------------------------------------
	local ng = 0
	if not stale then
		for _, g in ipairs(threats) do
			if ng >= NTHR then break end
			local sx, sy = to_screen(g.z - vz0, g.x - vx0)
			local rr = (g.ring or 0) * k
			-- skip sites (and rings) that are entirely off the scope
			if math.abs(sx) - rr < 2.5 and math.abs(sy) - rr < 3.0 then
				ng = ng + 1
				local h = hg[ng]
				h.x:set(sx); h.y:set(sy)
				local top_lim = (CFG.text_top_y or 1.15) - 0.30 - origin_y
				h.vis:set((sy < top_lim and math.abs(sx) < 1.15) and 1 or 0)
				h.txt:set(g.lbl)
				if curs_on then
					local d = math.sqrt((sx - cur_x) ^ 2 + (sy - cur_y) ^ 2)
					if d < best_d then
						best_d = d
						view.hov_x, view.hov_z = g.x, g.z
						best = {col = 3, id = "SAM " .. g.lbl,
						        alt = (g.ring and g.ring > 0) and string.format("RING %d%s", math.floor(g.ring / unit_m + 0.5), unit_lbl) or "EWR",
						        bra = bra_of(ox, oz, g.x, g.z), be = be_of(be, g.x, g.z)}
					end
				end
				if g.ring and g.ring > 0 then
					local inside = ((g.x - ox) ^ 2 + (g.z - oz) ^ 2) < g.ring ^ 2
					h.ring:set(inside and 2 or 1)
					for j = 1, NSEG do
						local a = TWO_PI * (j - 1) / NSEG
						local px, py = to_screen(g.z - vz0 + g.ring * math.sin(a), g.x - vx0 + g.ring * math.cos(a))
						h.px[j]:set(px); h.py[j]:set(py)
					end
				else
					h.ring:set(0)
				end
			end
		end
	end
	for i = ng + 1, NTHR do
		hg[i].vis:set(0); hg[i].ring:set(0)
	end

	-- contacts -------------------------------------------------------
	local lim = 1.6
	local used = 0
	local nc = 0                        -- candidates in CAND[1..nc] (records reused)
	if not stale then
		for ci, c in ipairs(contacts) do
			if used >= NMAX then break end
			local age = t - (c.t or t)
			if age < 0 then age = 0 end
			local mx = c.mx or CFG.max_extrapolate_s or 20
			if age > mx then age = mx end
			local vx, vz = c[4] or 0, c[5] or 0
			local cx = (c[1] or 0) + vx * age
			local cz = (c[2] or 0) + vz * age
			local sx, sy = to_screen(cz - vz0, cx - vx0)
			-- keep symbols out of the header lines at the top of the page
			local top = (CFG.text_top_y or 1.15) - 0.30 - origin_y
			if math.abs(sx) < 1.15 and sy < top and sy > -3.2 then
				used = used + 1
				local h = hc[used]
				h.typ:set(c[0])
				h.x:set(sx)
				h.y:set(sy)
				-- course on the scope (rotation, CCW positive) and colour
				local dx, dy = to_screen(vz, vx)
				h.hdg:set(math.atan2(-dx, dy))
				h.mov:set(((vx * vx + vz * vz) > 25) and 1 or 0)
				local base = (c[0] or 0) % 10
				h.col:set(CONTACT_COL[base] or 3)
				local lx, ly = to_screen(vz * 60, vx * 60)
				local L = math.sqrt(lx * lx + ly * ly)
				if L > 1e-6 then
					local s = 1
					if L > 0.25 then s = 0.25 / L elseif L < 0.06 then s = 0.06 / L end
					if (vx * vx + vz * vz) < 4 then s = 0 end
					lx, ly = lx * s, ly * s
				end
				h.lx:set(lx)
				h.ly:set(ly)
				-- label: set after the loop (label_pass), SYM 2 / 3 group and move them
				local lr = LB[used]
				if not lr then lr = {}; LB[used] = lr end
				lr[1], lr[2], lr[3], lr[4], lr[8], lr[9], lr[10], lr[11] =
					sx, sy, CONTACT_COL[base] or 3, (cx - ox) ^ 2 + (cz - oz) ^ 2, ci, c, vx, vz
				nc = nc + 1
				local r = CAND[nc]
				if not r then r = {}; CAND[nc] = r end
				r[1], r[2], r[3], r[4], r[5], r[6], r[7] = sx, sy, (cx - ox) ^ 2 + (cz - oz) ^ 2, ((c[0] or 0) % 10) == 2, base, cx, cz
				if curs_on then
					local d = math.sqrt((sx - cur_x) ^ 2 + (sy - cur_y) ^ 2)
					if d < best_d then
						best_d = d
						local idn = CONTACT_IDN[base] or "UNKN"
						view.hov_x, view.hov_z = cx, cz
						best = {col = CONTACT_COL[base] or 3, id = idn .. (((c[0] or 0) >= 10) and " RDR" or " DL"),
						        alt = fmt_alt(c[3] or 0, vx, vz), bra = bra_of(ox, oz, cx, cz), be = be_of(be, cx, cz)}
					end
				end
			end
		end
	end
	for i = used + 1, NMAX do
		hc[i].typ:set(0)
	end
	label_pass(used, sym, t, k, contacts, to_screen(oz - vz0, ox - vx0))
	-- MFD-5 NEXT: park the cursor on the n-th nearest contact (follows it)
	-- T1..T5: the n-th nearest contact on the scope, hostiles first, then the rest
	if curs_on and sel_hostile > 0 then
		local hs, rest = SORT_HS, SORT_REST
		for i = #hs, 1, -1 do hs[i] = nil end
		for i = #rest, 1, -1 do rest[i] = nil end
		for i = 1, nc do
			local c = CAND[i]
			if c[4] then hs[#hs + 1] = c
			elseif c[5] ~= 4 and c[5] ~= 5 then rest[#rest + 1] = c end   -- not AWACS / own flight
		end
		table.sort(hs, by_range)
		table.sort(rest, by_range)
		for _, c in ipairs(rest) do hs[#hs + 1] = c end
		local c = hs[sel_hostile]
		if not c and #hs > 0 then c = hs[#hs] end
		if c then
			cur_x, cur_y = c[1], c[2]; H.curs_x:set(cur_x); H.curs_y:set(cur_y)
			if expanded then exp_cx, exp_cz = c[6], c[7] end     -- EXP follows the picked contact
		end
	end
	if curs_on and sel_rank > 0 and nc == 0 then curs_on = false; sel_rank = 0 end
	if curs_on and sel_rank > 0 and nc > 0 then
		local cs = SORT_HS
		for i = #cs, 1, -1 do cs[i] = nil end
		for i = 1, nc do cs[i] = CAND[i] end
		table.sort(cs, by_range)
		if sel_rank > nc then sel_rank = 0; curs_on = false end
		local c = cs[sel_rank]
		if c then
			cur_x, cur_y = c[1], c[2]
			H.curs_x:set(cur_x); H.curs_y:set(cur_y)
			if expanded then exp_cx, exp_cz = c[6], c[7] end     -- EXP follows the picked contact
		end
	end

	-- the radar's locked target: marked on the scope and shown in the
	-- readout whenever the cursor is not over something else
	local lk = feed.lock
	if lk and not stale and (t - lk.t) < 5 then
		local age = math.min(t - lk.t, 5)
		local lx, lz = lk.x + (lk.vx or 0) * age, lk.z + (lk.vz or 0) * age
		local sx, sy = to_screen(lz - vz0, lx - vx0)
		H.lock_x:set(sx); H.lock_y:set(sy); H.lock_vis:set(1)
		if not best then
			-- identity from the matching datalink / radar contact, if any
			local col, idn, bd = 2, "LOCK", 3000
			for _, c in ipairs(contacts) do
				local d = math.sqrt(((c[1] or 0) - lk.x) ^ 2 + ((c[2] or 0) - lk.z) ^ 2)
				if d < bd then
					bd = d
					local b = (c[0] or 0) % 10
					col = CONTACT_COL[b] or 2
					idn = "LOCK " .. (CONTACT_IDN[b] or "UNKN")
				end
			end
			best = {col = col, id = idn, alt = fmt_alt(lk.y or 0, lk.vx, lk.vz), bra = bra_of(ox, oz, lx, lz), be = be_of(be, lx, lz)}
		end
	else
		H.lock_vis:set(0)
	end
	if best and not DL_TAC.intc then
		H.hov_col:set(best.col); H.hov_id:set(best.id); H.hov_alt:set(best.alt); H.hov_bra:set(best.bra)
		H.hov_be:set(best.be or "BE --")
	else
		H.hov_col:set(0)
	end
end

local next_full = 0
-- v1.7.8: start-up hold. DCS loads the MFD pages on a worker thread while
-- the device already runs on the main thread; writing our parameters while
-- a page is still being built crashed DCS (CockpitBase access violation in
-- ccIndicatorPage::load -> element setValue, Nov 2026, at spawn). So the
-- device does nothing for the first start_hold_s seconds after it is
-- created (settings.lua; default 6). UDP packets wait in the socket.
local HOLD = {t0 = nil}
local function holding()
	local t = now()
	if not HOLD.t0 or t < HOLD.t0 then HOLD.t0 = t end
	if HOLD.done then return false end
	HOLD.n = (HOLD.n or 0) + 1      -- (and never longer than 600 updates, should model time stand still)
	if t - HOLD.t0 < (CFG.start_hold_s or 6) and HOLD.n < 600 then return true end
	HOLD.done = true
	dbg(string.format("start-up hold over (%.1f s)", t - HOLD.t0))
	return false
end

function update()
	if holding() then return end
	H.dev_id:set(devices.MIG29_DL or 0)
	net_tick()
	if DL_PROF_ON then DL_PROF.mark(1) end   -- v1.7.5 timing log (dl_prof.lua)
	-- v1.7: display power / start-up screens; the pages wait meanwhile
	if boot_tick() then return end
	if DL_PROF_ON then DL_PROF.mark(2) end
	if page == 0 then
		return
	end

	local t = now()
	-- the SA page and the HSI move with the jet: 20 per second (and SNAKE,
	-- page 16). The text pages only need a few updates per second.
	local m = DL_PAGES.mode
	if m ~= 1 and m ~= 8 and m ~= 16 then
		if t < next_full and not DL_PAGES.dirty then return end
		next_full = t + (CFG.text_page_period or 0.25)
		DL_PAGES.dirty = false
	end
	local sd = sensors()
	if not sd then
		hide_all()
		return
	end
	local ox, oalt, oz = sd.getSelfCoordinates()
	if not ox then
		hide_all()
		return
	end
	local hdg = true_heading()
	local stale = (t - last_rx) > (CFG.stale_after_s or 8) and not (DL_EWR and DL_EWR.fresh(t))

	-- route: the jet's loaded route from the export feed, else the mission route
	-- flight plan: the chosen cartridge, or MSN = the cartridge stored with
	-- the jet in the mission, else the jet's route, else the mission route
	local plan = PL.plan
	if not plan then
		if feed.msn_dtc then
			plan = feed.msn_dtc
		else
			local r = mission_route
			if ex_route and (t - ex_route.t) < (CFG.route_stale_after_s or 15) and #ex_route.points > 0 then r = ex_route.points end
			-- v1.7.5: the export sends the jet's route with every packet (a new
			-- table each time): the plan is only made again when the points changed
			if not PL.msn or PL.msn_src ~= r then
				local sig = PL.route_sig(r)
				if not PL.msn or PL.msn_sig ~= sig then
					PL.msn = DL_PLAN.make("MSN RTE", nil, r, nil); PL.msn_sig = sig
				end
				PL.msn_src = r
			end
			plan = PL.msn
		end
	end
	PL.base = plan
	plan = PL.route_of(plan)
	-- selected waypoint: whichever was changed last, the MiG-29's own NAV
	-- panel (WP-A/D buttons 1-3, WP or A/D) or the KRN STP selection
	do
		local nav = feed.nav
		local nkey = nil
		if nav then
			local bi, bv = 0, CFG.nav_lamp_threshold or 0.3
			for k = 1, 3 do if (nav[k] or 0) > bv then bi, bv = k, nav[k] end end
			if bi > 0 then
				local ad = ((nav.sw or 0) > 0.5) == ((CFG.nav_ad_switch_value or 1) > 0.5)
				nkey = (ad and "A" or "W") .. bi
			end
		end
		if PL.nav_pressed() then PL.src = "nav" end
		if nkey ~= PL.last_nav then
			if nkey then PL.src = "nav"; dbg("NAV panel selection " .. nkey .. " (switch " .. tostring(nav and nav.sw) .. ")") end
			PL.last_nav = nkey
		end
		local kn = krn_active()
		if kn ~= PL.last_krn then
			-- with a cartridge loaded KRN's STP index belongs to the mission
			-- route, so only our own STP stepping counts
			if kn > 0 and not PL.plan then PL.src = "krn" end
			PL.last_krn = kn
		end
		PL.act = nil
		if PL.src == "nav" and PL.last_nav then
			local list = (PL.last_nav:sub(1, 1) == "A") and plan.ads or plan.wps
			PL.act = list[tonumber(PL.last_nav:sub(2))]
		elseif PL.src == "krn" and PL.last_krn > 0 then
			PL.act = plan.wps[PL.last_krn] or plan.pts[PL.last_krn]
		elseif PL.src == "stp" and PL.stp_i then
			PL.act = plan.pts[PL.stp_i]
		end
		PL.cur = plan
		if PL.src == "stp" and PL.stp_i and not plan.pts[PL.stp_i] then PL.src, PL.stp_i = nil, nil end
		if route_on then PL.seq(ox, oz) end
	end
	-- drawings (.geo.txt) of the loaded cartridge
	DL_GEO.load(PL.plan and PL.plan.name or nil)
	-- bullseye of our own side (mission bullseye, from the hook script)
	local be = nil
	if feed.be_all then
		local side = (feed.own_coal == 1) and feed.be_all.red or feed.be_all.blue
		if side and side[1] and side[2] and (side[1] ~= 0 or side[2] ~= 0) then be = side end
	end
	-- v1.7.5: the SA scope is drawn only while the SA page is on the screen
	-- (all its elements sit under dl_root, shown only for DL_MODE 1). On the
	-- other pages a running intercept is still tracked, else it would be
	-- dropped after intc_drop_s.
	if m == 1 then
		draw_scope(t, sd, ox, oz, hdg, plan, stale, be)
	else
		-- the view is kept current on the other pages too: the PICTURE page
		-- puts the SA cursor on a group with it (CX.cursor_to)
		set_view(ox, oz, hdg)
		-- v1.8.1: the RWR page has the SA heading tape too
		local rt = (m == 10) and CFG.rwr_hdg_tape ~= false
		H.hdg_on:set(rt and 1 or 0)
		if rt then DL_TAC.tape(math.deg(hdg) % 360, nil) end
	end
	if m ~= 1 and DL_TAC.intc then
		view.oy, view.sym, view.unit_m, view.unit_lbl = (CFG.ownship_y or 0) + (decentered and (CFG.decenter_dy or -0.65) or 0), DL_PAGES.sym or 1, unit_m, unit_lbl
		local ok_t, tas = pcall(sd.getTrueAirSpeed)
		local ok_f, fuel = pcall(sd.getTotalFuelWeight)
		DL_TAC.draw(view, contacts, t, hdg, ok_t and tonumber(tas) or 0, ok_f and tonumber(fuel) or nil, DL_PAGES.ff, DL_PAGES.bingo)
	end
	if DL_PROF_ON then DL_PROF.mark(3) end   -- (scope = everything before the pages)
	-- the other MFD pages
	CX.t, CX.sd, CX.ox, CX.oz, CX.alt, CX.hdg = t, sd, ox, oz, oalt, hdg
	CX.feed, CX.plan, CX.act, CX.route_on = feed, plan, PL.act, route_on
	CX.unit_m, CX.unit_lbl, CX.theatre = unit_m, unit_lbl, feed.theatre or theatre
	CX.nav = PL
	CX.contacts, CX.be = contacts, be
	CX.dl_status = (CFG.opt_datalink == false) and "DL OFF" or (stale and "NO DL" or string.format("DL %d CONTACTS", #contacts))
	DL_PAGES.update(CX)
	local ut = DL_PAGES.ufcp_text()
	if ut then H.ufcp_l1:set(DL_text and DL_text(ut) or ut); H.ufcp_menu:set(1) else H.ufcp_menu:set(0) end
	PL.ufcp_nav(ox, oz, hdg, route_on)
end

-- v1.7.5: timing log, only with perf_log = true in settings.lua (wraps
-- update(); see dl_prof.lua). A missing or broken dl_prof.lua changes nothing.
if CFG.perf_log then
	pcall(function()
		dofile(LockOn_Options.script_path .. "DL/dl_prof.lua")
		if DL_PROF and DL_PROF.wrap then
			update = DL_PROF.wrap(update, "cockpit device")
			DL_PROF_ON = true
			dbg("perf_log on: timing in Logs/mig29dl_perf.log")
		end
	end)
end

need_to_be_closed = false
