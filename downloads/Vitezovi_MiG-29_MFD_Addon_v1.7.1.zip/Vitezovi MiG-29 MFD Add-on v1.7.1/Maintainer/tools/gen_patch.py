"""Builds the add-on's patch data from KRN MODS V1.0.3 (original) and the
finished v1.7 files: text insertions, the UFCP.edm splice and texture tiles."""
import hashlib, json, os, re, struct, subprocess, sys
import numpy as np
from PIL import Image
K = "/tmp/claude-0/krnorig/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/"
P = "/home/claude/v17pkg/Saved Games/DCS/Mods/tech/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/"
OUT = "/home/claude/addon/build/installer/"
os.makedirs(OUT + "tiles", exist_ok=True)
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest().upper()
def lines(p): return open(p, 'rb').read().decode('latin-1').replace('\r\n', '\n').split('\n')

def ins(f, mode, anchor, nth="first"):
    """text that v1.7 has after/before the anchor line (or appended) that the original lacks"""
    a, b = lines(K + f), lines(P + f)
    import difflib
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    blocks = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal': continue
        assert tag in ('insert', 'replace'), (f, tag)
        blocks.append((i1, i2, b[j1:j2], a[i1:i2]))
    return blocks

ops = []
def add(f, mode, anchor, text):
    ops.append({"file": f.replace('/', '\\'), "mode": mode, "anchor": anchor, "text": text})

# show the raw blocks, then define ops explicitly (checked below by re-applying)
for f in ["Cockpit/Scripts/MFD/pages/obf_K7j9M2sW5yZ8bB1cD4fG7hJ0kL3nO6pQ.lua", "Cockpit/Scripts/UFCP/base_page.lua",
          "Cockpit/Scripts/device_init.lua", "Cockpit/Scripts/devices.lua", "Cockpit/Scripts/materials.lua",
          "Options/optionsDb.lua", "Options/options.dlg", "Cockpit/Scripts/clickabledata.lua"]:
    for i1, i2, new, old in ins(f, None, None):
        print(f, "orig lines", i1, i2, "old", [o[:50] for o in old], "new", len(new))

def make_ops(f):
    a, b = lines(K + f), lines(P + f)
    import difflib
    res = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == 'equal': continue
        new = b[j1:j2]
        # original ends without newline: a[-1] is the last text line
        if i1 >= len(a) or (i1 == len(a) - 1 and a[-1] == '' ):
            res.append({"file": f, "mode": "append", "anchor": [], "text": new}); continue
        for n in (1, 2, 3, 4):
            ctx = a[max(0, i1 - n):i1]
            if len(ctx) < n: break
            hits = [k for k in range(len(a) - n + 1) if a[k:k + n] == ctx]
            if len(hits) == 1:
                res.append({"file": f, "mode": "after", "anchor": ctx, "text": new}); break
        else:
            for n in (1, 2, 3, 4):
                ctx = a[i1:i1 + n]
                hits = [k for k in range(len(a) - n + 1) if a[k:k + n] == ctx]
                if len(hits) == 1:
                    res.append({"file": f, "mode": "before", "anchor": ctx, "text": new}); break
            else:
                raise SystemExit("no unique anchor " + f)
    return res

def apply_ops(text_lines, file_ops):
    L = list(text_lines)
    for o in file_ops:
        if o["mode"] == "append":
            if L and L[-1] == '': L = L[:-1] + o["text"] + ['']
            else: L = L + o["text"]
            continue
        n = len(o["anchor"])
        hits = [k for k in range(len(L) - n + 1) if L[k:k + n] == o["anchor"]]
        assert len(hits) == 1, (o["file"], o["anchor"])
        k = hits[0] + (n if o["mode"] == "after" else 0)
        L = L[:k] + o["text"] + L[k:]
    return L

TEXT = ["Cockpit/Scripts/MFD/pages/obf_K7j9M2sW5yZ8bB1cD4fG7hJ0kL3nO6pQ.lua", "Cockpit/Scripts/UFCP/base_page.lua",
        "Cockpit/Scripts/device_init.lua", "Cockpit/Scripts/devices.lua", "Cockpit/Scripts/materials.lua",
        "Options/optionsDb.lua", "Options/options.dlg", "Cockpit/Scripts/clickabledata.lua"]
allops, files = [], {}
for f in TEXT:
    fo = make_ops(f)
    got = apply_ops(lines(K + f), fo)
    want = lines(P + f)
    # the original sometimes lacks the final newline: compare without trailing empties
    def norm(L):
        out = []
        for x in L:
            if x.strip() == '' and out and out[-1] == '': continue
            out.append('' if x.strip() == '' else x)
        while out and out[-1] == '': out.pop()
        return out
    assert norm(got) == norm(want), f
    print("ok", f, [(o["mode"], o["anchor"][-1][:40] if o["anchor"] else "", len(o["text"])) for o in fo])
    allops += fo
    raw = open(K + f, 'rb').read().decode('latin-1')
    nrm = raw.replace('\r\n', '\n').rstrip()
    files[f] = {"sha256": sha(K + f), "kind": "text", "norm_sha256": hashlib.sha256(nrm.encode('latin-1')).hexdigest().upper()}

# ---------------------------------------------------------------- UFCP.edm splice
import subprocess
subprocess.run(["python3", "/home/claude/addon/patch_edm.py", K + "Shapes/UFCP.edm", "/tmp/claude-0/ufcp_add.edm"],
               env=dict(os.environ, OPS="1"), check=True, capture_output=True)
assert open("/tmp/claude-0/ufcp_add.edm", "rb").read() == open(P + "Shapes/UFCP.edm", "rb").read()
edm = json.load(open("/tmp/claude-0/ufcp_add.edm.ops.json"))
ob = open(K + "Shapes/UFCP.edm", "rb").read()
edm["overwrite_orig"] = [[o, ob[o:o + len(h) // 2].hex()] for o, h in edm["overwrite"]]
files["Shapes/UFCP.edm"] = {"sha256": sha(K + "Shapes/UFCP.edm"), "kind": "edm", "result_sha256": sha(P + "Shapes/UFCP.edm")}

# ---------------------------------------------------------------- texture tiles
import cv2
tiles = []
for f in ["Textures/Shared_Material.png", "Textures/Buttons.png"]:
    a = np.array(Image.open(K + f).convert('RGB')); b = np.array(Image.open(P + f).convert('RGB'))
    assert a.shape == b.shape
    m = (np.abs(a.astype(int) - b.astype(int)).sum(axis=2) > 0).astype(np.uint8)
    m2 = cv2.dilate(m, np.ones((25, 25), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m2, 8)
    for k in range(1, n):
        x, y, w, h = st[k, 0], st[k, 1], st[k, 2], st[k, 3]
        name = "%s_%d_%d.png" % (os.path.basename(f)[:-4], x, y)
        Image.fromarray(b[y:y + h, x:x + w]).save(OUT + "tiles/" + name, optimize=True)
        tiles.append({"file": f.replace('/', '\\'), "x": int(x), "y": int(y), "tile": name})
    # check: the tiles on the original give exactly v1.7
    c = a.copy()
    for t in tiles:
        if t["file"] == f.replace('/', '\\'):
            tl = np.array(Image.open(OUT + "tiles/" + t["tile"]))
            c[t["y"]:t["y"] + tl.shape[0], t["x"]:t["x"] + tl.shape[1]] = tl
    assert (c == b).all(), f
    files[f] = {"sha256": sha(K + f), "kind": "png", "size": [int(a.shape[1]), int(a.shape[0])]}
    print("tiles", f, [(t["x"], t["y"]) for t in tiles if t["file"] == f.replace('/', '\\')])

for o in allops: o["file"] = o["file"].replace('/', '\\')
fx = {k.replace('/', '\\'): v for k, v in files.items()}
json.dump({"krn_version": "KRN MODS V1.0.3", "files": fx, "text": allops, "edm": edm, "tiles": tiles},
          open(OUT + "krn_patch.json", "w"), indent=1)
print("written", OUT + "krn_patch.json", os.path.getsize(OUT + "krn_patch.json"))
