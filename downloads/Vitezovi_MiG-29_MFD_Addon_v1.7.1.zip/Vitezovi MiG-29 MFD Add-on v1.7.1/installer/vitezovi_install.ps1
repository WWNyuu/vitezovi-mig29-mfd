# Vitezovi MiG-29 MFD add-on - installer / uninstaller
# Run through INSTALL.bat / UNINSTALL.bat (Windows PowerShell 5.1, nothing else needed).
#
# The add-on sits on top of "MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3",
# which the player installs first, unchanged, from KRN's own download.
# This script:
#   1. finds KRN's mod in Saved Games\DCS\Mods\tech
#   2. checks the KRN files it changes are KRN's V1.0.3 originals and keeps a
#      copy of each (Saved Games\DCS\Vitezovi-MFD-Addon\krn_backup)
#   3. applies the add-on's changes to them: a few added lines in KRN's
#      scripts and options, the extra click boxes of the MFD bezel buttons in
#      Shapes\UFCP.edm, the new button labels in two textures
#   4. copies the add-on's own files (MFD pages, fonts, export, hook, ...)
# -Uninstall puts KRN's originals back and removes the add-on's files.
param([switch]$Uninstall, [string]$SavedGames = "")
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Here
$L1 = [System.Text.Encoding]::GetEncoding(28591)       # bytes <-> text 1:1

$SEP = [System.IO.Path]::DirectorySeparatorChar
function J($a, $b) { return [System.IO.Path]::Combine($a, ($b -replace '\\', $SEP)) }
function Say($m) { Write-Host ("  " + $m) }
function Fail($m) { Write-Host ""; Write-Host ("  PROBLEM: " + $m) -ForegroundColor Yellow; Write-Host ""; exit 1 }
function Sha($p) { return (Get-FileHash -Algorithm SHA256 -LiteralPath $p).Hash.ToUpper() }
function ShaText($s) {
	$h = [System.Security.Cryptography.SHA256]::Create()
	return ([BitConverter]::ToString($h.ComputeHash($L1.GetBytes($s))) -replace "-", "").ToUpper()
}
function NormText($s) { return $s.Replace("`r`n", "`n").TrimEnd() }

# ---------------------------------------------------------------- where
if ($SavedGames -eq "") {
	$SavedGames = Join-Path $env:USERPROFILE "Saved Games\DCS"
	if (-not (Test-Path $SavedGames) -and (Test-Path (Join-Path $env:USERPROFILE "Saved Games\DCS.openbeta"))) {
		$SavedGames = Join-Path $env:USERPROFILE "Saved Games\DCS.openbeta"
	}
}
if (-not (Test-Path $SavedGames)) { Fail "Could not find your DCS Saved Games folder ($SavedGames). Start DCS once, then try again." }
Say ("DCS Saved Games: " + $SavedGames)
if (Get-Process -Name "DCS" -ErrorAction SilentlyContinue) { Fail "DCS is running. Close DCS first." }

$Tech = J $SavedGames "Mods\tech"
$Krn = @()
if (Test-Path $Tech) {
	foreach ($d in Get-ChildItem -LiteralPath $Tech -Directory) {
		$e = J $d.FullName "entry.lua"
		if ((Test-Path -LiteralPath $e) -and ((Get-Content -LiteralPath $e -Raw) -match 'declare_plugin\(\s*"mig_29am"')) { $Krn += $d.FullName }
	}
}
if ($Krn.Count -eq 0) {
	Fail ("KRN's mod is not installed. Install 'MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3' first " +
	      "(unzip it into $Tech), then run this again.")
}
if ($Krn.Count -gt 1) { Fail ("KRN's mod is installed more than once - DCS would load both. Keep one:`n    " + ($Krn -join "`n    ")) }
$Krn = $Krn[0]
Say ("KRN mod: " + $Krn)

# files from a downloaded zip may be marked "from the internet": unmark ours
if ($env:OS -eq "Windows_NT") {
	try { Get-ChildItem -LiteralPath $Root -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue } catch { }
}
$Data = Get-Content -LiteralPath (J $Here "krn_patch.json") -Raw | ConvertFrom-Json
$Addon = J $SavedGames "Vitezovi-MFD-Addon"
$Backup = J $Addon "krn_backup"
$OldBackup = J $SavedGames "MiG29-DL-Addon\backup_original"     # the old all-in-one package
$Files = @($Data.files.PSObject.Properties | ForEach-Object { $_.Name })

# ---------------------------------------------------------------- uninstall
function Remove-ExportLine {
	$exp = J $SavedGames "Scripts\Export.lua"
	if (Test-Path -LiteralPath $exp) {
		$t = [System.IO.File]::ReadAllText($exp, $L1)
		$lines = $t -split "`r?`n" | Where-Object { $_ -notmatch "MiG29DL_Export\.lua" -and $_ -notmatch "MiG-29 DL / moving map add-on" }
		[System.IO.File]::WriteAllText($exp, ($lines -join "`r`n"), $L1)
	}
}
if ($Uninstall) {
	# without KRN's original scripts / model we must not take the add-on's
	# files away (KRN's changed files would point at missing ones)
	$need = @($Files | Where-Object { $Data.files.$_.kind -ne "png" -and -not (Test-Path -LiteralPath (J $Backup $_)) })
	if ($need.Count -gt 0) {
		Fail ("No copy of KRN's originals was found (the add-on was not installed with this installer).`n" +
		      "  To remove it: delete the folder`n    $Krn`n  and unzip KRN's mod again. Nothing was changed.")
	}
	$missing = @()
	foreach ($rel in $Files) {
		$b = J $Backup $rel
		if (Test-Path -LiteralPath $b) { Copy-Item -LiteralPath $b -Destination (J $Krn $rel) -Force }
		else { $missing += $rel }
	}
	foreach ($p in @("Cockpit\Scripts\DL", "Cockpit\Textures\IndicationTextures\mig29_dl_font.dds", "Cockpit\Textures\IndicationTextures\mig29_dl_logo.dds")) {
		$q = J $Krn $p
		if (Test-Path -LiteralPath $q) { Remove-Item -LiteralPath $q -Recurse -Force }
	}
	foreach ($p in @("Scripts\MiG29DL_Export.lua", "Scripts\Hooks\MiG29DL_Hook.lua")) {
		$q = J $SavedGames $p
		if (Test-Path -LiteralPath $q) { Remove-Item -LiteralPath $q -Force }
	}
	Remove-ExportLine
	Say "KRN's original files are back, the add-on is removed."
	if ($missing.Count -gt 0) { Say ("No backup for: " + ($missing -join ", ") + " - reinstall KRN's mod to get those back exactly.") }
	Say "(Your flight list, cartridges in DTC and missions were left in place.)"
	exit 0
}

# ---------------------------------------------------------------- the originals
Say "Checking KRN's files ..."
Add-Type -Path (J $Here "VitezoviPatch.cs")
$Tmp = J $Addon "tmp"
New-Item -ItemType Directory -Force -Path $Tmp | Out-Null
$Src = @{}            # rel -> path of KRN's original (or the best we have)
$NoBackup = @()
$Bad = @()
foreach ($rel in $Files) {
	$info = $Data.files.$rel
	$cur = J $Krn $rel
	$bak = J $Backup $rel
	if (-not (Test-Path -LiteralPath $cur)) { $Bad += "$rel (missing)"; continue }
	if ((Test-Path -LiteralPath $bak) -and ((Sha $bak) -eq $info.sha256)) { $Src[$rel] = $bak; continue }
	if ((Sha $cur) -eq $info.sha256) { $Src[$rel] = $cur; continue }
	$old = J $OldBackup $rel
	if ((Test-Path -LiteralPath $old) -and ((Sha $old) -eq $info.sha256)) { $Src[$rel] = $old; continue }
	# changed by an earlier install of this add-on: take our changes out again
	if ($info.kind -eq "text") {
		$t = NormText ([System.IO.File]::ReadAllText($cur, $L1))
		$lines = [System.Collections.Generic.List[string]]($t -split "`n")
		foreach ($op in @($Data.text | Where-Object { $_.file -eq $rel })) {
			$blk = [System.Collections.Generic.List[string]]([string[]]@($op.text))
			if ($op.mode -eq "append") {
				# the file's end was trimmed above: so is the block's
				while ($blk.Count -gt 0 -and $blk[$blk.Count - 1] -eq "") { $blk.RemoveAt($blk.Count - 1) }
				while ($blk.Count -gt 0 -and $blk[0] -eq "") { $blk.RemoveAt(0) }
			}
			if ($blk.Count -eq 0) { continue }
			for ($k = 0; $k -le $lines.Count - $blk.Count; $k++) {
				$m = $true
				for ($j = 0; $j -lt $blk.Count; $j++) { if ($lines[$k + $j] -ne $blk[$j]) { $m = $false; break } }
				if ($m) { $lines.RemoveRange($k, $blk.Count); break }
			}
		}
		$t2 = NormText ($lines -join "`n")
		if ((ShaText $t2) -eq $info.norm_sha256) {
			$p = J $Tmp (($rel -replace "[\\/:]", "_") + ".orig")
			[System.IO.File]::WriteAllText($p, $t2.Replace("`n", "`r`n") + "`r`n", $L1)
			$Src[$rel] = $p; continue
		}
	}
	if ($info.kind -eq "edm" -and (Sha $cur) -eq $info.result_sha256) {
		$p = J $Tmp "UFCP.edm.orig"
		$e = $Data.edm
		[VitezoviPatch]::EdmUnsplice($cur, $p, [long[]]@($e.overwrite_orig | ForEach-Object { $_[0] }), [string[]]@($e.overwrite_orig | ForEach-Object { $_[1] }),
			[long[]]@($e.insert | ForEach-Object { $_[0] }), [string[]]@($e.insert | ForEach-Object { $_[1] }))
		if ((Sha $p) -eq $info.sha256) { $Src[$rel] = $p; continue }
	}
	if ($info.kind -eq "png") {
		# the label tiles replace whole areas: they work on a changed copy too,
		# only the backup for UNINSTALL is missing then
		$Src[$rel] = $cur; $NoBackup += $rel; continue
	}
	$Bad += $rel
}
if ($Bad.Count -gt 0) {
	Fail ("These KRN files are not the ones from KRN MODS V1.0.3:`n    " + ($Bad -join "`n    ") + "`n`n" +
	      "  Either a different KRN version is installed, or files were changed (for example by the old`n" +
	      "  all-in-one Vitezovi package). Fix: delete the folder`n    $Krn`n" +
	      "  unzip KRN's 'MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3' again, then run INSTALL again.`n" +
	      "  Nothing was changed.")
}

# ---------------------------------------------------------------- backups
foreach ($rel in $Files) {
	if ($NoBackup -contains $rel) { continue }
	$bak = J $Backup $rel
	if ($Src[$rel] -ne $bak) {
		New-Item -ItemType Directory -Force -Path (Split-Path -Parent $bak) | Out-Null
		Copy-Item -LiteralPath $Src[$rel] -Destination $bak -Force
	}
}
Say ("KRN's originals kept in " + $Backup)

# ---------------------------------------------------------------- patch (into tmp, then move)
Say "Applying the add-on's changes to KRN's files ..."
$Out = @{}
foreach ($rel in $Files) {
	$info = $Data.files.$rel
	$dst = J $Tmp (($rel -replace "[\\/:]", "_") + ".new")
	if ($info.kind -eq "text") {
		$raw = [System.IO.File]::ReadAllText($Src[$rel], $L1)
		$nl = "`n"; if ($raw.Contains("`r`n")) { $nl = "`r`n" }
		$lines = [System.Collections.Generic.List[string]]($raw.Replace("`r`n", "`n") -split "`n")
		foreach ($op in @($Data.text | Where-Object { $_.file -eq $rel })) {
			$txt = [string[]]@($op.text)
			if ($op.mode -eq "append") {
				if ($lines.Count -gt 0 -and $lines[$lines.Count - 1] -eq "") { $lines.RemoveAt($lines.Count - 1); $lines.AddRange($txt); $lines.Add("") }
				else { $lines.AddRange($txt) }
				continue
			}
			$anc = @($op.anchor)
			$hit = -1; $n = 0
			for ($k = 0; $k -le $lines.Count - $anc.Count; $k++) {
				$m = $true
				for ($j = 0; $j -lt $anc.Count; $j++) { if ($lines[$k + $j] -ne $anc[$j]) { $m = $false; break } }
				if ($m) { $hit = $k; $n++ }
			}
			if ($n -ne 1) { Fail "$rel : the place for the add-on's lines was not found ($n). Nothing was changed." }
			$at = $hit; if ($op.mode -eq "after") { $at = $hit + $anc.Count }
			$lines.InsertRange($at, $txt)
		}
		[System.IO.File]::WriteAllText($dst, ($lines -join $nl), $L1)
	} elseif ($info.kind -eq "edm") {
		$e = $Data.edm
		[VitezoviPatch]::EdmSplice($Src[$rel], $dst, [long[]]@($e.overwrite | ForEach-Object { $_[0] }), [string[]]@($e.overwrite | ForEach-Object { $_[1] }),
			[long[]]@($e.insert | ForEach-Object { $_[0] }), [string[]]@($e.insert | ForEach-Object { $_[1] }))
		if ((Sha $dst) -ne $info.result_sha256) { Fail "UFCP.edm: the result is not as expected. Nothing was changed." }
	} elseif ($info.kind -eq "png") {
		$ts = @($Data.tiles | Where-Object { $_.file -eq $rel })
		[VitezoviPatch]::PasteTiles($Src[$rel], [string[]]@($ts | ForEach-Object { J $Here ("tiles\" + $_.tile) }),
			[int[]]@($ts | ForEach-Object { $_.x }), [int[]]@($ts | ForEach-Object { $_.y }), $dst)
	}
	$Out[$rel] = $dst
}
foreach ($rel in $Files) { Move-Item -LiteralPath $Out[$rel] -Destination (J $Krn $rel) -Force }
Remove-Item -LiteralPath $Tmp -Recurse -Force -ErrorAction SilentlyContinue

# ---------------------------------------------------------------- our files
Say "Copying the add-on's files ..."
foreach ($p in @("Cockpit\Scripts\DL\dl_hud_init.lua", "Cockpit\Scripts\DL\dl_hud_page.lua", "Cockpit\Scripts\DL\checklists_default.txt",
                 "Cockpit\Textures\IndicationTextures\mig29_dl_map_caucasus.dds")) {
	$q = J $Krn $p
	if (Test-Path -LiteralPath $q) { Remove-Item -LiteralPath $q -Force }
}
Copy-Item -Path (J $Root "files\KRN mod\*") -Destination $Krn -Recurse -Force
Copy-Item -Path (J $Root "files\Saved Games DCS\*") -Destination $SavedGames -Recurse -Force

# ---------------------------------------------------------------- Export.lua line
$exp = J $SavedGames "Scripts\Export.lua"
$line = "pcall(function() local l=require('lfs'); dofile(l.writedir()..[[Scripts\MiG29DL_Export.lua]]) end)"
if (-not (Test-Path -LiteralPath $exp)) { New-Item -ItemType File -Force -Path $exp | Out-Null }
$t = [System.IO.File]::ReadAllText($exp, $L1)
if ($t -notmatch "MiG29DL_Export\.lua") {
	$add = "`r`n-- MiG-29 DL / moving map add-on (feeds the MiG-29 MFD datalink page)`r`n" + $line + "`r`n"
	[System.IO.File]::AppendAllText($exp, $add, $L1)
	Say "Export.lua: datalink line added."
} else { Say "Export.lua: datalink line already there." }

$ver = Get-Content -LiteralPath (J $Root "files\KRN mod\Cockpit\Scripts\DL\dl_config.lua") | Where-Object { $_ -match '^DL_VERSION' }
Set-Content -LiteralPath (J $Addon "installed.txt") -Value @("Vitezovi MiG-29 MFD add-on  $ver", "KRN mod: $Krn", (Get-Date).ToString("s"))
Write-Host ""
Say "Done. Start DCS and fly the MiG-29 (KRN's mod must be enabled in Options > Special > MIG-29AM)."
if ($NoBackup.Count -gt 0) { Say ("Note: no original kept for " + ($NoBackup -join ", ") + " (it was already changed). UNINSTALL cannot restore it - reinstall KRN's mod for that.") }
exit 0
