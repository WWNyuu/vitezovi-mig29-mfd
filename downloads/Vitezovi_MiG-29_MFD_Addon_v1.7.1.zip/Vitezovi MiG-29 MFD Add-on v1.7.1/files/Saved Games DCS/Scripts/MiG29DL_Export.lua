-----------------------------------------------------------------------
-- MiG29DL_Export.lua  --  datalink feed for the MiG-29 DL / moving map page
--
-- Loaded from Saved Games\DCS\Scripts\Export.lua with:
--   pcall(function() local l=require('lfs'); dofile(l.writedir()..[[Scripts\MiG29DL_Export.lua]]) end)
--
-- Only does anything while you sit in a MiG-29. It builds the air picture
-- and sends it once a second over UDP to 127.0.0.1:42888, where the DL
-- cockpit device of the "MiG-29A(M) Cockpit Modernization" add-on reads it.
--
-- Also sends the route loaded in the jet (LoGetRoute: DTC / mission route,
-- with the active steerpoint) so the page shows the real flight plan.
--
-- Picture sources
--   * own radar contacts           LoGetTargetInformation()  (always)
--   * friendly aircraft (PPLI)     LoGetWorldObjects()       (needs the
--   * hostiles seen by friendly    server to allow exporting  world
--     AWACS / EWR / ships / radar  objects; single player always does)
--     -equipped fighters
-- Hostiles from world objects are only passed on when a friendly sensor
-- could plausibly see them: inside its range, above the radar horizon and
-- not hidden behind terrain (sampled with LoGetAltitude). Fighters only
-- share what is inside their radar cone, and only while their radar is on.
-- This is a simulation of a coalition picture, not DCS's own detection.
-----------------------------------------------------------------------

local DL = {
	period          = 1.0,    -- s between packets to the cockpit
	awacs_period    = 6.0,    -- s between AWACS/EWR picture refreshes (report latency)

	friendly_range  = 300000, -- m: friendly aircraft shown within this distance
	awacs_range     = 350000, -- m: AWACS detection range vs. fighters
	ewr_range       = 250000, -- m
	ship_range      = 150000, -- m
	fighter_range   =  80000, -- m: shared fighter radar range
	fighter_cone    = 60,     -- deg half-angle of a shared fighter radar
	ewr_mast        = 25,     -- m antenna height above ground for EWR / SAM search radars
	terrain_samples = 24,     -- LOS samples per sensor/target pair
	use_horizon     = true,   -- apply 4/3-earth radar horizon
	share_fighters  = true,   -- friendly fighters with radar on share contacts
	share_ships     = true,
	max_contacts    = 40,     -- must match DL_MAX_CONTACTS in dl_config.lua

	-- fighter-to-fighter datalink: friendly fighters of these types share
	-- what their radar sees (Lua patterns matched against the unit type)
	f2f_period      = 2.0,    -- s between fighter datalink updates
	threat_period   = 3.0,    -- s between ground-threat line-of-sight checks
	los_budget      = 2500,   -- max terrain samples per refresh (keeps big missions cheap)
	f2f_assume_radar_on = true, -- AI radar state is often not exported: assume on
	DATALINK = { "^F%-16", "^FA%-18", "^F%-15", "^F%-14", "^JF%-17", "^J%-11", "^Su%-30", "^Su%-35",
	             "^MiG%-31", "Typhoon", "Rafale", "Gripen", "^AV8BNA", "^A%-10C", "^F%-35", "^F%-22" },

	-- ground threats: enemy SAM / EWR radars that a friendly aircraft could
	-- pick up (inside the radar's detection range with line of sight) are
	-- reported with their approximate lethal ring.
	max_threats     = 16,     -- must match DL_MAX_THREATS in dl_config.lua
	THREATS = {   -- {pattern (lower case), label, ring m, detection m}
		{"s%-300ps 40b6m tr", "SA-10", 75000, 160000}, {"s%-300ps 40b6md sr", "SA-10", 75000, 160000},
		{"s%-300ps 64h6e sr", "SA-10", 75000, 200000}, {"buk sr", "SA-11", 35000, 100000},
		{"buk ln", "SA-11", 35000, 60000}, {"kub 1s91", "SA-6", 25000, 70000},
		{"osa 9a33", "SA-8", 10000, 30000}, {"tor 9a331", "SA-15", 12000, 25000},
		{"snr_75v", "SA-2", 43000, 100000}, {"snr s%-125", "SA-3", 18000, 60000},
		{"p%-19 s%-125", "SA-3", 18000, 160000}, {"rpc_5n62v", "SA-5", 150000, 270000},
		{"strela%-10", "SA-13", 5000, 10000}, {"strela%-1 ", "SA-9", 4000, 8000},
		{"tunguska", "SA-19", 8000, 18000}, {"zsu%-23%-4", "ZSU", 2500, 8000},
		{"hawk tr", "HAWK", 45000, 90000}, {"hawk sr", "HAWK", 45000, 90000},
		{"patriot str", "PAT", 100000, 160000}, {"nasams_radar", "NASM", 25000, 50000},
		{"rapier_fsa_blindfire", "RAP", 7000, 20000}, {"roland ads", "ROL", 8000, 15000},
		{"hq%-7_str", "HQ-7", 12000, 25000}, {"gepard", "GEP", 4000, 15000},
		{"1l13 ewr", "EWR", 0, 300000}, {"55g6 ewr", "EWR", 0, 300000},
		{"fps%-117", "EWR", 0, 300000}, {"dog ear", "EWR", 0, 35000},
	},

	AWACS = { ["A-50"] = true, ["E-3A"] = true, ["E-2C"] = true, ["KJ-2000"] = true, ["E-2D"] = true },
	EWR   = {
		["1L13 EWR"] = true, ["55G6 EWR"] = true, ["FPS-117"] = true, ["FPS-117 Dome"] = true,
		["p-19 s-125 sr"] = 160000, ["S-300PS 40B6MD sr"] = 160000, ["S-300PS 64H6E sr"] = 200000,
		["SA-11 Buk SR 9S18M1"] = 100000, ["Dog Ear radar"] = 35000, ["Kub 1S91 str"] = 70000,
		["Patriot str"] = 160000, ["Hawk sr"] = 90000, ["NASAMS_Radar_MPQ64F1"] = 50000,
		["RLS_19J6"] = 150000, ["RPC_5N62V"] = 270000, ["S-200_Radar"] = 270000,
	},
}

-- switches from DCS Options > Special > MIG-29AM (Saved Games\DCS\Config\options.lua),
-- read when a mission starts: with the datalink off no world objects are
-- scanned at all (only the own radar picture is sent), with the RWR off no
-- RWR packets are sent
local OPT = {mig29dl_datalink = true, mig29dl_rwr = true}
local function read_options()
	pcall(function()
		local lfs_mod = require("lfs")
		local f = loadfile(lfs_mod.writedir() .. "Config/options.lua")
		if not f then return end
		local env = {}
		setfenv(f, env)
		f()
		local p = env.options and env.options.plugins and env.options.plugins["mig_29am"]
		if type(p) ~= "table" then return end
		for k in pairs(OPT) do if type(p[k]) == "boolean" then OPT[k] = p[k] end end
	end)
end
read_options()

local MAX_ROUTE = 20   -- must match DL_MAX_WPTS

local last_send, last_awacs, last_f2f, last_thr, last_prune = -1000, -1000, -1000, -1000, -1000
local f2f_seen    = {}      -- [id] = true for hostiles a datalink fighter sees
local threat_mem  = {}      -- [id] = {lbl, x, y, z, ring} detected enemy SAM / EWR sites
-- type lookups are remembered per type name (they run for every unit, every second)
local dl_cache, threat_cache = {}, {}
local function is_datalink(name)
	name = name or ""
	local c = dl_cache[name]
	if c == nil then
		c = false
		for _, p in ipairs(DL.DATALINK) do
			if string.find(name, p) then c = true; break end
		end
		dl_cache[name] = c
	end
	return c
end
local function threat_of(name)
	name = name or ""
	local c = threat_cache[name]
	if c == nil then
		c = false
		local n = string.lower(name)
		for _, th in ipairs(DL.THREATS) do
			if string.find(n, th[1]) then c = th; break end
		end
		threat_cache[name] = c
	end
	return c or nil
end
local awacs_seen  = {}      -- [id] = true for hostiles the coalition sensors saw at the last refresh
local awacs_up    = false
local prev_pos    = {}      -- [id] = {t, x, z}
local vel         = {}      -- [id] = {vx, vz}

-- errors into dcs.log: at most one per 30 s and 5 per mission, so a
-- broken feature can never fill the log
local last_log, log_count = -1000, 0
local function log_err(msg)
	local t = LoGetModelTime and LoGetModelTime() or 0
	if t - last_log < 30 or log_count >= 5 then return end
	last_log, log_count = t, log_count + 1
	if log and log.write then log.write("MiG29DL", log.ERROR, tostring(msg)) end
end

-- transport: UDP to the cockpit device on this PC (127.0.0.1). The KRN
-- plugin devices share numbers with the jet's own devices, so GetDevice(n)
-- from here would reach the wrong system - a local socket avoids that.
local DL_PORT = 42888
local udp = nil
local function get_udp()
	if udp then return udp end
	local ok_lfs, lfs_mod = pcall(require, "lfs")
	local root = (ok_lfs and lfs_mod and lfs_mod.currentdir and lfs_mod.currentdir()) or "."
	package.path  = package.path  .. ";" .. root .. "/LuaSocket/?.lua"
	package.cpath = package.cpath .. ";" .. root .. "/LuaSocket/?.dll"
	local ok, socket = pcall(require, "socket")
	if not ok or not socket then return nil end
	local u = socket.udp()
	u:settimeout(0)
	u:setpeername("127.0.0.1", DL_PORT)
	udp = u
	return udp
end

local function dist2d(ax, az, bx, bz)
	local dx, dz = ax - bx, az - bz
	return math.sqrt(dx * dx + dz * dz)
end

local los_budget = 0          -- terrain samples left for this refresh
local function terrain_clear(x1, y1, z1, x2, y2, z2)
	if not LoGetAltitude then return true end
	-- one sample every ~4 km (6 .. terrain_samples); out of budget: assume clear
	local d = dist2d(x1, z1, x2, z2)
	local n = math.max(6, math.min(DL.terrain_samples, math.floor(d / 4000)))
	if los_budget < n then return true end
	los_budget = los_budget - n
	for i = 1, n - 1 do
		local t = i / n
		local x = x1 + (x2 - x1) * t
		local z = z1 + (z2 - z1) * t
		local y = y1 + (y2 - y1) * t
		local g = LoGetAltitude(x, z)
		if g and g > y then return false end
	end
	return true
end

local function horizon_ok(h1, h2, d)
	if not DL.use_horizon then return true end
	local R = 6371000 * 4 / 3
	local lim = math.sqrt(2 * R * math.max(h1, 0)) + math.sqrt(2 * R * math.max(h2, 0))
	return d <= lim
end

local function sees(sensor, tgt)
	local d = dist2d(sensor.x, sensor.z, tgt.x, tgt.z)
	if d > sensor.range then return false end
	if sensor.cone then
		local brg = math.atan2(tgt.z - sensor.z, tgt.x - sensor.x)   -- DCS: x north, z east
		local diff = math.abs(((brg - sensor.hdg) + math.pi) % (2 * math.pi) - math.pi)
		if diff > sensor.cone then return false end
	end
	if not horizon_ok(sensor.y, tgt.y, d) then return false end
	return terrain_clear(sensor.x, sensor.y, sensor.z, tgt.x, tgt.y, tgt.z)
end

local function pos_of(o)
	local p = o.Position or (o.position and (o.position.p or o.position))
	if not p then return nil end
	return p.x, p.y, p.z
end

local function update_velocity(id, t, x, z)
	local p = prev_pos[id]
	if p then
		if t > p.t + 0.2 then
			local dt = t - p.t
			local vx, vz = (x - p.x) / dt, (z - p.z) / dt
			if math.abs(vx) < 1500 and math.abs(vz) < 1500 then
				local v = vel[id]
				if v then v[1], v[2] = vx, vz else vel[id] = {vx, vz} end
			end
		end
		p.t, p.x, p.z, p.seen = t, x, z, t
	else
		prev_pos[id] = {t = t, x = x, z = z, seen = t}
	end
end

local function build_picture(t, self_id, me)
	local list = {}
	local status = 0
	local mx, my, mz = me.x, me.y, me.z
	local my_coal = me.coal

	-- world objects --------------------------------------------------
	local objs = OPT.mig29dl_datalink and LoGetWorldObjects and LoGetWorldObjects() or nil
	local have_objs = false
	local air, sensors, fighters, ground, present = {}, {}, {}, {}, {}
	if type(objs) == "table" then
		for id, o in pairs(objs) do
			have_objs = true
			local lvl1 = o.Type and o.Type.level1
			local x, y, z = pos_of(o)
			if x and id ~= self_id then
				local coal = o.CoalitionID
				local lname = tostring(o.Name or ""):lower()
				-- ejected pilots / parachutes are not aircraft
				if lvl1 == 1 and (lname:find("^pilot") or lname:find("parachut")) then lvl1 = nil end
				if lvl1 == 1 then
					update_velocity(id, t, x, z)
					local a = {id = id, x = x, y = y, z = z, coal = coal, name = o.Name or "",
					           group = o.GroupName, hdg = o.Heading or 0,
					           radar = o.Flags and o.Flags.RadarActive, born = not (o.Flags and o.Flags.Born == false),
					           unit = o.UnitName or ((o.Name or "AC") .. " " .. tostring(id)), human = o.Flags and o.Flags.Human,
					           jam = o.Flags and (o.Flags.Jamming or o.Flags.IRJamming)}
					a.dl = is_datalink(a.name)
					air[#air + 1] = a
					if coal == my_coal then
						if DL.AWACS[a.name] then
							sensors[#sensors + 1] = {x = x, y = y, z = z, range = DL.awacs_range}
						elseif DL.share_fighters and a.dl and (a.radar or DL.f2f_assume_radar_on) then
							fighters[#fighters + 1] = {x = x, y = y, z = z, range = DL.fighter_range,
							                           hdg = a.hdg, cone = math.rad(DL.fighter_cone)}
						end
					end
				elseif coal ~= my_coal and coal ~= 0 and lvl1 == 2 then
					local th = threat_of(o.Name)
					if th then
						present[id] = true
						if not threat_mem[id] then
							ground[#ground + 1] = {id = id, th = th, x = x, y = y or 0, z = z}
						end
					end
				elseif coal == my_coal and (lvl1 == 2 or lvl1 == 3) then
					local r = DL.EWR[o.Name or ""]
					if r then
						local rng = (r == true) and DL.ewr_range or r
						sensors[#sensors + 1] = {x = x, y = (y or 0) + DL.ewr_mast, z = z, range = rng}
					elseif lvl1 == 3 and DL.share_ships then
						sensors[#sensors + 1] = {x = x, y = (y or 0) + 30, z = z, range = DL.ship_range}
					end
				end
			end
		end
	end
	if have_objs then status = status + 1 end
	-- forget aircraft that are gone (keeps the tables small in long missions)
	if t - last_prune > 30 then
		last_prune = t
		for id, p in pairs(prev_pos) do
			if t - (p.seen or p.t) > 15 then prev_pos[id] = nil; vel[id] = nil; awacs_seen[id] = nil; f2f_seen[id] = nil end
		end
	end

	-- own sensors count too (our own radar is handled below, but the
	-- own jet also extends the picture by line of sight for friendlies)

	-- coalition sensor refresh (slow, like a real report cycle) --------
	if t - last_awacs >= DL.awacs_period then
		last_awacs = t
		los_budget = DL.los_budget
		awacs_seen = {}
		awacs_up = false
		for _, s in ipairs(sensors) do
			if not s.cone then awacs_up = true end
		end
		for _, a in ipairs(air) do
			if a.coal ~= my_coal and a.coal ~= 0 then
				for _, s in ipairs(sensors) do
					if sees(s, a) then
						local v = vel[a.id] or {0, 0}
						awacs_seen[a.id] = {x = a.x, y = a.y, z = a.z, vx = v[1], vz = v[2]}
						break
					end
				end
			end
		end
	end
	if awacs_up then status = status + 2 end

	-- fighter-to-fighter datalink: what datalink fighters' radars see ------
	if t - last_f2f >= DL.f2f_period then
		last_f2f = t
		los_budget = DL.los_budget
		f2f_seen = {}
		for _, a in ipairs(air) do
			if a.coal ~= my_coal and a.coal ~= 0 then
				for _, s in ipairs(fighters) do
					if sees(s, a) then f2f_seen[a.id] = true; break end
				end
			end
		end
	end
	if #fighters > 0 then status = status + 8 end

	-- ground threats: picked up by any friendly aircraft (incl. us) -------
	if have_objs and t - last_thr >= DL.threat_period then
		last_thr = t
		los_budget = DL.los_budget
		for id in pairs(threat_mem) do
			if not present[id] then threat_mem[id] = nil end       -- destroyed / gone
		end
		local friends = {{x = mx, y = my, z = mz}}
		for _, a in ipairs(air) do
			if a.coal == my_coal then friends[#friends + 1] = a end
		end
		for _, g in ipairs(ground) do
			local th = g.th
			for _, f in ipairs(friends) do
				local d = dist2d(f.x, f.z, g.x, g.z)
				if d <= th[4] and horizon_ok(g.y + DL.ewr_mast, f.y, d)
				   and terrain_clear(g.x, g.y + DL.ewr_mast, g.z, f.x, f.y, f.z) then
					threat_mem[g.id] = {lbl = th[2], x = g.x, y = g.y, z = g.z, ring = th[3]}
					break
				end
			end
		end
	end

	-- own radar --------------------------------------------------------
	local radar = {}
	local ok, tgts = pcall(function() return LoGetTargetInformation and LoGetTargetInformation() end)
	if ok and type(tgts) == "table" then
		for _, tg in pairs(tgts) do
			local x, y, z = pos_of(tg)
			if x then
				local vx, vz = 0, 0
				if type(tg.velocity) == "table" then vx, vz = tg.velocity.x or 0, tg.velocity.z or 0 end
				radar[#radar + 1] = {id = tg.ID, x = x, y = y, z = z, vx = vx, vz = vz}
			end
		end
	end
	if #radar > 0 then status = status + 4 end
	local radar_by_id = {}
	for _, r in ipairs(radar) do if r.id then radar_by_id[r.id] = r end end

	-- assemble ---------------------------------------------------------
	local used = {}
	for _, a in ipairs(air) do
		local typ = nil
		if a.coal == my_coal then
			if dist2d(a.x, a.z, mx, mz) <= DL.friendly_range then
				if DL.AWACS[a.name] then typ = 4
				elseif me.group and a.group == me.group then typ = 5
				elseif a.dl then typ = 6
				else typ = 1 end
			end
		elseif f2f_seen[a.id] then
			typ = 2
			a.f2f = true
		elseif awacs_seen[a.id] then
			typ = 2
		end
		local r = radar_by_id[a.id]
		if r then
			if a.coal == my_coal then
				typ = (typ == 5 and 15) or (typ == 4 and 14) or (typ == 6 and 16) or 11
			else
				typ = 12
			end
		end
		if typ then
			local v = vel[a.id] or {0, 0}
			local item = {typ = typ, x = a.x, z = a.z, y = a.y, vx = v[1], vz = v[2], age = 0,
			              d = dist2d(a.x, a.z, mx, mz), nm = (a.name ~= "") and a.name or nil}
			if r then
				item.x, item.z, item.y, item.vx, item.vz = r.x, r.z, r.y, r.vx, r.vz
			elseif typ == 2 and not a.f2f then
				-- AWACS / coalition report: position as of the last report, the
				-- cockpit dead-reckons it forward
				local snap = awacs_seen[a.id]
				item.x, item.z, item.y, item.vx, item.vz = snap.x, snap.z, snap.y, snap.vx, snap.vz
				item.age = t - last_awacs
			end
			list[#list + 1] = item
			used[a.id] = true
		end
	end
	-- radar contacts we could not match to a world object (export off)
	for _, r in ipairs(radar) do
		if not (r.id and used[r.id]) then
			list[#list + 1] = {typ = 13, x = r.x, z = r.z, y = r.y, vx = r.vx, vz = r.vz, age = 0,
			                   d = dist2d(r.x, r.z, mx, mz)}
		end
	end

	-- nearest first, own radar first
	table.sort(list, function(a, b)
		local ra, rb = a.typ >= 10, b.typ >= 10
		if ra ~= rb then return ra end
		return a.d < b.d
	end)
	local thr = {}
	for _, m in pairs(threat_mem) do
		-- one entry per site: skip a second radar of the same type close by
		local dup = false
		for _, o in ipairs(thr) do
			if o.lbl == m.lbl and dist2d(o.x, o.z, m.x, m.z) < 5000 then dup = true; break end
		end
		if not dup then
			m.d = dist2d(m.x, m.z, mx, mz)
			thr[#thr + 1] = m
		end
	end
	table.sort(thr, function(a, b) return a.d < b.d end)
	return list, status, thr, air
end

local function fmt(v) return string.format("%.1f", v or 0) end

-- the route that is loaded in the jet (DTC / mission / edits in the cockpit)
local function route_lines(out)
	local ok, r = pcall(function() return LoGetRoute and LoGetRoute() end)
	if not ok or type(r) ~= "table" or type(r.route) ~= "table" then return end
	local pts = {}
	for _, p in pairs(r.route) do
		if type(p) == "table" and type(p.world_point) == "table" and p.world_point.x then
			pts[#pts + 1] = p
		end
	end
	table.sort(pts, function(a, b) return (a.this_point_num or 0) < (b.this_point_num or 0) end)
	local goto_num = r.goto_point and r.goto_point.this_point_num
	local active = 0
	for i = 1, math.min(#pts, MAX_ROUTE) do
		local p = pts[i]
		out[#out + 1] = "W," .. fmt(p.world_point.x) .. "," .. fmt(p.world_point.z) .. "," .. tostring(p.this_point_num or (i - 1))
		if goto_num and p.this_point_num == goto_num then active = i end
	end
	out[#out + 1] = "A," .. active
end

-- weapon names for the SMS page, looked up once per weapon type
local name_cache = {}
local function store_name(w)
	if type(w) ~= "table" or not LoGetNameByType then return "" end
	local key = (w.level1 or 0) .. "." .. (w.level2 or 0) .. "." .. (w.level3 or 0) .. "." .. (w.level4 or 0)
	local n = name_cache[key]
	if not n then
		local ok, r = pcall(LoGetNameByType, w.level1 or 0, w.level2 or 0, w.level3 or 0, w.level4 or 0)
		n = ((ok and r) and tostring(r) or ""):gsub("[,\r\n]", " ")
		name_cache[key] = n
	end
	return n
end

local function tick()
	local t = LoGetModelTime and LoGetModelTime() or 0
	if t - last_send < DL.period then return end
	last_send = t

	local self = LoGetSelfData and LoGetSelfData()
	if not self or not self.Position then return end
	if not string.find(self.Name or "", "MiG%-29") then return end
	local u = get_udp()
	if not u then return end

	local self_id = LoGetPlayerPlaneId and LoGetPlayerPlaneId()
	local me = {x = self.Position.x, y = self.Position.y, z = self.Position.z,
	            coal = self.CoalitionID, group = self.GroupName}
	if LoGetObjectById and self_id then
		local o = LoGetObjectById(self_id)
		if o then
			me.coal  = o.CoalitionID or me.coal
			me.group = o.GroupName or me.group
		end
	end

	local list, status, thr, air = build_picture(t, self_id, me)
	local out = {"MIG29DL 1", "S," .. status, "O," .. tostring(me.coal or 0)}
	-- the MiG-29's own navigation panel: WP-A/D button lamps 1-3 and the
	-- WP / A-D switch (cockpit draw arguments)
	do
		local ok, nav = pcall(function()
			local d = GetDevice(0)
			local function a(n) return d:get_argument_value(n) or 0 end
			return string.format("N,%.2f,%.2f,%.2f,%.2f,%.2f", a(607), a(311), a(312), a(412), a(318)) .. "\n" ..
			       -- radio channel knob / display, RSBN, ILS, ADF and GCI (KRU) channel selectors
			       string.format("X,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f", a(252), a(284), a(133), a(134), a(144), a(447), a(234), a(235))
		end)
		if ok and nav then out[#out + 1] = nav end
	end
	-- engine / systems (for the ENG and FUEL pages)
	do
		local ok, q = pcall(function()
			local e = LoGetEngineInfo and LoGetEngineInfo() or {}
			local m = LoGetMechInfo and LoGetMechInfo() or {}
			local hp = e.HydraulicPressure or {}
			local acc = LoGetAccelerationUnits and LoGetAccelerationUnits() or {}
			local mach = LoGetMachNumber and LoGetMachNumber() or 0
			local function v(t) return (type(t) == "table" and (t.value or 0)) or 0 end
			return string.format("Q,%.1f,%.1f,%.3f,%.3f,%.2f,%.2f,%.2f,%.2f,%.3f",
				hp.left or 0, hp.right or 0, e.fuel_internal or 0, e.fuel_external or 0,
				v(m.gear), v(m.flaps), v(m.speedbrakes), acc.y or 0, mach)
		end)
		if ok and q then out[#out + 1] = q end
		-- engines: RPM %, temperature, fuel consumption (left, right)
		local ok2, e = pcall(function()
			local ei = LoGetEngineInfo and LoGetEngineInfo() or {}
			local function lr(t) t = type(t) == "table" and t or {}; return tonumber(t.left) or 0, tonumber(t.right) or 0 end
			local rl, rr = lr(ei.RPM)
			local tl, tr = lr(ei.Temperature)
			local fl, fr = lr(ei.FuelConsumption)
			return string.format("E,%.2f,%.2f,%.1f,%.1f,%.5f,%.5f", rl, rr, tl, tr, fl, fr)
		end)
		if ok2 and e then
			out[#out + 1] = e
		end
	end
	-- the target the radar is locked on (shown selected on the DL page)
	do
		local ok, lk = pcall(function() return LoGetLockedTargetInformation and LoGetLockedTargetInformation() end)
		if ok and type(lk) == "table" then
			for _, tg in pairs(lk) do
				local x, y, z = pos_of(tg)
				if x then
					local vx, vz = 0, 0
					if type(tg.velocity) == "table" then vx, vz = tg.velocity.x or 0, tg.velocity.z or 0 end
					out[#out + 1] = "L," .. fmt(x) .. "," .. fmt(z) .. "," .. fmt(y) .. "," .. fmt(vx) .. "," .. fmt(vz)
					break
				end
			end
		end
	end
	for i = 1, math.min(#thr, DL.max_threats) do
		local m = thr[i]
		out[#out + 1] = "G," .. m.lbl .. "," .. fmt(m.x) .. "," .. fmt(m.z) .. "," .. fmt(m.ring)
	end
	for i = 1, math.min(#list, DL.max_contacts) do
		local c = list[i]
		out[#out + 1] = "C," .. c.typ .. "," .. fmt(c.x) .. "," .. fmt(c.z) .. "," .. fmt(c.y) .. "," ..
			fmt(c.vx) .. "," .. fmt(c.vz) .. "," .. fmt(c.age) .. (c.nm and ("," .. tostring(c.nm):gsub("[,\r\n]", " ")) or "")
	end
	-- friendly aircraft by name, for the FLIGHT page (designating flight members)
	do
		local fr = {}
		for _, a in ipairs(air or {}) do
			if a.coal == me.coal and a.id ~= self_id then
				local d = dist2d(a.x, a.z, me.x, me.z)
				if d <= DL.friendly_range then fr[#fr + 1] = {a = a, d = d} end
			end
		end
		table.sort(fr, function(p, q)
			if (p.a.human and true or false) ~= (q.a.human and true or false) then return p.a.human and true or false end
			return p.d < q.d
		end)
		local function clean(v) return (tostring(v or ""):gsub("[,\r\n]", " ")) end
		for i = 1, math.min(#fr, DL.max_flight_list or 24) do
			local a = fr[i].a
			local v = vel[a.id] or {0, 0}
			out[#out + 1] = string.format("F,%s,%s,%s,%s,%.3f,%s,%s,%d,%d,%d,%s,%s", tostring(a.id), fmt(a.x), fmt(a.z), fmt(a.y),
				a.hdg or 0, fmt(v[1]), fmt(v[2]), a.human and 1 or 0, a.radar and 1 or 0, a.jam and 1 or 0, clean(a.name), clean(a.unit))
		end
	end
	-- stores (SMS page): Y,station,count,name   Z,gun shells,chaff,flares,current station
	do
		local ok, pl = pcall(function() return LoGetPayloadInfo and LoGetPayloadInfo() end)
		if ok and type(pl) == "table" then
			for i, st in ipairs(pl.Stations or {}) do
				local nm = ""
				if (st.count or 0) > 0 then nm = store_name(st.weapon) end
				out[#out + 1] = string.format("Y,%d,%d,%s", i, st.count or 0, nm)
			end
			local sn = LoGetSnares and LoGetSnares() or {}
			out[#out + 1] = string.format("Z,%d,%d,%d,%d", (pl.Cannon and pl.Cannon.shells) or 0, sn.chaff or 0, sn.flare or 0, pl.CurrentStation or 0)
		end
	end
	route_lines(out)
	out[#out + 1] = "E"
	u:send(table.concat(out, "\n"))
end

-- debug log: Saved Games\DCS\Logs\mig29dl_export.log
local dbg_n = 0
local function dbg(msg)
	if dbg_n > 50 then return end
	dbg_n = dbg_n + 1
	pcall(function()
		local l = require("lfs")
		local f = io.open(l.writedir() .. "Logs/mig29dl_export.log", (dbg_n == 1) and "w" or "a")
		if f then f:write(os.date("%H:%M:%S ") .. tostring(msg) .. "\n"); f:close() end
	end)
end
-- RWR, in its own small packet "MIG29DLV"
--  * full-fidelity MiG-29: the SPO-15 (L006LM) lamps, read from the cockpit
--    (arguments from the module's ASE/L006LM/lamps.lua), 10 times a second,
--    sent only when a lamp changes (and twice a second to keep it alive):
--      sectors (all threats) 191-198 = L70 L50 L30 L10 R10 R30 R50 R70, 199 / 200 rear
--      main threat sectors   150-157, 158 / 159 rear
--      type lamps (all) 171-176, main threat type 164-169: P Z H N F S
--      lock 162, above 160, below 161, power level 202-216 (1..15), SPO on 177
--    P,<main sectors>,<sectors>,<main types>,<types>,lock,above,below,power,on,launch
--  * FC3 MiG-29s: LoGetTWSInfo, 5 times a second
--    V,azimuth rad,power,state(1 scan 2 track 3 lock 4 launch),level1,name
local last_rwr, last_rwr_send, last_spo = -1000, -1000, nil
local SPO_MSEC = {150, 151, 152, 153, 154, 155, 156, 157, 158, 159}
local SPO_SEC  = {191, 192, 193, 194, 195, 196, 197, 198, 199, 200}
local SPO_MTYP = {164, 165, 166, 167, 168, 169}
local SPO_TYP  = {171, 172, 173, 174, 175, 176}
local spo_lock = {last = 0, flips = {}, launch_t = -100}
local spo_dev, spo_bits = nil, {}
local function lamp(a) return (spo_dev:get_argument_value(a) or 0) > 0.5 end
local function bits(list)
	for k, a in ipairs(list) do spo_bits[k] = lamp(a) and "1" or "0" end
	for k = #list + 1, #spo_bits do spo_bits[k] = nil end
	return table.concat(spo_bits)
end
local function spo_line(t)
	spo_dev = GetDevice(0)
	if not spo_dev then return nil end
	local pl = 0
	for k = 15, 1, -1 do if lamp(201 + k) then pl = k; break end end
	local lock = lamp(162) and 1 or 0
	-- a flashing lock lamp is the SPO-15's missile warning
	local fl = spo_lock.flips
	if lock ~= spo_lock.last then fl[#fl + 1] = t; spo_lock.last = lock end
	while fl[1] and t - fl[1] > 2.0 do table.remove(fl, 1) end
	if #fl >= 3 then spo_lock.launch_t = t end
	return string.format("P,%s,%s,%s,%s,%d,%d,%d,%d,%d,%d", bits(SPO_MSEC), bits(SPO_SEC), bits(SPO_MTYP), bits(SPO_TYP),
		lock, lamp(160) and 1 or 0, lamp(161) and 1 or 0, pl, lamp(177) and 1 or 0, (t - spo_lock.launch_t) < 2.0 and 1 or 0)
end
local function rwr_name(ty)
	if not LoGetNameByType then return "" end
	local ok, n = pcall(LoGetNameByType, ty.level1 or 0, ty.level2 or 0, ty.level3 or 0, ty.level4 or 0)
	return (((ok and n) and tostring(n) or ""):gsub("[,\r\n]", " "))
end
local function rwr_tick()
	if not OPT.mig29dl_rwr then return end
	local t = LoGetModelTime and LoGetModelTime() or 0
	if t - last_rwr < 0.1 then return end
	last_rwr = t
	local self = LoGetSelfData and LoGetSelfData()
	if not self or not string.find(self.Name or "", "MiG%-29") then return end
	local u = get_udp()
	if not u then return end
	local tws = LoGetTWSInfo and LoGetTWSInfo()
	if type(tws) ~= "table" then
		local line = spo_line(t)
		if line and (line ~= last_spo or t - last_rwr_send >= 0.5) then
			last_spo, last_rwr_send = line, t
			u:send("MIG29DLV\n" .. line)
		end
		return
	end
	if t - last_rwr_send < 0.2 then return end
	last_rwr_send = t
	local out = {"MIG29DLV"}
	do
		for _, e in ipairs(tws.Emitters or {}) do
			local sig = tostring(e.SignalType or "")
			local st = 1
			if sig:find("missile") then st = 4 elseif sig:find("lock") then st = 3 elseif sig:find("track") then st = 2 end
			local ty = type(e.Type) == "table" and e.Type or {}
			out[#out + 1] = string.format("V,%.3f,%.3f,%d,%d,%s", tonumber(e.Azimuth) or 0, tonumber(e.Power) or 0, st,
				ty.level1 or 0, rwr_name(ty))
		end
	end
	u:send(table.concat(out, "\n"))
end
-- chain into the export callbacks without disturbing other scripts.
-- Other export scripts may replace LuaExportAfterNextFrame inside their
-- own LuaExportStart, so the hook is (re)attached after they have run.
local function our_after()
	local ok, err = pcall(tick)
	if not ok then log_err(err); dbg("error: " .. tostring(err)) end
	local ok2, err2 = pcall(rwr_tick)
	if not ok2 then dbg("rwr error: " .. tostring(err2)) end
end
local function attach()
	local cur = LuaExportAfterNextFrame
	if cur and cur == MIG29DL_HOOK then return end
	MIG29DL_HOOK = function()
		our_after()
		if cur then cur() end
	end
	LuaExportAfterNextFrame = MIG29DL_HOOK
end
attach()
dbg("export script loaded")
do
	local prev_start = LuaExportStart
	LuaExportStart = function()
		if prev_start then pcall(prev_start) end
		read_options()
		dbg("options: datalink=" .. tostring(OPT.mig29dl_datalink) .. " rwr=" .. tostring(OPT.mig29dl_rwr))
		attach()
		dbg("LuaExportStart: hook attached")
	end
	local prev_act = LuaExportActivityNextEvent
	LuaExportActivityNextEvent = function(t)
		attach()
		if prev_act then return prev_act(t) end
		return t + 1.0
	end
	local prev_stop = LuaExportStop
	LuaExportStop = function()
		last_send, last_awacs, last_f2f, last_thr, last_prune = -1000, -1000, -1000, -1000, -1000
		last_rwr, last_rwr_send, last_spo = -1000, -1000, nil
		last_log, log_count = -1000, 0
		name_cache = {}
		prev_pos, vel, awacs_seen, f2f_seen, threat_mem = {}, {}, {}, {}, {}
		if udp then pcall(function() udp:close() end); udp = nil end
		dbg("LuaExportStop")
		if prev_stop then prev_stop() end
	end
end
