-----------------------------------------------------------------------
-- MiG29DL_Hook.lua  --  mission data for the MiG-29 MFD pages
-- (Saved Games\DCS\Scripts\Hooks)
--
-- Every few seconds, over UDP to 127.0.0.1:42888 (the MFD cockpit device):
--   * both coalitions' bullseye                          (SA page)
--   * the map name, the data cartridge stored with your MiG-29 in the
--     mission and its radio presets ("MSN DTC" on the PLAN page; .dtc
--     files from Saved Games\DCS\DTC are picked with PLAN > LOAD)
--   * which player sits in which aircraft               (FLT page)
-- Does nothing where nobody flies on this PC (dedicated server, spectators).
-----------------------------------------------------------------------
local DL_PORT = 42888
local udp     = nil
local last    = -100
local msg     = nil

local function get_udp()
	if udp then return udp end
	local ok_lfs, lfs_mod = pcall(require, "lfs")
	local root = (ok_lfs and lfs_mod and lfs_mod.currentdir and lfs_mod.currentdir()) or "."
	package.path  = package.path  .. ";" .. root .. "/LuaSocket/?.lua"
	package.cpath = package.cpath .. ";" .. root .. "/LuaSocket/?.dll"
	local ok, socket = pcall(require, "socket")
	if not ok or not socket then return nil end
	udp = socket.udp()
	udp:settimeout(0)
	return udp
end

-- Saved Games\DCS\Logs\mig29dl_hook.log: new file each DCS start, a few lines
local log_n = 0
local function log(msg)
	if log_n >= 50 then return end
	log_n = log_n + 1
	pcall(function()
		local l = require("lfs")
		local f = io.open(l.writedir() .. "Logs/mig29dl_hook.log", (log_n == 1) and "w" or "a")
		if f then f:write(os.date("%H:%M:%S ") .. tostring(msg) .. "\n"); f:close() end
	end)
end

-- someone flies on this PC: single player, or a multiplayer client / host
-- sitting in a slot (not a dedicated server, not a spectator)
local function flying_here()
	if not (DCS.isMultiplayer and DCS.isMultiplayer()) then return true end
	local ok, slot = pcall(function() return net.get_player_info(net.get_my_player_id(), "slot") end)
	return ok and slot ~= nil and slot ~= "" and slot ~= 0 and slot ~= "0"
end
-- the mission environment can only be asked where the mission runs
local function mission_here()
	return not (DCS.isMultiplayer and DCS.isMultiplayer()) or (DCS.isServer and DCS.isServer())
end

-- a list of points with x / y map coordinates
local function is_route(t)
	return type(t) == "table" and type(t[1]) == "table" and tonumber(t[1].x) and tonumber(t[1].y)
end

-- find a cartridge route inside a table (mission unit or .dtc data)
local function has_points(p)
	return type(p) == "table" and (is_route(p.Route) or is_route(p.Waypoints) or is_route(p.Airdromes))
end
local function route_in_cartridge(d)
	if type(d) ~= "table" then return nil end
	local data = d.data or d
	local prog = data.SelectedProgram and data[data.SelectedProgram]
	if has_points(prog) then return prog, data.SelectedProgram end
	if has_points(data.Program_1) then return data.Program_1, "Program_1" end
	return nil
end

local function search(t, depth, seen)
	if type(t) ~= "table" or depth > 7 or seen[t] then return nil end
	seen[t] = true
	local r, p = route_in_cartridge(t)
	if r then return r, p end
	for k, v in pairs(t) do
		if type(v) == "table" then
			local kk = string.lower(tostring(k))
			if depth < 2 or kk:find("dtc") or kk:find("cartridge") or kk:find("program") or kk:find("data") then
				local r2, p2 = search(v, depth + 1, seen)
				if r2 then return r2, p2 end
			end
		end
	end
	return nil
end

local function mission_table()
	local ok, m = pcall(DCS.getCurrentMission)
	if not ok or type(m) ~= "table" then return nil end
	return m.mission or m
end

-- 1. cartridge stored with a player MiG-29 in the mission
local function dtc_from_mission(mis)
	local c = mis and mis.coalition
	if type(c) ~= "table" then return nil end
	for _, side in pairs(c) do
		for _, ctry in pairs(type(side) == "table" and side.country or {}) do
			local planes = type(ctry) == "table" and ctry.plane
			for _, grp in pairs(type(planes) == "table" and planes.group or {}) do
				for _, u in pairs(type(grp) == "table" and grp.units or {}) do
					if type(u) == "table" and tostring(u.type):find("MiG%-29")
					   and (u.skill == "Player" or u.skill == "Client") then
						local r, p = search(u, 0, {})
						if r then return r, "mission " .. tostring(p) end
					end
				end
			end
		end
	end
	return nil
end

local route_msg = nil
local function build_route()
	local mis = mission_table()
	local out = {"MIG29DLR", "T," .. tostring(mis and mis.theatre or "")}
	local prog, src = dtc_from_mission(mis)
	if prog then
		out[#out + 1] = "P," .. (tostring(src):gsub(",", " "))
		local function add(tag, list)
			for i, w in ipairs(type(list) == "table" and list or {}) do
				if tonumber(w.x) and tonumber(w.y) then
					local num = tostring(w.num or w.name or i):gsub("[^%w]", "")
					out[#out + 1] = string.format("%s,%.1f,%.1f,%s", tag, tonumber(w.x), tonumber(w.y), num)
				end
			end
		end
		add("R", prog.Route); add("W", prog.Waypoints); add("A", prog.Airdromes)
		log("mission DTC: " .. tostring(src))
	else
		log("no DTC stored with the jet in this mission")
	end
	-- radio presets of the player MiG-29 (mission editor), for the COM/NAV page
	pcall(function()
		for _, side in pairs(mis.coalition or {}) do
			for _, ctry in pairs(type(side) == "table" and side.country or {}) do
				local planes = type(ctry) == "table" and ctry.plane
				for _, grp in pairs(type(planes) == "table" and planes.group or {}) do
					for _, u in pairs(type(grp) == "table" and grp.units or {}) do
						if type(u) == "table" and tostring(u.type):find("MiG%-29")
						   and (u.skill == "Player" or u.skill == "Client") and type(u.Radio) == "table" then
							local r1 = u.Radio[1] and u.Radio[1].channels
							for ch, f in pairs(type(r1) == "table" and r1 or {}) do
								if tonumber(f) then out[#out + 1] = string.format("C,%d,%.3f", ch, tonumber(f)) end
							end
							error("done")
						end
					end
				end
			end
		end
	end)
	return table.concat(out, "\n")
end

local function build()
	local ok, m = pcall(DCS.getCurrentMission)
	if not ok or type(m) ~= "table" then return nil end
	local mis = m.mission or m
	local c = mis and mis.coalition
	if type(c) ~= "table" then return nil end
	local function be(side)
		local b = c[side] and c[side].bullseye
		if type(b) == "table" and b.x and b.y then return string.format("%.1f,%.1f", b.x, b.y) end
		return "0,0"
	end
	return "MIG29DLB\nB," .. be("blue") .. "," .. be("red")
end

-----------------------------------------------------------------------
-- player names of the friendly aircraft (FLIGHT page remembers members by
-- player name). Asked from the mission itself, so this only runs where the
-- mission runs: single player, or a player hosting from his own PC.
-- Only coalition.getPlayers is used, every 10 s: almost no load.
-----------------------------------------------------------------------
local PLAYERS_CODE = [==[
local side = %d
local out = {}
local function clean(v) return (tostring(v or ""):gsub("[|;\n\r]", " ")) end
-- only the player-flown aircraft: cheap for the server even in big missions
for _, u in ipairs(coalition.getPlayers(side) or {}) do
	if u and u:isExist() then
		out[#out + 1] = table.concat({clean(u:getName()), clean(u:getPlayerName() or ""), clean(u:getTypeName()), "", "", ""}, "|")
	end
end
return table.concat(out, "\n")
]==]
local players_last = -100
local function my_side()
	local ok, side = pcall(function() return net.get_player_info(net.get_my_player_id(), "side") end)
	side = ok and tonumber(side) or 0
	return side
end
local function send_players(u, t)
	if t - players_last < 10 then return end
	players_last = t
	if not mission_here() then return end
	local side = my_side()
	if side ~= 1 and side ~= 2 then return end
	local ok, res = pcall(net.dostring_in, "mission", string.format(PLAYERS_CODE, side))
	if ok and type(res) == "string" and res ~= "" then
		pcall(function() u:sendto("MIG29DLW\n" .. res, "127.0.0.1", DL_PORT) end)
	end
end

-----------------------------------------------------------------------
-- who flies which editor slot (any multiplayer client): the mission's
-- client slots by unit name, with the player sitting in each
-----------------------------------------------------------------------
local brief_units = nil      -- {unitId = {name, type}}
local function build_brief()
	brief_units = {}
	local mis = mission_table()
	for _, side in pairs(type(mis) == "table" and mis.coalition or {}) do
		for _, ctry in pairs(type(side) == "table" and side.country or {}) do
			for _, cat in ipairs({"plane", "helicopter"}) do
				local c = type(ctry) == "table" and ctry[cat]
				for _, grp in pairs(type(c) == "table" and c.group or {}) do
					for _, u in pairs(type(grp) == "table" and grp.units or {}) do
						if type(u) == "table" and (u.skill == "Client" or u.skill == "Player") then
							brief_units[tostring(u.unitId)] = {name = tostring(u.name or ""), type = tostring(u.type or "")}
						end
					end
				end
			end
		end
	end
end
local brief_last = -100
local function send_brief(u, t)
	if t - brief_last < 10 then return end
	brief_last = t
	if not brief_units then pcall(build_brief) end
	if not brief_units then return end
	-- who sits in which slot (slot = the mission unit id for editor slots)
	local pilot = {}
	pcall(function()
		for _, id in ipairs(net.get_player_list() or {}) do
			local info = net.get_player_info(id) or {}
			if info.slot and info.name then pilot[tostring(info.slot)] = info.name end
		end
	end)
	local out = {"MIG29DLM"}
	local function clean(v) return (tostring(v or ""):gsub("[|\n\r]", " ")) end
	for uid, b in pairs(brief_units) do
		if #out < 60 then
			out[#out + 1] = table.concat({clean(b.name), clean(pilot[uid] or ""), clean(b.type), "", "", ""}, "|")
		end
	end
	pcall(function() u:sendto(table.concat(out, "\n"), "127.0.0.1", DL_PORT) end)
end

local cb = {}
-- the mission is only read once somebody flies on this PC (never on a
-- dedicated server: there the hook just checks every 5 s and stops)
local need_build = false
function cb.onSimulationStart()
	msg, route_msg = nil, nil
	need_build = true
	last = -100
end
function cb.onSimulationStop()
	need_build = false
	msg = nil
	route_msg = nil
	brief_units = nil
end
function cb.onSimulationFrame()
	if not need_build and not msg and not route_msg then return end
	local t = DCS.getModelTime and DCS.getModelTime() or 0
	if t - last < 5 then return end
	last = t
	if not flying_here() then return end
	if need_build then
		need_build = false
		msg = build()
		local ok, rm = pcall(build_route)
		route_msg = ok and rm or nil
		if not ok then log("route error: " .. tostring(rm)) end
		if not msg and not route_msg then return end
	end
	local u = get_udp()
	if u then
		if msg then pcall(function() u:sendto(msg, "127.0.0.1", DL_PORT) end) end
		if route_msg then pcall(function() u:sendto(route_msg, "127.0.0.1", DL_PORT) end) end
	end
	if u then pcall(send_players, u, t); pcall(send_brief, u, t) end
end
DCS.setUserCallbacks(cb)
