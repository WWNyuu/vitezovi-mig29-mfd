-- Theatre recognition for the MiG-29 DL page.
-- Each entry: a DCS world point (x north, z east, metres) and the lat/lon it must map to
-- on that theatre. terrain.convertMetersToLatLon() tells us which theatre is loaded.
-- MarianasWWII uses the same projection as MarianaIslands, so it shows the MarianaIslands charts.
DL_THEATRES = {
	{name = "Afghanistan", x = 62027.05, z = -24694.80, lat = 34.5, lon = 66.0},
	{name = "Caucasus", x = -197826.86, z = 634263.66, lat = 43.0, lon = 42.0},
	{name = "Falklands", x = 85851.38, z = 9429.48, lat = -51.7, lon = -59.0},
	{name = "GermanyColdWar", x = -303744.69, z = -692470.75, lat = 51.5, lon = 10.5},
	{name = "Iraq", x = -28326.03, z = -21127.78, lat = 33.0, lon = 44.0},
	{name = "Kola", x = 71255.16, z = 223084.19, lat = 68.5, lon = 28.0},
	{name = "MarianaIslands", x = 56798.69, z = 22397.44, lat = 14.0, lon = 145.0},
	{name = "Nevada", x = -369573.86, z = -59659.39, lat = 36.5, lon = -115.5},
	{name = "PersianGulf", x = -18387.56, z = -74371.13, lat = 26.0, lon = 55.5},
	{name = "Sinai", x = -6527.65, z = 169222.00, lat = 30.0, lon = 33.0},
	{name = "Syria", x = -4995.37, z = 100284.91, lat = 35.0, lon = 37.0},
}

-- returns the theatre name or nil
function DL_detect_theatre()
	if DL_CFG and DL_CFG.force_theatre and DL_CFG.force_theatre ~= "" then
		return DL_CFG.force_theatre
	end
	local ok, terr = pcall(require, "terrain")
	if not ok or type(terr) ~= "table" or not terr.convertMetersToLatLon then
		return nil
	end
	for _, t in ipairs(DL_THEATRES) do
		local ok2, lat, lon = pcall(terr.convertMetersToLatLon, t.x, t.z)
		if ok2 and lat and lon and math.abs(lat - t.lat) < 0.05 and math.abs(lon - t.lon) < 0.05 then
			return t.name
		end
	end
	return nil
end

-- loads DL/charts/<theatre>.lua into DL_CHART (nil if there is none)
function DL_load_chart(theatre)
	DL_CHART = nil
	if not theatre then return nil end
	local path = LockOn_Options.script_path .. "DL/charts/" .. theatre .. ".lua"
	local ok = pcall(dofile, path)
	if ok and DL_CHART and DL_CHART.tiles then return DL_CHART end
	DL_CHART = nil
	return nil
end
