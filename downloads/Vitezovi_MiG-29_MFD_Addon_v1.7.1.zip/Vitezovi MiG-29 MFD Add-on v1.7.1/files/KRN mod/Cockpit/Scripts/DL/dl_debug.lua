-- MiG-29 DL page: tiny debug log, Saved Games\DCS\Logs\mig29dl_<name>.log
DL_DEBUG_COUNT = DL_DEBUG_COUNT or {}
function DL_dbg(name, msg)
	local n = (DL_DEBUG_COUNT[name] or 0) + 1
	DL_DEBUG_COUNT[name] = n
	if n > 300 then return end
	pcall(function()
		local l = require("lfs")
		local f = io.open(l.writedir() .. "Logs/mig29dl_" .. name .. ".log", (n == 1) and "w" or "a")
		if f then f:write(os.date("%H:%M:%S ") .. tostring(msg) .. "\n"); f:close() end
	end)
end
