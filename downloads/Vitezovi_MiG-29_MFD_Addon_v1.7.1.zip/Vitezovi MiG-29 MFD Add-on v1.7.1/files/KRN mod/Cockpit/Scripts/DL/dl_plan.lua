-----------------------------------------------------------------------
-- MiG-29 DL page: flight plans and data cartridges (DTC)
--
-- A plan is {name, pts, wps, ads}:
--   wps  the jet's navigation waypoints (WP-A/D buttons 1-3 in WP)
--   ads  the airfields (WP-A/D buttons 1-3 in A/D)
--   pts  what is drawn: the route (or the waypoints), then the airfields
-- Coordinates are DCS map metres: x = north, z = east.
--
-- Choices (UFCP button 3 steps through them, nothing is loaded on its own):
--   MSN            the mission: a cartridge stored with your jet in the
--                  mission (mission planner), else the mission route
--   <file>.dtc     each MiG-29 cartridge in Saved Games\DCS\DTC made for
--                  the map you are flying
-----------------------------------------------------------------------

DL_PLAN = {}

local JSON = nil
local function json()
	if JSON then return JSON end
	local roots = {"", "./"}
	local ok_lfs, lfs_mod = pcall(require, "lfs")
	if ok_lfs and lfs_mod and lfs_mod.currentdir then
		local r = lfs_mod.currentdir()
		if r:sub(-1) ~= "/" and r:sub(-1) ~= "\\" then r = r .. "/" end
		roots[#roots + 1] = r
		roots[#roots + 1] = r .. "../"
	end
	for _, r in ipairs(roots) do
		local f = loadfile(r .. "Scripts/JSON.lua")
		if f then
			local ok, j = pcall(f)
			if ok and j then JSON = j; return JSON end
		end
	end
	return nil
end

local function short(lbl, prefix, i)
	lbl = tostring(lbl or ""):gsub("[^%w]", "")
	lbl = lbl:gsub("^WPT", "W"):gsub("^PNT", "P")
	if lbl == "" or not lbl:find("%a") then lbl = prefix .. tostring(i) end
	return lbl
end

-- build a plan from lists of {x, y(east), num} points
function DL_PLAN.make(name, route, wps, ads)
	local p = {name = name, pts = {}, wps = {}, ads = {}}
	-- a cartridge with only a route: its points are the nav waypoints
	if (not wps or #wps == 0) and route and #route > 0 then wps, route = route, nil end
	for i, w in ipairs(wps or {}) do
		p.wps[#p.wps + 1] = {x = w.x, z = w.z, lbl = "W" .. i, name = w.name or w.lbl}
	end
	for i, a in ipairs(ads or {}) do
		p.ads[#p.ads + 1] = {x = a.x, z = a.z, lbl = "A" .. i, ad = true, name = a.name or a.lbl}
	end
	local line = (route and #route > 0) and route or wps or {}
	for i, w in ipairs(line) do
		p.pts[#p.pts + 1] = {x = w.x, z = w.z, lbl = (line == wps) and ("W" .. i) or short(w.lbl, "W", i), name = w.name, rt = i, tags = w.tags}
	end
	p.nrt = #p.pts            -- route points first, then the airfields
	for _, a in ipairs(p.ads) do p.pts[#p.pts + 1] = a end
	return p
end

-- a plan with only some of its route points, in the order given (the
-- RTE page): sel = list of route indices of the full plan
function DL_PLAN.route_view(plan, sel)
	local p = {}
	for k, v in pairs(plan) do p[k] = v end
	p.pts, p._rt, p.full = {}, nil, plan
	for _, i in ipairs(sel) do
		local w = plan.pts[i]
		if w and i <= (plan.nrt or #plan.pts) then p.pts[#p.pts + 1] = w end
	end
	p.nrt = #p.pts
	for i = (plan.nrt or #plan.pts) + 1, #plan.pts do p.pts[#p.pts + 1] = plan.pts[i] end
	return p
end
-- "ALL" for a plan with member tags: its route rows are the members'
-- routes woven together, so ALL = every point once, by point number
-- (nil = no tags: the route as it is)
function DL_PLAN.all_order(plan)
	if not plan or #DL_PLAN.members(plan) == 0 then return nil end
	local seen, list = {}, {}
	for i = 1, plan.nrt or 0 do
		local w = plan.pts[i]
		local key = tostring(w.lbl)
		if not seen[key] then seen[key] = true; list[#list + 1] = i end
	end
	local function num(i) return tonumber(tostring(plan.pts[i].lbl):match("(%d+)")) or 1e9 end
	table.sort(list, function(a, b) local na, nb = num(a), num(b); if na ~= nb then return na < nb end return a < b end)
	return list
end
-- the flight member numbers used in a plan's route tags (sorted)
function DL_PLAN.members(plan)
	local seen, out = {}, {}
	for i = 1, (plan and plan.nrt) or 0 do
		for m in pairs(plan.pts[i].tags or {}) do if not seen[m] then seen[m] = true; out[#out + 1] = m end end
	end
	table.sort(out)
	return out
end

local function pts_of(list)
	local out = {}
	if type(list) ~= "table" then return out end
	for i, w in ipairs(list) do
		local x, y = tonumber(w.x), tonumber(w.y)
		-- name: the cartridge note ("RV", "TGT") when there is one
		local note = (type(w.note) == "string" and w.note ~= "") and w.note or nil
		-- flight member tags at the start of the note: "12 TGT" = for 1 and 2
		local tags = nil
		if note then
			local t, rest = note:match("^(%d+)%s+(.*)$")
			if not t then t = note:match("^(%d+)$"); rest = "" end
			if t then
				tags = {}
				for c in t:gmatch("%d") do tags[tonumber(c)] = true end
				note = (rest ~= "") and rest or nil
			end
		end
		if x and y then out[#out + 1] = {x = x, z = y, lbl = w.num or w.name or i, name = note or w.unit_name or w.name, tags = tags} end
	end
	return out
end

-- MiG-29 cartridges for this map, sorted by name
function DL_PLAN.list_files(theatre)
	local files = {}
	local ok_lfs, lfs_mod = pcall(require, "lfs")
	if not ok_lfs or not lfs_mod then return files end
	local dir = lfs_mod.writedir() .. "DTC/"
	local J = json()
	if not J then return files end
	local ok_dir = pcall(function()
		for name in lfs_mod.dir(dir) do
			if name:lower():match("%.dtc$") then
				local fh = io.open(dir .. name, "r")
				if fh then
					local txt = fh:read("*a"); fh:close()
					local ok, d = pcall(function() return J:decode(txt) end)
					local data = ok and type(d) == "table" and (d.data or d)
					if data and tostring(data.type or d.type or ""):find("MiG%-29") then
						local terr = data.terrain
						if not theatre or not terr or tostring(terr):lower() == tostring(theatre):lower() then
							files[#files + 1] = {name = name:gsub("%.[dD][tT][cC]$", ""), data = data}
						end
					end
				end
			end
		end
	end)
	table.sort(files, function(a, b) return a.name:lower() < b.name:lower() end)
	return files
end

-- plan from a decoded cartridge (its selected program)
function DL_PLAN.from_cartridge(name, data)
	local prog = data[data.SelectedProgram or "Program_1"] or data.Program_1
	if type(prog) ~= "table" then return DL_PLAN.make(name, {}, {}, {}) end
	local p = DL_PLAN.make(name, pts_of(prog.Route), pts_of(prog.Waypoints), pts_of(prog.Airdromes))
	-- radio presets (Channel_0 = channel 1), RSBN and ADF channels
	p.radio = {}
	for k, c in pairs(type(prog.Radio) == "table" and prog.Radio or {}) do
		local n = tonumber(tostring(k):match("(%d+)$"))
		if n and type(c) == "table" and tonumber(c.freq) then p.radio[n + 1] = tonumber(c.freq) end
	end
	p.rsbn = {}
	for _, r in ipairs(type(prog.RSBN) == "table" and prog.RSBN or {}) do
		p.rsbn[#p.rsbn + 1] = {name = r.name or r.unit_name or "?", channel = tonumber(r.channel), x = tonumber(r.x), z = tonumber(r.y)}
	end
	p.adf = {}
	for k, c in pairs(type(prog.ADF) == "table" and prog.ADF or {}) do
		if type(c) == "table" and tonumber(c.freq) then p.adf[#p.adf + 1] = {key = tostring(k), freq = tonumber(c.freq)} end
	end
	table.sort(p.adf, function(a, b) return a.key < b.key end)
	return p
end

-- plan from the hook's "MSN DTC" packet lines (R / W / A)
function DL_PLAN.from_lines(name, lines)
	return DL_PLAN.make(name, lines.R or {}, lines.W or {}, lines.A or {})
end

-----------------------------------------------------------------------
-- coordinates: WGS84 UTM / MGRS (for typed-in waypoints on the NAV page)
-----------------------------------------------------------------------
local WA, WF, K0 = 6378137.0, 1 / 298.257223563, 0.9996
local WE2 = WF * (2 - WF)
local WEP2 = WE2 / (1 - WE2)

function DL_PLAN.utm_zone(lat, lon)
	local z = math.floor((lon + 180) / 6) + 1
	if lat >= 56 and lat < 64 and lon >= 3 and lon < 12 then z = 32 end     -- Norway
	return math.max(1, math.min(60, z))
end
function DL_PLAN.ll_to_utm(lat, lon, zone)
	zone = zone or DL_PLAN.utm_zone(lat, lon)
	local phi, lam = math.rad(lat), math.rad(lon)
	local lam0 = math.rad((zone - 1) * 6 - 180 + 3)
	local sp, cp, tp = math.sin(phi), math.cos(phi), math.tan(phi)
	local N = WA / math.sqrt(1 - WE2 * sp * sp)
	local T, Cc = tp * tp, WEP2 * cp * cp
	local A = cp * (lam - lam0)
	local e4, e6 = WE2 * WE2, WE2 * WE2 * WE2
	local Mm = WA * ((1 - WE2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi - (3 * WE2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * math.sin(2 * phi)
		+ (15 * e4 / 256 + 45 * e6 / 1024) * math.sin(4 * phi) - (35 * e6 / 3072) * math.sin(6 * phi))
	local e = K0 * N * (A + (1 - T + Cc) * A ^ 3 / 6 + (5 - 18 * T + T * T + 72 * Cc - 58 * WEP2) * A ^ 5 / 120) + 500000
	local n = K0 * (Mm + N * tp * (A * A / 2 + (5 - T + 9 * Cc + 4 * Cc * Cc) * A ^ 4 / 24 + (61 - 58 * T + T * T + 600 * Cc - 330 * WEP2) * A ^ 6 / 720))
	if lat < 0 then n = n + 10000000 end
	return zone, e, n
end
function DL_PLAN.utm_to_ll(zone, e, n, north)
	local x, y = e - 500000, north and n or (n - 10000000)
	local Mm = y / K0
	local mu = Mm / (WA * (1 - WE2 / 4 - 3 * WE2 ^ 2 / 64 - 5 * WE2 ^ 3 / 256))
	local e1 = (1 - math.sqrt(1 - WE2)) / (1 + math.sqrt(1 - WE2))
	local phi1 = mu + (3 * e1 / 2 - 27 * e1 ^ 3 / 32) * math.sin(2 * mu) + (21 * e1 ^ 2 / 16 - 55 * e1 ^ 4 / 32) * math.sin(4 * mu)
		+ (151 * e1 ^ 3 / 96) * math.sin(6 * mu) + (1097 * e1 ^ 4 / 512) * math.sin(8 * mu)
	local s1, c1, t1 = math.sin(phi1), math.cos(phi1), math.tan(phi1)
	local N1 = WA / math.sqrt(1 - WE2 * s1 * s1)
	local T1, C1 = t1 * t1, WEP2 * c1 * c1
	local R1 = WA * (1 - WE2) / (1 - WE2 * s1 * s1) ^ 1.5
	local D = x / (N1 * K0)
	local lat = phi1 - (N1 * t1 / R1) * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * WEP2) * D ^ 4 / 24
		+ (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * WEP2 - 3 * C1 * C1) * D ^ 6 / 720)
	local lon = (D - (1 + 2 * T1 + C1) * D ^ 3 / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * WEP2 + 24 * T1 * T1) * D ^ 5 / 120) / c1
	return math.deg(lat), (zone - 1) * 6 - 180 + 3 + math.deg(lon)
end
-- "38T KM": grid zone and the 100 km square letters
function DL_PLAN.mgrs_square(lat, zone, e, n)
	local bands = "CDEFGHJKLMNPQRSTUVWX"
	local b = math.max(1, math.min(20, math.floor((lat + 80) / 8) + 1))
	local sets = {"ABCDEFGH", "JKLMNPQR", "STUVWXYZ"}
	local set = sets[(zone - 1) % 3 + 1]
	local col = math.max(1, math.min(8, math.floor(e / 100000)))
	local rows = "ABCDEFGHJKLMNPQRSTUV"
	local r = (math.floor(n / 100000) + ((zone % 2 == 0) and 5 or 0)) % 20
	return string.format("%d%s %s%s", zone, bands:sub(b, b), set:sub(col, col), rows:sub(r + 1, r + 1))
end
