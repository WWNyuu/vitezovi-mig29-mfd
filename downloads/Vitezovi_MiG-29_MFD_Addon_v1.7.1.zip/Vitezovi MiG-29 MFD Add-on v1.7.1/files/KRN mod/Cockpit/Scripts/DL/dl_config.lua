-----------------------------------------------------------------------
-- MiG-29 datalink SIT page (F-15 SIT style)  --  user settings
-- Add-on for "MiG-29A(M) Cockpit Modernization - KRN MODS".
-- Safe to edit. Restart the mission after changing anything here.
-----------------------------------------------------------------------

DL_CFG = {
	-- Map underneath the SA page (set by the "Moving map" switch in
	-- Options > Special, see the end of this file):
	--  "dcs"  = DCS's own aeronautical charts for the theatre you are on
	--           (read from Mods\terrains\<theatre>\RasterCharts, nothing copied)
	--  "none" = black background (F-15 SIT style)
	map_source = "none",
	-- Leave empty to detect the theatre automatically, or set e.g. "MarianasWWII".
	force_theatre = "",
	-- How much to darken the chart under the symbols (0 = not at all, 1 = black).
	map_brightness = 0.30,   -- chart brightness: 1 = as printed, 0.30 = dark, 0 = black. LOWER = DARKER
	logo_brightness = 0.85,  -- squadron badge on the MFD main menu: 1 = full, lower = dimmer
	logo_size = 1.50,        -- badge size on the main menu (screen units, about 2.2 wide)
	map_dim = 0,             -- optional extra black layer over the map (0..1, higher = darker)
	-- Mount the chart archives ourselves (harmless if DCS already did).
	mount_chart_archives = true,

	-- Waypoints: the route loaded in the jet (DTC / mission) is read from
	-- Export (LoGetRoute). Without the export feed the mission route is used.
	route_stale_after_s = 15,
	-- Flight plan / DTC menu: MFD-1 (DTC) opens it on the UFCP top line,
	-- MFD-3 / MFD-4 flip through MSN (the cartridge stored with your jet in
	-- the mission, else the mission route), your MiG-29 .dtc files for this
	-- map and OFF (no flight plan); MFD-1 (LOAD) loads it.
	-- The selected waypoint follows the MiG-29 NAV panel (WP-A/D 1-3) or the
	-- KRN STP selection, whichever you changed last.
	nav_ad_switch_value = 1,  -- NAV panel WP / A-D switch position that means A/D (0 or 1)
	nav_lamp_threshold  = 0.3,
	show_route   = true,

	-- Range scale steps cycled by MFD-4. Units: "km" or "nm".
	range_units  = "km",
	ranges_km    = {20, 40, 80, 160, 320},
	ranges_nm    = {10, 20, 40, 80, 160},
	default_range_index = 3,

	-- Where the ownship symbol sits on the screen and how far the
	-- selected range reaches (display units of the KRN MFD page:
	-- the screen is roughly x -1..+1, y -1.3..+1.0, their NAV page puts
	-- the aircraft at y = -0.8).
	ownship_y    = -0.15,   -- SIT style: aircraft in the middle of the range circle
	-- The DL page is the MFD's only page (the KRN menu / NAV page are never
	-- shown). false = old behaviour: MFD-4 "DL" on the KRN menu opens it.
	always_on    = true,
	start_page   = "MENU",   -- page shown when you get in: "MENU" or "DL"
	-- UFCP keypad (KRN button number = key). Change if the digits come out wrong.
	-- UFCP MRK (markpoint), DIR (was DVR: direct to) and NAV (was FLT/MENU: NAV page):
	-- clickabledata sends 6041 / 6043 / 6042, 6011 / 6012 / 6015 are the KRN
	-- commands of the same buttons (key bindings)
	ufcp_mrk_cmd = {6041, 6011},
	ufcp_dir_cmd = {6043, 6012},
	ufcp_nav_cmd = {6042, 6015},
	ufcp_keypad  = {[18] = "K1", [17] = "K2", [16] = "K3", [21] = "K4", [20] = "K5", [19] = "K6",
	                [24] = "K7", [23] = "K8", [22] = "K9", [26] = "K0", [25] = "CLR", [27] = "ENT"},
	default_tacan_channel = nil, -- e.g. 16 for Batumi (BTM)
	fuel_reserve_kg = 500,   -- FUEL page: time / range until this much fuel is left
	bingo_default_kg = 0,    -- FPAS bingo at start (0 = off; set it with MFD-1 + UFCP keypad)
	bingo_alert_s    = 8,    -- s the BINGO FUEL banner / UFCP "BINGO" stays up
	home_approach_kg = 150,  -- added to the fuel-to-home estimate for descent and approach
	rwr_radius       = 0.68,
	rwr_center_y     = 0.12,
	rwr_azimuth_sign = 1,    -- set to -1 if RWR emitters show on the wrong side
	rwr_swap_rear    = false, -- SPO-15 rear sectors: set true if rear threats show on the wrong side
	egt_warn       = 900,    -- ENG page: EGT shown red above this (deg C)
	hsi_cdi_full_m = 5000,   -- HSI: course deviation bar full scale (metres off course)
	expand_factor = 4,      -- MFD-8 EXP: zoom around the cursor
	-- DL cursor (MFD-1 CURS): moved with the jet's TDC (target acquisition symbol)
	cursor_speed    = 0.9,   -- page units per second at full TDC deflection
	cursor_deadzone = 0.08,
	cursor_invert_y = false, -- set true if the cursor moves the wrong way up/down
	cursor_rel_gain = 0.01,  -- for TDCs bound to the relative axes
	-- Bullseye readouts ("BE 045/32"): nil = same units as the range scale
	bullseye_units = nil,    -- or "nm" / "km"
	decenter_dy  = -0.65,   -- MFD-2 (DCTR): moves the aircraft this far down for a forward look
	range_radius =  0.88,   -- radius of the range circle (= selected range)

	-- Positions of the text lines (display units).
	text_top_y    =  1.15,
	text_bottom_y = -1.35,
	text_left_x   = -0.86,
	text_right_x  =  0.86,
	-- labels next to the left bezel buttons (page units; screen is about
	-- x -1.1..1.1, y -1.6..1.6). Move them if they don't line up with the buttons.
	symbol_size   = 0.045,   -- contact symbol radius (page units)
	line_width    = 0.007,   -- width of the range circle and symbol outlines
	course_line   = 0.07,    -- length of the course line on each contact
	show_mach     = true,    -- Mach number next to the altitude above each contact
	text_outline  = 0.006,   -- black outline around texts, only used when a map is shown
	font          = "font_arial_13",
	button_debounce_s = 0.35, -- presses of the same button closer than this count once
	-- page font: "texture" = thin monospaced cockpit font (Share Tech Mono), "dcs" = DCS's Arial
	-- display brightness 1..10 (brightness rocker top right; D/N switch bottom right)
	brightness_day   = 10,
	brightness_night = 4,
	font_style    = "texture",
	font_scale    = 1.25,    -- texture font size (1 = smaller, 1.5 = bigger)
	font_width    = 1.0,     -- texture font width (lower = narrower letters)
	btn_label_x   = -1.02,
	btn_label_size = 0.0036, -- text size of the side button labels (was 0.0044)
	-- label positions next to the bezel buttons (screen units, centre = 0),
	-- measured on cockpit screenshots (v1.6): the centre of each label line
	-- sits on its button
	btn_label_y   = {0.878, 0.448, 0.014, -0.462, -0.879},       -- left column, top to bottom
	btn_label_y_right = {0.877, 0.452, 0.035, -0.430, -0.832},  -- right column, top to bottom
	btn_row_x_bottom  = {-0.61, -0.285, 0.048, 0.370, 0.695},   -- bottom row, left to right
	btn_top_label_y   = 1.37,
	btn_row_x     = {-0.635, -0.307, 0.021, 0.351, 0.684},      -- top row, left to right
	btn8_label_y  = -1.25,   -- bottom row labels

	-- If the map turns the wrong way compared with the waypoints and the
	-- contacts (it should never move relative to them), set this to -1.
	map_rotation_sign = 1,
	-- Moving symbols are placed through controllers, which DCS does not scale
	-- with the MFD's SetCustomScale. nil = automatic (0.1 * MFD_SCALE = 0.045).
	-- Only touch these if symbols sit in the wrong place:
	--   everything that moves crowded on the ownship -> raise towards 1
	--   nothing that moves visible at all           -> lower
	move_gain = nil,
	line_gain = nil,     -- nil = same as move_gain (route legs, velocity leaders)

	-- How contact altitude is printed under the symbol:
	--  "km"  -> 7.5   (thousands of metres)      "kft" -> 25 (thousands of feet)
	alt_units = "km",

	-- Seconds without any datalink packet before the page shows "NO DL".
	stale_after_s = 8,

	-- Contacts are drawn moving along their last known track between
	-- updates (dead reckoning) for at most this many seconds.
	max_extrapolate_s = 20,

	-- v1.7 display power and start-up
	-- The MFD runs on the jet's DC power (battery / generator) and has its
	-- own POWER button: KRN's cog rocker top left (press = on, hold = off).
	-- Cold start: dark until there is power AND you press it, then the boot
	-- sequence (screen test, boot ROM, software, badge, BIT, cartridge).
	-- Hot / air start: already on.
	power_mode      = "jet",   -- "jet" = needs jet power + POWER button, "always" = always on (no boot)
	power_hold_s    = 2.0,     -- hold the POWER button this long to switch off
	power_blink_s   = 1.5,     -- power gaps shorter than this keep the page (no reboot)
	power_min_volt  = 15,      -- DC volts (cockpit voltmeter) that count as power
	boot_spawn_s    = 3.0,     -- powered within this many seconds of spawning = hot / air start (no boot)
	boot_skip       = false,   -- true = no boot sequence: straight to the MENU page
}


-- Symbol slots on the page (must match between page and device).
-- version shown on the start-up screens (one place for it)
DL_VERSION = "1.7.1"
-- built-in test lines on the start-up screen (order = dl_boot.lua bit_results)
DL_BIT_ROWS = {"POWER SUPPLY", "DISPLAY PROCESSOR", "SYMBOL GENERATOR", "NAV / POSITION", "CHART DATABASE",
               "DATALINK RECEIVER", "RWR INTERFACE", "STORES INTERFACE", "UFCP LINK", "DTC READER", "GCI / BULLSEYE"}

DL_MAX_CONTACTS = 40
DL_MAX_WPTS     = 40
DL_MAX_THREATS  = 16     -- ground threats shown (must match max_threats in MiG29DL_Export.lua)
DL_RING_SEGMENTS = 24    -- segments per threat ring
-- Geo drawings from a cartridge's .geo.txt (dl_geo.lua): line pieces per colour
-- (r = RING red, p = RING? pink, c = FLOT / AREA cyan, g = BORDER grey) and labels.
-- More pieces = more detail when many drawings are on the scope, but more to draw.
DL_GEO_POOLS  = {r = 72, p = 56, c = 150, g = 110}
DL_GEO_LABELS = 12
-- optional: DL_CFG.geo_line_width (0.004), geo_ring_segments (40),
-- geo_clip = {x min, x max, y min, y max} of the area drawings may use (page units)


-----------------------------------------------------------------------
-- Switches from DCS Options > Special > MIG-29AM ("MiG-29 WW MFD").
-- They are read when the mission loads; a change needs a mission restart.
--   mig29dl_datalink  datalink picture (SA contacts, friendlies, SAM rings, FLT)
--   mig29dl_rwr       RWR page
--   mig29dl_launch    missile launch warnings on the RWR
--   mig29dl_map       moving map (DCS charts) behind the SA page
-----------------------------------------------------------------------
do
	local DEF = {mig29dl_datalink = true, mig29dl_rwr = true, mig29dl_launch = true, mig29dl_map = false}
	local file_opts = nil
	local function from_file()
		if file_opts then return file_opts end
		file_opts = {}
		pcall(function()
			local lfs_mod = require("lfs")
			local f = loadfile(lfs_mod.writedir() .. "Config/options.lua")
			if not f then return end
			local env = {}
			setfenv(f, env)
			f()
			local p = env.options and env.options.plugins and env.options.plugins["mig_29am"]
			if type(p) == "table" then file_opts = p end
		end)
		return file_opts
	end
	local function opt(key)
		local v = nil
		if get_plugin_option_value then
			local ok, r = pcall(get_plugin_option_value, "mig_29am", key, "local")
			if ok and type(r) == "boolean" then v = r end
		end
		if v == nil then
			local r = from_file()[key]
			if type(r) == "boolean" then v = r end
		end
		if v == nil then v = DEF[key] end
		return v
	end
	DL_CFG.opt_datalink = opt("mig29dl_datalink")
	DL_CFG.opt_rwr      = opt("mig29dl_rwr")
	DL_CFG.opt_launch   = opt("mig29dl_launch")
	DL_CFG.opt_map      = opt("mig29dl_map")
	-- the moving map uses DCS's own charts for the theatre
	if DL_CFG.opt_map and (DL_CFG.map_source or "none") == "none" then DL_CFG.map_source = "dcs" end
	if not DL_CFG.opt_map then DL_CFG.map_source = "none" end
end
