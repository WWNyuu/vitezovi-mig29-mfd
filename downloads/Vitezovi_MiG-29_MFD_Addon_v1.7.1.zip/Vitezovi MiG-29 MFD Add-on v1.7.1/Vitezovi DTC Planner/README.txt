VITEZOVI DTC PLANNER
====================
Double-click "Vitezovi DTC Planner.html" to open it in your browser (Chrome or Edge).
Works offline. All map data is built into the file, so you can copy it to squadron mates as-is.

SAVE writes the .dtc (plus .geo.txt if you drew anything) to your Downloads folder.
Move them into:  Saved Games\DCS\DTC

DCS CHARTS layer: click it and pick your DCS map's RasterCharts folder
(e.g. D:\DCS World\Mods\terrains\Caucasus\RasterCharts). Read locally, nothing is uploaded.
