@echo off
setlocal
title Vitezovi MiG-29 MFD add-on - uninstall
echo.
echo  Removes the Vitezovi MiG-29 MFD add-on and puts KRN's original files back.
echo  KRN's mod itself stays installed. Close DCS before continuing.
echo.
pause
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\vitezovi_install.ps1" -Uninstall
echo.
pause
