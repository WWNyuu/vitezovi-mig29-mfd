@echo off
setlocal
title Vitezovi MiG-29 MFD add-on - install
echo.
echo  Vitezovi MiG-29 MFD add-on v1.7.1
echo  for "MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3"
echo.
echo  KRN's mod must be installed first (Saved Games\DCS\Mods\tech).
echo  Close DCS before continuing.
echo.
pause
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\vitezovi_install.ps1"
echo.
pause
