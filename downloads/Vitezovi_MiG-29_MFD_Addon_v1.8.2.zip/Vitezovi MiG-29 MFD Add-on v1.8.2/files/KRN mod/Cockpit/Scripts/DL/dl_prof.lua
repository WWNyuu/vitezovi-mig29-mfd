-----------------------------------------------------------------------
-- MiG-29 DL pages: timing log (v1.7.5 test build)
--
-- Off unless Saved Games\DCS\Vitezovi-MFD-Addon\settings.lua has
--     perf_log = true
-- Then every 30 s one block goes to Saved Games\DCS\Logs\mig29dl_perf.log:
-- how often update() ran, how long it took (average, worst, how many
-- calls took 1 ms or more), split by MFD page, and how much Lua memory
-- each call created (garbage the collector has to clean up later).
--
-- Timing: os.clock steps in 1 ms on Windows. A single call of ~0.05 ms
-- then reads 0 or 1 ms, but the AVERAGE over many calls is right (the
-- calls start at random points between two clock steps). Calls of 1 ms
-- or more are the ones that can make a frame late.
--
-- Nothing in here may stop the cockpit: every step is in a pcall, and
-- the wrapped update() runs exactly as before.
-----------------------------------------------------------------------
DL_PROF = DL_PROF or {}
local P = DL_PROF
P.version = "1.7.7"
local PERIOD = 30          -- seconds between two blocks
local MAX_BLOCKS = 480     -- 4 hours of blocks per cockpit, then it stops

local clock = (os and os.clock) or function() return 0 end
local function gc_kb()
	local ok, v = pcall(collectgarbage, "count")
	if ok and type(v) == "number" then return v end
	return nil
end

local MODE = {[0] = "MENU", [1] = "SA", [4] = "FPAS", [5] = "COMNAV", [6] = "DTC", [8] = "HSI",
	[9] = "FLT", [10] = "RWR", [11] = "SMS", [12] = "NAV", [13] = "RTE", [14] = "PIC",
	[15] = "EDIT", [16] = "SNAKE"}
-- sections of one full update (marks set by dl_device.lua)
local SEC = {"net", "boot", "scope", "pages"}

local function new_bucket()
	return {n = 0, sum = 0, max = 0, n1 = 0, n4 = 0, n16 = 0, asum = 0, an = 0, sec = {0, 0, 0, 0}, full = 0}
end

local st = nil
local function reset_period(now)
	st.p0 = now
	st.calls = 0
	st.b = {}
	st.mem_lo, st.mem_hi = nil, nil
end

local function log_path(name)
	local ok, l = pcall(require, "lfs")
	if not (ok and l and l.writedir) then return nil end
	return l.writedir() .. "Logs/" .. name
end

local function write_lines(lines)
	pcall(function()
		local path = log_path("mig29dl_perf.log")
		if not path then return end
		if not st.opened then
			st.opened = true
			-- the file of the cockpit before stays as .old.log
			local old = log_path("mig29dl_perf.old.log")
			pcall(os.remove, old)
			pcall(os.rename, path, old)
			local f = io.open(path, "w")
			if not f then return end
			f:write(table.concat(lines, "\n") .. "\n"); f:close()
			return
		end
		local f = io.open(path, "a")
		if f then f:write(table.concat(lines, "\n") .. "\n"); f:close() end
	end)
end

local function ms(v) return string.format("%.3f", v * 1000) end

local function report(now)
	local dt = now - st.p0
	if dt <= 0 then dt = PERIOD end
	st.blocks = st.blocks + 1
	local L = {}
	local mem = gc_kb()
	L[#L + 1] = string.format("%s  %.0f s  update %d calls (%.1f/s)  Lua memory %s KB (low %s, high %s)  clock step %s ms",
		os.date("%H:%M:%S"), dt, st.calls, st.calls / dt,
		mem and string.format("%.0f", mem) or "?",
		st.mem_lo and string.format("%.0f", st.mem_lo) or "?", st.mem_hi and string.format("%.0f", st.mem_hi) or "?",
		st.step and string.format("%.3f", st.step * 1000) or "?")
	-- pages in a fixed order: the busiest first
	local keys = {}
	for k in pairs(st.b) do keys[#keys + 1] = k end
	table.sort(keys, function(a, b) return st.b[a].sum > st.b[b].sum end)
	for _, k in ipairs(keys) do
		local b = st.b[k]
		local avg = b.sum / b.n
		local line = string.format("  %-7s %6d calls  avg %s ms  worst %s ms  >=1ms %d  >=4ms %d  >=16ms %d  alloc %s KB/call  %.2f%% of the time",
			k, b.n, ms(avg), ms(b.max), b.n1, b.n4, b.n16,
			(b.an > 0) and string.format("%.2f", b.asum / b.an) or "?", 100 * b.sum / dt)
		if b.full > 0 then
			local s = {}
			for i = 1, #SEC do s[#s + 1] = SEC[i] .. " " .. ms(b.sec[i] / b.full) end
			line = line .. "  [" .. table.concat(s, ", ") .. " ms]"
		end
		L[#L + 1] = line
	end
	if st.blocks == MAX_BLOCKS then L[#L + 1] = "(log full: " .. MAX_BLOCKS .. " blocks, nothing more is written for this cockpit)" end
	write_lines(L)
end

-- marks inside update(): the clock when section i ended
function P.mark(i)
	if st and st.in_call then st.m[i] = clock(); st.last = i end
end

function P.wrap(f, label)
	if type(f) ~= "function" then return f end
	st = {blocks = 0, m = {}, last = 0, step = nil, opened = false, in_call = false}
	local t0 = clock()
	reset_period(t0)
	write_lines({string.format("Vitezovi MiG-29 MFD timing log (%s, add-on %s)  %s", label or "device", tostring(DL_VERSION or "?"), os.date("%Y-%m-%d %H:%M:%S")),
		"  one block every " .. PERIOD .. " s; avg is per call; 'of the time' = share of one CPU core",
		"  sections: net = datalink packets in, boot = power / start-up, scope = SA scope and route, pages = the page shown"})
	P.on = true
	return function(...)
		if st.blocks >= MAX_BLOCKS then return f(...) end
		local m0 = gc_kb()
		st.in_call, st.last = true, 0
		local c0 = clock()
		st.c0 = c0
		local r = f(...)
		local c1 = clock()
		st.in_call = false
		local m1 = gc_kb()
		pcall(function()
			local d = c1 - c0
			if d > 0 and (not st.step or d < st.step) then st.step = d end
			-- which page: before the boot mark = off / starting, before the
			-- scope mark = nothing drawn (MFD off, or a text page between
			-- its updates)
			local k
			if st.last < 2 then k = "BOOT"
			elseif st.last < 3 then k = "WAIT"
			else
				local mo = DL_PAGES and DL_PAGES.mode
				k = MODE[mo] or ("PAGE" .. tostring(mo))
			end
			local b = st.b[k]
			if not b then b = new_bucket(); st.b[k] = b end
			b.n = b.n + 1
			b.sum = b.sum + d
			if d > b.max then b.max = d end
			if d >= 0.001 then b.n1 = b.n1 + 1 end
			if d >= 0.004 then b.n4 = b.n4 + 1 end
			if d >= 0.016 then b.n16 = b.n16 + 1 end
			if m0 and m1 and m1 >= m0 then b.asum = b.asum + (m1 - m0); b.an = b.an + 1 end
			if m1 then
				if not st.mem_lo or m1 < st.mem_lo then st.mem_lo = m1 end
				if not st.mem_hi or m1 > st.mem_hi then st.mem_hi = m1 end
			end
			if st.last >= 3 then
				local m = st.m
				b.full = b.full + 1
				b.sec[1] = b.sec[1] + ((m[1] or c0) - c0)
				b.sec[2] = b.sec[2] + ((m[2] or c0) - (m[1] or c0))
				b.sec[3] = b.sec[3] + ((m[3] or c1) - (m[2] or c0))
				b.sec[4] = b.sec[4] + (c1 - (m[3] or c1))
			end
			st.m[1], st.m[2], st.m[3] = nil, nil, nil
			st.calls = st.calls + 1
			if c1 - st.p0 >= PERIOD then
				report(c1)
				reset_period(c1)
			end
		end)
		return r
	end
end
