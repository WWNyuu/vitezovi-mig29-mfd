-----------------------------------------------------------------------
-- MiG-29 DL page: textures (loaded from materials.lua)
--
-- Works out which theatre is loaded and registers DCS's own raster
-- aeronautical charts for it (Mods\terrains\<theatre>\RasterCharts) as
-- cockpit textures "DLT_<n>". The chart archives are also mounted into the
-- texture file system in case the terrain has not done so itself.
-- Nothing is copied: the textures are read straight from your DCS install.
-----------------------------------------------------------------------

dofile(LockOn_Options.script_path .. "DL/dl_config.lua")
dofile(LockOn_Options.script_path .. "DL/dl_theatres.lua")

materials["DL_MAP_WHITE"] = {255, 255, 255, 255}
-- the chart is tinted (multiplied) by this colour: map_brightness 1 = as printed
local b = DL_CFG.map_brightness or 0.30
if b < 0 then b = 0 elseif b > 1 then b = 1 end
local g = math.floor(255 * b + 0.5)
materials["DL_MAP_TINT"] = {g, g, g, 255}

-- squadron badge for the MFD main menu (tinted by logo_brightness)
do
	local lb = DL_CFG.logo_brightness or 1.0
	if lb < 0 then lb = 0 elseif lb > 1 then lb = 1 end
	local lg = math.floor(255 * lb + 0.5)
	materials["DL_LOGO_TINT"] = {lg, lg, lg, 255}
	textures["MIG29_DL_LOGO"] = {IND_TEX_PATH .. "mig29_dl_logo.dds", materials["DL_LOGO_TINT"]}
end

local src = DL_CFG.map_source or "none"
if src == "dcs" then
	local theatre = DL_detect_theatre()
	local chart = DL_load_chart(theatre)
	if chart then
		-- mount the chart archives (absolute path from the DCS folder when we can get it)
		local root = ""
		local ok_lfs, lfs_mod = pcall(require, "lfs")
		if ok_lfs and lfs_mod and lfs_mod.currentdir then
			root = lfs_mod.currentdir()
			if root:sub(-1) ~= "/" and root:sub(-1) ~= "\\" then root = root .. "/" end
			-- DCS normally runs from its install folder; if we are in bin/ step up
			if root:lower():match("[/\\]bin[/\\]$") or root:lower():match("[/\\]bin%-mt[/\\]$") then
				root = root:gsub("[^/\\]+[/\\]$", "")
			end
		end
		if mount_vfs_texture_path and DL_CFG.mount_chart_archives ~= false then
			for _, z in ipairs(chart.zips) do
				pcall(mount_vfs_texture_path, root .. z)
			end
		end
		-- v1.7.8: textures built by INSTALL are files in DL/charts_gen/<theatre>/
		local dir = chart.gen and (LockOn_Options.script_path .. chart.dir) or ""
		for i, t in ipairs(chart.tiles) do
			textures["DLT_" .. i] = {dir .. t[1], materials["DL_MAP_TINT"]}
		end
	end
end
