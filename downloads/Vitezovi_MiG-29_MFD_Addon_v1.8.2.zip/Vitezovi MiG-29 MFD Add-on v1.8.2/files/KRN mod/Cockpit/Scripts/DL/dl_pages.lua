-----------------------------------------------------------------------
-- MiG-29 DL add-on: MFD pages (indicator elements)
-- Loaded from the end of dl_page.lua, which shares its drawing helpers in
-- DLH. One root per page, shown while DL_MODE has that page's number:
--   0 MENU  4 FPAS  5 COM/NAV  6 PLAN (+ DTC)  8 HSI  9 FLT  10 RWR  11 SMS  12 NAV  13 RTE  14 PICTURE
--   15 EDIT (route editor, v1.7.3)  16 SNAKE (easter egg, v1.7.4)
-- (1 is the DL situation page in dl_page.lua). Values: dl_pages_dev.lua.
-----------------------------------------------------------------------
do
	local D = DLH
	local text, text1, mesh, simple = D.text, D.text1, D.mesh, D.simple
	local M, F, TXT, TXS, G, LW, CFG = D.M, D.F, D.TXT, D.TXT_SMALL, D.G, D.LW, D.CFG
	local BX, BY, BYR = D.BX, D.BY, D.BYR       -- left / right button rows
	local RX = -BX
	local ROW = D.ROWB                          -- bottom row x
	local ROWT = D.ROWT                         -- top row x
	local YB = D.YB8                            -- bottom row labels
	local YT = D.YT8                            -- top row labels
	local TXL = {0.0060, 0.0018, 0, -0.0022}     -- large
	local TXT_T = {0.0028, 0.00085, 0, -0.0010}  -- tiny (lists)
	local LX = -0.80                            -- left edge of page text
	-- side button labels on these pages: smaller than on the SA page
	local SBS = CFG.sub_btn_label_scale or 0.72
	local TXT_SB = {D.TXT_BTN[1] * SBS, D.TXT_BTN[2] * SBS, D.TXT_BTN[3] * SBS, D.TXT_BTN[4] * SBS}
	-- with the smaller labels the rows sat a little off the buttons (measured
	-- in the cockpit): left labels up, right labels down
	-- (per row, top to bottom; + = up)
	-- (v1.6: the base rows in dl_config are measured on the buttons; these
	-- per-row nudges are 0 unless set in dl_config)
	local DYL = CFG.sub_btn_dy_left or {0, 0, 0, 0, 0}
	local DYR = CFG.sub_btn_dy_right or {0, 0, 0, 0, 0}
	local BYS, BYRS = {}, {}
	for k = 1, 5 do
		BYS[k]  = BY[k] + (DYL[k] or 0)
		BYRS[k] = BYR[k] + (DYR[k] or 0)
	end

	local function root(name, mode)
		simple(name, nil, {0, 0, 0}, {"DL_PAGE", "DL_MODE"},
			{{"parameter_in_range", 0, 0.5, 2.5}, {"parameter_in_range", 1, mode - 0.1, mode + 0.1}})
		mesh(name .. "_bg", name, "triangles", {{-1.1, 1.6}, {1.1, 1.6}, {1.1, -1.6}, {-1.1, -1.6}}, {0, 1, 2, 0, 2, 3}, M.black)
	end
	local function lbl_left(r, k, s, f) text(r .. "_l" .. k, r, {BX, BYS[k], 0}, f or F.white, TXT_SB, "LeftCenter", s) end
	local function lbl_right(r, k, s, f) text(r .. "_r" .. k, r, {RX, BYRS[k], 0}, f or F.white, TXT_SB, "RightCenter", s) end
	local function menu_btn(r) text(r .. "_menu", r, {ROW[3], YB, 0}, F.white, TXS, "CenterCenter", "MENU") end
	-- Eurofighter-style framing: thin outlined boxes around titles and headers
	local function cw(defs) return (D.char_w and D.TEXF) and D.char_w(defs) or 0.062 end
	local function box(r, n, cx, cy, w, h, mat)
		local t = LW
		local x0, x1, y0, y1 = cx - w / 2, cx + w / 2, cy - h / 2, cy + h / 2
		local v = {{x0, y1}, {x1, y1}, {x1, y1 - t}, {x0, y1 - t},  {x0, y0 + t}, {x1, y0 + t}, {x1, y0}, {x0, y0},
		           {x0, y1}, {x0 + t, y1}, {x0 + t, y0}, {x0, y0},  {x1 - t, y1}, {x1, y1}, {x1, y0}, {x1 - t, y0}}
		local idx = {}
		for q = 0, 3 do local b = q * 4; for _, k in ipairs({0, 1, 2, 0, 2, 3}) do idx[#idx + 1] = b + k end end
		mesh(r .. "_" .. n, r, "triangles", v, idx, mat or M.white)
	end
	-- text in a box; align "LeftCenter" (x = left edge of the box) or "CenterCenter"
	local function boxed(r, n, x, y, s, f, defs, mat, align)
		defs = defs or TXS
		local w = #s * cw(defs) + 0.07
		local cx = (align == "LeftCenter") and (x + w / 2) or x
		text(r .. "_" .. n, r, {cx, y, 0}, f or F.white, defs, "CenterCenter", s)
		box(r, n .. "_box", cx, y, w, defs[1] / G * 1.0 + 0.035, mat)
	end
	local function title(r, s) boxed(r, "title", 0, 1.22, s, F.white, TXT, M.white) end
	local function line(r, n, x, y, param, f, defs, align, vis)
		return text1(r .. "_" .. n, r, {x, y, 0}, f or F.white, defs or TXS, align or "LeftCenter", nil, param, vis)
	end
	-- a parameter text shown with its own format (fmt, e.g. "%.0f" for a
	-- number). text1 always uses "%s" and adds the element at once, and DCS
	-- takes the element as it is when it is added, so changing e.formats
	-- afterwards does nothing: the format has to be set before Add. Font,
	-- size, alignment and position are copied from "like", a text1 element
	-- made the same way (text1's size table is private to dl_page.lua).
	local function num_text(like, name, parent, param, vis, fmt)
		local e = CreateElement "ceStringPoly"
		e.name            = name
		e.material        = like.material
		e.init_pos        = {like.init_pos[1], like.init_pos[2], like.init_pos[3]}
		e.alignment       = like.alignment
		e.stringdefs      = like.stringdefs
		e.parent_element  = parent
		e.h_clip_relation = like.h_clip_relation
		e.level           = like.level
		e.formats         = {fmt}
		local params, ctrls = {param}, {{"text_using_parameter", 0}}
		if vis then
			params[2] = vis[1]
			ctrls[2] = {"parameter_in_range", 1, vis[2], vis[3]}
		end
		e.element_params = params
		e.controllers    = ctrls
		Add(e)
		return e
	end
	local function hline(r, n, y, x0, x1)
		x0, x1 = x0 or -0.8, x1 or 0.8
		mesh(r .. "_" .. n, r, "triangles", {{x0, y + LW / 2}, {x1, y + LW / 2}, {x1, y - LW / 2}, {x0, y - LW / 2}}, {0, 1, 2, 0, 2, 3}, M.blue)
	end

	-------------------------------------------------------------------
	-- 0 MENU
	-------------------------------------------------------------------
	root("dlp_menu", 0)
	boxed("dlp_menu", "t1", 0, 1.13, "MIG-29 WW", F.white, TXL, M.white)
	text("dlp_menu_t2", "dlp_menu", {0, 0.96, 0}, F.amber, TXS, "CenterCenter", "UPGRADE PROGRAM")
	-- squadron badge (127th Vitezovi FAS "Wild Wolves"), green MFD rendition
	do
		local half = (CFG.logo_size or 1.5) / 2
		local cy = CFG.logo_center_y or -0.02
		local e = CreateElement "ceTexPoly"
		e.name            = "dlp_menu_logo"
		e.primitivetype   = "triangles"
		e.vertices        = {{-half, cy + half}, {half, cy + half}, {half, cy - half}, {-half, cy - half}}
		e.indices         = {0, 1, 2, 0, 2, 3}
		e.tex_coords      = {{0, 0}, {1, 0}, {1, 1}, {0, 1}}
		e.material        = "MIG29_DL_LOGO"
		e.init_pos        = {0, 0, 0}
		e.parent_element  = "dlp_menu"
		e.h_clip_relation = D.CLIP
		e.level           = D.LVL
		Add(e)
	end
	text1("dlp_menu_stat", "dlp_menu", {0, -1.18, 0}, F.white, TXS, "CenterCenter", nil, "DLP_MENU_STAT")
	-- left: navigation, right: aircraft / combat (4 + 4)
	lbl_left("dlp_menu", 1, "SA"); lbl_left("dlp_menu", 2, "NAV"); lbl_left("dlp_menu", 3, "HSI"); lbl_left("dlp_menu", 4, "COM/NAV")
	lbl_right("dlp_menu", 1, "FPAS"); lbl_right("dlp_menu", 2, "SMS"); lbl_right("dlp_menu", 3, "FLT")
	local RWR_ON = CFG.opt_rwr ~= false                    -- DCS Options > Special
	local LAUNCH_ON = RWR_ON and CFG.opt_launch ~= false
	if RWR_ON then lbl_right("dlp_menu", 4, "RWR") end

	-------------------------------------------------------------------
	-- 6 PLAN: the flight plan (view 0) and the data cartridges (view 1,
	-- left 1 LOAD). DLP_PLAN_VIEW picks the view.
	-------------------------------------------------------------------
	local function sub(name, parent, param, lo, hi)
		simple(name, parent, {0, 0, 0}, {param}, {{"parameter_in_range", 0, lo, hi}})
	end
	root("dlp_fpl", 6)
	sub("dlp_fplv", "dlp_fpl", "DLP_PLAN_VIEW", -0.5, 0.5)
	sub("dlp_dtc", "dlp_fpl", "DLP_PLAN_VIEW", 0.5, 1.5)
	-- route view
	title("dlp_fplv", "FLIGHT PLAN")
	line("dlp_fplv", "src", 0, 1.08, "DLP_FPL_SRC", F.grey, TXS, "CenterCenter")
	text("dlp_fplv_hd", "dlp_fplv", {LX, 0.92, 0}, F.blue, TXT_T, "LeftCenter", "PT  NAME          ETA         FUEL")
	for i = 1, 10 do
		local y = 0.80 - (i - 1) * 0.12
		line("dlp_fplv", "w" .. i, LX, y, "DLP_FPL_L" .. i, F.white, TXS, "LeftCenter", {"DLP_FPL_A" .. i, 0.5, 1.5})
		line("dlp_fplv", "wy" .. i, LX, y, "DLP_FPL_L" .. i, F.amber, TXS, "LeftCenter", {"DLP_FPL_A" .. i, 1.5, 2.5})
		line("dlp_fplv", "wc" .. i, LX, y, "DLP_FPL_L" .. i, F.cyan, TXS, "LeftCenter", {"DLP_FPL_A" .. i, 2.5, 3.5})
		line("dlp_fplv", "wg" .. i, LX, y, "DLP_FPL_L" .. i, F.grey, TXS, "LeftCenter", {"DLP_FPL_A" .. i, 3.5, 4.5})
		-- DLP_FPL_T: 1 = has a TOT, 2 = PT cursor, 3 = both
		text("dlp_fplv_tot" .. i, "dlp_fplv", {0.66, y, 0}, F.red, TXT_T, "LeftCenter", "TOT", nil, {"DLP_FPL_T" .. i, 0.5, 1.5})
		text("dlp_fplv_totc" .. i, "dlp_fplv", {0.66, y, 0}, F.red, TXT_T, "LeftCenter", "TOT", nil, {"DLP_FPL_T" .. i, 2.5, 3.5})
		text("dlp_fplv_cur" .. i, "dlp_fplv", {0.86, y, 0}, F.white, TXS, "LeftCenter", "<", nil, {"DLP_FPL_T" .. i, 1.5, 3.5})
	end
	-------------------------------------------------------------------
	-- time on target: TOT line, required / ground speed, speed cue
	-- (box = speed for the TOT, caret = ground speed), fuel at the TOT
	-- point and at the last steerpoint. Hint / keypad entry when no TOT.
	-------------------------------------------------------------------
	local function tot_block(PR, DY)
		hline(PR, "tsep", (-0.38 + DY), -0.85, 0.85)
		line(PR, "thint", LX, (-0.46 + DY), "DLP_TOT_HINT", F.grey, TXS, "LeftCenter", {"DLP_TOT_ON", -0.5, 0.5})
		sub("dlp_tot", PR, "DLP_TOT_ON", 0.5, 1.5)
		line("dlp_tot", "l1", LX, (-0.46 + DY), "DLP_TOT_L1", F.red, TXS)
		for c, f in ipairs({F.green, F.amber, F.red}) do
			line("dlp_tot", "st" .. c, -LX, (-0.46 + DY), "DLP_TOT_ST", f, TXS, "RightCenter", {"DLP_TOT_C", c - 0.5, c + 0.5})
		end
		line("dlp_tot", "spd", LX, (-0.57 + DY), "DLP_TOT_SPD", F.white, TXS)
		do
			local x0, x1, yb = -0.70, 0.70, (-0.76 + DY)
			mesh("dlp_tot_scale", "dlp_tot", "triangles", {{x0, yb + LW / 2}, {x1, yb + LW / 2}, {x1, yb - LW / 2}, {x0, yb - LW / 2}}, {0, 1, 2, 0, 2, 3}, M.white)
			local tv, ti = {}, {}
			for k = 0, 8 do
				local x = x0 + (x1 - x0) * k / 8
				local h = (k % 2 == 0) and 0.045 or 0.025
				local b = #tv
				tv[b + 1] = {x - LW / 2, yb}; tv[b + 2] = {x + LW / 2, yb}; tv[b + 3] = {x + LW / 2, yb + h}; tv[b + 4] = {x - LW / 2, yb + h}
				for _, q in ipairs({0, 1, 2, 0, 2, 3}) do ti[#ti + 1] = b + q end
			end
			mesh("dlp_tot_ticks", "dlp_tot", "triangles", tv, ti, M.white)
			text("dlp_tot_slow", "dlp_tot", {x0, (-0.66 + DY), 0}, F.grey, TXT_T, "LeftCenter", "SLOW")
			text("dlp_tot_fast", "dlp_tot", {x1, (-0.66 + DY), 0}, F.grey, TXT_T, "RightCenter", "FAST")
			-- required speed: green box above the scale
			simple("dlp_tot_req", "dlp_tot", {0, 0, 0}, {"DLP_TOT_RX", "DLP_TOT_RV"}, {{"move_left_right_using_parameter", 0, G}, {"parameter_in_range", 1, 0.5, 1.5}})
			box("dlp_tot_req", "box", 0, yb + 0.055, 0.05, 0.07, M.friend or M.white)
			-- ground speed: cyan caret under the scale
			simple("dlp_tot_gs", "dlp_tot", {0, 0, 0}, {"DLP_TOT_GX", "DLP_TOT_GV"}, {{"move_left_right_using_parameter", 0, G}, {"parameter_in_range", 1, 0.5, 1.5}})
			mesh("dlp_tot_caret", "dlp_tot_gs", "triangles", {{0, yb - 0.01}, {0.035, yb - 0.075}, {-0.035, yb - 0.075}}, {0, 1, 2}, M.own)
		end
		line("dlp_tot", "then", LX, (-0.91 + DY), "DLP_TOT_THEN", F.white, TXS)
		line("dlp_tot", "fuel", LX, (-1.01 + DY), "DLP_TOT_FUEL", F.white, TXS, "LeftCenter", {"DLP_TOT_FC", 0.5, 1.5})
		line("dlp_tot", "fuela", LX, (-1.01 + DY), "DLP_TOT_FUEL", F.amber, TXS, "LeftCenter", {"DLP_TOT_FC", 1.5, 2.5})
	end
	lbl_left("dlp_fplv", 1, "LOAD"); lbl_left("dlp_fplv", 2, "TOT"); lbl_left("dlp_fplv", 3, "PT"); lbl_left("dlp_fplv", 4, "CLR")
	-- cartridge view: R1-R5 load (then back to the route), B1/B2 page
	line("dlp_dtc", "title", 0, 1.22, "DLP_DTC_TITLE", F.white, TXS, "CenterCenter")
	hline("dlp_dtc", "tl", 1.14, -0.85, 0.85)
	for k = 1, 5 do
		line("dlp_dtc", "i" .. k, RX - 0.1, BYRS[k], "DLP_DTC_I" .. k, F.white, TXS, "RightCenter", {"DLP_DTC_M" .. k, 0.5, 1.5})
		line("dlp_dtc", "iy" .. k, RX - 0.1, BYRS[k], "DLP_DTC_I" .. k, F.amber, TXS, "RightCenter", {"DLP_DTC_M" .. k, 1.5, 2.5})
		text("dlp_dtc_ar" .. k, "dlp_dtc", {RX, BYRS[k], 0}, F.white, TXS, "RightCenter", "<", nil, {"DLP_DTC_M" .. k, 0.5, 2.5})
	end
	hline("dlp_dtc", "bl", -0.84, -0.85, 0.85)
	for i = 1, 3 do line("dlp_dtc", "d" .. i, LX, -0.91 - (i - 1) * 0.09, "DLP_DTC_D" .. i, (i == 1) and F.amber or F.white) end
	line("dlp_dtc", "pg", (ROW[4] + ROW[5]) / 2, YB, "DLP_DTC_PAGE", F.grey, TXS, "CenterCenter")
	text("dlp_dtc_b1", "dlp_dtc", {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "PREV")
	text("dlp_dtc_b2", "dlp_dtc", {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "NEXT")
	lbl_left("dlp_dtc", 1, "BACK"); lbl_left("dlp_dtc", 2, "RFSH")
	menu_btn("dlp_fpl")

	-------------------------------------------------------------------
	-- 4 FPAS: fuel (like the Hornet's FPAS), bingo / home, engines
	-------------------------------------------------------------------
	root("dlp_fuel", 4)
	title("dlp_fuel", "FPAS")
	do
		local FX = -0.62                      -- clear of the BINGO / HOME labels
		local y = 1.02
		local function L(n, param, f, d, vis) line("dlp_fuel", n, FX, y, param, f, d, nil, vis); y = y - 0.10 end
		local function H(n, s) y = y - 0.02; boxed("dlp_fuel", n, FX, y, s, F.amber, TXS, M.amber, "LeftCenter"); hline("dlp_fuel", n .. "_hl", y, FX + #s * cw(TXS) + 0.1, 0.84); y = y - 0.13 end
		L("tot", "DLP_FUEL_TOT", F.white, TXL); y = y - 0.03
		L("int", "DLP_FUEL_INT", F.grey)
		L("flow", "DLP_FUEL_FLOW", F.white)
		H("cur", "CURRENT")
		L("to", "DLP_FUEL_TO", F.amber)
		L("torng", "DLP_FUEL_TO_RNG", F.white)
		L("sr", "DLP_FUEL_SR", F.white)
		H("best", "BEST RANGE   (ESTIMATE)")
		L("b1", "DLP_FUEL_B1", F.white)
		L("b2", "DLP_FUEL_B2", F.white)
		L("b4", "DLP_FUEL_B4", F.grey)
		H("end", "BEST ENDURANCE")
		L("b3", "DLP_FUEL_B3", F.white)
		L("res", "DLP_FUEL_RES", F.grey)
		H("bngh", "BINGO / HOME")
		line("dlp_fuel", "bngr", FX, y, "DLP_FUEL_BNG", F.red, TXS, nil, {"DLP_BINGO_WARN", 0.5, 1.5})
		L("bng", "DLP_FUEL_BNG", F.white, nil, {"DLP_BINGO_WARN", -0.5, 0.5})
		L("home", "DLP_FUEL_HOME", F.white)
		L("need", "DLP_FUEL_NEED", F.white)
		L("harr", "DLP_FUEL_HARR", F.grey)
	end
	-- engines, top right next to the fuel total: what the sim gives on this jet
	-- (RPM, EGT left / right); EGT red when it is over egt_warn
	line("dlp_fuel", "rpm", 0.84, 1.03, "DLP_FUEL_ENG", F.white, TXS, "RightCenter")
	line("dlp_fuel", "egt", 0.84, 0.93, "DLP_FUEL_EGT", F.white, TXS, "RightCenter", {"DLP_FUEL_EGTW", -0.5, 0.5})
	line("dlp_fuel", "egtr", 0.84, 0.93, "DLP_FUEL_EGT", F.red, TXS, "RightCenter", {"DLP_FUEL_EGTW", 0.5, 1.5})
	lbl_left("dlp_fuel", 1, "BINGO"); lbl_left("dlp_fuel", 2, "HOME")
	menu_btn("dlp_fuel")

	-------------------------------------------------------------------
	-- 5 COM / NAV: R-862 and its presets, RSBN / ILS / ADF / GCI channels,
	-- the nearest RSBN / PRMG stations (all read from the jet's own knobs)
	-------------------------------------------------------------------
	root("dlp_rdo", 5)
	title("dlp_rdo", "COM / NAV")
	line("dlp_rdo", "freq", 0, 1.08, "DLP_RDO_FREQ", F.amber, TXS, "CenterCenter")
	line("dlp_rdo", "src", 0, 0.99, "DLP_RDO_SRC", F.grey, TXT_T, "CenterCenter")
	hline("dlp_rdo", "sep", 0.92)
	for i = 1, 20 do
		local x = (i <= 10) and -0.72 or 0.06
		local y = 0.84 - ((i - 1) % 10) * 0.088
		line("dlp_rdo", "c" .. i, x, y, "DLP_RDO_C" .. i, F.white, TXS, "LeftCenter", {"DLP_RDO_S" .. i, -0.5, 0.5})
		line("dlp_rdo", "cy" .. i, x, y, "DLP_RDO_C" .. i, F.amber, TXS, "LeftCenter", {"DLP_RDO_S" .. i, 0.5, 1.5})
	end
	hline("dlp_rdo", "sep2", -0.03)
	line("dlp_rdo", "rsbn", LX, -0.12, "DLP_RSBN_SEL", F.amber, TXS)
	line("dlp_rdo", "ils", LX, -0.22, "DLP_RSBN_ILS", F.amber, TXS)
	line("dlp_rdo", "adf", LX, -0.32, "DLP_RDO_ADF", F.white, TXS)
	line("dlp_rdo", "kru", LX, -0.42, "DLP_RDO_KRU", F.white, TXS)
	hline("dlp_rdo", "sep3", -0.50)
	text("dlp_rdo_hd", "dlp_rdo", {LX, -0.58, 0}, F.blue, TXT_T, "LeftCenter", "NEAREST  CH ID  STATION       BRG DIST")
	for i = 1, 5 do
		local y = -0.68 - (i - 1) * 0.095
		line("dlp_rdo", "r" .. i, LX, y, "DLP_RSBN_L" .. i, F.white, TXT_T, "LeftCenter", {"DLP_RSBN_A" .. i, 0.5, 1.5})
		line("dlp_rdo", "ry" .. i, LX, y, "DLP_RSBN_L" .. i, F.amber, TXT_T, "LeftCenter", {"DLP_RSBN_A" .. i, 1.5, 2.5})
	end
	menu_btn("dlp_rdo")

	-------------------------------------------------------------------
	-- 8 HSI (NATO style): rose, heading bug, course + deviation bar,
	-- pointer 1 = steerpoint (green), pointer 2 = TACAN (yellow)
	-------------------------------------------------------------------
	root("dlp_hsi", 8)
	do
		local CY = CFG.hsi_center_y or -0.05
		local R = CFG.hsi_radius or 0.74
		simple("dlp_hsi_c", "dlp_hsi", {0, CY, 0})
		-- rose: ring and ticks, turned with heading
		local v, i = D.circle_ring(R, LW, 96)
		mesh("dlp_hsi_ring", "dlp_hsi_c", "triangles", v, i, M.white)
		simple("dlp_hsi_rot", "dlp_hsi_c", {0, 0, 0}, {"DLP_HSI_ROT"}, {{"rotate_using_parameter", 0, 1}})
		do
			local tv, ti = {}, {}
			for deg = 0, 355, 5 do
				local len = (deg % 30 == 0) and 0.09 or ((deg % 10 == 0) and 0.06 or 0.035)
				local a = math.rad(90 - deg)
				local ca, sa = math.cos(a), math.sin(a)
				local px, py = -sa * LW / 2, ca * LW / 2
				local r0, r1 = R - len, R
				local k = #tv
				tv[k + 1] = {r0 * ca + px, r0 * sa + py}; tv[k + 2] = {r1 * ca + px, r1 * sa + py}
				tv[k + 3] = {r1 * ca - px, r1 * sa - py}; tv[k + 4] = {r0 * ca - px, r0 * sa - py}
				ti[#ti + 1] = k; ti[#ti + 1] = k + 1; ti[#ti + 1] = k + 2
				ti[#ti + 1] = k; ti[#ti + 1] = k + 2; ti[#ti + 1] = k + 3
			end
			mesh("dlp_hsi_ticks", "dlp_hsi_rot", "triangles", tv, ti, M.white)
		end
		local names = {"N", "3", "6", "E", "12", "15", "S", "21", "24", "W", "30", "33"}
		for k = 0, 11 do
			simple("dlp_hsi_lb" .. k, "dlp_hsi_c", {0, 0, 0}, {"DLP_HSI_L" .. k .. "_X", "DLP_HSI_L" .. k .. "_Y"},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})
			text("dlp_hsi_lt" .. k, "dlp_hsi_lb" .. k, {0, 0, 0}, (k % 3 == 0) and F.white or F.grey, TXS, "CenterCenter", names[k + 1])
		end
		-- lubber line, heading box, aircraft
		mesh("dlp_hsi_lub", "dlp_hsi_c", "triangles", {{-0.03, R + 0.06}, {0.03, R + 0.06}, {0, R + 0.005}}, {0, 1, 2}, M.white)
		line("dlp_hsi", "hdg", 0, CY + R + 0.15, "DLP_HSI_HDG", F.white, TXT, "CenterCenter")
		do
			local av, ai = D.poly_lines({{0, 0.09}, {0.012, 0.03}, {0.07, 0.0}, {0.07, -0.014}, {0.01, -0.005},
				{0.008, -0.05}, {0.03, -0.065}, {0, -0.06}, {-0.03, -0.065}, {-0.008, -0.05},
				{-0.01, -0.005}, {-0.07, -0.014}, {-0.07, 0.0}, {-0.012, 0.03}})
			mesh("dlp_hsi_ac", "dlp_hsi_c", "lines", av, ai, M.own)
		end
		-- heading bug (yellow notch on the rose)
		simple("dlp_hsi_bug", "dlp_hsi_c", {0, 0, 0}, {"DLP_HSI_BUGR"}, {{"rotate_using_parameter", 0, 1}})
		mesh("dlp_hsi_bugm", "dlp_hsi_bug", "triangles",
			{{-0.05, R + 0.01}, {-0.02, R + 0.01}, {-0.02, R - 0.04}, {0.02, R - 0.04}, {0.02, R + 0.01}, {0.05, R + 0.01}, {0.05, R - 0.07}, {-0.05, R - 0.07}},
			{0, 1, 7, 1, 2, 7, 2, 6, 7, 2, 3, 6, 3, 5, 6, 3, 4, 5}, M.unknown)
		-- course arrow with the deviation bar
		simple("dlp_hsi_crs", "dlp_hsi_c", {0, 0, 0}, {"DLP_HSI_CRSR"}, {{"rotate_using_parameter", 0, 1}})
		local w = LW * 1.4
		local function rect(n, par, x0, y0, x1, y1, mat, params, ctrls)
			mesh(n, par, "triangles", {{x0, y1}, {x1, y1}, {x1, y0}, {x0, y0}}, {0, 1, 2, 0, 2, 3}, mat, nil, params, ctrls)
		end
		rect("dlp_hsi_crs_h", "dlp_hsi_crs", -w, 0.36, w, R - 0.12, M.wing)
		mesh("dlp_hsi_crs_a", "dlp_hsi_crs", "triangles", {{0, R - 0.04}, {0.05, R - 0.13}, {-0.05, R - 0.13}}, {0, 1, 2}, M.wing)
		rect("dlp_hsi_crs_t", "dlp_hsi_crs", -w, -(R - 0.12), w, -0.36, M.wing)
		for _, dx in ipairs({-0.30, -0.15, 0.15, 0.30}) do
			local dv, di = D.circle_ring(0.018, LW, 12)
			for _, p in ipairs(dv) do p[1] = p[1] + dx end
			mesh("dlp_hsi_dot" .. tostring(dx), "dlp_hsi_crs", "triangles", dv, di, M.white)
		end
		simple("dlp_hsi_cdi", "dlp_hsi_crs", {0, 0, 0}, {"DLP_HSI_CDI"}, {{"move_left_right_using_parameter", 0, G * 0.30}})
		rect("dlp_hsi_cdib", "dlp_hsi_cdi", -w, -0.33, w, 0.33, M.wing)
		-- bearing pointers
		local function pointer(n, rot, vis, mat, double)
			simple(n, "dlp_hsi_c", {0, 0, 0}, {rot, vis},
				{{"rotate_using_parameter", 0, 1}, {"parameter_in_range", 1, 0.5, 1.5}})
			local off = double and {-0.025, 0.025} or {0}
			for j, ox in ipairs(off) do
				rect(n .. "_h" .. j, n, ox - LW / 2, R - 0.30, ox + LW / 2, R - 0.06, mat)
				rect(n .. "_t" .. j, n, ox - LW / 2, -(R - 0.06), ox + LW / 2, -(R - 0.25), mat)
			end
			mesh(n .. "_a", n, "triangles", {{0, R - 0.02}, {0.05, R - 0.10}, {-0.05, R - 0.10}}, {0, 1, 2}, mat)
		end
		pointer("dlp_hsi_p1", "DLP_HSI_B1R", "DLP_HSI_B1V", M.friend, false)
		pointer("dlp_hsi_p2", "DLP_HSI_B2R", "DLP_HSI_B2V", M.unknown, true)
		-- readouts
		line("dlp_hsi", "stp1", LX, 1.2, "DLP_HSI_STP1", F.green, TXS)
		line("dlp_hsi", "stp2", LX, 1.1, "DLP_HSI_STP2", F.green, TXS)
		line("dlp_hsi", "tcn1", -LX, 1.2, "DLP_HSI_TCN1", F.amber, TXS, "RightCenter")
		line("dlp_hsi", "tcn2", -LX, 1.1, "DLP_HSI_TCN2", F.amber, TXS, "RightCenter")
		-- v1.7.6: heading bug / course readouts moved up under the TACAN lines
		-- (the space under the rose holds the next waypoints now)
		line("dlp_hsi", "bugt", -LX, 0.98, "DLP_HSI_BUG", F.amber, TXS, "RightCenter")
		line("dlp_hsi", "crst", -LX, 0.88, "DLP_HSI_CRS", F.cyan, TXS, "RightCenter")
		line("dlp_hsi", "entry", LX, -1.07, "DLP_HSI_ENTRY", F.amber, TXT, "LeftCenter")
		-- v1.7.6: the steerpoint and the two route points after it, under the
		-- rose (as on the NAV list: bearing / distance from the jet, ETA)
		-- (27 characters a line, centred under the rose)
		local NY, NX = CFG.hsi_next_y or -0.92, -27 * cw(TXS) / 2
		line("dlp_hsi", "nx1", NX, NY, "DLP_HSI_NX1", F.green, TXS)
		line("dlp_hsi", "nx2", NX, NY - 0.10, "DLP_HSI_NX2", F.white, TXS)
		line("dlp_hsi", "nx3", NX, NY - 0.20, "DLP_HSI_NX3", F.white, TXS)
	end
	lbl_left("dlp_hsi", 1, "HDG"); lbl_left("dlp_hsi", 2, "CRS"); lbl_left("dlp_hsi", 3, "TCN")
	lbl_left("dlp_hsi", 4, "STP"); lbl_left("dlp_hsi", 5, "SYNC")
	-- right 1: TACAN off (only while a channel is set)
	text("dlp_hsi_r1", "dlp_hsi", {RX, BYRS[1], 0}, F.white, TXT_SB, "RightCenter", "TCN\nOFF", nil, {"DLP_HSI_TCNON", 0.5, 1.5})
	menu_btn("dlp_hsi")

	-------------------------------------------------------------------
	-- 12 NAV: steering to the selected steerpoint (route leg, cross-track,
	-- command track), the route list with TOTs, the TOT block and the
	-- cartridge loading (R1 LOAD -> the cartridge list of page 6).
	-- Values: upd_nav / upd_tot in dl_pages_dev.
	-------------------------------------------------------------------
	root("dlp_nav", 12)
	do
		local r = "dlp_nav"
		title(r, "NAV")
		line(r, "src", 0, 1.10, "DLP_NAV_SRC", F.grey, TXS, "CenterCenter")
		line(r, "stp", LX, 1.00, "DLP_NAV_STP", F.green, TXS)
		line(r, "brg", LX, 0.91, "DLP_NAV_BRG", F.white, TXS)
		line(r, "time", LX, 0.82, "DLP_NAV_TIME", F.white, TXS)
		line(r, "leg", LX, 0.73, "DLP_NAV_LEG", F.cyan, TXS)
		-- steering bar: scale = +-45 deg from the nose, diamond = command track
		local SY, SW = 0.55, 0.60
		mesh(r .. "_sbar", r, "triangles", {{-SW, SY + LW / 2}, {SW, SY + LW / 2}, {SW, SY - LW / 2}, {-SW, SY - LW / 2}}, {0, 1, 2, 0, 2, 3}, M.white)
		do
			local tv, ti = {}, {}
			for k = -4, 4 do
				local x = SW * k / 4
				local hh = (k == 0) and 0.07 or ((k % 2 == 0) and 0.045 or 0.028)
				local b = #tv
				tv[b + 1] = {x - LW / 2, SY - hh}; tv[b + 2] = {x + LW / 2, SY - hh}; tv[b + 3] = {x + LW / 2, SY}; tv[b + 4] = {x - LW / 2, SY}
				for _, q in ipairs({0, 1, 2, 0, 2, 3}) do ti[#ti + 1] = b + q end
			end
			mesh(r .. "_sticks", r, "triangles", tv, ti, M.white)
		end
		-- fixed nose marker under the centre, moving command diamond above the bar
		mesh(r .. "_snose", r, "triangles", {{0, SY - 0.075}, {0.04, SY - 0.13}, {-0.04, SY - 0.13}}, {0, 1, 2}, M.white)
		simple(r .. "_sdia", r, {0, SY, 0}, {"DLP_NAV_STEER", "DLP_NAV_SV"},
			{{"move_left_right_using_parameter", 0, G * SW}, {"parameter_in_range", 1, 0.5, 1.5}})
		mesh(r .. "_sdiam", r .. "_sdia", "triangles", {{0, 0.11}, {0.04, 0.06}, {0, 0.01}, {-0.04, 0.06}}, {0, 1, 2, 0, 2, 3}, M.friend)
		text(r .. "_sl", r, {-SW, SY + 0.07, 0}, F.grey, TXT_T, "LeftCenter", "L")
		text(r .. "_sr", r, {SW, SY + 0.07, 0}, F.grey, TXT_T, "RightCenter", "R")
		line(r, "cmd", 0, 0.36, "DLP_NAV_CMD", F.green, TXS, "CenterCenter")
		hline(r, "sep1", 0.29, -0.85, 0.85)
		-- same font as the rows so the columns line up (row format "%-4s %-8s %s %6s %s")
		text(r .. "_hd", r, {LX, 0.21, 0}, F.blue, TXS, "LeftCenter", "PT   NAME     BRG    DIST  ETA")
		for i = 1, 5 do
			local y = 0.12 - (i - 1) * 0.10
			for c, f in ipairs({F.white, F.green, F.cyan, F.grey}) do
				line(r, "w" .. i .. "_" .. c, LX, y, "DLP_NAV_L" .. i, f, TXS, "LeftCenter", {"DLP_NAV_C" .. i, c - 0.5, c + 0.5})
			end
			-- DLP_NAV_T: 1 = has a TOT, 2 = PT cursor, 3 = both
			text(r .. "_tot" .. i, r, {0.62, y, 0}, F.red, TXT_T, "LeftCenter", "TOT", nil, {"DLP_NAV_T" .. i, 0.5, 1.5})
			text(r .. "_totc" .. i, r, {0.62, y, 0}, F.red, TXT_T, "LeftCenter", "TOT", nil, {"DLP_NAV_T" .. i, 2.5, 3.5})
			text(r .. "_cur" .. i, r, {0.80, y, 0}, F.white, TXS, "LeftCenter", "<", nil, {"DLP_NAV_T" .. i, 1.5, 3.5})
		end
		-- bottom block (R5 switches): time on target, or RSBN stations
		sub("dlp_nav_tb", r, "DLP_NAV_VIEW", -0.5, 0.5)
		tot_block("dlp_nav_tb", 0.03)
		sub("dlp_nav_rb", r, "DLP_NAV_VIEW", 0.5, 1.5)
		hline("dlp_nav_rb", "rsep", -0.35, -0.85, 0.85)
		text("dlp_nav_rb_hd", "dlp_nav_rb", {LX, -0.43, 0}, F.blue, TXS, "LeftCenter", "STN CH STATION    BRG  RNG")
		for i = 1, 4 do
			local y = -0.53 - (i - 1) * 0.10
			for c, f in ipairs({F.white, F.green, F.cyan, F.grey}) do
				line("dlp_nav_rb", "r" .. i .. "_" .. c, LX, y, "DLP_NAV_R" .. i, f, TXS, "LeftCenter", {"DLP_NAV_RC" .. i, c - 0.5, c + 0.5})
			end
		end
		line("dlp_nav_rb", "rsel", LX, -0.97, "DLP_NAV_RSEL", F.green, TXS)
		-- sequencing mode, or (amber) the ADD waypoint entry / a message
		line(r, "seq", LX, -1.08, "DLP_NAV_SEQ", F.grey, TXS, "LeftCenter", {"DLP_NAV_ADD", -0.5, 0.5})
		line(r, "seqa", LX, -1.08, "DLP_NAV_SEQ", F.amber, TXS, "LeftCenter", {"DLP_NAV_ADD", 0.5, 1.5})
	end
	lbl_left("dlp_nav", 1, "PREV"); lbl_left("dlp_nav", 2, "NEXT")
	text("dlp_nav_l3a", "dlp_nav", {BX, BYS[3], 0}, F.white, TXT_SB, "LeftCenter", "AUTO", nil, {"DLP_NAV_AUTO", 0.5, 1.5})
	text("dlp_nav_l3m", "dlp_nav", {BX, BYS[3], 0}, F.amber, TXT_SB, "LeftCenter", "MAN", nil, {"DLP_NAV_AUTO", -0.5, 0.5})
	lbl_left("dlp_nav", 4, "DIR"); lbl_left("dlp_nav", 5, "RTE")
	lbl_right("dlp_nav", 1, "LOAD"); lbl_right("dlp_nav", 2, "TOT"); lbl_right("dlp_nav", 3, "PT"); lbl_right("dlp_nav", 4, "CLR")
	text("dlp_nav_r5r", "dlp_nav", {RX, BYRS[5], 0}, F.white, TXT_SB, "RightCenter", "RSBN", nil, {"DLP_NAV_VIEW", -0.5, 0.5})
	text("dlp_nav_r5t", "dlp_nav", {RX, BYRS[5], 0}, F.white, TXT_SB, "RightCenter", "TOT", nil, {"DLP_NAV_VIEW", 0.5, 1.5})
	-- bottom 1 ADD (typed-in waypoint: lat/long, again = MGRS), bottom 2 DEL
	text("dlp_nav_b1", "dlp_nav", {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "ADD")
	text("dlp_nav_b2", "dlp_nav", {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "DEL")
	text("dlp_nav_b4", "dlp_nav", {ROW[4], YB, 0}, F.white, TXS, "CenterCenter", "EDIT")
	menu_btn("dlp_nav")

	-------------------------------------------------------------------
	-- 13 RTE: pick the route points to fly (from NAV left 5). Right 1-5
	-- add / remove a point (flown in the order picked), left 1-4 flight
	-- member routes (note tags), left 5 DONE, bottom PREV NEXT CLR ALL.
	-------------------------------------------------------------------
	root("dlp_rte", 13)
	do
		local r = "dlp_rte"
		line(r, "title", 0, 1.22, "DLP_RTE_TITLE", F.white, TXS, "CenterCenter")
		hline(r, "tl", 1.14, -0.85, 0.85)
		line(r, "sum", LX, 1.05, "DLP_RTE_SUM", F.green, TXS)
		line(r, "mem", LX, 0.95, "DLP_RTE_MEM", F.grey, TXS)
		for k = 1, 5 do
			line(r, "r" .. k, RX - 0.1, BYRS[k], "DLP_RTE_R" .. k, F.white, TXS, "RightCenter", {"DLP_RTE_C" .. k, 0.5, 1.5})
			line(r, "rg" .. k, RX - 0.1, BYRS[k], "DLP_RTE_R" .. k, F.green, TXS, "RightCenter", {"DLP_RTE_C" .. k, 1.5, 2.5})
			text(r .. "_ar" .. k, r, {RX, BYRS[k], 0}, F.white, TXS, "RightCenter", "<", nil, {"DLP_RTE_C" .. k, 0.5, 2.5})
		end
		for k = 1, 4 do
			text1(r .. "_m" .. k, r, {BX, BYS[k], 0}, F.white, TXT_SB, "LeftCenter", nil, "DLP_RTE_M" .. k)
		end
		hline(r, "bl", -0.84, -0.85, 0.85)
		text(r .. "_help", r, {LX, -0.92, 0}, F.grey, TXT_T, "LeftCenter", "PICK IN FLYING ORDER - DONE TO USE IT")
		line(r, "pg", (ROW[3] + ROW[4]) / 2 + 0.05, -1.03, "DLP_RTE_PG", F.grey, TXS, "CenterCenter")
		text(r .. "_b1", r, {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "PREV")
		text(r .. "_b2", r, {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "NEXT")
		text(r .. "_b4", r, {ROW[4], YB, 0}, F.white, TXS, "CenterCenter", "CLR")
		text(r .. "_b5", r, {ROW[5], YB, 0}, F.white, TXS, "CenterCenter", "ALL")
	end
	lbl_left("dlp_rte", 5, "DONE")
	menu_btn("dlp_rte")

	-------------------------------------------------------------------
	-- 15 EDIT (v1.7.2): the working route with its own cursor (the
	-- active steerpoint stays). Right 1-5 put the cursor on a point, left
	-- 1 / 2 move it a place up / down, 3 POS new position, 4 ADD a point
	-- after it, 5 DONE; bottom PREV / NEXT page, DEL (twice), STP.
	-------------------------------------------------------------------
	root("dlp_wed", 15)
	do
		local r = "dlp_wed"
		line(r, "title", 0, 1.22, "DLP_WED_TITLE", F.white, TXS, "CenterCenter")
		hline(r, "tl", 1.14, -0.85, 0.85)
		-- the point under the cursor: name, MGRS, lat / long
		line(r, "sel", LX, 1.05, "DLP_WED_SEL", F.green, TXS)
		line(r, "mg", -LX, 1.05, "DLP_WED_MG", F.white, TXS, "RightCenter")
		line(r, "ll", LX, 0.96, "DLP_WED_LL", F.white, TXS)
		for k = 1, 5 do
			for c, f in ipairs({F.white, F.green, F.cyan}) do
				line(r, "r" .. k .. "_" .. c, RX - 0.1, BYRS[k], "DLP_WED_R" .. k, f, TXS, "RightCenter", {"DLP_WED_C" .. k, c - 0.5, c + 0.5})
			end
			text(r .. "_ar" .. k, r, {RX, BYRS[k], 0}, F.white, TXS, "RightCenter", "<", nil, {"DLP_WED_C" .. k, 0.5, 3.5})
		end
		hline(r, "bl", -0.90, -0.85, 0.85)
		line(r, "msg", LX, -0.97, "DLP_WED_MSG", F.grey, TXS, "LeftCenter", {"DLP_WED_MSGC", -0.5, 0.5})
		line(r, "msga", LX, -0.97, "DLP_WED_MSG", F.amber, TXS, "LeftCenter", {"DLP_WED_MSGC", 0.5, 1.5})
		line(r, "pg", (ROW[3] + ROW[4]) / 2 + 0.05, -1.07, "DLP_WED_PG", F.grey, TXS, "CenterCenter")
		text(r .. "_b1", r, {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "PREV")
		text(r .. "_b2", r, {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "NEXT")
		text(r .. "_b4", r, {ROW[4], YB, 0}, F.white, TXS, "CenterCenter", "DEL")
		text(r .. "_b5", r, {ROW[5], YB, 0}, F.white, TXS, "CenterCenter", "STP")
	end
	lbl_left("dlp_wed", 1, "MV UP"); lbl_left("dlp_wed", 2, "MV DN"); lbl_left("dlp_wed", 3, "POS")
	lbl_left("dlp_wed", 4, "ADD"); lbl_left("dlp_wed", 5, "DONE")
	menu_btn("dlp_wed")

	-------------------------------------------------------------------
	-- 16 SNAKE (v1.7.4 easter egg, dl_snake.lua): typed on the UFCP as
	-- S N A K E on a button phone (77776625533). A 20 x 20 grid, up to
	-- DL_SNAKE_MAX body squares that move (a ring of slots), a filled
	-- head and a red food diamond. Keypad 2 4 6 8 steer, 5 pause.
	-------------------------------------------------------------------
	root("dlp_snk", 16)
	do
		local r = "dlp_snk"
		local X0, Y0, CELL, NC = -0.76, 0.84, 0.08, 20
		local x1, y1 = X0 + NC * CELL, Y0 - NC * CELL
		local q = 0.03                      -- half a square
		line(r, "score", X0, 0.96, "DLP_SNK_SCORE", F.green, TXS)
		line(r, "hi", x1, 0.96, "DLP_SNK_HI", F.amber, TXS, "RightCenter")
		-- the field
		box(r, "field", (X0 + x1) / 2, (Y0 + y1) / 2, x1 - X0 + 0.02, Y0 - y1 + 0.02, M.ring)
		for i = 1, (DL_SNAKE_MAX or 100) do
			local n = r .. "_s" .. i
			simple(n, r, {0, 0, 0}, {"DLP_SNK_X" .. i, "DLP_SNK_Y" .. i, "DLP_SNK_V" .. i},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
				 {"parameter_in_range", 2, 0.5, 1.5}})
			box(n, "q", 0, 0, 2 * q, 2 * q, M.ring)
		end
		simple(r .. "_head", r, {0, 0, 0}, {"DLP_SNK_HX", "DLP_SNK_HY", "DLP_SNK_HV"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 1.5}})
		mesh(r .. "_head_sq", r .. "_head", "triangles", {{-q, q}, {q, q}, {q, -q}, {-q, -q}}, {0, 1, 2, 0, 2, 3}, M.ring)
		simple(r .. "_food", r, {0, 0, 0}, {"DLP_SNK_FX", "DLP_SNK_FY", "DLP_SNK_FV"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 1.5}})
		do
			local a, t = 0.036, LW * 1.4
			local o, n2 = {{0, a}, {a, 0}, {0, -a}, {-a, 0}}, {}
			local v, idx = {}, {}
			for k = 1, 4 do
				local p0, p1 = o[k], o[k % 4 + 1]
				local dx, dy = p1[1] - p0[1], p1[2] - p0[2]
				local l = math.sqrt(dx * dx + dy * dy)
				local nx, ny = -dy / l * t / 2, dx / l * t / 2
				local b = #v
				v[b + 1] = {p0[1] + nx, p0[2] + ny}; v[b + 2] = {p1[1] + nx, p1[2] + ny}
				v[b + 3] = {p1[1] - nx, p1[2] - ny}; v[b + 4] = {p0[1] - nx, p0[2] - ny}
				for _, j in ipairs({0, 1, 2, 0, 2, 3}) do idx[#idx + 1] = b + j end
			end
			mesh(r .. "_food_d", r .. "_food", "triangles", v, idx, M.hostile)
		end
		line(r, "len", 0, y1 - 0.08, "DLP_SNK_LEN", F.grey, TXS, "CenterCenter")
		-- banner: READY (green) / game over (red) / PAUSED (amber)
		simple(r .. "_ban", r, {0, 0, 0}, {"DLP_SNK_BAN"}, {{"parameter_in_range", 0, 0.5, 3.5}})
		mesh(r .. "_ban_bg", r .. "_ban", "triangles", {{-0.62, 0.22}, {0.62, 0.22}, {0.62, -0.18}, {-0.62, -0.18}}, {0, 1, 2, 0, 2, 3}, M.black)
		box(r .. "_ban", "frame", 0, 0.02, 1.24, 0.40, M.white)
		for k, f in ipairs({F.green, F.red, F.amber}) do
			line(r .. "_ban", "t" .. k, 0, 0.09, "DLP_SNK_B1", f, TXT, "CenterCenter", {"DLP_SNK_BAN", k - 0.5, k + 0.5})
		end
		line(r .. "_ban", "sub", 0, -0.07, "DLP_SNK_B2", F.white, TXS, "CenterCenter")
		text(r .. "_help", r, {0, YB + 0.13, 0}, F.dim, TXT_T, "CenterCenter", "UFCP 2 4 6 8 STEER   5 PAUSE   CLR EXIT")
	end
	menu_btn("dlp_snk")

	-------------------------------------------------------------------
	-- 14 PICTURE (SA page right 2): hostile contacts grouped into
	-- formations, bullseye / BRAA per group, the call written out and a
	-- small north-up plot around the bullseye (dl_tac.lua groups them)
	-------------------------------------------------------------------
	root("dlp_pic", 14)
	do
		local r = "dlp_pic"
		title(r, "PICTURE")
		line(r, "hdr", LX, 1.05, "DLP_PIC_HDR", F.green, TXS)
		line(r, "show", -LX, 1.05, "DLP_PIC_SORT", F.grey, TXS, "RightCenter")
		text(r .. "_cols", r, {LX, 0.95, 0}, F.blue, TXT_T, "LeftCenter", "GRP BULLS   BRAA        ALT SIZE     ASPECT")
		hline(r, "cl", 0.905, -0.82, 0.82)
		for k = 1, 5 do
			local y = 0.85 - (k - 1) * 0.085
			line(r, "row" .. k, LX, y, "DLP_PIC_R" .. k, F.red, TXT_T, nil, {"DLP_PIC_C" .. k, 0.5, 1.5})
			line(r, "rowf" .. k, LX, y, "DLP_PIC_R" .. k, F.green, TXT_T, nil, {"DLP_PIC_C" .. k, 1.5, 2.5})
			simple(r .. "_sb" .. k, r, {0, 0, 0}, {"DLP_PIC_S" .. k}, {{"parameter_in_range", 0, 0.5, 1.5}})
			box(r .. "_sb" .. k, "b", 0, y, 1.68, 0.075, M.white)
			text(r .. "_rl" .. k, r, {RX, BYRS[k], 0}, F.white, TXT_SB, "RightCenter", "GRP " .. k, nil, {"DLP_PIC_RV" .. k, 0.5, 1.5})
		end
		-- the call for the selected group (2 lines)
		text(r .. "_callh", r, {LX, 0.30, 0}, F.blue, TXT_T, "LeftCenter", "CALL")
		for k = 1, 2 do line(r, "call" .. k, LX, 0.23 - (k - 1) * 0.075, "DLP_PIC_K" .. k, F.white, TXS) end
		-- plot: north up, around the bullseye (CALL BULL) or the jet (CALL BRAA)
		local PCY, PR = CFG.pic_plot_y or -0.52, CFG.pic_plot_r or 0.40
		simple(r .. "_plot", r, {0, PCY, 0})
		local dim = D.col(60, 95, 70, 255)
		local cv, ci = D.circle_ring(PR, LW * 0.6, 64)
		mesh(r .. "_ring1", r .. "_plot", "triangles", cv, ci, dim)
		cv, ci = D.circle_ring(PR / 2, LW * 0.6, 48)
		mesh(r .. "_ring2", r .. "_plot", "triangles", cv, ci, dim)
		line(r, "scale", PR + 0.02, PCY + PR - 0.02, "DLP_PIC_PR", F.grey, TXT_T, "LeftCenter")
		simple(r .. "_be", r .. "_plot", {0, 0, 0}, {"DLP_PIC_BX", "DLP_PIC_BY", "DLP_PIC_BE"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}, {"parameter_in_range", 2, 0.5, 1.5}})
		do
			local bv, bi = D.circle_ring(0.018, LW * 0.6, 16)
			mesh(r .. "_be_c", r .. "_be", "triangles", bv, bi, M.friend)
			mesh(r .. "_be_x", r .. "_be", "lines", {{-0.035, 0}, {0.035, 0}, {0, -0.035}, {0, 0.035}}, {0, 1, 2, 3}, M.friend)
			text(r .. "_be_l", r .. "_be", {0.03, -0.045, 0}, F.green, TXT_T, "LeftCenter", "BE")
		end
		-- the jet
		simple(r .. "_own", r .. "_plot", {0, 0, 0}, {"DLP_PIC_OX", "DLP_PIC_OY", "DLP_PIC_OV"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}, {"parameter_in_range", 2, 0.5, 1.5}})
		simple(r .. "_own_r", r .. "_own", {0, 0, 0}, {"DLP_PIC_OH"}, {{"rotate_using_parameter", 0, 1}})
		do
			local f = 0.6
			local ov, oi = D.poly_lines({{0, 0.06 * f}, {0.010 * f, 0.026 * f}, {0.048 * f, 0.0}, {0.048 * f, -0.010 * f}, {0.009 * f, 0.0},
				{0.007 * f, -0.034 * f}, {0.022 * f, -0.047 * f}, {0, -0.043 * f}, {-0.022 * f, -0.047 * f}, {-0.007 * f, -0.034 * f},
				{-0.009 * f, 0.0}, {-0.048 * f, -0.010 * f}, {-0.048 * f, 0.0}, {-0.010 * f, 0.026 * f}})
			mesh(r .. "_own_s", r .. "_own_r", "lines", ov, oi, M.own)
		end
		-- groups: hostile = red triangle along the track, friendly = green
		-- circle; white ring = selected. DLP_PIC_G<k>_V: 1 hostile, 2 hostile
		-- selected, 3 friendly, 4 friendly selected
		for k = 1, 5 do
			local g = r .. "_g" .. k
			local gv = "DLP_PIC_G" .. k .. "_V"
			simple(g, r .. "_plot", {0, 0, 0}, {"DLP_PIC_G" .. k .. "_X", "DLP_PIC_G" .. k .. "_Y", gv},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}, {"parameter_in_range", 2, 0.5, 4.5}})
			simple(g .. "_r", g, {0, 0, 0}, {"DLP_PIC_G" .. k .. "_H"}, {{"rotate_using_parameter", 0, 1}})
			local q = 0.026
			local tv, ti = D.band({{0, q * 1.2}, {q * 0.9, -q * 0.75}, {-q * 0.9, -q * 0.75}},
				{{0, q * 1.2 - LW * 2.2}, {q * 0.9 - LW * 1.6, -q * 0.75 + LW}, {-q * 0.9 + LW * 1.6, -q * 0.75 + LW}})
			mesh(g .. "_s", g .. "_r", "triangles", tv, ti, M.hostile, nil, {gv}, {{"parameter_in_range", 0, 0.5, 2.5}})
			local fv, fi = D.circle_ring(0.022, LW * 0.7, 20)
			mesh(g .. "_f", g, "triangles", fv, fi, M.friend, nil, {gv}, {{"parameter_in_range", 0, 2.5, 4.5}})
			mesh(g .. "_fl", g .. "_r", "lines", {{0, 0.022}, {0, 0.06}}, {0, 1}, M.friend, nil, {gv}, {{"parameter_in_range", 0, 2.5, 4.5}})
			local sv, si = D.circle_ring(0.05, LW * 0.6, 24)
			mesh(g .. "_sel", g, "triangles", sv, si, M.white, nil, {gv}, {{"parameter_in_range", 0, 1.5, 2.5}})
			mesh(g .. "_self", g, "triangles", sv, si, M.white, nil, {gv}, {{"parameter_in_range", 0, 3.5, 4.5}})
			text(g .. "_n", g, {0.05, 0.035, 0}, F.red, TXT_T, "LeftCenter", tostring(k), nil, {gv, 0.5, 2.5})
			text(g .. "_nf", g, {0.05, 0.035, 0}, F.green, TXT_T, "LeftCenter", tostring(k), nil, {gv, 2.5, 4.5})
		end
		-- bottom row: plot range +/- and AUTO (fit), SHOW hostile / friendly / all
		text(r .. "_b1", r, {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "RNG+")
		text(r .. "_b2", r, {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "RNG-")
		text(r .. "_b4", r, {ROW[4], YB, 0}, F.white, TXS, "CenterCenter", "AUTO", nil, {"DLP_PIC_AUTO", -0.5, 0.5})
		text(r .. "_b4g", r, {ROW[4], YB, 0}, F.green, TXS, "CenterCenter", "AUTO", nil, {"DLP_PIC_AUTO", 0.5, 1.5})
		line(r, "b5", ROW[5], YB, "DLP_PIC_SHOW", F.white, TXS, "CenterCenter")
		text1(r .. "_l2", r, {BX, BYS[2], 0}, F.white, TXT_SB, "LeftCenter", nil, "DLP_PIC_L2")
		lbl_left(r, 4, "INTC")
		lbl_left(r, 5, "SA")
	end
	menu_btn("dlp_pic")

	-------------------------------------------------------------------
	-- 9 FLIGHT: designated flight members (R1-R5), details of the selected
	-- one on the left; ADD view lists the friendly aircraft in range
	-------------------------------------------------------------------
	root("dlp_flt", 9)
	line("dlp_flt", "title", 0, 1.22, "DLP_FLT_TITLE", F.white, TXS, "CenterCenter")
	hline("dlp_flt", "tl", 1.14, -0.85, 0.85)
	for k = 1, 5 do
		local y = BYRS[k]
		line("dlp_flt", "r" .. k, RX - 0.1, y + 0.03, "DLP_FLT_R" .. k, F.white, TXS, "RightCenter", {"DLP_FLT_M" .. k, 0.5, 1.5})
		line("dlp_flt", "ry" .. k, RX - 0.1, y + 0.03, "DLP_FLT_R" .. k, F.amber, TXS, "RightCenter", {"DLP_FLT_M" .. k, 1.5, 2.5})
		line("dlp_flt", "rs" .. k, RX - 0.1, y - 0.06, "DLP_FLT_S" .. k, F.grey, TXT_T, "RightCenter", {"DLP_FLT_M" .. k, 0.5, 2.5})
		text("dlp_flt_ar" .. k, "dlp_flt", {RX, y + 0.03, 0}, F.white, TXS, "RightCenter", "<", nil, {"DLP_FLT_M" .. k, 0.5, 2.5})
	end
	-- left buttons: ADD / BACK, REM
	text1("dlp_flt_l1", "dlp_flt", {BX, BYS[1], 0}, F.white, TXT_SB, "LeftCenter", nil, "DLP_FLT_L1")
	text1("dlp_flt_l2", "dlp_flt", {BX, BYS[2], 0}, F.white, TXT_SB, "LeftCenter", nil, "DLP_FLT_L2")
	-- details of the selected member (list view) / hints (add view)
	for i = 1, 14 do
		local y = 0.6 - (i - 1) * 0.095
		for c, f in ipairs({F.white, F.green, F.red, F.amber, F.grey}) do
			line("dlp_flt", "d" .. i .. "_" .. c, -0.66, y, "DLP_FLT_D" .. i, f, TXS, "LeftCenter", {"DLP_FLT_C" .. i, c - 1.5, c - 0.5})
		end
	end
	-- paging in the add view
	simple("dlp_flt_add", "dlp_flt", {0, 0, 0}, {"DLP_FLT_VIEW"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	text("dlp_flt_b1", "dlp_flt_add", {ROW[1], YB, 0}, F.white, TXS, "CenterCenter", "PREV")
	text("dlp_flt_b2", "dlp_flt_add", {ROW[2], YB, 0}, F.white, TXS, "CenterCenter", "NEXT")
	line("dlp_flt_add", "pg", (ROW[4] + ROW[5]) / 2, YB, "DLP_FLT_PG", F.grey, TXS, "CenterCenter")
	menu_btn("dlp_flt")

	-------------------------------------------------------------------
	-- 10 RWR: emitters around the jet (stronger = nearer the centre),
	-- green scan, amber track, red lock, blinking ring = missile launch
	-------------------------------------------------------------------
	if RWR_ON then
	root("dlp_rwr", 10)
	-- v1.8.1: title at the very top, the
	-- heading tape (same as the SA page) under it, compass on the ring
	local YRT = CFG.rwr_top_y or 1.37
	boxed("dlp_rwr", "title", 0, YRT, "RWR", F.white, TXT, M.white)
	-- (the SPO-15 / emitter count line is gone: the list under the scope has
	-- it all; chaff / flares sit bottom right, on the MENU row)
	line("dlp_rwr", "cm", CFG.rwr_cm_x or 0.92, YB, "DLP_RWR_CM", F.grey, TXS, "RightCenter")
	if D.hdg_tape and CFG.rwr_hdg_tape ~= false then D.hdg_tape("dlp_rwr_hdg", "dlp_rwr", CFG.hdg_tape_y or 1.13) end
	do
		local CY = CFG.rwr_center_y or 0.10
		local R = CFG.rwr_radius or 0.62
		simple("dlp_rwr_c", "dlp_rwr", {0, CY, 0})
		local v, i = D.circle_ring(R + 0.04, LW, 96)
		mesh("dlp_rwr_ring", "dlp_rwr_c", "triangles", v, i, M.white)
		v, i = D.circle_ring(R * 0.5, LW, 64)
		mesh("dlp_rwr_ring2", "dlp_rwr_c", "triangles", v, i, M.blue)
		-- v1.8.1 compass rose on the ring, turned with heading (ticks every
		-- 10 deg, long every 30), upright labels N 3 6 E .. outside it and a
		-- fixed lubber mark at the top (the nose)
		simple("dlp_rwr_rot", "dlp_rwr_c", {0, 0, 0}, {"DLP_RWC_ROT"}, {{"rotate_using_parameter", 0, 1}})
		local tv, ti = {}, {}
		for deg = 0, 350, 10 do
			local a = math.rad(90 - deg)
			local ca, sa = math.cos(a), math.sin(a)
			local px, py = -sa * LW / 2, ca * LW / 2
			local r0, r1 = R + 0.04, R + ((deg % 30 == 0) and 0.10 or 0.07)
			local k = #tv
			tv[k + 1] = {r0 * ca + px, r0 * sa + py}; tv[k + 2] = {r1 * ca + px, r1 * sa + py}
			tv[k + 3] = {r1 * ca - px, r1 * sa - py}; tv[k + 4] = {r0 * ca - px, r0 * sa - py}
			for _, q in ipairs({0, 1, 2, 0, 2, 3}) do ti[#ti + 1] = k + q end
		end
		mesh("dlp_rwr_ticks", "dlp_rwr_rot", "triangles", tv, ti, M.white)
		mesh("dlp_rwr_lub", "dlp_rwr_c", "triangles", {{-0.028, R + 0.035}, {0.028, R + 0.035}, {0, R - 0.025}}, {0, 1, 2}, M.white)
		local names = {"N", "3", "6", "E", "12", "15", "S", "21", "24", "W", "30", "33"}
		for k = 0, 11 do
			simple("dlp_rwr_lb" .. k, "dlp_rwr_c", {0, 0, 0}, {"DLP_RWC_L" .. k .. "_X", "DLP_RWC_L" .. k .. "_Y"},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})
			text("dlp_rwr_lt" .. k, "dlp_rwr_lb" .. k, {0, 0, 0}, (k % 3 == 0) and F.white or F.grey, TXS, "CenterCenter", names[k + 1])
		end
		local av, ai = D.poly_lines({{0, 0.06}, {0.010, 0.026}, {0.048, 0.0}, {0.048, -0.010}, {0.009, 0.0},
			{0.007, -0.034}, {0.022, -0.047}, {0, -0.043}, {-0.022, -0.047}, {-0.007, -0.034},
			{-0.009, 0.0}, {-0.048, -0.010}, {-0.048, 0.0}, {-0.010, 0.026}})
		mesh("dlp_rwr_ac", "dlp_rwr_c", "lines", av, ai, M.own)
		for k = 1, 12 do
			local n = "dlp_rw" .. k
			simple(n, "dlp_rwr_c", {0, 0, 0}, {"DLP_RW" .. k .. "_X", "DLP_RW" .. k .. "_Y", "DLP_RW" .. k .. "_S"},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
				 {"parameter_in_range", 2, 0.5, 4.5}})
			-- symbol: a number ("11", "29", shown with %.0f: number-like text
			-- must not go through %s) or letters ("U", "EW") -- DLP_RW<k>_K picks
			simple(n .. "_num", n, {0, 0, 0}, {"DLP_RW" .. k .. "_K"}, {{"parameter_in_range", 0, 0.5, 1.5}})
			simple(n .. "_str", n, {0, 0, 0}, {"DLP_RW" .. k .. "_K"}, {{"parameter_in_range", 0, -0.5, 0.5}})
			for c, cf in ipairs({{F.green, 0.5, 1.5}, {F.amber, 1.5, 2.5}, {F.red, 2.5, 4.5}}) do
				local vis = {"DLP_RW" .. k .. "_S", cf[2], cf[3]}
				local et = text1(n .. "_t" .. c, n .. "_str", {0, 0, 0}, cf[1], TXS, "CenterCenter", nil, "DLP_RW" .. k .. "_T", vis)
				num_text(et, n .. "_n" .. c, n .. "_num", "DLP_RW" .. k .. "_N", vis, "%.0f")
			end
			v, i = D.circle_ring(0.06, LW, 24)
			mesh(n .. "_lk", n, "triangles", v, i, M.hostile, nil, {"DLP_RW" .. k .. "_S"}, {{"parameter_in_range", 0, 2.5, 4.5}})
			if LAUNCH_ON then
				v, i = D.circle_ring(0.085, LW * 1.5, 28)
				mesh(n .. "_ln", n, "triangles", v, i, M.hostile, nil, {"DLP_RW" .. k .. "_S"}, {{"parameter_in_range", 0, 3.5, 4.5}})
			end
		end
	end
	hline("dlp_rwr", "sep", CFG.rwr_list_y or -0.76)
	for k = 1, 6 do
		local y = (CFG.rwr_list_y or -0.76) - 0.07 - (k - 1) * 0.072
		for c, cf in ipairs({{F.green, -0.5, 0.5}, {F.amber, 0.5, 1.5}, {F.red, 1.5, 2.5}}) do
			line("dlp_rwr", "l" .. k .. "_" .. c, LX, y, "DLP_RWR_L" .. k, cf[1], TXS, "LeftCenter", {"DLP_RWR_C" .. k, cf[2], cf[3]})
		end
	end
	menu_btn("dlp_rwr")
	end

	-------------------------------------------------------------------
	-- 11 SMS: stores per station, gun, chaff / flares
	-------------------------------------------------------------------
	root("dlp_sms", 11)
	title("dlp_sms", "STORES")
	-- v1.7.6: laid out like the stores page of the upgraded MiG-29 (SMT):
	-- the jet seen from behind (its left wing on your left), a line hanging
	-- from each station, longer from the middle outwards, and at its end the
	-- store (drawn as seen from behind) with its name under it. Station 1 =
	-- left wing tip .. 7 = right wing tip, 4 = under the fuselage.
	do
		-- drawn in metres from the real jet (span 11.36 m, fins 3.3 m above the
		-- engine axis, tailplane 7.78 m), origin = engine axis on the centre
		-- line, then scaled to the page
		local SY = CFG.sms_axis_y or 0.52                 -- engine axis on the page
		local K = 0.92 / 5.68                             -- page units per metre
		local SXM = {-4.10, -3.20, -2.30, 0, 2.30, 3.20, 4.10}   -- stations (m from the centre line)
		local SX = {}
		for k = 1, 7 do SX[k] = SXM[k] * K end
		local DROP = {0.76, 0.58, 0.40, 0.22, 0.40, 0.58, 0.76}  -- end of each station's line below the axis
		local CX = {-0.80, -0.55, -0.30, 0, 0.30, 0.55, 0.80}    -- the stores' columns (evenly spread)
		local GR = D.col(150, 160, 155, 255)              -- outline
		local GD = D.col(105, 112, 108, 255)              -- detail lines
		local W, WD = LW * 0.65, LW * 0.42
		-- thick polyline (closed = back to the first point)
		local function stroke(pts, w, closed)
			local v, idx, n = {}, {}, #pts
			for i = 1, closed and n or n - 1 do
				local a, b = pts[i], pts[i % n + 1]
				local dx, dy = b[1] - a[1], b[2] - a[2]
				local L = math.sqrt(dx * dx + dy * dy)
				if L > 0 then
					local ux, uy = dx / L * w / 2, dy / L * w / 2
					local k = #v
					v[k + 1] = {a[1] - ux - uy, a[2] - uy + ux}; v[k + 2] = {b[1] + ux - uy, b[2] + uy + ux}
					v[k + 3] = {b[1] + ux + uy, b[2] + uy - ux}; v[k + 4] = {a[1] - ux + uy, a[2] - uy - ux}
					for _, q in ipairs({0, 1, 2, 0, 2, 3}) do idx[#idx + 1] = k + q end
				end
			end
			return v, idx
		end
		-- metres -> page (and the mirror image for the right side)
		local function pg(pts, mir)
			local m = {}
			for i, q in ipairs(pts) do m[i] = {(mir and -q[1] or q[1]) * K, q[2] * K} end
			return m
		end
		simple("dlp_sms_jet", "dlp_sms", {0, SY, 0})
		local nj = 0
		-- a shape given in metres for the left side; both = also its mirror
		local function draw(pts, closed, both, mat, w)
			for _, mir in ipairs(both and {false, true} or {false}) do
				nj = nj + 1
				local v, i = stroke(pg(pts, mir), w or W, closed)
				mesh("dlp_sms_jet" .. nj, "dlp_sms_jet", "triangles", v, i, mat or GR)
			end
		end
		local function ring(xm, zm, rm, mat, w, n)
			nj = nj + 1
			local v, i = D.circle_ring(rm * K, w or W, n or 32)
			mesh("dlp_sms_jet" .. nj, "dlp_sms_jet", "triangles", v, i, mat or GR, {xm * K, zm * K, 0})
		end
		-- (v1.7.6 rev 3: thin body as on the real jet - seen from behind it is
		-- mostly the two big nozzles with a flat deck between them, a low
		-- spine, the fins at the outer corners and the tailplanes below them)
		-- wing: thin, anhedral, rounded tip; root at the top of the nacelles
		draw({{-1.60, 0.50}, {-5.60, 0.25}, {-5.68, 0.22}, {-5.60, 0.19}, {-1.60, 0.42}}, true, true)
		-- tailplane from the fin root, about level with the top of the nozzles' mouth
		draw({{-1.66, 0.21}, {-3.86, 0.17}, {-3.89, 0.15}, {-3.86, 0.13}, {-1.66, 0.15}}, true, true, GR, WD)
		-- fins: thin, canted out, antenna fairing at the tip, rudder hinge line
		draw({{-1.66, 0.52}, {-1.93, 2.92}, {-1.91, 3.02}, {-1.85, 3.03}, {-1.81, 2.92}, {-1.50, 0.58}}, true, true)
		draw({{-1.60, 0.80}, {-1.82, 2.70}}, false, true, GD, WD)
		-- (v1.7.6 rev 5: traced from a photo straight from behind)
		-- upper side: fin root, sloping up over the nacelle tops to the spine
		draw({{-1.60, 0.50}, {-1.30, 0.62}, {-0.98, 0.69}, {-0.60, 0.70}, {-0.45, 0.70}})
		draw({{1.60, 0.50}, {1.30, 0.62}, {0.98, 0.69}, {0.60, 0.70}, {0.45, 0.70}})
		-- spine: narrow, rounded on top, flaring out down to the tail deck
		do
			local L = {{-0.45, 0.70}, {-0.37, 0.75}, {-0.315, 0.83}, {-0.29, 0.95}, {-0.275, 1.06},
			           {-0.235, 1.14}, {-0.16, 1.195}, {-0.06, 1.215}}
			local pts = {}
			for i = 1, #L do pts[#pts + 1] = L[i] end
			for i = #L, 1, -1 do pts[#pts + 1] = {-L[i][1], L[i][2]} end
			draw(pts)
		end
		-- tail deck (air brakes / chute bay): a flat plate between the nacelles
		draw({{-0.45, 0.70}, {-0.47, 0.48}}, false, true, GD, WD)
		draw({{-0.47, 0.48}, {0.47, 0.48}, {0.44, 0.29}, {0.16, 0.29}}, false, false, GR, W)
		draw({{-0.16, 0.29}, {-0.44, 0.29}, {-0.47, 0.48}}, false, false, GR, W)
		-- brake-chute bay under the plate: the tube (thick rim, opening),
		-- held by two brackets
		draw({{-0.10, 0.29}, {-0.10, 0.355}}, false, true, GD, WD)
		ring(0, 0.24, 0.135, GR, W, 40)
		ring(0, 0.24, 0.105, GR, WD, 36)
		ring(0, 0.24, 0.06, GD, WD, 24)
		-- underside of the tail between the nozzles (a shallow curve); the
		-- centre pylon (station 4) hangs from it
		do
			local pts = {}
			for q = 0, 16 do
				local x = -0.37 + 0.74 * q / 16
				pts[#pts + 1] = {x, 0.06 - 0.08 * (1 - (x / 0.37) ^ 2)}
			end
			draw(pts)
		end
		-- nacelle outer side: from the nozzle up past the tailplane root to the fin
		draw({{-1.60, -0.05}, {-1.64, 0.10}, {-1.66, 0.15}}, false, true)
		draw({{-1.66, 0.21}, {-1.64, 0.36}, {-1.60, 0.50}}, false, true)
		draw({{-1.60, -0.05}, {-1.52, -0.30}, {-1.38, -0.44}}, false, true, GD, WD)
		-- engine nozzles: wide band of outer flaps, lip, dark mouth with spokes
		for _, x in ipairs({-0.98, 0.98}) do
			ring(x, 0, 0.62, GR, W, 72)
			ring(x, 0, 0.48, GR, W, 64)
			for q = 0, 27 do
				local a = 2 * math.pi * q / 28
				draw({{x + 0.48 * math.cos(a), 0.48 * math.sin(a)}, {x + 0.62 * math.cos(a), 0.62 * math.sin(a)}}, false, false, GD, WD)
			end
			ring(x, 0, 0.10, GD, WD, 20)
			for q = 0, 15 do
				local a = 2 * math.pi * (q + 0.5) / 16
				draw({{x + 0.10 * math.cos(a), 0.10 * math.sin(a)}, {x + 0.40 * math.cos(a), 0.40 * math.sin(a)}}, false, false, GD, WD)
			end
		end

		-- stores, as seen from behind (centre = middle of the store)
		local SHAPES = {
			-- 1 small AAM (R-73 / R-60): body + four fins (X)
			function(n, p, m) local v, i = D.circle_ring(0.016, W, 14); mesh(n .. "b", p, "triangles", v, i, m)
				for _, a in ipairs({45, 135, 225, 315}) do local c, s2 = math.cos(math.rad(a)), math.sin(math.rad(a))
					v, i = stroke({{0.016 * c, 0.016 * s2}, {0.036 * c, 0.036 * s2}}, W); mesh(n .. "f" .. a, p, "triangles", v, i, m) end end,
			-- 2 big AAM (R-27): bigger body, longer fins
			function(n, p, m) local v, i = D.circle_ring(0.022, W, 16); mesh(n .. "b", p, "triangles", v, i, m)
				for _, a in ipairs({45, 135, 225, 315}) do local c, s2 = math.cos(math.rad(a)), math.sin(math.rad(a))
					v, i = stroke({{0.022 * c, 0.022 * s2}, {0.052 * c, 0.052 * s2}}, W); mesh(n .. "f" .. a, p, "triangles", v, i, m) end end,
			-- 3 fuel tank: big round
			function(n, p, m) local v, i = D.circle_ring(0.05, W, 28); mesh(n .. "b", p, "triangles", v, i, m) end,
			-- 4 bomb: body + four fins (+) with a ring round the fin tips
			function(n, p, m) local v, i = D.circle_ring(0.028, W, 18); mesh(n .. "b", p, "triangles", v, i, m)
				v, i = D.circle_ring(0.044, W * 0.7, 20); mesh(n .. "r", p, "triangles", v, i, m)
				for _, a in ipairs({0, 90, 180, 270}) do local c, s2 = math.cos(math.rad(a)), math.sin(math.rad(a))
					v, i = stroke({{0.028 * c, 0.028 * s2}, {0.044 * c, 0.044 * s2}}, W); mesh(n .. "f" .. a, p, "triangles", v, i, m) end end,
			-- 5 rocket pod: tube with the rocket tubes inside
			function(n, p, m) local v, i = D.circle_ring(0.042, W, 24); mesh(n .. "b", p, "triangles", v, i, m)
				for _, a in ipairs({90, 210, 330}) do local c, s2 = math.cos(math.rad(a)), math.sin(math.rad(a))
					v, i = D.circle_ring(0.010, W * 0.8, 10); mesh(n .. "t" .. a, p, "triangles", v, i, m, {0.019 * c, 0.019 * s2, 0}) end end,
			-- 6 anything else: a square
			function(n, p, m) local v, i = stroke({{-0.03, 0.03}, {0.03, 0.03}, {0.03, -0.03}, {-0.03, -0.03}}, W, true)
				mesh(n .. "b", p, "triangles", v, i, m) end,
		}
		local HALF = {0.036, 0.052, 0.05, 0.044, 0.042, 0.03}      -- how far each store reaches up / down
		for k = 1, 7 do
			local x = SX[k]
			local r = "dlp_sms_st" .. k
			-- pylon: under the wing's lower surface (station 4: under the centre beam)
			local xm = math.abs(SXM[k])
			local top = ((k == 4) and -0.02 or (0.42 - 0.23 * (xm - 1.60) / 4.08)) * K
			local ph = 0.42 * K
			local bot = -DROP[k]
			-- station 4: the store hangs right on its pylon, no line (v1.7.6)
			local onjet = (k == 4 and CFG.sms_tank_on_jet ~= false)
			if onjet then ph = 0.05 * K; bot = top - ph end
			local pv, pi = stroke({{x - 0.07 * K, top}, {x + 0.07 * K, top}, {x + 0.05 * K, top - ph}, {x - 0.05 * K, top - ph}}, W, true)
			mesh("dlp_sms_jet_py" .. k, "dlp_sms_jet", "triangles", pv, pi, GR)
			-- (v1.7.6: no station numbers on the jet, the stores say it all)
			-- the line down (amber while the station is selected): straight down
			-- from the pylon, then out to the store's own column, so the names
			-- under the stores keep clear of the neighbours' lines
			local cx = CX[k]
			if bot < top - ph - 0.01 then
				local lv, li = stroke({{x, top - ph}, {x, top - ph - 0.05}, {cx, bot + 0.07}, {cx, bot}}, LW * 0.6)
				mesh(r .. "_ln", "dlp_sms_jet", "triangles", lv, li, GR, nil, {"DLP_SMS_A" .. k}, {{"parameter_in_range", 0, -0.5, 1.5}})
				mesh(r .. "_lns", "dlp_sms_jet", "triangles", lv, li, M.amber, nil, {"DLP_SMS_A" .. k}, {{"parameter_in_range", 0, 1.5, 2.5}})
			end
			-- the store at its end: DLP_SMS_I<k> = shape (1..6) + 10 while selected
			simple(r, "dlp_sms_jet", {cx, bot, 0}, {"DLP_SMS_I" .. k}, {{"parameter_in_range", 0, 0.5, 16.5}})
			for t = 1, 6 do
				for sel = 0, 1 do
					local n = r .. "_s" .. t .. "_" .. sel
					local tank = onjet and t == 3      -- the centre tank to scale, as on the photo
					simple(n, r, {0, tank and -0.34 * K or -HALF[t], 0}, {"DLP_SMS_I" .. k},
						{{"parameter_in_range", 0, t + 10 * sel - 0.1, t + 10 * sel + 0.1}})
					local m = sel == 1 and M.amber or M.white
					if tank then
						local v, ii = D.circle_ring(0.34 * K, W, 48); mesh(n .. "_b", n, "triangles", v, ii, m)
						v, ii = D.circle_ring(0.13 * K, WD, 28); mesh(n .. "_c", n, "triangles", v, ii, m, {0, 0.07 * K, 0})
						v, ii = D.circle_ring(0.05 * K, WD, 16); mesh(n .. "_d", n, "triangles", v, ii, m, {0, 0.07 * K, 0})
					else
						SHAPES[t](n .. "_", n, m)
					end
				end
			end
			-- name (white, amber while selected) and how many (x2 ..)
			local ny = SY + bot - (onjet and 0.175 or 0.155)
			line("dlp_sms", "st" .. k .. "_nm", cx, ny, "DLP_SMS_N" .. k, F.white, TXS, "CenterCenter", {"DLP_SMS_A" .. k, 0.5, 1.5})
			line("dlp_sms", "st" .. k .. "_nms", cx, ny, "DLP_SMS_N" .. k, F.amber, TXS, "CenterCenter", {"DLP_SMS_A" .. k, 1.5, 2.5})
			line("dlp_sms", "st" .. k .. "_ct", cx, ny - 0.075, "DLP_SMS_C" .. k, F.grey or F.white, TXT_T, "CenterCenter", {"DLP_SMS_A" .. k, 0.5, 2.5})
		end
	end
	hline("dlp_sms", "sep", -0.54)
	line("dlp_sms", "sel", LX, -0.65, "DLP_SMS_SEL", F.amber, TXS)
	line("dlp_sms", "gun", LX, -0.75, "DLP_SMS_GUN", F.white, TXS)
	line("dlp_sms", "cm", LX, -0.85, "DLP_SMS_CM", F.white, TXS)
	line("dlp_sms", "tot", LX, -0.95, "DLP_SMS_TOT", F.grey, TXS)
	menu_btn("dlp_sms")

	-------------------------------------------------------------------
	-- v1.7 start-up screens and display-off mask: over every page above
	-------------------------------------------------------------------
	do
		local ok_b, err_b = pcall(dofile, LockOn_Options.script_path .. "DL/dl_boot_page.lua")
		if not ok_b and DL_dbg then DL_dbg("page", "dl_boot_page.lua: " .. tostring(err_b)) end
	end

	-------------------------------------------------------------------
	-- short alerts on every page: MISSILE LAUNCH (blinks), BINGO FUEL
	-- (not while the display is off or starting up)
	-------------------------------------------------------------------
	simple("dlp_alert", nil, {0, 0, 0}, {"DL_PAGE", "DL_BOOT"}, {{"parameter_in_range", 0, 0.5, 2.5}, {"parameter_in_range", 1, -0.5, 0.5}})
	if LAUNCH_ON then
		simple("dlp_launch", "dlp_alert", {0, 0, 0}, {"DLP_LAUNCH"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		mesh("dlp_launch_bg", "dlp_launch", "triangles", {{-0.55, 0.80}, {0.55, 0.80}, {0.55, 0.64}, {-0.55, 0.64}}, {0, 1, 2, 0, 2, 3}, M.black)
		box("dlp_launch", "box", 0, 0.72, 1.1, 0.16, M.hostile)
		text("dlp_launch_t", "dlp_launch", {0, 0.72, 0}, F.red, TXT, "CenterCenter", "MISSILE LAUNCH")
	end
	simple("dlp_bingo", "dlp_alert", {0, 0, 0}, {"DLP_BINGO_SHOW"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	mesh("dlp_bingo_bg", "dlp_bingo", "triangles", {{-0.6, 0.56}, {0.6, 0.56}, {0.6, 0.40}, {-0.6, 0.40}}, {0, 1, 2, 0, 2, 3}, M.black)
	box("dlp_bingo", "box", 0, 0.48, 1.2, 0.16, M.amber)
	line("dlp_bingo", "txt", 0, 0.48, "DLP_BINGO_TXT", F.amber, TXT, "CenterCenter")

	-- MENU label on the DL page too
	text("dlp_dl_menu", "dl_root", {ROW[3], YB, 0}, F.white, TXS, "CenterCenter", "MENU")

	-------------------------------------------------------------------
	-- brightness: a black see-through layer over every page (drawn last),
	-- one layer per step; DLP_DIM 0 = full brightness .. 9 = darkest
	-------------------------------------------------------------------
	simple("dlp_dim", nil, {0, 0, 0}, {"DL_PAGE"}, {{"parameter_in_range", 0, 0.5, 2.5}})
	for k = 1, 9 do
		local a = math.floor(255 * k / 10 + 0.5)
		mesh("dlp_dim_" .. k, "dlp_dim", "triangles", {{-1.1, 1.6}, {1.1, 1.6}, {1.1, -1.6}, {-1.1, -1.6}}, {0, 1, 2, 0, 2, 3},
			D.col(0, 0, 0, a), nil, {"DLP_DIM"}, {{"parameter_in_range", 0, k - 0.5, k + 0.5}})
	end
	-- "DAY BRT 7/10" for a moment after the rocker / switch is used (not dimmed)
	simple("dlp_brt", "dlp_dim", {0, 0, 0}, {"DLP_BRT_SHOW"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	mesh("dlp_brt_bg", "dlp_brt", "triangles", {{-0.5, 1.03}, {0.5, 1.03}, {0.5, 0.87}, {-0.5, 0.87}}, {0, 1, 2, 0, 2, 3}, M.black)
	box("dlp_brt", "box", 0, 0.95, 1.0, 0.16, M.amber)
	line("dlp_brt", "txt", 0, 0.95, "DLP_BRT_TXT", F.amber, TXS, "CenterCenter")
end
