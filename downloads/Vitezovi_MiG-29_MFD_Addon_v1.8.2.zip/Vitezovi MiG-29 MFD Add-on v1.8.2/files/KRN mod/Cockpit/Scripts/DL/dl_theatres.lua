-- Theatre recognition for the MiG-29 DL page.
-- Each entry: a DCS world point (x north, z east, metres) and the lat/lon it must map to
-- on that theatre. terrain.convertMetersToLatLon() tells us which theatre is loaded.
-- MarianasWWII uses the same projection as MarianaIslands; see marianas_variant() below.
DL_THEATRES = {
	{name = "Afghanistan", x = 62027.05, z = -24694.80, lat = 34.5, lon = 66.0},
	{name = "Caucasus", x = -197826.86, z = 634263.66, lat = 43.0, lon = 42.0},
	{name = "Falklands", x = 85851.38, z = 9429.48, lat = -51.7, lon = -59.0},
	{name = "GermanyColdWar", x = -303744.69, z = -692470.75, lat = 51.5, lon = 10.5},
	{name = "Iraq", x = -28326.03, z = -21127.78, lat = 33.0, lon = 44.0},
	{name = "Kola", x = 71255.16, z = 223084.19, lat = 68.5, lon = 28.0},
	{name = "MarianaIslands", x = 56798.69, z = 22397.44, lat = 14.0, lon = 145.0},
	{name = "Nevada", x = -369573.86, z = -59659.39, lat = 36.5, lon = -115.5},
	{name = "PersianGulf", x = -18387.56, z = -74371.13, lat = 26.0, lon = 55.5},
	{name = "Sinai", x = -6527.65, z = 169222.00, lat = 30.0, lon = 33.0},
	{name = "Syria", x = -4995.37, z = 100284.91, lat = 35.0, lon = 37.0},
}

-- v1.7.2: theatre names. Missions, the hook (T line) and .dtc files use
-- DCS's theatre id; the terrain folders (Mods\terrains\<folder>), the
-- chart files (DL\charts\<folder>.lua) and DL_detect_theatre() use the
-- folder name. They differ on three maps.
DL_THEATRE_ID_OF_FOLDER = {GermanyColdWar = "GermanyCW", Sinai = "SinaiMap", MarianasWWII = "MarianaIslandsWWII"}
DL_THEATRE_FOLDER_OF_ID = {GermanyCW = "GermanyColdWar", SinaiMap = "Sinai", MarianaIslandsWWII = "MarianasWWII"}
local function lc_lookup(t, name)
	local l = name:lower()
	for k, v in pairs(t) do if k:lower() == l then return v end end
	return nil
end
-- DCS theatre id for a theatre id or folder name ("" / nil -> nil)
function DL_theatre_id(name)
	if type(name) ~= "string" then return nil end
	name = name:gsub("^%s+", ""):gsub("%s+$", "")
	if name == "" then return nil end
	return lc_lookup(DL_THEATRE_ID_OF_FOLDER, name) or name
end
-- terrain folder name for a theatre id or folder name ("" / nil -> nil)
function DL_theatre_folder(name)
	if type(name) ~= "string" then return nil end
	name = name:gsub("^%s+", ""):gsub("%s+$", "")
	if name == "" then return nil end
	return lc_lookup(DL_THEATRE_FOLDER_OF_ID, name) or name
end
-- true when two names (id or folder, any case) mean the same theatre
function DL_same_theatre(a, b)
	local ia, ib = DL_theatre_id(a), DL_theatre_id(b)
	return ia ~= nil and ib ~= nil and ia:lower() == ib:lower()
end

-- MarianaIslands and MarianasWWII share one projection, so the reference
-- point cannot tell them apart. Ask the terrain (newer DCS), else go by
-- which of the two terrains is installed.
local function marianas_variant(terr)
	if type(terr.GetTerrainConfig) == "function" then
		local ok, id = pcall(terr.GetTerrainConfig, "id")
		if ok and type(id) == "string" and id ~= "" then
			if id:lower():find("wwii") then return "MarianasWWII" end
			return "MarianaIslands"
		end
	end
	local okl, lfs = pcall(require, "lfs")
	if okl and type(lfs) == "table" and lfs.attributes then
		local has = function(d)
			local ok, a = pcall(lfs.attributes, "Mods/terrains/" .. d)
			return ok and type(a) == "table" and a.mode == "directory"
		end
		if not has("MarianaIslands") and has("MarianasWWII") then return "MarianasWWII" end
	end
	return "MarianaIslands"
end

-- returns the theatre name (terrain folder name) or nil
function DL_detect_theatre()
	if DL_CFG and DL_CFG.force_theatre and DL_CFG.force_theatre ~= "" then
		return DL_CFG.force_theatre
	end
	local ok, terr = pcall(require, "terrain")
	if not ok or type(terr) ~= "table" or not terr.convertMetersToLatLon then
		return nil
	end
	for _, t in ipairs(DL_THEATRES) do
		local ok2, lat, lon = pcall(terr.convertMetersToLatLon, t.x, t.z)
		if ok2 and lat and lon and math.abs(lat - t.lat) < 0.05 and math.abs(lon - t.lon) < 0.05 then
			if t.name == "MarianaIslands" then
				local okm, v = pcall(marianas_variant, terr)
				return okm and v or t.name
			end
			return t.name
		end
	end
	return nil
end

-- v1.7.8: element budget for the moving map. The page builds one textured
-- quad per chart tile AND range step (Syria 1024, Caucasus 739, Kola 6720),
-- and spawning with such a page crashed DCS while it built the cockpit
-- (Nov 2026; no crash with the map off). Range steps get the chart in the
-- order 3, 2, 4, 1, 5 while the quads stay within map_max_quads (default
-- 300); the others show no chart. map_max_quads = 0 = no limit (as before).
function DL_chart_budget(chart)
	local cfg = DL_CFG or {}
	local budget = cfg.map_max_quads or 300
	local per = {}
	for _, t in ipairs(chart.tiles) do per[t[6]] = (per[t[6]] or 0) + 1 end
	local keep, used = {}, 0
	for _, ri in ipairs(cfg.map_range_order or {3, 2, 4, 1, 5}) do
		local ci = chart.range_class[ri]
		if ci and ci > 0 then
			local cost = per[ci] or 0
			if used + cost <= budget then keep[ri] = ci; used = used + cost end
		end
	end
	local rc = {}
	for ri = 1, #chart.range_class do rc[ri] = keep[ri] or 0 end
	chart.range_class_full, chart.range_class, chart.quads = chart.range_class, rc, used
end

-- v1.7.8: where the jet is while the MFD page is built (the moving map is
-- built around it). Returns x, z, source - or nil, nil, source.
--  1. the cockpit's own aircraft data, if the page's Lua state has it
--  2. Saved Games\DCS\Vitezovi-MFD-Addon\map_pos.txt, written by the
--     device every 30 s (same theatre only: the last flight's position)
-- "ic=" lists the keys of LockOn_Options.init_conditions (diagnostics).
function DL_map_pos(theatre)
	local ic = ""
	pcall(function()
		local t = LockOn_Options and LockOn_Options.init_conditions
		if type(t) == "table" then
			local k = {}
			for key, v in pairs(t) do k[#k + 1] = tostring(key) .. ((type(v) == "number") and ("=" .. string.format("%.0f", v)) or "") end
			table.sort(k)
			ic = " ic=" .. table.concat(k, ","):sub(1, 200)
		end
	end)
	for _, fname in ipairs({"get_base_data", "sensor_data"}) do
		local ok, x, z = pcall(function()
			local g = _G or getfenv(1)
			local f = g[fname]
			local d = (type(f) == "function") and f() or f
			if type(d) ~= "table" and type(d) ~= "userdata" then return nil end
			local cx, _, cz = d.getSelfCoordinates()
			return cx, cz
		end)
		if ok and type(x) == "number" and type(z) == "number" and (x ~= 0 or z ~= 0) then return x, z, fname .. ic end
	end
	local ok, x, z = pcall(function()
		local okl, l = pcall(require, "lfs")
		if not (okl and type(l) == "table" and l.writedir) then return nil end
		local f = io.open(l.writedir() .. "Vitezovi-MFD-Addon/map_pos.txt", "r")
		if not f then return nil end
		local line = f:read("*l") or ""
		f:close()
		local th, sx, sz = line:match("^(%S*)%s+(%S+)%s+(%S+)")
		if th and th ~= "" and theatre and th:lower() == tostring(theatre):lower() then return tonumber(sx), tonumber(sz) end
		return nil
	end)
	if ok and type(x) == "number" and type(z) == "number" then return x, z, "last flight" .. ic end
	return nil, nil, "no position" .. ic
end

-- v1.7.8: which source class a range step uses (0 = the last one before
-- it that has one; the C# chart builder does the same)
local function src_class(rc, ri)
	local last = 0
	for i = 1, math.min(#rc, ri) do if (rc[i] or 0) > 0 then last = rc[i] end end
	if last == 0 then for i = 1, #rc do if (rc[i] or 0) > 0 then last = rc[i]; break end end end
	return last
end

-- v1.7.8: a chart built by INSTALL (DL/charts_gen/<theatre>.lua): DCS's
-- tiles joined into a few big textures per sharpness ("layer"). Each range
-- step gets the coarsest layer that is about as sharp as the screen
-- (range / screen_px metres per texel, 25 % slack as in the builder's
-- Slack, so km and nm steps share layers), from the chart series DCS
-- uses at that range. range_class[ri] = layer number (= t[6] of its tiles).
function DL_gen_ranges(chart, cfg)
	local nm = (cfg.range_units == "nm")
	local ranges = (nm and cfg.ranges_nm or cfg.ranges_km) or {}
	local unit = nm and 1852.0 or 1000.0
	local rc = {}
	for ri, r in ipairs(ranges) do
		local cls = src_class(chart.src_range_class or {}, ri)
		local target = (tonumber(r) or 0) * unit / (chart.screen_px or 300)
		local best, bm, fine, fm = 0, -1, 0, 1e18
		for li, l in ipairs(chart.layers or {}) do
			if l.cls == cls then
				if l.mpp <= target * 1.25 and l.mpp > bm then best, bm = li, l.mpp end
				if l.mpp < fm then fine, fm = li, l.mpp end
			end
		end
		rc[ri] = (best > 0) and best or fine
	end
	chart.range_class = rc
end

-- loads DL/charts_gen/<theatre>.lua (built by INSTALL; DL_CFG.map_built =
-- false: not used) or else DL/charts/<theatre>.lua into DL_CHART (nil if
-- there is none)
function DL_load_chart(theatre)
	DL_CHART = nil
	if not theatre then return nil end
	local cfg = DL_CFG or {}
	if cfg.map_built ~= false then
		local okg = pcall(dofile, LockOn_Options.script_path .. "DL/charts_gen/" .. theatre .. ".lua")
		if okg and DL_CHART and DL_CHART.gen and DL_CHART.tiles and #DL_CHART.tiles > 0 then
			pcall(DL_gen_ranges, DL_CHART, cfg)
			return DL_CHART
		end
		DL_CHART = nil
	end
	local path = LockOn_Options.script_path .. "DL/charts/" .. theatre .. ".lua"
	local ok = pcall(dofile, path)
	if ok and DL_CHART and DL_CHART.tiles then
		return DL_CHART
	end
	DL_CHART = nil
	return nil
end
