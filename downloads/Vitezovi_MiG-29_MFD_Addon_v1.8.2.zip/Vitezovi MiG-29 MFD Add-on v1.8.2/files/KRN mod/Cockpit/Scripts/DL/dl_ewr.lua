-----------------------------------------------------------------------
-- MiG-29 DL page: EWR picture from server text messages (v1.7.8)
-- Some servers block export (no LoGetWorldObjects, so no datalink picture)
-- but send an "EWR ... Picture Report" trigger text. The hook
-- (MiG29DL_Hook.lua, onTriggerMessage) forwards that text as packet
-- MIG29DLE; this file turns its lines into contacts in the device's
-- format, placed from the jet's position when the report arrived.
--   "<Server> EWR | Friendly Picture Report"  -> friendly (code 1)
--   "<Server> EWR | Picture Report"           -> hostile  (code 2)
--   line: TYPE BRG RNG NM ALT ft SPD Knts HDG [name / aspect]
--   (v1.7.9: or km / m / km/h, see parse_line)
-- A new block of one kind replaces the old contacts of that kind. They
-- move along their heading between reports (at most ewr_extrapolate_s)
-- and are dropped after ewr_keep_s.
-- Contacts: c[0] code, c[1] x, c[2] z, c[3] alt, c[4] vx, c[5] vz,
-- c[6] age, c.t time, c.nm type, c.ewr = true, c.mx extrapolation cap.
-----------------------------------------------------------------------
DL_EWR = {fr = nil, hs = nil, t_fr = nil, t_hs = nil, n = 0}
local CFG = DL_CFG or {}
local NM, FT, KT = 1852, 0.3048, 0.514444
local RAD = math.pi / 180

local function keep() return CFG.ewr_keep_s or 180 end

-- "F/A-18  139  19.8 NM  12,000 ft  674 Knts  316  Hot"
-- v1.7.9: metric servers too: "Su-27  139  36.7 km  3,658 m  1248 km/h  316"
-- RNG in NM / km / m, ALT in ft / m / km, SPD in kts / km/h / mph / m/s.
-- (TYPE may hold spaces: "Mirage F1"; the units anchor it. A row with a
-- unit not in these lists is left out rather than drawn in the wrong place.)
local LINE = "^%s*(.-)%s+(%d+)%s+([%d,%.]+)%s*(%a+)%s+(%-?[%d,%.]+)%s*(%a+)%s+([%d,%.]+)%s*([%a/]+)%s+(%d+)%s*(.-)%s*$"
local U_RNG = {nm = NM, km = 1000, m = 1}
local U_ALT = {ft = FT, feet = FT, m = 1, km = 1000}
local U_SPD = {kts = KT, knts = KT, knots = KT, kt = KT, kn = KT, kph = 1 / 3.6, kmh = 1 / 3.6, ["km/h"] = 1 / 3.6,
               kmph = 1 / 3.6, mph = 0.44704, ["m/s"] = 1, mps = 1}
local function num(s) return tonumber((s:gsub(",", ""))) end

-- one row -> {type, brg (deg), rng (m), alt (m), spd (m/s), hdg (deg), rest} or nil
function DL_EWR.parse_line(line)
	local ty, brg, rng, ur, alt, ua, spd, us, hdg, rest = line:match(LINE)
	if not ty or ty == "" or ty:upper() == "TYPE" then return nil end
	local fr, fa, fs = U_RNG[ur:lower()], U_ALT[ua:lower()], U_SPD[us:lower()]
	if not (fr and fa and fs) then return nil end
	brg, rng, alt, spd, hdg = tonumber(brg), num(rng), num(alt), num(spd), tonumber(hdg)
	if not (brg and rng and alt and spd and hdg) then return nil end
	return {type = ty, brg = brg, rng = rng * fr, alt = alt * fa, spd = spd * fs, hdg = hdg, rest = rest}
end

-- the report's lines -> {fr = {...} or nil, hs = {...} or nil} (raw rows)
function DL_EWR.split(text)
	local out, cur = {}, nil
	for line in tostring(text or ""):gmatch("[^\r\n]+") do
		local u = line:upper()
		if u:find("PICTURE REPORT", 1, true) or u:find("PICTURE", 1, true) and u:find("EWR", 1, true) then
			cur = u:find("FRIENDLY", 1, true) and "fr" or "hs"
			out[cur] = out[cur] or {}
		elseif cur then
			local r = DL_EWR.parse_line(line)
			if r then local l = out[cur]; l[#l + 1] = r end
		end
	end
	return out
end

-- rows -> contacts. ox, oz: own position (x north, z east, metres);
-- decl: magnetic declination in radians (true = magnetic + decl), used
-- when ewr_bearing = "magnetic"
local function to_contacts(rows, code, t, ox, oz, decl)
	local mag = CFG.ewr_bearing == "magnetic"
	local d = mag and (decl or 0) or 0
	local mx = CFG.ewr_extrapolate_s or 120
	local list = {}
	for _, r in ipairs(rows) do
		local b = r.brg * RAD + d
		local h = r.hdg * RAD + d
		local R, v = r.rng, r.spd          -- metres, m/s (parse_line converts)
		list[#list + 1] = {[0] = code, ox + R * math.cos(b), oz + R * math.sin(b), r.alt,
		                   v * math.cos(h), v * math.sin(h), 0,
		                   t = t, nm = r.type, ewr = true, mx = mx}
	end
	return list
end

-- a MIG29DLE packet. Returns true when it held a report.
function DL_EWR.on_packet(data, t, ox, oz, decl)
	if CFG.ewr_enabled == false or not ox or not oz then return false end
	local s = DL_EWR.split(data)
	local got = false
	if s.fr then DL_EWR.fr, DL_EWR.t_fr, got = to_contacts(s.fr, 1, t, ox, oz, decl), t, true end
	if s.hs then DL_EWR.hs, DL_EWR.t_hs, got = to_contacts(s.hs, 2, t, ox, oz, decl), t, true end
	if got then DL_EWR.n = DL_EWR.n + 1 end
	return got
end

local function alive(tt, t) return tt and t - tt <= keep() and t >= tt end

-- any EWR report still shown (the SA page is not "NO DL" while one is)
function DL_EWR.fresh(t) return alive(DL_EWR.t_fr, t) or alive(DL_EWR.t_hs, t) end

-- forget reports that are too old; true when something was dropped
function DL_EWR.expire(t)
	local x = false
	if DL_EWR.t_fr and not alive(DL_EWR.t_fr, t) then DL_EWR.fr, DL_EWR.t_fr, x = nil, nil, true end
	if DL_EWR.t_hs and not alive(DL_EWR.t_hs, t) then DL_EWR.hs, DL_EWR.t_hs, x = nil, nil, true end
	return x
end

-- the datalink list plus the EWR contacts. With a datalink picture (export
-- allowed: contacts that are not own radar) the EWR is left out unless
-- ewr_with_datalink = true: it would draw every aircraft twice.
function DL_EWR.merge(list, t)
	list = list or {}
	if not (DL_EWR.fr or DL_EWR.hs) or CFG.ewr_enabled == false then return list end
	if CFG.ewr_with_datalink ~= true then
		for _, c in ipairs(list) do if (c[0] or 0) < 10 then return list end end
	end
	local out = {}
	for i, c in ipairs(list) do out[i] = c end
	for _, l in ipairs({DL_EWR.fr or {}, DL_EWR.hs or {}}) do
		for _, c in ipairs(l) do out[#out + 1] = c end
	end
	return out
end
