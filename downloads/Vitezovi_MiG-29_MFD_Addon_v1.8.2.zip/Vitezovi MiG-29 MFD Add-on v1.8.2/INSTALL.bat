@echo off
setlocal
title Vitezovi MiG-29 MFD add-on - install
rem started from inside the zip, Windows unpacks only this file: the
rem installer next to it is missing then
if exist "%~dp0installer\vitezovi_install.ps1" goto have_files
echo.
echo  Unzip the whole folder first, then run INSTALL.bat from there.
echo  (Windows started INSTALL.bat from inside the zip - the rest of the add-on is not next to it.)
echo.
pause
exit /b 1
:have_files
echo.
echo  Vitezovi MiG-29 MFD add-on v1.8.2
echo  for "MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3"
echo.
echo  KRN's mod must be installed first (Saved Games\DCS\Mods\tech).
echo  Close DCS before continuing.
echo.
pause
rem options are passed on to the installer, e.g. INSTALL.bat -SavedGames "D:\Saved Games\DCS"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\vitezovi_install.ps1" %*
echo.
pause
