// Vitezovi MiG-29 MFD add-on: moving-map chart builder (compiled by the
// installer with PowerShell's Add-Type; plain C# 5 / .NET Framework 4.5,
// nothing outside mscorlib / System.dll).
//
// v1.7.8: DCS's raster charts come as hundreds or thousands of 1024 px
// tiles. One MFD element per tile and range step crashed DCS while it
// built the cockpit. This joins the tiles of a theatre into a few big
// textures ("layers", one per sharpness that the range steps need), so the
// MFD page needs only a few dozen elements for the whole map at every range.
//  * reads the tiles straight from DCS's chart zips (own zip reader, Zip64 too)
//  * decodes DDS: DXT1 / DXT3 / DXT5 / BC1-3 (DX10 header) / 32-bit RGBA
//  * resamples onto the new grid (bilinear, from the mip level that fits)
//  * writes DXT1 DDS files (1-bit alpha, full mip chain) and the index
//    DL\charts_gen\<theatre>.lua that the MFD reads instead of DL\charts
using System;
using System.IO;
using System.IO.Compression;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

public static class VitezoviCharts
{
	public const string Version = "2";
	static readonly CultureInfo IC = CultureInfo.InvariantCulture;

	// ------------------------------------------------------------ zip
	class ZipEntryInfo { public string Zip; public long Offset; public long CSize; public long USize; public int Method; }

	static ushort U16(byte[] b, int o) { return (ushort)(b[o] | b[o + 1] << 8); }
	static uint U32(byte[] b, int o) { return (uint)(b[o] | b[o + 1] << 8 | b[o + 2] << 16 | b[o + 3] << 24); }
	static long U64(byte[] b, int o) { return (long)U32(b, o) | ((long)U32(b, o + 4) << 32); }

	static byte[] ReadAt(FileStream f, long pos, int n)
	{
		byte[] b = new byte[n];
		f.Seek(pos, SeekOrigin.Begin);
		int got = 0;
		while (got < n)
		{
			int r = f.Read(b, got, n - got);
			if (r <= 0) throw new IOException("unexpected end of file");
			got += r;
		}
		return b;
	}

	// file name (lower case, no folder) -> entry, for every zip
	static void IndexZip(string path, Dictionary<string, ZipEntryInfo> map)
	{
		using (FileStream f = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
		{
			long len = f.Length;
			int tail = (int)Math.Min(len, 65536 + 22);
			byte[] t = ReadAt(f, len - tail, tail);
			int e = -1;
			for (int i = tail - 22; i >= 0; i--) { if (U32(t, i) == 0x06054b50) { e = i; break; } }
			if (e < 0) throw new IOException("not a zip file: " + path);
			long count = U16(t, e + 10);
			long cdSize = U32(t, e + 12);
			long cdOff = U32(t, e + 16);
			if (count == 0xFFFF || cdSize == 0xFFFFFFFF || cdOff == 0xFFFFFFFF)
			{
				// Zip64: locator just before the end record
				if (e < 20 || U32(t, e - 20) != 0x07064b50) throw new IOException("bad zip64 file: " + path);
				long e64 = U64(t, e - 20 + 8);
				byte[] r = ReadAt(f, e64, 56);
				if (U32(r, 0) != 0x06064b50) throw new IOException("bad zip64 record: " + path);
				count = U64(r, 32); cdSize = U64(r, 40); cdOff = U64(r, 48);
			}
			byte[] cd = ReadAt(f, cdOff, (int)cdSize);
			int p = 0;
			for (long n = 0; n < count && p + 46 <= cd.Length; n++)
			{
				if (U32(cd, p) != 0x02014b50) break;
				int method = U16(cd, p + 10);
				long cs = U32(cd, p + 20), us = U32(cd, p + 24);
				int nl = U16(cd, p + 28), el = U16(cd, p + 30), kl = U16(cd, p + 32);
				long lo = U32(cd, p + 42);
				string name = Encoding.UTF8.GetString(cd, p + 46, nl);
				int x = p + 46 + nl, xe = x + el;
				while (x + 4 <= xe)
				{
					int id = U16(cd, x), sz = U16(cd, x + 2);
					if (id == 1)
					{
						int q = x + 4;
						if (us == 0xFFFFFFFF) { us = U64(cd, q); q += 8; }
						if (cs == 0xFFFFFFFF) { cs = U64(cd, q); q += 8; }
						if (lo == 0xFFFFFFFF) { lo = U64(cd, q); q += 8; }
					}
					x += 4 + sz;
				}
				p = xe + kl;
				string key = name.Replace('\\', '/');
				int sl = key.LastIndexOf('/');
				if (sl >= 0) key = key.Substring(sl + 1);
				key = key.ToLowerInvariant();
				if (key.Length == 0 || map.ContainsKey(key)) continue;
				ZipEntryInfo z = new ZipEntryInfo();
				z.Zip = path; z.Offset = lo; z.CSize = cs; z.USize = us; z.Method = method;
				map[key] = z;
			}
		}
	}

	static byte[] ReadEntry(ZipEntryInfo z)
	{
		using (FileStream f = new FileStream(z.Zip, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16))
		{
			byte[] h = ReadAt(f, z.Offset, 30);
			if (U32(h, 0) != 0x04034b50) throw new IOException("bad zip entry in " + z.Zip);
			long data = z.Offset + 30 + U16(h, 26) + U16(h, 28);
			if (z.USize > int.MaxValue) throw new IOException("zip entry too big");
			byte[] o = new byte[z.USize];
			if (z.Method == 0) return ReadAt(f, data, (int)z.USize);
			if (z.Method != 8) throw new IOException("zip method " + z.Method + " not supported");
			f.Seek(data, SeekOrigin.Begin);
			using (DeflateStream d = new DeflateStream(f, CompressionMode.Decompress, true))
			{
				int got = 0;
				while (got < o.Length)
				{
					int r = d.Read(o, got, o.Length - got);
					if (r <= 0) break;
					got += r;
				}
				if (got != o.Length) throw new IOException("zip entry cut short in " + z.Zip);
			}
			return o;
		}
	}

	// ------------------------------------------------------------ DDS read
	class Img { public int W; public int H; public byte[] Px; }   // RGBA, row 0 = first row of the file

	// format: 1 = BC1, 2 = BC2, 3 = BC3, 4 = 32-bit (mask order in rgbaShift)
	static bool DdsInfo(byte[] b, out int w, out int h, out int mips, out int fmt, out int data, out int[] sh)
	{
		w = h = mips = fmt = data = 0; sh = null;
		if (b.Length < 128 || U32(b, 0) != 0x20534444) return false;
		h = (int)U32(b, 12); w = (int)U32(b, 16);
		mips = Math.Max(1, (int)U32(b, 28));
		uint pfFlags = U32(b, 80), four = U32(b, 84);
		data = 128;
		if ((pfFlags & 4) != 0)
		{
			string fc = Encoding.ASCII.GetString(b, 84, 4);
			if (fc == "DXT1") fmt = 1;
			else if (fc == "DXT2" || fc == "DXT3") fmt = 2;
			else if (fc == "DXT4" || fc == "DXT5") fmt = 3;
			else if (fc == "DX10")
			{
				if (b.Length < 148) return false;
				uint dx = U32(b, 128);
				data = 148;
				if (dx == 70 || dx == 71 || dx == 72) fmt = 1;
				else if (dx == 73 || dx == 74 || dx == 75) fmt = 2;
				else if (dx == 76 || dx == 77 || dx == 78) fmt = 3;
				else if (dx == 27 || dx == 28 || dx == 29) { fmt = 4; sh = new int[] { 0, 8, 16, 24 }; }
				else if (dx == 87 || dx == 90 || dx == 91) { fmt = 4; sh = new int[] { 16, 8, 0, 24 }; }
				else return false;
			}
			else return false;
			return true;
		}
		if ((pfFlags & 0x40) != 0 && U32(b, 88) == 32)
		{
			fmt = 4;
			sh = new int[] { Shift(U32(b, 92)), Shift(U32(b, 96)), Shift(U32(b, 100)), ((pfFlags & 1) != 0) ? Shift(U32(b, 104)) : -1 };
			return true;
		}
		return false;
	}
	static int Shift(uint m) { if (m == 0) return -1; int s = 0; while ((m & 1) == 0) { m >>= 1; s++; } return s; }

	static int LevelBytes(int fmt, int w, int h)
	{
		if (fmt == 4) return w * h * 4;
		int bw = Math.Max(1, (w + 3) / 4), bh = Math.Max(1, (h + 3) / 4);
		return bw * bh * (fmt == 1 ? 8 : 16);
	}

	// decodes mip level `level` (or the smallest there is)
	static Img DecodeDds(byte[] b, int level)
	{
		int w, h, mips, fmt, off; int[] sh;
		if (!DdsInfo(b, out w, out h, out mips, out fmt, out off, out sh)) return null;
		if (level > mips - 1) level = mips - 1;
		for (int i = 0; i < level; i++)
		{
			off += LevelBytes(fmt, w, h);
			w = Math.Max(1, w / 2); h = Math.Max(1, h / 2);
		}
		if (off + LevelBytes(fmt, w, h) > b.Length) return null;
		Img im = new Img(); im.W = w; im.H = h; im.Px = new byte[w * h * 4];
		if (fmt == 4)
		{
			for (int i = 0; i < w * h; i++)
			{
				uint v = U32(b, off + i * 4);
				for (int c = 0; c < 4; c++) im.Px[i * 4 + c] = (byte)(sh[c] < 0 ? 255 : (v >> sh[c]) & 255);
			}
			return im;
		}
		int bs = fmt == 1 ? 8 : 16;
		int bw = Math.Max(1, (w + 3) / 4), bh = Math.Max(1, (h + 3) / 4);
		byte[] col = new byte[16];
		byte[] alpha = new byte[16];
		for (int by = 0; by < bh; by++)
		{
			for (int bx = 0; bx < bw; bx++)
			{
				int p = off + (by * bw + bx) * bs;
				int cp = p;
				if (fmt == 2)
				{
					for (int i = 0; i < 16; i++) { int v = (b[p + i / 2] >> ((i & 1) * 4)) & 15; alpha[i] = (byte)(v * 17); }
					cp = p + 8;
				}
				else if (fmt == 3)
				{
					int a0 = b[p], a1 = b[p + 1];
					byte[] pal = new byte[8];
					pal[0] = (byte)a0; pal[1] = (byte)a1;
					if (a0 > a1) { for (int i = 1; i < 7; i++) pal[i + 1] = (byte)(((7 - i) * a0 + i * a1) / 7); }
					else { for (int i = 1; i < 5; i++) pal[i + 1] = (byte)(((5 - i) * a0 + i * a1) / 5); pal[6] = 0; pal[7] = 255; }
					ulong bits = 0;
					for (int i = 0; i < 6; i++) bits |= (ulong)b[p + 2 + i] << (8 * i);
					for (int i = 0; i < 16; i++) alpha[i] = pal[(int)((bits >> (3 * i)) & 7)];
					cp = p + 8;
				}
				int c0 = U16(b, cp), c1 = U16(b, cp + 2);
				uint idx = U32(b, cp + 4);
				byte[,] pc = new byte[4, 4];
				Unpack565(c0, pc, 0); Unpack565(c1, pc, 1);
				bool four = c0 > c1 || fmt != 1;
				for (int c = 0; c < 3; c++)
				{
					if (four)
					{
						pc[2, c] = (byte)((2 * pc[0, c] + pc[1, c]) / 3);
						pc[3, c] = (byte)((pc[0, c] + 2 * pc[1, c]) / 3);
					}
					else { pc[2, c] = (byte)((pc[0, c] + pc[1, c]) / 2); pc[3, c] = 0; }
				}
				pc[0, 3] = pc[1, 3] = pc[2, 3] = 255; pc[3, 3] = (byte)(four ? 255 : 0);
				for (int i = 0; i < 16; i++)
				{
					int x = bx * 4 + (i & 3), y = by * 4 + (i >> 2);
					if (x >= w || y >= h) continue;
					int k = (int)((idx >> (2 * i)) & 3);
					int o = (y * w + x) * 4;
					im.Px[o] = pc[k, 0]; im.Px[o + 1] = pc[k, 1]; im.Px[o + 2] = pc[k, 2];
					im.Px[o + 3] = fmt == 1 ? pc[k, 3] : alpha[i];
				}
			}
		}
		return im;
	}
	static void Unpack565(int c, byte[,] pc, int i)
	{
		int r = (c >> 11) & 31, g = (c >> 5) & 63, b = c & 31;
		pc[i, 0] = (byte)((r << 3) | (r >> 2)); pc[i, 1] = (byte)((g << 2) | (g >> 4)); pc[i, 2] = (byte)((b << 3) | (b >> 2));
	}

	// ------------------------------------------------------------ DXT1 write
	static int Pack565(double r, double g, double b)
	{
		int R = (int)Math.Round(Clamp(r) * 31 / 255.0), G = (int)Math.Round(Clamp(g) * 63 / 255.0), B = (int)Math.Round(Clamp(b) * 31 / 255.0);
		return (R << 11) | (G << 5) | B;
	}
	static double Clamp(double v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

	static void EncodeBlock(byte[] px, int w, int h, int bx, int by, byte[] o, int op)
	{
		double[] cr = new double[16], cg = new double[16], cb = new double[16];
		bool[] op_ = new bool[16];
		int n = 0; bool anyClear = false;
		double mr = 0, mg = 0, mb = 0;
		for (int i = 0; i < 16; i++)
		{
			int x = Math.Min(w - 1, bx * 4 + (i & 3)), y = Math.Min(h - 1, by * 4 + (i >> 2));
			int p = (y * w + x) * 4;
			cr[i] = px[p]; cg[i] = px[p + 1]; cb[i] = px[p + 2];
			op_[i] = px[p + 3] >= 128;
			if (op_[i]) { n++; mr += cr[i]; mg += cg[i]; mb += cb[i]; } else anyClear = true;
		}
		if (n == 0)
		{
			o[op] = 0; o[op + 1] = 0; o[op + 2] = 0; o[op + 3] = 0;
			o[op + 4] = o[op + 5] = o[op + 6] = o[op + 7] = 0xFF;
			return;
		}
		mr /= n; mg /= n; mb /= n;
		// principal axis (power iteration on the covariance)
		double xx = 0, xy = 0, xz = 0, yy = 0, yz = 0, zz = 0;
		for (int i = 0; i < 16; i++)
		{
			if (!op_[i]) continue;
			double r = cr[i] - mr, g = cg[i] - mg, b = cb[i] - mb;
			xx += r * r; xy += r * g; xz += r * b; yy += g * g; yz += g * b; zz += b * b;
		}
		double ar = 1, ag = 1, ab = 1;
		for (int it = 0; it < 6; it++)
		{
			double nr = xx * ar + xy * ag + xz * ab, ng = xy * ar + yy * ag + yz * ab, nb = xz * ar + yz * ag + zz * ab;
			double l = Math.Sqrt(nr * nr + ng * ng + nb * nb);
			if (l < 1e-9) break;
			ar = nr / l; ag = ng / l; ab = nb / l;
		}
		double lo = 1e9, hi = -1e9;
		for (int i = 0; i < 16; i++)
		{
			if (!op_[i]) continue;
			double t = (cr[i] - mr) * ar + (cg[i] - mg) * ag + (cb[i] - mb) * ab;
			if (t < lo) lo = t; if (t > hi) hi = t;
		}
		int e0 = Pack565(mr + ar * hi, mg + ag * hi, mb + ab * hi);
		int e1 = Pack565(mr + ar * lo, mg + ag * lo, mb + ab * lo);
		int c0, c1;
		if (anyClear) { c0 = Math.Min(e0, e1); c1 = Math.Max(e0, e1); }        // 3 colours + clear
		else if (e0 == e1) { c0 = e0; c1 = e1; }
		else { c0 = Math.Max(e0, e1); c1 = Math.Min(e0, e1); }
		byte[,] pc = new byte[4, 4];
		Unpack565(c0, pc, 0); Unpack565(c1, pc, 1);
		int ncol;
		if (c0 > c1)
		{
			for (int c = 0; c < 3; c++) { pc[2, c] = (byte)((2 * pc[0, c] + pc[1, c]) / 3); pc[3, c] = (byte)((pc[0, c] + 2 * pc[1, c]) / 3); }
			ncol = 4;
		}
		else
		{
			for (int c = 0; c < 3; c++) pc[2, c] = (byte)((pc[0, c] + pc[1, c]) / 2);
			ncol = 3;
		}
		uint idx = 0;
		for (int i = 0; i < 16; i++)
		{
			int best = 3;
			if (op_[i] || !anyClear)
			{
				double bd = 1e18; best = 0;
				for (int k = 0; k < ncol; k++)
				{
					double dr = cr[i] - pc[k, 0], dg = cg[i] - pc[k, 1], db = cb[i] - pc[k, 2];
					double d = dr * dr * 0.3 + dg * dg * 0.59 + db * db * 0.11;
					if (d < bd) { bd = d; best = k; }
				}
			}
			idx |= (uint)best << (2 * i);
		}
		o[op] = (byte)c0; o[op + 1] = (byte)(c0 >> 8); o[op + 2] = (byte)c1; o[op + 3] = (byte)(c1 >> 8);
		o[op + 4] = (byte)idx; o[op + 5] = (byte)(idx >> 8); o[op + 6] = (byte)(idx >> 16); o[op + 7] = (byte)(idx >> 24);
	}

	static byte[] Half(byte[] px, int w, int h)
	{
		int w2 = Math.Max(1, w / 2), h2 = Math.Max(1, h / 2);
		byte[] o = new byte[w2 * h2 * 4];
		for (int y = 0; y < h2; y++)
		{
			for (int x = 0; x < w2; x++)
			{
				double r = 0, g = 0, b = 0, a = 0;
				for (int k = 0; k < 4; k++)
				{
					int sx = Math.Min(w - 1, x * 2 + (k & 1)), sy = Math.Min(h - 1, y * 2 + (k >> 1));
					int p = (sy * w + sx) * 4;
					double al = px[p + 3];
					r += px[p] * al; g += px[p + 1] * al; b += px[p + 2] * al; a += al;
				}
				int q = (y * w2 + x) * 4;
				if (a > 0) { o[q] = (byte)(r / a + 0.5); o[q + 1] = (byte)(g / a + 0.5); o[q + 2] = (byte)(b / a + 0.5); }
				o[q + 3] = (byte)(a / 4 + 0.5);
			}
		}
		return o;
	}

	static void WriteDxt1(string path, byte[] px, int w, int h)
	{
		int mips = 1;
		while ((w >> mips) > 0 || (h >> mips) > 0) mips++;
		using (FileStream f = new FileStream(path, FileMode.Create, FileAccess.Write))
		{
			byte[] hd = new byte[128];
			Put(hd, 0, 0x20534444); Put(hd, 4, 124); Put(hd, 8, 0x1 | 0x2 | 0x4 | 0x1000 | 0x20000 | 0x80000);
			Put(hd, 12, (uint)h); Put(hd, 16, (uint)w); Put(hd, 20, (uint)LevelBytes(1, w, h)); Put(hd, 28, (uint)mips);
			Put(hd, 76, 32); Put(hd, 80, 4); hd[84] = (byte)'D'; hd[85] = (byte)'X'; hd[86] = (byte)'T'; hd[87] = (byte)'1';
			Put(hd, 108, 0x1000 | 0x8 | 0x400000);
			f.Write(hd, 0, 128);
			int cw = w, ch = h;
			byte[] cur = px;
			for (int m = 0; m < mips; m++)
			{
				int bw = Math.Max(1, (cw + 3) / 4), bh = Math.Max(1, (ch + 3) / 4);
				byte[] o = new byte[bw * bh * 8];
				for (int by = 0; by < bh; by++)
					for (int bx = 0; bx < bw; bx++)
						EncodeBlock(cur, cw, ch, bx, by, o, (by * bw + bx) * 8);
				f.Write(o, 0, o.Length);
				if (m + 1 < mips) { cur = Half(cur, cw, ch); cw = Math.Max(1, cw / 2); ch = Math.Max(1, ch / 2); }
			}
		}
	}
	static void Put(byte[] b, int o, uint v) { b[o] = (byte)v; b[o + 1] = (byte)(v >> 8); b[o + 2] = (byte)(v >> 16); b[o + 3] = (byte)(v >> 24); }

	// ------------------------------------------------------------ chart index (DL\charts\<theatre>.lua)
	class Tile { public string Name; public double Xs, Zw, Xn, Ze; public int Cls; }
	class Chart { public List<string> Zips = new List<string>(); public double[] Classes; public int[] RangeClass; public List<Tile> Tiles = new List<Tile>(); }

	static double[] Nums(string s)
	{
		List<double> l = new List<double>();
		foreach (string p in s.Split(',')) { string q = p.Trim(); if (q.Length > 0) l.Add(double.Parse(q, IC)); }
		return l.ToArray();
	}

	static Chart ReadChart(string luaPath)
	{
		string s = File.ReadAllText(luaPath);
		Chart c = new Chart();
		foreach (Match m in Regex.Matches(s, "\"([^\"]+\\.zip)\"", RegexOptions.IgnoreCase)) c.Zips.Add(m.Groups[1].Value);
		Match mc = Regex.Match(s, @"classes\s*=\s*\{([^}]*)\}");
		Match mr = Regex.Match(s, @"range_class\s*=\s*\{([^}]*)\}");
		if (!mc.Success || !mr.Success) throw new IOException("chart index without classes / range_class: " + luaPath);
		c.Classes = Nums(mc.Groups[1].Value);
		double[] rc = Nums(mr.Groups[1].Value);
		c.RangeClass = new int[rc.Length];
		for (int i = 0; i < rc.Length; i++) c.RangeClass[i] = (int)rc[i];
		string num = @"\s*(-?[0-9.]+)\s*";
		foreach (Match m in Regex.Matches(s, "\\{\\s*\"([^\"]+)\"\\s*," + num + "," + num + "," + num + "," + num + ",\\s*([0-9]+)\\s*\\}"))
		{
			Tile t = new Tile();
			t.Name = m.Groups[1].Value;
			t.Xs = double.Parse(m.Groups[2].Value, IC); t.Zw = double.Parse(m.Groups[3].Value, IC);
			t.Xn = double.Parse(m.Groups[4].Value, IC); t.Ze = double.Parse(m.Groups[5].Value, IC);
			t.Cls = int.Parse(m.Groups[6].Value, IC);
			c.Tiles.Add(t);
		}
		return c;
	}

	// which source class a range step uses (as the MFD does: 0 = the last one that has one)
	public static int SourceClass(int[] rc, int ri)
	{
		int last = 0;
		for (int i = 0; i < rc.Length && i <= ri; i++) if (rc[i] > 0) last = rc[i];
		if (last == 0) for (int i = 0; i < rc.Length; i++) if (rc[i] > 0) { last = rc[i]; break; }
		return last;
	}

	// ------------------------------------------------------------ build
	class Layer { public int Cls; public int K; public double Mpp; public int Id; }
	class OutTile { public string File; public double Xs, Zw, Xn, Ze; public int Layer; }

	// Builds DL\charts_gen\<theatre>.lua and its textures in outDir\<theatre>\.
	//  dcsRoot     DCS install folder (the zips are relative to it)
	//  chartLua    DL\charts\<theatre>.lua
	//  outDir      DL\charts_gen
	//  rangeIdx / rangeM  the range steps (index from 0, radius in metres) to cover;
	//              every range scale the MFD offers (km and nm)
	//  px          texture size (2048)
	//  metresPerPx the screen scale: a range step gets the coarsest layer
	//              with metres-per-texel <= range / metresPerPx (300)
	// Returns a one-line summary; the index is written last (no index = the
	// MFD keeps using DCS's own tiles).
	// a range step may use a layer up to this much coarser than range / screen_px
	// (same in dl_theatres.lua; keeps km and nm steps on the same layers)
	public const double Slack = 1.25;

	class Plan
	{
		public string Status; public Chart Ch; public Dictionary<string, ZipEntryInfo> Zmap = new Dictionary<string, ZipEntryInfo>();
		public string SigLine, IdxPath, TexDir; public Dictionary<int, double> BaseMpp = new Dictionary<int, double>();
		public List<Layer> Layers = new List<Layer>(); public long SrcBytes;
	}

	static Plan MakePlan(string dcsRoot, string chartLua, string outDir, string theatre, int[] rangeIdx, double[] rangeM, int px, double screenPx, bool force)
	{
		Plan P = new Plan();
		Chart ch = ReadChart(chartLua);
		P.Ch = ch;
		StringBuilder sig = new StringBuilder("v" + Version + " px" + px + " s" + screenPx.ToString(IC));
		foreach (double r in rangeM) sig.Append(" ").Append(r.ToString(IC));
		int zipsFound = 0;
		foreach (string z in ch.Zips)
		{
			string p = Path.Combine(dcsRoot, z.Replace('/', Path.DirectorySeparatorChar));
			if (!File.Exists(p)) continue;
			FileInfo fi = new FileInfo(p);
			sig.Append(" | ").Append(z).Append(" ").Append(fi.Length).Append(" ").Append(fi.LastWriteTimeUtc.Ticks);
			IndexZip(p, P.Zmap);
			P.SrcBytes += fi.Length;
			zipsFound++;
		}
		if (zipsFound == 0) { P.Status = "SKIP"; return P; }
		P.IdxPath = Path.Combine(outDir, theatre + ".lua");
		P.TexDir = Path.Combine(outDir, theatre);
		P.SigLine = "-- sig: " + sig.ToString().Replace("\r", " ").Replace("\n", " ");
		P.Status = "NEW";
		if (!force && File.Exists(P.IdxPath))
		{
			foreach (string l in File.ReadAllLines(P.IdxPath)) if (l == P.SigLine) { P.Status = "SAME"; return P; }
		}
		// source resolution per class (from the first tile found)
		foreach (Tile t in ch.Tiles)
		{
			if (P.BaseMpp.ContainsKey(t.Cls)) continue;
			ZipEntryInfo z;
			if (!P.Zmap.TryGetValue(t.Name.ToLowerInvariant(), out z)) continue;
			byte[] b = ReadEntry(z);
			int w, h, mips, fmt, off; int[] sh;
			if (!DdsInfo(b, out w, out h, out mips, out fmt, out off, out sh)) continue;
			P.BaseMpp[t.Cls] = (t.Ze - t.Zw) / w;
		}
		// the layers the range steps need
		for (int i = 0; i < rangeIdx.Length; i++)
		{
			int cls = SourceClass(ch.RangeClass, rangeIdx[i]);
			double bm;
			if (cls == 0 || !P.BaseMpp.TryGetValue(cls, out bm)) continue;
			double target = rangeM[i] / screenPx * Slack;
			int k = 0;
			while (bm * Math.Pow(2, k + 1) <= target) k++;
			Layer found = null;
			foreach (Layer l in P.Layers) if (l.Cls == cls && l.K == k) found = l;
			if (found == null)
			{
				found = new Layer(); found.Cls = cls; found.K = k; found.Mpp = bm * Math.Pow(2, k); found.Id = P.Layers.Count + 1;
				P.Layers.Add(found);
			}
		}
		return P;
	}

	// the grid of one layer: source tiles found, origin, rows, cols
	static List<Tile> LayerSources(Plan P, Layer L, int px, out double x0, out double z0, out int rows, out int cols, out int missing)
	{
		List<Tile> src = new List<Tile>();
		x0 = 1e18; z0 = 1e18; double x1 = -1e18, z1 = -1e18; missing = 0;
		foreach (Tile t in P.Ch.Tiles)
		{
			if (t.Cls != L.Cls) continue;
			if (!P.Zmap.ContainsKey(t.Name.ToLowerInvariant())) { missing++; continue; }
			src.Add(t);
			x0 = Math.Min(x0, t.Xs); z0 = Math.Min(z0, t.Zw); x1 = Math.Max(x1, t.Xn); z1 = Math.Max(z1, t.Ze);
		}
		double T = px * L.Mpp;
		rows = src.Count == 0 ? 0 : (int)Math.Ceiling((x1 - x0) / T - 1e-6);
		cols = src.Count == 0 ? 0 : (int)Math.Ceiling((z1 - z0) / T - 1e-6);
		return src;
	}

	// Rough size of a build, without building: "SKIP" / "SAME" / "NEW <textures> <MB> <seconds>".
	// Seconds are for an average gaming PC (measured Nov 2026: ~0.1 s per texture).
	public static string Estimate(string dcsRoot, string chartLua, string outDir, string theatre, int[] rangeIdx, double[] rangeM, int px, double screenPx)
	{
		Plan P = MakePlan(dcsRoot, chartLua, outDir, theatre, rangeIdx, rangeM, px, screenPx, false);
		if (P.Status != "NEW") return P.Status;
		int n = 0;
		foreach (Layer L in P.Layers)
		{
			double x0, z0; int rows, cols, miss;
			List<Tile> src = LayerSources(P, L, px, out x0, out z0, out rows, out cols, out miss);
			double T = px * L.Mpp;
			for (int i = 0; i < rows; i++)
				for (int j = 0; j < cols; j++)
				{
					double txs = x0 + i * T, tzw = z0 + j * T;
					foreach (Tile t in src)
						if (!(t.Xn <= txs || t.Xs >= txs + T || t.Ze <= tzw || t.Zw >= tzw + T)) { n++; break; }
				}
		}
		long one = 0; int w = px;
		while (w >= 1) { one += (long)Math.Max(1, (w + 3) / 4) * Math.Max(1, (w + 3) / 4) * 8; if (w == 1) break; w /= 2; }
		long mb = (n * (one + 128L)) / 1048576;
		long sec = 5 + (long)(n * 0.12) + P.SrcBytes / (300L * 1048576);
		return "NEW " + n + " " + mb + " " + sec;
	}

	public static string Build(string dcsRoot, string chartLua, string outDir, string theatre, int[] rangeIdx, double[] rangeM, int px, double screenPx, bool force)
	{
		Plan P = MakePlan(dcsRoot, chartLua, outDir, theatre, rangeIdx, rangeM, px, screenPx, force);
		if (P.Status == "SKIP") return "SKIP no chart zips of " + theatre + " in " + dcsRoot;
		if (P.Status == "SAME") return "SAME " + theatre + " (built before from the same charts)";
		Chart ch = P.Ch; Dictionary<string, ZipEntryInfo> zmap = P.Zmap; List<Layer> layers = P.Layers;
		Dictionary<int, double> baseMpp = P.BaseMpp;
		string idxPath = P.IdxPath, texDir = P.TexDir, sigLine = P.SigLine;
		Remove(outDir, theatre);
		Directory.CreateDirectory(texDir);

		List<OutTile> outs = new List<OutTile>();
		int missing = 0;
		long bytes = 0;
		object lk = new object();
		try
		{
		foreach (Layer L in layers)
		{
			double x0, z0; int rows, cols, miss;
			List<Tile> src = LayerSources(P, L, px, out x0, out z0, out rows, out cols, out miss);
			missing += miss;
			if (src.Count == 0) continue;
			double T = px * L.Mpp;
			int lvl = 0;
			double bm = baseMpp[L.Cls];
			while (bm * Math.Pow(2, lvl + 1) <= L.Mpp * 1.0001) lvl++;
			int total = rows * cols, done = 0;
			ParallelOptions po = new ParallelOptions();
			po.MaxDegreeOfParallelism = Math.Max(1, Environment.ProcessorCount);
			Console.Write("    " + theatre + " layer " + L.Id + " (" + Math.Round(L.Mpp) + " m per pixel, " + total + " pieces) ");
			Parallel.For(0, total, po, delegate(int n)
			{
				int i = n / cols, j = n % cols;
				double txs = x0 + i * T, txn = txs + T, tzw = z0 + j * T, tze = tzw + T;
				byte[] cv = null;
				foreach (Tile t in src)
				{
					if (t.Xn <= txs || t.Xs >= txn || t.Ze <= tzw || t.Zw >= tze) continue;
					Img im = DecodeDds(ReadEntry(zmap[t.Name.ToLowerInvariant()]), lvl);
					if (im == null) continue;
					if (cv == null) cv = new byte[px * px * 4];
					Paint(cv, px, txn, tzw, L.Mpp, t, im);
				}
				bool any = false;
				if (cv != null) for (int p = 3; p < cv.Length; p += 4) if (cv[p] >= 128) { any = true; break; }
				if (any)
				{
					string file = theatre + "_L" + L.Id + "_" + i + "_" + j + ".dds";
					string fp = Path.Combine(texDir, file);
					WriteDxt1(fp, cv, px, px);
					OutTile o = new OutTile(); o.File = file; o.Xs = txs; o.Xn = txn; o.Zw = tzw; o.Ze = tze; o.Layer = L.Id;
					lock (lk) { outs.Add(o); bytes += new FileInfo(fp).Length; }
				}
				int d = Interlocked.Increment(ref done);
				if (d * 10 / total != (d - 1) * 10 / total) { lock (lk) { Console.Write("."); } }
			});
			Console.WriteLine();
		}
		}
		catch
		{
			// no half-built chart left behind (no index = DCS's own tiles)
			Console.WriteLine();
			try { Directory.Delete(texDir, true); } catch { }
			throw;
		}
		if (outs.Count == 0)
		{
			try { Directory.Delete(texDir, true); } catch { }
			return "SKIP " + theatre + ": none of its DCS chart tiles could be read";
		}
		outs.Sort(delegate(OutTile a, OutTile b) { return string.CompareOrdinal(a.File, b.File); });

		StringBuilder sb = new StringBuilder();
		sb.Append("-- built by the Vitezovi MFD add-on installer from DCS's own charts (DL\\charts\\" + theatre + ".lua)\n");
		sb.Append("-- big textures joined from DCS's chart tiles, one set per sharpness (layer); INSTALL builds it again\n");
		sb.Append(sigLine).Append("\n");
		sb.Append("DL_CHART = {\n\ttheatre = \"" + theatre + "\",\n\tgen = true,\n\tdir = \"DL/charts_gen/" + theatre + "/\",\n\tzips = {},\n");
		sb.Append("\tsrc_range_class = {");
		for (int i = 0; i < ch.RangeClass.Length; i++) sb.Append(i > 0 ? ", " : "").Append(ch.RangeClass[i]);
		sb.Append("},\n\tscreen_px = ").Append(screenPx.ToString(IC)).Append(",\n\tlayers = {\n");
		foreach (Layer L in layers)
			sb.Append("\t\t{cls = " + L.Cls + ", mpp = " + L.Mpp.ToString("0.###", IC) + ", size = " + (px * L.Mpp).ToString("0.###", IC) + "},\n");
		sb.Append("\t},\n\tclasses = {");
		for (int i = 0; i < layers.Count; i++) sb.Append(i > 0 ? ", " : "").Append((px * layers[i].Mpp).ToString("0.###", IC));
		sb.Append("},\n\trange_class = {1},   -- set by DL_load_chart for the range steps in use\n\ttiles = {\n");
		foreach (OutTile o in outs)
			sb.Append("\t\t{\"" + o.File + "\", " + o.Xs.ToString("0.0", IC) + ", " + o.Zw.ToString("0.0", IC) + ", " + o.Xn.ToString("0.0", IC) + ", " + o.Ze.ToString("0.0", IC) + ", " + o.Layer + "},\n");
		sb.Append("\t},\n}\n");
		File.WriteAllText(idxPath, sb.ToString(), new UTF8Encoding(false));
		return "BUILT " + theatre + ": " + outs.Count + " textures in " + layers.Count + " layers, " + (bytes / 1048576) + " MB" +
		       (missing > 0 ? (", " + missing + " DCS tiles not found") : "");
	}

	// removes a built map (index first, so the MFD never sees half of one)
	public static void Remove(string outDir, string theatre)
	{
		string idx = Path.Combine(outDir, theatre + ".lua"), dir = Path.Combine(outDir, theatre);
		if (File.Exists(idx)) File.Delete(idx);
		if (Directory.Exists(dir)) Directory.Delete(dir, true);
	}

	// draws one DCS tile onto the canvas (bilinear, alpha over)
	static void Paint(byte[] cv, int px, double txn, double tzw, double mpp, Tile t, Img im)
	{
		int r0 = Math.Max(0, (int)Math.Floor((txn - t.Xn) / mpp)), r1 = Math.Min(px - 1, (int)Math.Ceiling((txn - t.Xs) / mpp));
		int q0 = Math.Max(0, (int)Math.Floor((t.Zw - tzw) / mpp)), q1 = Math.Min(px - 1, (int)Math.Ceiling((t.Ze - tzw) / mpp));
		double sx = im.W / (t.Ze - t.Zw), sy = im.H / (t.Xn - t.Xs);
		for (int r = r0; r <= r1; r++)
		{
			double x = txn - (r + 0.5) * mpp;
			if (x < t.Xs || x > t.Xn) continue;
			double v = (t.Xn - x) * sy - 0.5;
			int y0 = (int)Math.Floor(v); double fy = v - y0;
			int ya = Math.Max(0, Math.Min(im.H - 1, y0)), yb = Math.Max(0, Math.Min(im.H - 1, y0 + 1));
			for (int q = q0; q <= q1; q++)
			{
				double z = tzw + (q + 0.5) * mpp;
				if (z < t.Zw || z > t.Ze) continue;
				double u = (z - t.Zw) * sx - 0.5;
				int x0 = (int)Math.Floor(u); double fx = u - x0;
				int xa = Math.Max(0, Math.Min(im.W - 1, x0)), xb = Math.Max(0, Math.Min(im.W - 1, x0 + 1));
				int p00 = (ya * im.W + xa) * 4, p01 = (ya * im.W + xb) * 4, p10 = (yb * im.W + xa) * 4, p11 = (yb * im.W + xb) * 4;
				double w00 = (1 - fx) * (1 - fy), w01 = fx * (1 - fy), w10 = (1 - fx) * fy, w11 = fx * fy;
				double a = im.Px[p00 + 3] * w00 + im.Px[p01 + 3] * w01 + im.Px[p10 + 3] * w10 + im.Px[p11 + 3] * w11;
				if (a < 1) continue;
				int o = (r * px + q) * 4;
				double ia = 1.0 / a;
				double fa = a / 255.0;
				for (int c = 0; c < 3; c++)
				{
					double s = (im.Px[p00 + c] * im.Px[p00 + 3] * w00 + im.Px[p01 + c] * im.Px[p01 + 3] * w01 +
					            im.Px[p10 + c] * im.Px[p10 + 3] * w10 + im.Px[p11 + c] * im.Px[p11 + 3] * w11) * ia;
					cv[o + c] = (byte)Math.Round(s * fa + cv[o + c] * (1 - fa));
				}
				cv[o + 3] = (byte)Math.Max(cv[o + 3], (int)Math.Round(a));
			}
		}
	}

	// for the installer's test: decodes a DDS mip level to RGBA (row 0 first)
	public static byte[] DecodeForTest(string ddsPath, int level, out int w, out int h)
	{
		Img im = DecodeDds(File.ReadAllBytes(ddsPath), level);
		w = im == null ? 0 : im.W; h = im == null ? 0 : im.H;
		return im == null ? null : im.Px;
	}
}
