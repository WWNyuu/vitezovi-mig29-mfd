"""Builds the add-on's patch data (build175/installer/krn_patch.json + tiles)
from KRN MODS V1.0.3 (the originals) and the finished v1.7.5 files.

v1.7.2: everything the installer needs to recognise a file is in the json:
  * KRN's original (sha256 of the bytes, sha256 of the text without CR and
    trailing white space, and how to rebuild KRN's exact bytes - line ends
    and the end of the file - from that text)
  * every result an earlier version of the add-on left behind (v1.7 / v1.7.1
    all-in-one packages, the v1.7.1 installer, v1.7.2, v1.7.3, v1.7.4, v1.7.5), with the steps that
    turn it back into KRN's original (text) - so INSTALL / UNINSTALL only
    touch a file that is KRN's V1.0.3 original or exactly one of ours
  * textures by their pixels (the installer re-encodes PNGs, so the file
    bytes depend on the PC's .NET version; the pixels do not)
  * the dl_config.lua files earlier versions shipped (to tell whether the
    player changed theirs).
The text patch is checked here by running exactly the installer's steps:
KRN's original + ops must give the v1.7.5 file byte for byte."""
import difflib, hashlib, json, os, subprocess
import numpy as np
from PIL import Image
K = "/tmp/claude-0/krnorig/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/"
P = "/home/claude/v175pkg/Saved Games/DCS/Mods/tech/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/"
# earlier results: v1.7 package, v1.7.1 package / review snapshot (= what the
# v1.7.1 users have; the v1.7.1 installer wrote the same text with CRLF line
# ends, recognised by the CR-free hash)
OLD = {"1.7": "/home/claude/v17pkg/Saved Games/DCS/Mods/tech/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/",
       "1.7.1": "/home/claude/review/krn_mod_installed/",
       "1.7.1 package": "/home/claude/v171pkg/Saved Games/DCS/Mods/tech/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/",
       "1.7.2": "/home/claude/v172pkg/Saved Games/DCS/Mods/tech/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/",
       "1.7.3": "/home/claude/v173pkg/Saved Games/DCS/Mods/tech/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/",
       "1.7.4": "/home/claude/v174pkg/Saved Games/DCS/Mods/tech/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/"}
# dl_config.lua as shipped by earlier versions (unchanged by the player)
DL_CONFIGS = {"1.5": "/home/claude/v15pkg/v15/Saved Games/DCS/Mods/tech/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/Cockpit/Scripts/DL/dl_config.lua",
              "1.6": "/home/claude/v16pkg/Saved Games/DCS/Mods/tech/MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3/Cockpit/Scripts/DL/dl_config.lua",
              "1.7": OLD["1.7"] + "Cockpit/Scripts/DL/dl_config.lua",
              "1.7.1": OLD["1.7.1"] + "Cockpit/Scripts/DL/dl_config.lua",
              "1.7.2": OLD["1.7.2"] + "Cockpit/Scripts/DL/dl_config.lua",
              "1.7.3": OLD["1.7.3"] + "Cockpit/Scripts/DL/dl_config.lua",
              "1.7.4": OLD["1.7.4"] + "Cockpit/Scripts/DL/dl_config.lua"}
OUT = "/home/claude/addon/build175/installer/"
os.makedirs(OUT + "tiles", exist_ok=True)
def rb(p): return open(p, 'rb').read()
def sha(b): return hashlib.sha256(b).hexdigest().upper()
def lat(p): return rb(p).decode('latin-1')
def norm(s): return s.replace('\r\n', '\n').rstrip()       # = NormText in the installer
def shat(s): return sha(s.encode('latin-1'))

TEXT = ["Cockpit/Scripts/MFD/pages/obf_K7j9M2sW5yZ8bB1cD4fG7hJ0kL3nO6pQ.lua", "Cockpit/Scripts/UFCP/base_page.lua",
        "Cockpit/Scripts/device_init.lua", "Cockpit/Scripts/devices.lua", "Cockpit/Scripts/materials.lua",
        "Options/optionsDb.lua", "Options/options.dlg", "Cockpit/Scripts/clickabledata.lua"]

# ---------------------------------------------------------------- text: forward ops
def make_ops(f, a, b):
    """the add-on only ADDS lines to KRN's files: one op per inserted block,
    placed by the KRN lines in front of it (or after it), or at the end"""
    res = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == 'equal': continue
        assert tag == 'insert', (f, tag, a[i1:i2], b[j1:j2])
        new = b[j1:j2]
        if i1 >= len(a):
            res.append({"file": f, "mode": "append", "anchor": [], "text": new}); continue
        for n in range(1, 7):
            ctx = a[max(0, i1 - n):i1]
            if len(ctx) < n: break
            if sum(1 for k in range(len(a) - n + 1) if a[k:k + n] == ctx) == 1:
                res.append({"file": f, "mode": "after", "anchor": ctx, "text": new}); break
        else:
            for n in range(1, 7):
                ctx = a[i1:i1 + n]
                if sum(1 for k in range(len(a) - n + 1) if a[k:k + n] == ctx) == 1:
                    res.append({"file": f, "mode": "before", "anchor": ctx, "text": new}); break
            else:
                raise SystemExit("no unique anchor " + f)
    return res

def apply_ops(lines, file_ops):
    """exactly the installer's steps (vitezovi_install.ps1, Patch-Text)"""
    L = list(lines)
    for o in file_ops:
        if o["mode"] == "append":
            L = L + o["text"]; continue
        n = len(o["anchor"])
        hits = [k for k in range(len(L) - n + 1) if L[k:k + n] == o["anchor"]]
        assert len(hits) == 1, (o["file"], o["anchor"])
        k = hits[0] + (n if o["mode"] == "after" else 0)
        L = L[:k] + o["text"] + L[k:]
    return L

# ---------------------------------------------------------------- text: KRN's exact bytes from the normalised text
def eol_info(O):
    """line ends of KRN's file: the usual one, the lines that use the other,
    and the exact end of the file after the last text"""
    N = norm(O)
    ls = N.split('\n')
    ends, pos = [], 0
    for i, l in enumerate(ls[:-1]):
        pos += len(l)
        e = '\r\n' if O[pos:pos + 2] == '\r\n' else '\n'
        assert O[pos:pos + len(e)] == e
        ends.append(e); pos += len(e)
    pos += len(ls[-1])
    tail = O[pos:]
    nl = '\r\n' if ends.count('\r\n') > ends.count('\n') else '\n'
    other = [i for i, e in enumerate(ends) if e != nl]
    return {"nl": nl, "nl_other": other, "tail": tail}

def rebuild(N, info):
    """exactly the installer's steps (Rebuild-Original)"""
    ls = N.split('\n'); other = set(info["nl_other"])
    nlo = '\n' if info["nl"] == '\r\n' else '\r\n'
    out = []
    for i, l in enumerate(ls):
        out.append(l)
        if i < len(ls) - 1: out.append(nlo if i in other else info["nl"])
    return ''.join(out) + info["tail"]

def undo_hunks(res_norm, orig_norm):
    """steps that turn a result (normalised) back into KRN's text: [line, remove, insert]"""
    a, b = res_norm.split('\n'), orig_norm.split('\n')
    h = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag != 'equal': h.append([i1, i2 - i1, b[j1:j2]])
    return h

def apply_undo(res_norm, hunks):
    """exactly the installer's steps (Undo-Text): from the back"""
    L = res_norm.split('\n')
    for i, n, ins in sorted(hunks, key=lambda x: -x[0]):
        L[i:i + n] = ins
    return norm('\n'.join(L))

# the v1.7.1 installer (build171) wrote its own results: its "append" put
# the blank lines elsewhere, and its line ends are KRN's (CRLF). Two ways:
# from KRN's file as it is, or from the original it rebuilt itself (text
# with CRLF and one final CRLF, when it found no backup). Same steps as
# build171's vitezovi_install.ps1 (checked against a real run of it).
OLD171 = json.load(open("/home/claude/addon/build171/installer/krn_patch.json"))
def old171_apply(raw, rel):
    nl = "\r\n" if "\r\n" in raw else "\n"
    lines = raw.replace("\r\n", "\n").split("\n")
    for op in [o for o in OLD171["text"] if o["file"] == rel]:
        txt = list(op["text"])
        if op["mode"] == "append":
            if lines and lines[-1] == "": lines = lines[:-1] + txt + [""]
            else: lines = lines + txt
            continue
        anc = [x.lower() for x in op["anchor"]]          # its -ne compared case-blind
        hits = [k for k in range(len(lines) - len(anc) + 1) if [l.lower() for l in lines[k:k + len(anc)]] == anc]
        assert len(hits) == 1, rel
        at = hits[0] + (len(anc) if op["mode"] == "after" else 0)
        lines = lines[:at] + txt + lines[at:]
    return nl.join(lines)

allops, files = [], {}
for f in TEXT:
    O, R = lat(K + f), lat(P + f)
    a = O.replace('\r\n', '\n').split('\n')
    rnl = '\r\n' if '\r\n' in R else '\n'
    assert R.replace('\r\n', '').count('\n') == 0 or rnl == '\n', f
    assert not (rnl == '\n' and '\r' in R), f
    b = R.replace('\r\n', '\n').split('\n')
    fo = make_ops(f, a, b)
    got = rnl.join(apply_ops(a, fo))
    assert got == R, "forward patch does not give the v1.7.5 file exactly: " + f
    ei = eol_info(O)
    assert rebuild(norm(O), ei) == O, f
    info = {"kind": "text", "sha256": sha(rb(K + f)), "norm_sha256": shat(norm(O)),
            "nl": ei["nl"], "nl_other": ei["nl_other"], "tail": ei["tail"],
            "result_nl": rnl, "result_sha256": sha(rb(P + f)), "results": []}
    # every known result -> how to get KRN's original back from it
    seen = {}
    rel = f.replace('/', '\\')
    known = [(ver, lat(root + f)) for ver, root in [("1.7.5", P)] + list(OLD.items())]
    known += [("1.7.1 installer", old171_apply(O, rel)),
              ("1.7.1 installer, rebuilt original", old171_apply(norm(O).replace('\n', '\r\n') + '\r\n', rel))]
    for ver, Rv in known:
        k = shat(norm(Rv))
        if k in seen:
            if shat(Rv) not in seen[k]["sha256"]: seen[k]["sha256"].append(shat(Rv))
            seen[k]["version"] += ", " + ver
            continue
        hk = undo_hunks(norm(Rv), norm(O))
        assert apply_undo(norm(Rv), hk) == norm(O), (f, ver)
        assert rebuild(apply_undo(norm(Rv), hk), ei) == O, (f, ver)
        # undo only removes lines (or puts back blank ones): no KRN text in the json
        assert all(all(x.strip() == '' for x in ins) for _, _, ins in hk), (f, ver, "a result changed KRN lines")
        seen[k] = {"version": ver, "sha256": [shat(Rv)], "norm_sha256": k, "undo": hk}
        info["results"].append(seen[k])
    print("ok", f, [(o["mode"], o["anchor"][-1][:30] if o["anchor"] else "", len(o["text"])) for o in fo],
          "results:", [(r["version"], len(r["undo"])) for r in info["results"]], "nl", repr(ei["nl"]), len(ei["nl_other"]), repr(ei["tail"]))
    allops += fo
    files[f] = info

# ---------------------------------------------------------------- UFCP.edm splice
import tempfile
TMP = tempfile.mkdtemp() + "/ufcp_add.edm"
subprocess.run(["python3", "/home/claude/addon/patch_edm.py", K + "Shapes/UFCP.edm", TMP],
               env=dict(os.environ, OPS="1"), check=True, capture_output=True)
assert rb(TMP) == rb(P + "Shapes/UFCP.edm")
edm = json.load(open(TMP + ".ops.json"))
ob = rb(K + "Shapes/UFCP.edm")
edm["overwrite_orig"] = [[o, ob[o:o + len(h) // 2].hex()] for o, h in edm["overwrite"]]
er = sha(rb(P + "Shapes/UFCP.edm"))
for ver, root in OLD.items():      # one splice for every version so far: EdmUnsplice works on all
    assert sha(rb(root + "Shapes/UFCP.edm")) == er, ver
files["Shapes/UFCP.edm"] = {"kind": "edm", "sha256": sha(ob), "result_sha256": er,
                            "results": [{"version": "1.7, 1.7.1, 1.7.2, 1.7.3, 1.7.4, 1.7.5", "sha256": [er]}]}

# ---------------------------------------------------------------- texture tiles
import cv2
def pix(a): return sha(np.ascontiguousarray(a).tobytes())
tiles = []
for f in ["Textures/Shared_Material.png", "Textures/Buttons.png"]:
    ia, ib = Image.open(K + f), Image.open(P + f)
    assert ia.mode in ("RGB", "RGBA") and ib.mode == ia.mode, (f, ia.mode, ib.mode)
    A, B = np.array(ia), np.array(ib)
    a, b = A[:, :, :3], B[:, :, :3]
    assert a.shape == b.shape
    m = (np.abs(a.astype(int) - b.astype(int)).sum(axis=2) > 0).astype(np.uint8)
    m2 = cv2.dilate(m, np.ones((25, 25), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m2, 8)
    mine = []
    for k in range(1, n):
        x, y, w, h = st[k, 0], st[k, 1], st[k, 2], st[k, 3]
        name = "%s_%d_%d.png" % (os.path.basename(f)[:-4], x, y)
        Image.fromarray(b[y:y + h, x:x + w]).save(OUT + "tiles/" + name, optimize=True)
        mine.append({"file": f.replace('/', '\\'), "x": int(x), "y": int(y), "tile": name})
    tiles += mine
    # what VitezoviPatch.PasteTiles makes of KRN's original: RGB of the tiles, alpha kept
    C = A.copy()
    for t in mine:
        tl = np.array(Image.open(OUT + "tiles/" + t["tile"]))
        C[t["y"]:t["y"] + tl.shape[0], t["x"]:t["x"] + tl.shape[1], :3] = tl[:, :, :3]
    assert (C == B).all(), f
    rp = [pix(C)]
    shas = [sha(rb(P + f))]
    for ver, root in OLD.items():
        io_ = np.array(Image.open(root + f))
        assert pix(io_) == rp[0], (f, ver)
        if sha(rb(root + f)) not in shas: shas.append(sha(rb(root + f)))
    files[f] = {"kind": "png", "sha256": sha(rb(K + f)), "size": [int(A.shape[1]), int(A.shape[0])],
                "channels": int(A.shape[2]), "pix_sha256": pix(A), "result_pix_sha256": rp[0],
                "results": [{"version": "1.7, 1.7.1, 1.7.2, 1.7.3, 1.7.4, 1.7.5", "sha256": shas, "pix_sha256": rp}]}
    print("tiles", f, [(t["x"], t["y"]) for t in mine])

# ---------------------------------------------------------------- dl_config.lua shipped before
cfg = []
for ver, p in DL_CONFIGS.items():
    h = shat(norm(lat(p)))
    if h not in [c["norm_sha256"] for c in cfg]: cfg.append({"version": ver, "norm_sha256": h})

for o in allops: o["file"] = o["file"].replace('/', '\\')
fx = {k.replace('/', '\\'): v for k, v in files.items()}
json.dump({"krn_version": "KRN MODS V1.0.3", "files": fx, "text": allops, "edm": edm, "tiles": tiles,
           "dl_config_shipped": cfg},
          open(OUT + "krn_patch.json", "w"), indent=1)
print("dl_config shipped:", [c["version"] for c in cfg])
print("written", OUT + "krn_patch.json", os.path.getsize(OUT + "krn_patch.json"))
