# Vitezovi MiG-29 MFD add-on - installer / uninstaller
# Run through INSTALL.bat / UNINSTALL.bat (Windows PowerShell 5.1, nothing else needed).
#
# The add-on sits on top of "MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3",
# which the player installs first, unchanged, from KRN's own download.
# This script:
#   1. finds the player's Saved Games folder (where Windows really keeps it)
#      and every DCS* folder in it (DCS, DCS.openbeta, ...) that has KRN's
#      mod in Mods\tech, and does 2-5 for each of them
#   2. checks every KRN file it changes: it must be KRN's V1.0.3 original or
#      exactly what this add-on (v1.7 or later) made of it. Anything else
#      (for example a newer KRN version) stops the install before anything
#      is changed
#   3. keeps a copy of KRN's originals (Saved Games\DCS\Vitezovi-MFD-Addon\krn_backup)
#   4. applies the add-on's changes to them: a few added lines in KRN's
#      scripts and options, the extra click boxes of the MFD bezel buttons in
#      Shapes\UFCP.edm, the new button labels in two textures
#   5. copies the add-on's own files (MFD pages, fonts, export, hook, ...) and
#      adds one line to Scripts\Export.lua
# -Uninstall puts KRN's originals back (only over files that are still the
# add-on's) and removes the add-on's files.
# The player's own settings (Vitezovi-MFD-Addon\settings.lua) are never
# changed or removed; INSTALL only creates the file when there is none.
# -SavedGames <folder>: use this DCS folder (e.g. "D:\Saved Games\DCS") or
# the DCS* folders in this Saved Games folder instead of looking for them.
# v1.7.4: also adds the add-on's MFD / UFCP controls to the MiG-29's own
# controls (Options > Controls, category "Vitezovi MFD"): a marked block in
# <DCS install>\Mods\aircraft\MiG-29-Fulcrum\Input\MiG-29-Fulcrum\
# joystick\default.lua and keyboard\default.lua (ED's file stays as it is
# around it; UNINSTALL takes the block out again). A DCS update or repair
# puts ED's file back: INSTALL again adds the block again (the MFD's
# start-up test says so). -DcsPath <folder> = the DCS install to use.
# v1.7.8: also offers to build the moving map's charts (see Build-Charts):
# it shows the size and time per map and asks. -Charts yes / -Charts no
# answers that question beforehand (-NoCharts = -Charts no). Without the
# built charts the MFD uses DCS's own chart tiles around where you fly.
param([switch]$Uninstall, [string]$SavedGames = "", [string]$DcsPath = "", [switch]$NoCharts, [string]$Charts = "")

# Constrained Language Mode (company / school policy, AppLocker, WDAC):
# every .NET call below would fail with a raw error - say so first.
if ($ExecutionContext.SessionState.LanguageMode -ne "FullLanguage") {
	Write-Host ""
	Write-Host ("  PROBLEM: PowerShell runs in a restricted mode on this PC (" + $ExecutionContext.SessionState.LanguageMode + ",") -ForegroundColor Yellow
	Write-Host "  set by a company or school policy or a security program such as AppLocker)." -ForegroundColor Yellow
	Write-Host "  The installer cannot work in that mode. Nothing was changed." -ForegroundColor Yellow
	Write-Host "  Ask whoever manages this PC, or install on a PC without that policy." -ForegroundColor Yellow
	Write-Host ""
	exit 1
}

$ErrorActionPreference = "Stop"
$Here = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Path)
$Root = [System.IO.Path]::GetDirectoryName($Here)
$L1 = [System.Text.Encoding]::GetEncoding(28591)       # bytes <-> text 1:1
$SEP = [System.IO.Path]::DirectorySeparatorChar
$ExpComment = "-- MiG-29 DL / moving map add-on (feeds the MiG-29 MFD datalink page)"
$ExpLine = "pcall(function() local l=require('lfs'); dofile(l.writedir()..[[Scripts\MiG29DL_Export.lua]]) end)"
$Again = "INSTALL"; if ($Uninstall) { $Again = "UNINSTALL" }
$script:Step = "start"       # what is being done (for the advice when something fails)
$script:Problem = $null      # the message of Fail
$script:BindsNoAccess = $null # a DCS install folder Windows did not let us change (HOTAS binds)

# Paths are only ever handled by .NET or with -LiteralPath: a folder called
# "Vitezovi [v1.7.2]" must not be read as a wildcard.
function J($a, $b) { return [System.IO.Path]::Combine($a, ($b -replace '\\', $SEP)) }
function Say($m) { Write-Host ("  " + $m) }
# stop this DCS folder with a message for the player (shown by Show-Error)
function Fail($m) { $script:Problem = $m; throw "VITEZOVI-PROBLEM" }
function IsFile($p) { return [System.IO.File]::Exists($p) }
function IsDir($p) { return [System.IO.Directory]::Exists($p) }
function Sha($p) { return (Get-FileHash -Algorithm SHA256 -LiteralPath $p).Hash.ToUpper() }
function ShaBytes($b) {
	$h = [System.Security.Cryptography.SHA256]::Create()
	return ([BitConverter]::ToString($h.ComputeHash($b)) -replace "-", "").ToUpper()
}
function ShaText($s) { return (ShaBytes ($L1.GetBytes($s))) }
function NormText($s) { return $s.Replace("`r`n", "`n").TrimEnd() }
# ReadAllBytes, not ReadAllText: ReadAllText drops a UTF-8 BOM
function ReadL1($p) { return $L1.GetString([System.IO.File]::ReadAllBytes($p)) }
function Ensure-Dir($d) { if (-not (IsDir $d)) { [void][System.IO.Directory]::CreateDirectory($d) } }
function Clear-ReadOnly($p) {
	if (IsFile $p) {
		$a = [System.IO.File]::GetAttributes($p)
		if (($a -band [System.IO.FileAttributes]::ReadOnly) -ne 0) { [System.IO.File]::SetAttributes($p, ($a -band (-bnot [System.IO.FileAttributes]::ReadOnly))) }
	}
}
function WriteL1($p, $s) { Ensure-Dir ([System.IO.Path]::GetDirectoryName($p)); Clear-ReadOnly $p; [System.IO.File]::WriteAllBytes($p, $L1.GetBytes($s)) }
function CopyFile($a, $b) { Ensure-Dir ([System.IO.Path]::GetDirectoryName($b)); Clear-ReadOnly $b; [System.IO.File]::Copy($a, $b, $true) }
function Remove-File($p) { if (IsFile $p) { Clear-ReadOnly $p; [System.IO.File]::Delete($p) } }
function Remove-Dir($p) { if (IsDir $p) { Remove-Item -LiteralPath $p -Recurse -Force } }

# ---------------------------------------------------------------- what went wrong
function Get-Advice($step, $raw, $locked) {
	$tip = "Close DCS (and any program that has the file open). If your Saved Games folder is synced by OneDrive, pause the sync or wait until it is done."
	switch ($step) {
		"helper" { return ("Windows did not let the installer start its helper - an antivirus program or a company policy blocked it.`n" +
		                   "  Nothing was changed. Allow INSTALL.bat / PowerShell in the antivirus program (or install on a PC without that policy), then run $Again again.`n  ($raw)") }
		"data"   { return "The installer's own files are damaged or incomplete ($raw). Unzip the whole package again and run $Again from there. Nothing was changed." }
		"check"  { return "Could not read KRN's files or Scripts\Export.lua ($raw). Nothing was changed." }
		{ $_ -eq "backup" -or $_ -eq "patch" } {
			return ("Could not write to the folder Vitezovi-MFD-Addon in your DCS Saved Games folder ($raw).`n  $tip`n" +
			        "  Nothing was changed in KRN's mod; run INSTALL again.") }
		"move"   { return ("A file of KRN's mod could not be replaced ($raw).`n  It is probably in use or locked. $tip`n" +
		                   "  Then run INSTALL again: it finishes the job. (Or run UNINSTALL: it puts KRN's originals back.)") }
		"copy"   { return ("The add-on's files could not be copied ($raw).`n  $tip`n" +
		                   "  Then run INSTALL again: it finishes the job. (Or run UNINSTALL to remove the add-on.)") }
		"export" { return ("Scripts\Export.lua could not be changed ($raw).`n  It is read-only or open in another program: close that program, or untick 'Read-only'`n" +
		                   "  (right-click Scripts\Export.lua > Properties), then run $Again again. Everything else is done.") }
		"settings" { return "Could not create Vitezovi-MFD-Addon\settings.lua ($raw). The add-on itself is installed and works without it." }
		"restore" { return ("A file of KRN's mod could not be put back ($raw).`n  It is probably in use or locked. $tip`n" +
		                    "  Then run UNINSTALL again: it finishes the job.") }
		"remove" { return ("The add-on's files could not be removed ($raw).`n  $tip`n  Then run UNINSTALL again: it finishes the job.") }
		default  { return "Unexpected error: $raw`n  Nothing was changed." }
	}
}
function Show-Error($e, $where) {
	$m = $script:Problem
	$script:Problem = $null
	if (-not $m) {
		$ex = $e.Exception
		while ($ex.InnerException) { $ex = $ex.InnerException }
		$locked = ($ex -is [System.IO.IOException]) -or ($ex -is [System.UnauthorizedAccessException])
		$m = Get-Advice $script:Step $ex.Message $locked
	}
	if ($where) { $m = $m + "`n  (DCS folder: $where)" }
	Write-Host ""
	Write-Host ("  PROBLEM: " + $m) -ForegroundColor Yellow
	Write-Host ""
}

# ---------------------------------------------------------------- where
# Saved Games can be moved (Properties > Location of the folder): Windows
# keeps the real place in the registry, %USERPROFILE%\Saved Games is only
# the default.
function Get-SavedGamesRoot {
	$v = $null
	try {
		$k = Get-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" -ErrorAction Stop
		$v = $k.'{4C5C32FF-BB9D-43B0-B5B4-2D72E54EAAA4}'
	} catch { $v = $null }
	if ($v) {
		$v = [System.Environment]::ExpandEnvironmentVariables([string]$v)
		if (IsDir $v) { return $v }
	}
	if ($env:USERPROFILE) { return (J $env:USERPROFILE "Saved Games") }
	return $v
}
function Get-DcsFolders($root) {
	$r = @()
	if ($root -and (IsDir $root)) {
		foreach ($d in @(Get-ChildItem -LiteralPath $root -Directory)) { if ($d.Name -like "DCS*") { $r += $d.FullName } }
	}
	return $r
}
function Find-Krn($sg) {
	$tech = J $sg "Mods\tech"
	$k = @()
	if (IsDir $tech) {
		foreach ($d in @(Get-ChildItem -LiteralPath $tech -Directory)) {
			$e = J $d.FullName "entry.lua"
			if ((IsFile $e) -and ((ReadL1 $e) -match 'declare_plugin\(\s*"mig_29am"')) { $k += $d.FullName }
		}
	}
	return $k
}
# anything of the add-on in this DCS folder (a krn_backup left behind by an
# earlier UNINSTALL does not count; KRN's devices.lua with our device does)
function Has-Addon($sg) {
	if ((IsFile (J $sg "Scripts\MiG29DL_Export.lua")) -or (IsFile (J $sg "Scripts\Hooks\MiG29DL_Hook.lua"))) { return $true }
	foreach ($k in @(Find-Krn $sg)) {
		if (IsDir (J $k "Cockpit\Scripts\DL")) { return $true }
		$d = J $k "Cockpit\Scripts\devices.lua"
		if ((IsFile $d) -and ((ReadL1 $d).IndexOf("MIG29_DL", [System.StringComparison]::Ordinal) -ge 0)) { return $true }
	}
	$exp = J $sg "Scripts\Export.lua"
	if ((IsFile $exp) -and ((ReadL1 $exp).IndexOf("MiG29DL_Export.lua", [System.StringComparison]::OrdinalIgnoreCase) -ge 0)) { return $true }
	return $false
}
# UNINSTALL with nothing (left) in Saved Games: the add-on's block in the
# MiG-29's controls sits in DCS's own folder, and an earlier UNINSTALL
# without permission for that folder leaves it behind. True = it was there.
function Remove-LeftBinds {
	$inBinds = $false
	foreach ($d in @(Get-DcsInstalls)) {
		foreach ($kind in @("joystick", "keyboard")) {
			$f = J $d ($BindRel + "\" + $kind + "\default.lua")
			try { if ((IsFile $f) -and ((ReadL1 $f).IndexOf($BindBegin, [System.StringComparison]::Ordinal) -ge 0)) { $inBinds = $true } } catch { }
		}
	}
	if ($inBinds) {
		try { $null = Do-Binds $true $null }
		catch { Say ("HOTAS binds: not removed (" + $_.Exception.Message + ").") }
	}
	return $inBinds
}
function Get-Targets {
	if ($SavedGames -ne "") {
		if (-not (IsDir $SavedGames)) { Fail "The folder given with -SavedGames does not exist: $SavedGames`n  Nothing was changed." }
		$sg = (Get-Item -LiteralPath $SavedGames).FullName.TrimEnd([char]'\', [char]'/')
		$name = [System.IO.Path]::GetFileName($sg)
		if (($name -like "DCS*") -or (IsDir (J $sg "Mods")) -or (IsDir (J $sg "Config")) -or (IsDir (J $sg "Scripts"))) { $cands = @($sg) }
		else { $cands = @(Get-DcsFolders $sg) }
		$where = $sg
	} else {
		$where = Get-SavedGamesRoot
		$cands = @(Get-DcsFolders $where)
	}
	if ($cands.Count -eq 0) {
		if ($Uninstall -and (Remove-LeftBinds)) { exit 0 }
		Fail ("Could not find your DCS Saved Games folder (no DCS folder in $where).`n" +
		      "  Start DCS once so it creates it, then try again. Nothing was changed.")
	}
	if ($Uninstall) {
		$t = @($cands | Where-Object { Has-Addon $_ })
		if ($t.Count -eq 0) {
			Say ("The add-on is not installed in: " + ($cands -join ", "))
			if (-not (Remove-LeftBinds)) { Say "Nothing to do." }
			exit 0
		}
		return $t
	}
	$t = @($cands | Where-Object { @(Find-Krn $_).Count -gt 0 })
	if ($t.Count -eq 0) {
		Fail ("KRN's mod is not installed. Install 'MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3' first`n" +
		      "  (unzip it into " + (J $cands[0] "Mods\tech") + "), then run this again. Nothing was changed.`n" +
		      "  Looked in: " + (($cands | ForEach-Object { J $_ "Mods\tech" }) -join ", "))
	}
	return $t
}

# ---------------------------------------------------------------- KRN's text files
# KRN's exact bytes from the text without CR / trailing white space: line
# ends and the end of the file as KRN has them (krn_patch.json)
function Rebuild-Original($n, $info) {
	$ls = $n -split "`n"
	$nl = [string]$info.nl
	$nlo = "`r`n"; if ($nl -eq "`r`n") { $nlo = "`n" }
	$other = @{}
	foreach ($i in @($info.nl_other)) { $other[[int]$i] = $true }
	$sb = New-Object System.Text.StringBuilder
	for ($i = 0; $i -lt $ls.Count; $i++) {
		[void]$sb.Append($ls[$i])
		if ($i -lt $ls.Count - 1) { if ($other.ContainsKey($i)) { [void]$sb.Append($nlo) } else { [void]$sb.Append($nl) } }
	}
	[void]$sb.Append([string]$info.tail)
	return $sb.ToString()
}
# KRN's original (exact bytes) if this text is KRN's V1.0.3 file, else $null
function Get-TextOriginal($raw, $info) {
	if ((ShaText $raw) -eq $info.sha256) { return $raw }
	$n = NormText $raw
	if ((ShaText $n) -eq $info.norm_sha256) { return (Rebuild-Original $n $info) }
	return $null
}
# the add-on version whose result this text is, else $null
function Get-TextResult($raw, $info) {
	$h = ShaText (NormText $raw)
	foreach ($r in @($info.results)) { if ($r.norm_sha256 -eq $h) { return $r } }
	return $null
}
# take that version's lines out again (krn_patch.json: [line, how many, insert])
function Undo-Text($raw, $r) {
	$L = New-Object System.Collections.Generic.List[string]
	$L.AddRange([string[]]((NormText $raw) -split "`n"))
	$hs = @($r.undo)
	for ($k = $hs.Count - 1; $k -ge 0; $k--) {
		$h = @($hs[$k])
		$i = [int]$h[0]
		$L.RemoveRange($i, [int]$h[1])
		$ins = [string[]]@(@($h[2]) | Where-Object { $null -ne $_ })
		if ($ins.Count -gt 0) { $L.InsertRange($i, $ins) }
	}
	return (NormText ([string]::Join("`n", $L.ToArray())))
}
# KRN's original + the add-on's lines (gen_patch172.py runs the same steps
# and checks they give the v1.7.2 file byte for byte)
function Patch-Text($orig, $rel, $info) {
	$lines = New-Object System.Collections.Generic.List[string]
	$lines.AddRange([string[]]($orig.Replace("`r`n", "`n") -split "`n"))
	foreach ($op in @($Data.text | Where-Object { $_.file -eq $rel })) {
		$txt = [string[]]@($op.text)
		if ($op.mode -eq "append") { $lines.AddRange($txt); continue }
		$anc = [string[]]@($op.anchor)
		$hit = -1; $n = 0
		for ($k = 0; $k -le $lines.Count - $anc.Count; $k++) {
			$m = $true
			for ($j = 0; $j -lt $anc.Count; $j++) { if ($lines[$k + $j] -cne $anc[$j]) { $m = $false; break } }
			if ($m) { $hit = $k; $n++ }
		}
		if ($n -ne 1) { Fail "$rel : the place for the add-on's lines was not found ($n). Nothing was changed in KRN's mod." }
		$at = $hit; if ($op.mode -eq "after") { $at = $hit + $anc.Count }
		$lines.InsertRange($at, $txt)
	}
	return [string]::Join([string]$info.result_nl, $lines.ToArray())
}

# ---------------------------------------------------------------- KRN's binary files
function Is-BinResult($s, $info) { return (@($info.results | ForEach-Object { @($_.sha256) }) -contains $s) }
# a texture: "orig" (KRN's V1.0.3 pixels), "ours" (the add-on's result),
# "other", or the reason it cannot be read
function Get-PngState($p, $info) {
	$s = Sha $p
	if ($s -eq $info.sha256) { return "orig" }
	if (Is-BinResult $s $info) { return "ours" }
	$w = 0; $h = 0
	$why = [VitezoviPatch]::PngCheck($p, [ref]$w, [ref]$h)
	if ($why) { return ("is " + $why + " (KRN's V1.0.3 one is an 8-bit RGB PNG)") }
	if ($w -ne [int]$info.size[0] -or $h -ne [int]$info.size[1]) { return ("is $w x $h pixels (KRN's V1.0.3 one is " + $info.size[0] + " x " + $info.size[1] + " - another texture pack?)") }
	try { $px = [VitezoviPatch]::PngPixelSha($p) }
	catch { return ("cannot be read (damaged?)") }
	if ($px -eq $info.pix_sha256) { return "orig" }
	if (@($info.results | ForEach-Object { @($_.pix_sha256) }) -contains $px) { return "ours" }
	return "other"
}
# true when texture $cur is texture $base with the add-on's label tiles on it
function Test-PastedFrom($base, $cur, $rel, $tmpDir) {
	try {
		Ensure-Dir $tmpDir
		$ts = @($Data.tiles | Where-Object { $_.file -eq $rel })
		$t = J $tmpDir "pasted_check.png"
		$px = [VitezoviPatch]::PasteTiles($base, [string[]]@($ts | ForEach-Object { J $Here ("tiles\" + $_.tile) }),
			[int[]]@($ts | ForEach-Object { $_.x }), [int[]]@($ts | ForEach-Object { $_.y }), $t)
		Remove-File $t
		return ($px -eq [VitezoviPatch]::PngPixelSha($cur))
	} catch { return $false }
}
# a usable copy of KRN's original among these paths, else $null
function Find-BinOriginal($paths, $info) {
	foreach ($p in $paths) {
		if (-not (IsFile $p)) { continue }
		if ((Sha $p) -eq $info.sha256) { return $p }
		if ($info.kind -eq "png" -and (Get-PngState $p $info) -eq "orig") { return $p }
	}
	return $null
}

# ---------------------------------------------------------------- Export.lua
# The file stays byte for byte as it was except for the add-on's lines:
# read as bytes, BOM and line ends kept, lines split with their own ends.
function Split-Lines([string]$s) {
	$c = New-Object System.Collections.Generic.List[string]
	$t = New-Object System.Collections.Generic.List[string]
	$i = 0
	while ($i -lt $s.Length) {
		$j = $s.IndexOf([char]10, $i)
		if ($j -lt 0) { $c.Add($s.Substring($i)); $t.Add(""); break }
		if ($j -gt $i -and $s[$j - 1] -eq [char]13) { $c.Add($s.Substring($i, $j - 1 - $i)); $t.Add("`r`n") }
		else { $c.Add($s.Substring($i, $j - $i)); $t.Add("`n") }
		$i = $j + 1
	}
	return @{ c = $c; t = $t }
}
# a line that really runs the add-on's export (not one behind "--")
function Is-ActiveExportLine([string]$l) {
	$k = $l.IndexOf("--", [System.StringComparison]::Ordinal)
	if ($k -ge 0) { $l = $l.Substring(0, $k) }
	return ($l.IndexOf("MiG29DL_Export.lua", [System.StringComparison]::OrdinalIgnoreCase) -ge 0)
}
function Is-OurExportLine([string]$l) {
	return (($l.IndexOf("MiG29DL_Export.lua", [System.StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($l.IndexOf("MiG-29 DL / moving map add-on", [System.StringComparison]::Ordinal) -ge 0))
}
# before anything is changed: can the add-on's line go in / come out?
function Check-Export($exp, $forRemove) {
	if (-not (IsFile $exp)) { return }
	$b = [System.IO.File]::ReadAllBytes($exp)
	if ($forRemove -and ($L1.GetString($b).IndexOf("MiG29DL_Export.lua", [System.StringComparison]::OrdinalIgnoreCase) -lt 0)) { return }
	if ($b.Length -ge 2 -and (($b[0] -eq 0xFF -and $b[1] -eq 0xFE) -or ($b[0] -eq 0xFE -and $b[1] -eq 0xFF))) {
		Fail ("Scripts\Export.lua is saved as UTF-16 ('Unicode') - DCS cannot read it like that, and the installer cannot change it.`n" +
		      "  Open it in Notepad, File > Save As..., Encoding UTF-8, then run $Again again. Nothing was changed.`n    $exp")
	}
	if ((New-Object System.IO.FileInfo $exp).IsReadOnly) {
		Fail ("Scripts\Export.lua is read-only (some programs set that), so the add-on's line cannot be " + $(if ($forRemove) { "taken out" } else { "added" }) + ".`n" +
		      "  Right-click it > Properties > untick 'Read-only', then run $Again again. Nothing was changed.`n    $exp")
	}
}
function Add-ExportLine($exp) {
	$s = ""
	if (IsFile $exp) { $s = ReadL1 $exp } else { Ensure-Dir ([System.IO.Path]::GetDirectoryName($exp)) }
	$p = Split-Lines $s
	foreach ($l in $p.c) { if (Is-ActiveExportLine $l) { return "datalink line already there." } }
	$nl = "`r`n"
	if ($s.IndexOf("`r`n", [System.StringComparison]::Ordinal) -lt 0 -and $s.IndexOf([char]10) -ge 0) { $nl = "`n" }
	# a blank line, the comment, the line. A file that did not end with a
	# line end does not get one at its very end either (UNINSTALL can then
	# give back exactly what was there).
	if ($s.Length -eq 0) { $add = $ExpComment + $nl + $ExpLine + $nl }
	elseif ($p.t[$p.t.Count - 1] -eq "") { $add = $nl + $nl + $ExpComment + $nl + $ExpLine }
	else { $add = $nl + $ExpComment + $nl + $ExpLine + $nl }
	[System.IO.File]::WriteAllBytes($exp, $L1.GetBytes($s + $add))
	return "datalink line added."
}
# takes out every line of the add-on (also older forms of it) and the blank
# line INSTALL put in front of the comment; returns how many lines went
function Remove-ExportLine($exp) {
	if (-not (IsFile $exp)) { return 0 }
	$s = ReadL1 $exp
	$p = Split-Lines $s
	$n = $p.c.Count
	$cnt = 0
	$drop = New-Object bool[] ([Math]::Max($n, 1))
	for ($i = 0; $i -lt $n; $i++) { if (Is-OurExportLine $p.c[$i]) { $drop[$i] = $true; $cnt++ } }
	if ($cnt -eq 0) { return 0 }
	for ($i = 1; $i -lt $n; $i++) {
		if ($drop[$i] -and -not $drop[$i - 1] -and $p.c[$i].IndexOf("MiG-29 DL / moving map add-on", [System.StringComparison]::Ordinal) -ge 0 -and $p.c[$i - 1].Trim() -eq "") { $drop[$i - 1] = $true }
	}
	$last = -1
	for ($i = 0; $i -lt $n; $i++) { if (-not $drop[$i]) { $last = $i } }
	# our line was the end of a file without a final line end: so is the new end
	$noEnd = $drop[$n - 1] -and ($p.t[$n - 1] -eq "")
	$sb = New-Object System.Text.StringBuilder
	for ($i = 0; $i -lt $n; $i++) {
		if ($drop[$i]) { continue }
		[void]$sb.Append($p.c[$i])
		if (-not ($noEnd -and $i -eq $last)) { [void]$sb.Append($p.t[$i]) }
	}
	[System.IO.File]::WriteAllBytes($exp, $L1.GetBytes($sb.ToString()))
	return $cnt
}
# the add-on's scripts in Saved Games\DCS\Scripts and its Export.lua line
function Remove-OurScripts($sg) {
	$script:Step = "remove"
	$done = @()
	foreach ($p in @("Scripts\MiG29DL_Export.lua", "Scripts\Hooks\MiG29DL_Hook.lua")) {
		$q = J $sg $p
		if (IsFile $q) { Remove-File $q; $done += $p }
	}
	$script:Step = "export"
	if ((Remove-ExportLine (J $sg "Scripts\Export.lua")) -gt 0) { $done += "the add-on's line in Scripts\Export.lua" }
	return ,$done
}

# ---------------------------------------------------------------- the player's settings
$SettingsTemplate = [string]::Join("`r`n", @(
	"-- Vitezovi MiG-29 MFD add-on: YOUR OWN SETTINGS",
	"-- This file is yours: INSTALL, updates and UNINSTALL never change it.",
	"-- The add-on reads it after its defaults (Mods\tech\<KRN's mod>\Cockpit\",
	"-- Scripts\DL\dl_config.lua - every setting is explained there), so a line",
	"-- here overrides that default. Remove the -- in front of a line to use it,",
	"-- then restart the mission. Accepted forms, one per line:",
	"--     range_units = ""nm""                 -- a setting by its name",
	"--     DL_CFG.range_units = ""nm""          -- the same, written in full",
	"--     ranges_km[1] = 10                  -- one entry of a list",
	"-- A mistake here is written to Saved Games\DCS\Logs\mig29dl_device.log and",
	"-- the defaults are used for everything it did not set.",
	"",
	"-- range_units = ""nm""        -- range scale in nautical miles (""km"" = kilometres)",
	"-- map_brightness = 0.30     -- chart under the SA page: 1 = as printed, 0 = black",
	"-- boot_skip = true          -- no start-up sequence: straight to the MENU page",
	"-- perf_log = true           -- timing log for the MFD (Logs\mig29dl_perf.log); costs nothing when off",
	""))

# ---------------------------------------------------------------- the MiG-29's controls (v1.7.4)
$BindBegin = "-- VITEZOVI MFD ADD-ON BINDS BEGIN"
$BindEnd = "-- VITEZOVI MFD ADD-ON BINDS END"
$BindRel = "Mods\aircraft\MiG-29-Fulcrum\Input\MiG-29-Fulcrum"
# every DCS install folder (not Saved Games) that has the MiG-29's controls
function Get-DcsInstalls {
	$c = @()
	if ($DcsPath -ne "") { $c += $DcsPath }
	foreach ($k in @("HKCU:\Software\Eagle Dynamics\DCS World", "HKCU:\Software\Eagle Dynamics\DCS World OpenBeta",
	                 "HKLM:\SOFTWARE\Eagle Dynamics\DCS World", "HKLM:\SOFTWARE\WOW6432Node\Eagle Dynamics\DCS World")) {
		try { $v = (Get-ItemProperty -LiteralPath $k -ErrorAction Stop).Path; if ($v) { $c += [string]$v } } catch { }
	}
	foreach ($k in @("HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 223750",
	                 "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 223750")) {
		try { $v = (Get-ItemProperty -LiteralPath $k -ErrorAction Stop).InstallLocation; if ($v) { $c += [string]$v } } catch { }
	}
	$r = @(); $seen = @{}
	foreach ($d in $c) {
		$d = ([string]$d).Trim().Trim([char]'"').TrimEnd([char]'\', [char]'/')
		if ($d -eq "" -or -not (IsDir $d)) { continue }
		$key = $d.ToLowerInvariant()
		if ($seen[$key]) { continue }
		$seen[$key] = $true
		if (IsDir (J $d $BindRel)) { $r += $d }
	}
	return $r
}
# v1.7.8: DCS install folders for the moving-map charts. Unlike
# Get-DcsInstalls this needs no MiG-29 controls folder, and it also looks
# in the usual install places when the registry has nothing.
function Get-DcsRoots {
	$c = @()
	if ($DcsPath -ne "") { $c += $DcsPath }
	foreach ($k in @("HKCU:\Software\Eagle Dynamics\DCS World", "HKCU:\Software\Eagle Dynamics\DCS World OpenBeta",
	                 "HKLM:\SOFTWARE\Eagle Dynamics\DCS World", "HKLM:\SOFTWARE\WOW6432Node\Eagle Dynamics\DCS World")) {
		try { $v = (Get-ItemProperty -LiteralPath $k -ErrorAction Stop).Path; if ($v) { $c += [string]$v } } catch { }
	}
	foreach ($k in @("HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 223750",
	                 "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 223750")) {
		try { $v = (Get-ItemProperty -LiteralPath $k -ErrorAction Stop).InstallLocation; if ($v) { $c += [string]$v } } catch { }
	}
	foreach ($dr in @([System.IO.DriveInfo]::GetDrives())) {
		try { if ($dr.DriveType -ne "Fixed" -or -not $dr.IsReady) { continue } } catch { continue }
		$r = $dr.RootDirectory.FullName
		foreach ($sub in @("DCS World", "DCS World OpenBeta", "DCS", "Eagle Dynamics\DCS World", "Eagle Dynamics\DCS World OpenBeta",
		                   "Program Files\Eagle Dynamics\DCS World", "Program Files\Eagle Dynamics\DCS World OpenBeta",
		                   "Games\DCS World", "Games\DCS World OpenBeta", "SteamLibrary\steamapps\common\DCSWorld",
		                   "Program Files (x86)\Steam\steamapps\common\DCSWorld")) { $c += (J $r $sub) }
	}
	$r = @(); $seen = @{}
	foreach ($d in $c) {
		$d = ([string]$d).Trim().Trim([char]'"').TrimEnd([char]'\', [char]'/')
		if ($d -eq "" -or -not (IsDir (J $d "Mods\terrains"))) { continue }
		$key = $d.ToLowerInvariant()
		if ($seen[$key]) { continue }
		$seen[$key] = $true
		$r += $d
	}
	return $r
}
function Get-BindBlock($eol) {
	$rows = @(([System.IO.File]::ReadAllText((J $Here "vitezovi_binds.lua"))) -split "\r?\n" | Where-Object { $_ -ne "" })
	$ver = @((ReadL1 (J $Root "files\KRN mod\Cockpit\Scripts\DL\dl_config.lua")) -split "\r?\n" | Where-Object { $_ -match '^DL_VERSION' }) -join " "
	if ($ver -match '"([0-9.]+)"') { $ver = "v" + $Matches[1] } else { $ver = "" }
	$l = @(($BindBegin + " (Vitezovi MiG-29 MFD add-on " + $ver + "; INSTALL.bat adds this, UNINSTALL.bat removes it)"),
	       "join(res.keyCommands, {") + $rows + @("})", $BindEnd)
	return ([string]::Join($eol, $l) + $eol)
}
function Strip-Binds([string]$s) {
	return [regex]::Replace($s, "(?ms)^" + [regex]::Escape($BindBegin) + ".*?^" + [regex]::Escape($BindEnd) + "[^\r\n]*(\r?\n)?", "")
}
# "added" / "updated" / "already there" / "removed" / "not there" / why not
function Set-Binds($file, $remove, $backupDir) {
	if (-not (IsFile $file)) { return "no file" }
	$t = ReadL1 $file
	$has = $t.IndexOf($BindBegin, [System.StringComparison]::Ordinal) -ge 0
	if ($remove) {
		if (-not $has) { return "not there" }
		WriteL1 $file (Strip-Binds $t)
		return "removed"
	}
	$eol = "`n"; if ($t.IndexOf("`r`n", [System.StringComparison]::Ordinal) -ge 0) { $eol = "`r`n" }
	$base = $t
	if ($has) { $base = Strip-Binds $t }
	elseif ($backupDir) {
		Ensure-Dir $backupDir
		CopyFile $file (J $backupDir ([System.IO.Path]::GetFileName([System.IO.Path]::GetDirectoryName($file)) + "_default.lua"))
	}
	$ms = [regex]::Matches($base, "(?m)^return res[ \t]*\r?$")
	if ($ms.Count -eq 0) { return "left alone (not the usual format)" }
	$at = $ms[$ms.Count - 1].Index
	$new = $base.Substring(0, $at) + (Get-BindBlock $eol) + $base.Substring($at)
	if ($new -eq $t) { return "already there" }
	WriteL1 $file $new
	if ($has) { return "updated" }
	return "added"
}
function Do-Binds($remove, $backupRoot) {
	$script:Step = "binds"
	$ins = @(Get-DcsInstalls)
	if ($ins.Count -eq 0) {
		if (-not $remove) {
			Say "HOTAS binds: DCS's install folder was not found, so the MFD controls were not added to the MiG-29's"
			Say "  controls. Run INSTALL.bat -DcsPath ""D:\DCS World"" (your DCS folder) from a command prompt to add them."
		}
		return
	}
	foreach ($d in $ins) {
		$res = @()
		foreach ($kind in @("joystick", "keyboard")) {
			$f = J $d ($BindRel + "\" + $kind + "\default.lua")
			$bk = $null
			if ($backupRoot) { $bk = J $backupRoot ("dcs_input_backup\" + (($d -replace '[:\\/ ]+', '_').Trim('_'))) }
			try { $res += ($kind + " " + (Set-Binds $f $remove $bk)) }
			catch {
				$ex = $_.Exception
				if (($ex -is [System.UnauthorizedAccessException]) -or ($ex.InnerException -is [System.UnauthorizedAccessException])) {
					$res += ($kind + " NOT changed (no permission)"); $script:BindsNoAccess = $d
				} else { $res += ($kind + " NOT changed (" + $ex.Message + ")") }
			}
		}
		Say ("HOTAS binds in " + $d + ": " + ($res -join ", "))
	}
	if ($script:BindsNoAccess) {
		Say ("  Windows did not allow changes in " + $script:BindsNoAccess + ". Right-click INSTALL.bat (or UNINSTALL.bat) >")
		Say "  Run as administrator to do the HOTAS binds; everything else is done."
	}
	if (-not $remove) { Say "  In DCS: Options > Controls > MiG-29 > category ""Vitezovi MFD"". After a DCS update, run INSTALL.bat again." }
}

# ---------------------------------------------------------------- uninstall
function Uninstall-From($SG) {
	$script:Step = "check"
	Say ("DCS Saved Games: " + $SG)
	$Addon = J $SG "Vitezovi-MFD-Addon"
	$Backup = J $Addon "krn_backup"
	$OldBackup = J $SG "MiG29-DL-Addon\backup_original"     # the old all-in-one package
	$exp = J $SG "Scripts\Export.lua"
	Check-Export $exp $true
	$k = @(Find-Krn $SG)
	if ($k.Count -gt 1) { Fail ("KRN's mod is installed more than once - DCS would load both. Keep one, then run UNINSTALL again:`n    " + ($k -join "`n    ") + "`n  Nothing was changed.") }
	$Krn = $null
	$restore = @{}; $left = @(); $need = @(); $nobak = @(); $otherBack = 0
	if ($k.Count -eq 1) {
		$Krn = $k[0]
		Say ("KRN mod: " + $Krn)
		foreach ($rel in $Files) {
			$info = $Data.files.$rel
			$cur = J $Krn $rel
			$cands = @((J $Backup $rel), (J $OldBackup $rel))
			if (-not (IsFile $cur)) { $left += "$rel (missing)"; continue }
			if ($info.kind -eq "text") {
				$raw = ReadL1 $cur
				if ($null -ne (Get-TextOriginal $raw $info)) { continue }
				if ($null -eq (Get-TextResult $raw $info)) { $left += $rel; continue }
				$o = $null
				foreach ($p in $cands) { if ($null -eq $o -and (IsFile $p)) { $o = Get-TextOriginal (ReadL1 $p) $info } }
				if ($null -eq $o) { $need += $rel; continue }
				$restore[$rel] = @{ text = $o }
			} elseif ($info.kind -eq "edm") {
				$s = Sha $cur
				if ($s -eq $info.sha256) { continue }
				if (-not (Is-BinResult $s $info)) { $left += $rel; continue }
				$o = Find-BinOriginal $cands $info
				if ($null -eq $o) { $need += $rel; continue }
				$restore[$rel] = @{ path = $o }
			} else {
				$st = Get-PngState $cur $info
				if ($st -eq "orig") { continue }
				if ($st -ne "ours") {
					# another mod's texture with the add-on's labels on it: the copy
					# INSTALL kept of it before the labels were pasted goes back
					$ob = J $Addon ("textures_before_addon\" + $rel)
					if ($st -eq "other" -and (IsFile $ob) -and (Test-PastedFrom $ob $cur $rel (J $Addon "tmp"))) { $restore[$rel] = @{ path = $ob }; $otherBack++; continue }
					$left += $rel; continue
				}
				$o = Find-BinOriginal $cands $info
				if ($null -eq $o) { $nobak += $rel; continue }
				$restore[$rel] = @{ path = $o }
			}
		}
	} else {
		Say "KRN's mod is not installed here."
	}
	if ($need.Count -gt 0) {
		# KRN's mod stays as it is, but the add-on's scripts and its
		# Export.lua line go (without them nothing runs outside KRN's mod)
		$done = Remove-OurScripts $SG
		$what = "  Nothing else was removed."
		if ($done.Count -gt 0) { $what = "  Removed: " + ($done -join ", ") + "." }
		Fail ("No copy of KRN's originals was found (the add-on was put in by the old all-in-one package,`n" +
		      "  not by this installer), so KRN's mod was left as it is. To remove the add-on from it: delete the folder`n" +
		      "    $Krn`n  and unzip KRN's 'MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3' again.`n" + $what)
	}
	$script:Step = "restore"
	foreach ($rel in $Files) {
		if (-not $restore.ContainsKey($rel)) { continue }
		$r = $restore[$rel]
		if ($r.ContainsKey("text")) { WriteL1 (J $Krn $rel) $r.text } else { CopyFile $r.path (J $Krn $rel) }
	}
	$script:Step = "remove"
	$gone = 0
	if ($Krn) {
		foreach ($p in @("Cockpit\Scripts\DL", "Cockpit\Textures\IndicationTextures\mig29_dl_font.dds", "Cockpit\Textures\IndicationTextures\mig29_dl_logo.dds")) {
			$q = J $Krn $p
			if (IsDir $q) { Remove-Dir $q; $gone++ } elseif (IsFile $q) { Remove-File $q; $gone++ }
		}
	}
	$done = Remove-OurScripts $SG
	$script:Step = "remove"
	Remove-Dir (J $Addon "tmp")
	if ($restore.Count -gt 0 -and $otherBack -gt 0) { Say ("The files are back as they were before the add-on (" + $restore.Count + ", " + $otherBack + " of them another mod's texture), the add-on is removed.") }
	elseif ($restore.Count -gt 0) { Say ("KRN's original files are back (" + $restore.Count + "), the add-on is removed.") }
	elseif ($gone -eq 0 -and $done.Count -eq 0 -and $left.Count -eq 0 -and $nobak.Count -eq 0) { Say "Nothing of the add-on was found here - nothing to do." }
	elseif ($Krn -and $left.Count -eq 0 -and $nobak.Count -eq 0) { Say "KRN's files were KRN's originals already; the add-on is removed." }
	elseif ($Krn) { Say "The add-on is removed." }
	else { Say "The add-on's scripts are removed." }
	if ($done.Count -gt 0) { Say ("Removed: " + ($done -join ", ") + ".") }
	if ($left.Count -gt 0) {
		Say "Left as they are - not KRN's V1.0.3 files and not the add-on's (changed since, for example by a KRN update):"
		foreach ($x in $left) { Say ("    " + $x) }
	}
	if ($nobak.Count -gt 0) { Say ("No copy of KRN's original was kept for: " + ($nobak -join ", ") + " - it keeps the add-on's labels; reinstall KRN's mod to get it back exactly.") }
	Say "(Your settings in Vitezovi-MFD-Addon, flight list, cartridges in DTC and missions were left in place.)"
}

# ---------------------------------------------------------------- install
function Install-Into($SG) {
	$script:Step = "check"
	Say ("DCS Saved Games: " + $SG)
	$k = @(Find-Krn $SG)
	if ($k.Count -gt 1) { Fail ("KRN's mod is installed more than once - DCS would load both. Keep one:`n    " + ($k -join "`n    ") + "`n  Nothing was changed.") }
	$Krn = $k[0]
	Say ("KRN mod: " + $Krn)
	$Addon = J $SG "Vitezovi-MFD-Addon"
	$Backup = J $Addon "krn_backup"
	$OldBackup = J $SG "MiG29-DL-Addon\backup_original"     # the old all-in-one package
	$Tmp = J $Addon "tmp"
	$exp = J $SG "Scripts\Export.lua"
	Check-Export $exp $false

	# ------------------------------------------------ the originals (nothing is written before the checks are done)
	Say "Checking KRN's files ..."
	$plan = @{}           # rel -> text: KRN's original / path: a file with KRN's original; same: already the result
	$Bad = @(); $NoBackup = @(); $Notes = @()
	foreach ($rel in $Files) {
		$info = $Data.files.$rel
		$cur = J $Krn $rel
		$cands = @((J $Backup $rel), (J $OldBackup $rel))
		if (-not (IsFile $cur)) { $Bad += "$rel (missing)"; continue }
		if ($info.kind -eq "text") {
			$raw = ReadL1 $cur
			$o = Get-TextOriginal $raw $info
			if ($null -eq $o) {
				# a backup is used only when the file is still the add-on's
				$r = Get-TextResult $raw $info
				if ($null -eq $r) { $Bad += $rel; continue }
				foreach ($p in $cands) { if ($null -eq $o -and (IsFile $p)) { $o = Get-TextOriginal (ReadL1 $p) $info } }
				if ($null -eq $o) {
					$t = Undo-Text $raw $r      # no copy: take the add-on's lines out again
					if ((ShaText $t) -eq $info.norm_sha256) { $o = Rebuild-Original $t $info }
				}
				if ($null -eq $o) { $Bad += $rel; continue }
			}
			$plan[$rel] = @{ text = $o; same = ((ShaText $raw) -eq $info.result_sha256) }
		} elseif ($info.kind -eq "edm") {
			$s = Sha $cur
			if ($s -eq $info.sha256) { $plan[$rel] = @{ path = $cur; same = $false }; continue }
			if (-not (Is-BinResult $s $info)) { $Bad += $rel; continue }
			$o = Find-BinOriginal $cands $info
			if ($null -eq $o) {
				Ensure-Dir $Tmp
				$p = J $Tmp "UFCP.edm.orig"
				$e = $Data.edm
				[VitezoviPatch]::EdmUnsplice($cur, $p, [long[]]@($e.overwrite_orig | ForEach-Object { $_[0] }), [string[]]@($e.overwrite_orig | ForEach-Object { $_[1] }),
					[long[]]@($e.insert | ForEach-Object { $_[0] }), [string[]]@($e.insert | ForEach-Object { $_[1] }))
				if ((Sha $p) -eq $info.sha256) { $o = $p }
			}
			if ($null -eq $o) { $Bad += $rel; continue }
			$plan[$rel] = @{ path = $o; same = ($s -eq $info.result_sha256) }
		} else {
			# textures: the label tiles replace whole areas, so they also go onto
			# a texture someone else changed - but only one of KRN's size
			$st = Get-PngState $cur $info
			if ($st -eq "orig") { $plan[$rel] = @{ path = $cur; same = $false }; continue }
			if ($st -eq "ours") {
				$o = Find-BinOriginal $cands $info
				if ($null -ne $o) { $plan[$rel] = @{ path = $o; same = $true } }
				else { $plan[$rel] = @{ path = $cur; same = $true }; $NoBackup += $rel }
				continue
			}
			if ($st -eq "other") {
				$plan[$rel] = @{ path = $cur; same = $false; other = $true }; $NoBackup += $rel
				continue
			}
			$Notes += "$rel $st - left as it is, so the add-on's button labels in it are missing."
		}
	}
	if ($Bad.Count -gt 0) {
		Remove-Dir $Tmp
		Fail ("KRN's mod has changed (newer version?) - this add-on is made for V1.0.3; nothing was changed.`n" +
		      "  These files are neither KRN's V1.0.3 originals nor the add-on's changes of them:`n    " + ($Bad -join "`n    ") + "`n" +
		      "  If you updated KRN's mod, this add-on needs an update for that KRN version first.`n" +
		      "  To use it with V1.0.3: delete the folder`n    $Krn`n" +
		      "  unzip KRN's 'MiG-29A(M) Cockpit Modernization - KRN MODS V1.0.3' again, then run INSTALL again.")
	}
	# the player's changes in dl_config.lua (it is replaced by the new one)
	$cfgCur = J $Krn "Cockpit\Scripts\DL\dl_config.lua"
	$cfgSave = $false
	if (IsFile $cfgCur) {
		$h = ShaText (NormText (ReadL1 $cfgCur))
		$known = @($Data.dl_config_shipped | ForEach-Object { $_.norm_sha256 })
		$known += ShaText (NormText (ReadL1 (J $Root "files\KRN mod\Cockpit\Scripts\DL\dl_config.lua")))
		$cfgSave = ($known -notcontains $h)
	}

	# ------------------------------------------------ backups (only in Vitezovi-MFD-Addon)
	$script:Step = "backup"
	foreach ($rel in $Files) {
		if (-not $plan.ContainsKey($rel) -or $NoBackup -contains $rel) { continue }
		$info = $Data.files.$rel
		$bak = J $Backup $rel
		$pl = $plan[$rel]
		if ($pl.ContainsKey("text")) {
			if (-not (IsFile $bak) -or (Sha $bak) -ne $info.sha256) { WriteL1 $bak $pl.text }
		} elseif ($pl.path -ne $bak -and $null -eq (Find-BinOriginal @($bak) $info)) {
			CopyFile $pl.path $bak
		}
	}
	Say ("KRN's originals kept in " + $Backup)
	if ($cfgSave) {
		$dst = J $Addon "dl_config_before_update.lua"
		$i = 2
		while ((IsFile $dst) -and ((Sha $dst) -ne (Sha $cfgCur))) { $dst = J $Addon ("dl_config_before_update_" + $i + ".lua"); $i++ }
		CopyFile $cfgCur $dst
		$Notes += ("Your changed dl_config.lua was saved as`n      $dst`n" +
		           "    An update always replaces dl_config.lua: put your changes into Vitezovi-MFD-Addon\settings.lua`n" +
		           "    (see the top of dl_config.lua) - that file is kept from now on.")
	}

	# ------------------------------------------------ patch (into tmp, then copy over KRN's files)
	$script:Step = "patch"
	Say "Applying the add-on's changes to KRN's files ..."
	Ensure-Dir $Tmp
	$Out = @{}
	foreach ($rel in $Files) {
		if (-not $plan.ContainsKey($rel)) { continue }
		$pl = $plan[$rel]
		if ($pl.same) { continue }          # already exactly the add-on's result
		$info = $Data.files.$rel
		$dst = J $Tmp (($rel -replace "[\\/:]", "_") + ".new")
		if ($info.kind -eq "text") {
			$res = Patch-Text $pl.text $rel $info
			if ((ShaText $res) -ne $info.result_sha256) { Fail "$rel : the result is not as expected. Nothing was changed in KRN's mod." }
			WriteL1 $dst $res
		} elseif ($info.kind -eq "edm") {
			$e = $Data.edm
			[VitezoviPatch]::EdmSplice($pl.path, $dst, [long[]]@($e.overwrite | ForEach-Object { $_[0] }), [string[]]@($e.overwrite | ForEach-Object { $_[1] }),
				[long[]]@($e.insert | ForEach-Object { $_[0] }), [string[]]@($e.insert | ForEach-Object { $_[1] }))
			if ((Sha $dst) -ne $info.result_sha256) { Fail "UFCP.edm: the result is not as expected. Nothing was changed in KRN's mod." }
		} else {
			$ts = @($Data.tiles | Where-Object { $_.file -eq $rel })
			$px = [VitezoviPatch]::PasteTiles($pl.path, [string[]]@($ts | ForEach-Object { J $Here ("tiles\" + $_.tile) }),
				[int[]]@($ts | ForEach-Object { $_.x }), [int[]]@($ts | ForEach-Object { $_.y }), $dst)
			if (-not $pl.other -and $px -ne $info.result_pix_sha256) { Fail "$rel : the result is not as expected. Nothing was changed in KRN's mod." }
			if ($pl.other) {
				# another mod's texture: keep it as it is now, unless the copy kept
				# earlier is this same texture without (or with) our labels
				$ob = J $Addon ("textures_before_addon\" + $rel)
				$have = $false
				if (IsFile $ob) {
					try { $have = (([VitezoviPatch]::PngPixelSha($ob)) -eq ([VitezoviPatch]::PngPixelSha($pl.path))) } catch { }
					if (-not $have) { $have = Test-PastedFrom $ob $pl.path $rel $Tmp }
				}
				# pasting changed nothing: the labels are on it already (an earlier
				# package put them there), so this is not the texture as it was
				$labelled = $false
				try { $labelled = ($px -eq ([VitezoviPatch]::PngPixelSha($pl.path))) } catch { }
				if (-not $have -and -not $labelled) { CopyFile $pl.path $ob; $have = $true }
				if ($have) { $Notes += "$rel is not KRN's V1.0.3 texture (changed by another mod?) - the add-on's labels were pasted onto it. The texture as it was is kept in Vitezovi-MFD-Addon\textures_before_addon; UNINSTALL puts it back." }
				else { $Notes += "$rel is not KRN's V1.0.3 texture (changed by another mod?) and has the add-on's labels on it already; UNINSTALL cannot bring the earlier one back." }
			}
		}
		$Out[$rel] = $dst
	}
	$script:Step = "move"
	foreach ($rel in $Files) { if ($Out.ContainsKey($rel)) { CopyFile $Out[$rel] (J $Krn $rel) } }
	Remove-Dir $Tmp

	# ------------------------------------------------ our files
	$script:Step = "copy"
	Say "Copying the add-on's files ..."
	foreach ($p in @("Cockpit\Scripts\DL\dl_hud_init.lua", "Cockpit\Scripts\DL\dl_hud_page.lua", "Cockpit\Scripts\DL\checklists_default.txt",
	                 "Cockpit\Textures\IndicationTextures\mig29_dl_map_caucasus.dds")) {
		Remove-File (J $Krn $p)
	}
	$script:Replaced = @()
	$copied = @(Copy-Tree (J $Root "files\KRN mod") $Krn) + @(Copy-Tree (J $Root "files\Saved Games DCS") $SG (J $Addon "replaced_examples"))
	$miss = @($copied | Where-Object { -not (IsFile $_) })
	foreach ($p in @((J $Krn "Cockpit\Scripts\DL\dl_device.lua"), (J $SG "Scripts\MiG29DL_Export.lua"), (J $SG "Scripts\Hooks\MiG29DL_Hook.lua"))) {
		if (-not (IsFile $p)) { $miss += $p }
	}
	if ($miss.Count -gt 0) {
		Fail ("The add-on's files did not arrive where they belong:`n    " + ($miss -join "`n    ") + "`n" +
		      "  Unzip the whole package again into a normal folder (for example your Desktop), close DCS,`n" +
		      "  then run INSTALL.bat from there. (KRN's files are already changed; INSTALL again finishes the job.)")
	}

	# ------------------------------------------------ the moving map's charts (never stops the install)
	$script:Step = "charts"
	Build-Charts $Krn

	# ------------------------------------------------ Export.lua line
	$script:Step = "export"
	Say ("Export.lua: " + (Add-ExportLine $exp))

	# ------------------------------------------------ the player's own settings file (never overwritten)
	$script:Step = "settings"
	$set = J $Addon "settings.lua"
	if (-not (IsFile $set)) { WriteL1 $set $SettingsTemplate; Say ("Your own settings go into " + $set + " (new, nothing in it is switched on).") }
	else { Say ("Your own settings: " + $set + " (kept as it is).") }
	$ver = @((ReadL1 (J $Root "files\KRN mod\Cockpit\Scripts\DL\dl_config.lua")) -split "`r?`n" | Where-Object { $_ -match '^DL_VERSION' })
	[System.IO.File]::WriteAllLines((J $Addon "installed.txt"), [string[]]@(("Vitezovi MiG-29 MFD add-on  " + ($ver -join " ")), "KRN mod: $Krn", (Get-Date).ToString("s")))
	Write-Host ""
	Say "Done. Start DCS and fly the MiG-29 (KRN's mod must be enabled in Options > Special > MIG-29AM)."
	foreach ($n in $Notes) { Say ("Note: " + $n) }
	if ($script:Replaced.Count -gt 0) {
		Say ("Note: these example files were different from the package's and were replaced: " + ($script:Replaced -join ", "))
		Say ("    The ones you had are kept in " + (J $Addon "replaced_examples") + " (edit a copy under another name to keep your changes in use).")
	}
	foreach ($rel in $NoBackup) {
		if ($plan[$rel].other) { continue }
		Say ("Note: no original kept for $rel (it was already changed). UNINSTALL cannot restore it - reinstall KRN's mod for that.")
	}
}
# v1.7.8: the moving map. DCS's raster charts are hundreds or thousands of
# small tiles, and an MFD page with one element per tile and range step
# crashed DCS at spawn. VitezoviCharts.cs joins them into a few big textures
# (DXT1, 2048 px) per sharpness the range steps need, read straight from
# DCS's chart zips, into KRN mod\Cockpit\Scripts\DL\charts_gen (removed
# with the add-on). A map that was built before from the same DCS files is
# not built again. If anything goes wrong the MFD uses DCS's own tiles.
function Build-Charts($Krn) {
	$ans = $Charts.Trim().ToLowerInvariant()
	if ($NoCharts) { $ans = "no" }
	$dl = J $Krn "Cockpit\Scripts\DL"
	$out = J $dl "charts_gen"
	$roots = @(Get-DcsRoots)
	if ($roots.Count -eq 0) { Say "Moving map: DCS install folder not found (INSTALL.bat -DcsPath <folder>) - the MFD uses DCS's own chart tiles."; return }
	try { if (-not ("VitezoviCharts" -as [type])) { Add-Type -Path (J $Here "VitezoviCharts.cs") } }
	catch { Say ("Moving map: the chart builder did not start (" + $_.Exception.Message + ") - the MFD uses DCS's own chart tiles."); return }
	# every range step of the MFD, in km and nm (index from 0, metres)
	$ri = [int[]]@(0, 1, 2, 3, 4, 0, 1, 2, 3, 4)
	$rm = [double[]]@(20000, 40000, 80000, 160000, 320000, 18520, 37040, 74080, 148160, 296320)
	Say "Moving map: looking at DCS's chart files ..."
	$new = @(); $kept = 0
	foreach ($f in [System.IO.Directory]::GetFiles((J $dl "charts"), "*.lua")) {
		$t = [System.IO.Path]::GetFileNameWithoutExtension($f)
		foreach ($r in $roots) {
			try { $e = [VitezoviCharts]::Estimate($r, $f, $out, $t, $ri, $rm, 2048, 300.0) }
			catch { $x = $_.Exception; while ($x.InnerException) { $x = $x.InnerException }; Say ("    " + $t + ": cannot read its charts (" + $x.Message + ")"); break }
			if ($e -eq "SKIP") { continue }
			if ($e -eq "SAME") { Say ("    " + $t + ": built before from the same charts - kept"); $kept++ }
			else { $p = $e.Split(' '); $new += @{ t = $t; f = $f; r = $r; n = [int]$p[1]; mb = [long]$p[2]; s = [long]$p[3] } }
			break
		}
	}
	if ($new.Count -eq 0) {
		if ($kept -eq 0) { Say ("    no DCS chart files found in " + ($roots -join ", ") + " - the MFD uses DCS's own chart tiles.") }
		if ((IsDir $out) -and @([System.IO.Directory]::GetFileSystemEntries($out)).Count -eq 0) { Remove-Dir $out }
		return
	}
	$tmb = 0; $ts = 0
	Say "  The MFD's moving map works best from big textures joined from DCS's chart"
	Say "  tiles: the whole map at every range step, and a lighter MFD page that does not"
	Say "  crash DCS at spawn. Building them for these maps takes about:"
	foreach ($m in $new) {
		$tmb += $m.mb; $ts += $m.s
		Say ("    {0,-16} {1,6} MB   {2}" -f $m.t, $m.mb, (Fmt-Time $m.s))
	}
	Say ("    {0,-16} {1,6} MB   {2}   (disk space in KRN's mod folder)" -f "together", $tmb, (Fmt-Time $ts))
	Say "  Without them the MFD uses DCS's own small tiles, only around where you fly."
	if ($ans -eq "") {
		$redir = $false
		try { $redir = [Console]::IsInputRedirected } catch { }
		if ($redir) { $ans = "no" } else { Write-Host ""; $ans = (Read-Host "  Build the moving-map textures now? (Y = yes, N = no)").Trim().ToLowerInvariant() }
	}
	if ($ans -notmatch '^(y|yes|j|ja)$') {
		foreach ($m in $new) { try { [VitezoviCharts]::Remove($out, $m.t) } catch { } }
		Say "  Not built. Run INSTALL again any time to build them."
		if ((IsDir $out) -and @([System.IO.Directory]::GetFileSystemEntries($out)).Count -eq 0) { Remove-Dir $out }
		return
	}
	Say "  Building ..."
	$sw = [System.Diagnostics.Stopwatch]::StartNew()
	foreach ($m in $new) {
		try {
			$res = [VitezoviCharts]::Build($m.r, $m.f, $out, $m.t, $ri, $rm, 2048, 300.0, $false)
			Say ("    " + ($res -replace '^(BUILT|SAME|SKIP) ', ''))
		} catch {
			$x = $_.Exception
			while ($x.InnerException) { $x = $x.InnerException }
			Say ("    PROBLEM " + $m.t + ": " + $x.Message + " - the MFD uses DCS's own chart tiles there")
		}
	}
	Say ("  Moving map built in " + (Fmt-Time ([long]$sw.Elapsed.TotalSeconds)) + ".")
	if ((IsDir $out) -and @([System.IO.Directory]::GetFileSystemEntries($out)).Count -eq 0) { Remove-Dir $out }
}
function Fmt-Time($s) {
	if ($s -lt 90) { return ("about " + [Math]::Max(5, [Math]::Round($s / 5) * 5) + " s") }
	return ("about " + [Math]::Round($s / 60) + " min")
}
# copies a folder's files (not a wildcard copy: [ ] in the path stay literal)
# $keep: a folder for the example cartridges / missions (DTC, Missions) that
# are there already and differ from the package's - the player may have
# edited them, so the old one is kept there before it is replaced
function Copy-Tree($from, $to, $keep) {
	$base = [System.IO.Path]::GetFullPath($from).TrimEnd([char]'\', [char]'/')
	$list = @()
	foreach ($f in [System.IO.Directory]::GetFiles($base, "*", [System.IO.SearchOption]::AllDirectories)) {
		$name = [System.IO.Path]::GetFileName($f)
		if ($name -eq "Thumbs.db" -or $name -eq "desktop.ini") { continue }
		$rel = $f.Substring($base.Length).TrimStart([char]'\', [char]'/')
		$dst = J $to $rel
		if ($keep -and ($rel -match '^(DTC|Missions)[\\/]') -and (IsFile $dst) -and ((Sha $dst) -ne (Sha $f))) {
			$kp = J $keep $rel
			$i = 2
			while ((IsFile $kp) -and ((Sha $kp) -ne (Sha $dst))) {
				$kp = J $keep ([System.IO.Path]::Combine([System.IO.Path]::GetDirectoryName($rel), ([System.IO.Path]::GetFileNameWithoutExtension($rel) + " (" + $i + ")" + [System.IO.Path]::GetExtension($rel))))
				$i++
			}
			if (-not (IsFile $kp)) { CopyFile $dst $kp }
			$script:Replaced += $rel
		}
		CopyFile $f $dst
		$list += $dst
	}
	return $list
}
# the package must be complete before anything is changed (a partly
# unzipped folder would otherwise give a half installation)
function Check-Package {
	$miss = @()
	foreach ($p in @("files\KRN mod\Cockpit\Scripts\DL\dl_device.lua", "files\KRN mod\Cockpit\Scripts\DL\dl_config.lua", "installer\vitezovi_binds.lua",
	                 "files\Saved Games DCS\Scripts\MiG29DL_Export.lua", "files\Saved Games DCS\Scripts\Hooks\MiG29DL_Hook.lua")) {
		if (-not (IsFile (J $Root $p))) { $miss += $p }
	}
	foreach ($t in @($Data.tiles)) { if (-not (IsFile (J $Here ("tiles\" + $t.tile)))) { $miss += ("installer\tiles\" + $t.tile) } }
	if ($miss.Count -gt 0) {
		Fail ("The add-on's package is not complete - missing:`n    " + ($miss -join "`n    ") + "`n" +
		      "  Unzip the whole zip into a normal folder (for example your Desktop), then run INSTALL.bat from there.`n" +
		      "  Nothing was changed.")
	}
}

# ---------------------------------------------------------------- main
try {
	if (Get-Process -Name "DCS" -ErrorAction SilentlyContinue) { Fail "DCS is running. Close DCS first. Nothing was changed." }
	$script:Step = "data"
	$Data = [System.IO.File]::ReadAllText((J $Here "krn_patch.json")) | ConvertFrom-Json
	$Files = @($Data.files.PSObject.Properties | ForEach-Object { $_.Name })
	if (-not $Uninstall) { Check-Package }
	$script:Step = "start"
	$Targets = @(Get-Targets)
	# files from a downloaded zip may be marked "from the internet": unmark ours
	if ($env:OS -eq "Windows_NT") {
		try { Get-ChildItem -LiteralPath $Root -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue } catch { }
	}
	$script:Step = "helper"
	if (-not ("VitezoviPatch" -as [type])) { Add-Type -Path (J $Here "VitezoviPatch.cs") }
} catch {
	Show-Error $_ ""
	exit 1
}
if ($Targets.Count -gt 1) {
	$w = "KRN's mod is in"; if ($Uninstall) { $w = "The add-on is in" }
	Say ($w + " " + $Targets.Count + " DCS folders - each of them is done:")
	foreach ($t in $Targets) { Say ("    " + $t) }
}
$okT = @(); $badT = @()
foreach ($t in $Targets) {
	Write-Host ""
	try {
		if ($Uninstall) { Uninstall-From $t } else { Install-Into $t }
		$okT += $t
	} catch {
		Show-Error $_ $t
		$badT += $t
	}
}
# the MiG-29's controls: once for every DCS install (never stops the rest)
if ($okT.Count -gt 0) {
	Write-Host ""
	try { Do-Binds ([bool]$Uninstall) (J $okT[0] "Vitezovi-MFD-Addon") }
	catch { Say ("HOTAS binds: not done (" + $_.Exception.Message + "). Everything else is done.") }
}
if ($Targets.Count -gt 1) {
	Write-Host ""
	if ($okT.Count -gt 0) { Say ("Done in: " + ($okT -join ", ")) }
	if ($badT.Count -gt 0) { Say ("NOT done in: " + ($badT -join ", ") + " (see PROBLEM above)") }
}
if ($badT.Count -gt 0) { exit 1 }
exit 0
