-----------------------------------------------------------------------
-- MiG-29 DL add-on v1.8.5: SRS radios 2 and 3 on the COM/NAV page
--
-- SRS (DCS-SimpleRadio Standalone) gives the MiG-29 three radios:
--   radio 1  R-862         the jet's own radio: SRS reads it from the
--                          cockpit (device 51), the page only shows it
--   radio 2  AN/ARC-186    VHF 116.000 - 151.975 (SRS expansion radio)
--   radio 3  AN/ARC-164    UHF 225.000 - 399.975 (SRS expansion radio)
-- Radios 2 and 3 have no panel in the jet: SRS lets the overlay (and its
-- UDP command port) tune them. This file keeps 20 preset channels for
-- each and tunes SRS through that port, as the F-15C SIT add-on does:
--   FREQUENCY_SET  {"RadioId":r,"Frequency":f,"Command":12}   (MHz)
--   SET_VOLUME     {"RadioId":r,"Volume":v,"Command":5}       (0..1)
-- SRS does not answer: the page shows what was last sent from here.
-- Presets: settings.lua srs_vhf_presets / srs_uhf_presets (defaults),
-- changed on the page (EDIT, UFCP keypad) and kept with the selected
-- channels and volumes in Saved Games\DCS\Vitezovi-MFD-Addon\srs_radios.txt
-- Runs in the cockpit device (dl_device.lua); the device hands it its
-- UDP socket (DL_SRS.init), nothing here opens a port.
-----------------------------------------------------------------------

DL_SRS = {}
local S = DL_SRS
local CFG = DL_CFG or {}
local floor = math.floor

S.RADIOS = {
	[2] = {id = 2, key = "VHF", model = "ARC-186", min = 116.0, max = 151.975, guard = 121.5},
	[3] = {id = 3, key = "UHF", model = "ARC-164", min = 225.0, max = 399.975, guard = 243.0},
}
S.N = 20                       -- preset channels per radio

local send = nil               -- function(msg) from the device (UDP to SRS)
local dbg = function() end
local nlog = 0
local ST = {
	ch = {[2] = 1, [3] = 1},
	vol = {[2] = CFG.srs_vol_start or 80, [3] = CFG.srs_vol_start or 80},
	list = {[2] = {}, [3] = {}},
	edited = {[2] = false, [3] = false},
	sent = {},                 -- [r] = frequency last sent
	t0 = nil, started = false, loaded = false,
	sync_t = nil,              -- time of the last SYNC (page shows "SENT")
}
S.ST = ST

local function enabled() return CFG.srs_radios ~= false end
local function port() return tonumber(CFG.srs_port) or 9040 end

-- frequencies on the 25 kHz raster, inside the radio's band
local function snap(f) return floor(f / 0.025 + 0.5) * 0.025 end
function S.valid(r, f)
	local R = S.RADIOS[r]
	return R and type(f) == "number" and f == f and f >= R.min - 1e-6 and f <= R.max + 1e-6
end

-----------------------------------------------------------------------
-- file: Saved Games\DCS\Vitezovi-MFD-Addon\srs_radios.txt, lines
--   VHF_CH=3   VHF_VOL=80   VHF_01=124.800 ... (UHF the same)
-----------------------------------------------------------------------
local function file_path()
	local ok, l = pcall(require, "lfs")
	if not (ok and type(l) == "table" and l.writedir) then return nil end
	local okw, wd = pcall(l.writedir)
	if not (okw and type(wd) == "string") then return nil end
	if wd:sub(-1) ~= "/" and wd:sub(-1) ~= "\\" then wd = wd .. "/" end
	pcall(l.mkdir, wd .. "Vitezovi-MFD-Addon")
	return wd .. "Vitezovi-MFD-Addon/srs_radios.txt"
end
local function defaults()
	for r, R in pairs(S.RADIOS) do
		local src = CFG[(R.key == "VHF") and "srs_vhf_presets" or "srs_uhf_presets"]
		local list = {}
		if type(src) == "table" then
			for k = 1, S.N do
				local f = tonumber(src[k])
				if f and S.valid(r, f) then list[k] = snap(f) end
			end
		end
		ST.list[r] = list
		ST.edited[r] = false
	end
end
function S.load()
	ST.loaded = true
	defaults()
	local fn = file_path()
	local fh = fn and io.open(fn, "r")
	if not fh then return end
	for raw in fh:lines() do
		local key, what, v = raw:match("^%s*(%u%u%u)_(%w+)%s*=%s*([%d%.]+)")
		local r = (key == "VHF") and 2 or ((key == "UHF") and 3 or nil)
		v = tonumber(v)
		if r and v then
			if what == "CH" then ST.ch[r] = math.max(1, math.min(S.N, floor(v)))
			elseif what == "VOL" then ST.vol[r] = math.max(0, math.min(100, floor(v)))
			else
				local k = tonumber(what)
				if k and k >= 1 and k <= S.N and S.valid(r, v) then
					ST.list[r][floor(k)] = snap(v); ST.edited[r] = true
				end
			end
		end
	end
	fh:close()
end
local function save()
	local fn = file_path()
	local fh = fn and io.open(fn, "w")
	if not fh then return end
	fh:write("-- SRS radios 2 (VHF) and 3 (UHF) of the Vitezovi MiG-29 MFD add-on (COM/NAV page).\n")
	fh:write("-- Written by the cockpit; you can edit it with DCS closed. VHF 116-151.975, UHF 225-399.975 MHz.\n")
	for r = 2, 3 do
		local K = S.RADIOS[r].key
		fh:write(string.format("%s_CH=%d\n%s_VOL=%d\n", K, ST.ch[r], K, ST.vol[r]))
		for k = 1, S.N do
			local f = ST.list[r][k]
			if f then fh:write(string.format("%s_%02d=%.3f\n", K, k, f)) end
		end
	end
	fh:close()
end

-----------------------------------------------------------------------
-- SRS commands
-----------------------------------------------------------------------
local function cmd(msg)
	if not (send and enabled()) then return false end
	local ok = pcall(send, msg, port())
	if nlog < 40 then nlog = nlog + 1; dbg("SRS: " .. msg .. (ok and "" or " (send failed)")) end
	return ok
end
local function tune(r)
	local f = ST.list[r][ST.ch[r]]
	if not f then return end
	cmd(string.format('{"RadioId":%d,"Frequency":%.3f,"Command":12}', r, f))
	ST.sent[r] = f
end
local function set_vol(r)
	cmd(string.format('{"RadioId":%d,"Volume":%.2f,"Command":5}', r, ST.vol[r] / 100))
end

function S.init(sender, logf)
	send = sender
	if logf then dbg = logf end
	if not ST.loaded then S.load() end
end

-- channel step (dir +1 = next channel), tunes SRS when the channel has a frequency
function S.step(r, dir)
	if not S.RADIOS[r] then return end
	if not ST.loaded then S.load() end
	ST.ch[r] = (ST.ch[r] - 1 + dir) % S.N + 1
	tune(r)
	save()
end
function S.volume(r, dir)
	if not S.RADIOS[r] then return end
	if not ST.loaded then S.load() end
	ST.vol[r] = math.max(0, math.min(100, ST.vol[r] + dir * (CFG.srs_vol_step or 5)))
	set_vol(r)
	save()
end
-- new frequency for channel ch (the selected one when nil); nil + reason when not taken
function S.set_freq(r, f, ch)
	local R = S.RADIOS[r]
	if not R then return nil, "NO RADIO" end
	if not ST.loaded then S.load() end
	if not S.valid(r, f) then return nil, string.format("%s %.3f-%.3f ONLY", R.key, R.min, R.max) end
	ch = ch or ST.ch[r]
	ST.list[r][ch] = snap(f)
	ST.edited[r] = true
	if ch == ST.ch[r] then tune(r) end
	save()
	return true
end
-- typed digits -> MHz: the point goes after the third digit (124 = 124.000,
-- 1248 = 124.800, 251025 = 251.025)
function S.parse(buf)
	if type(buf) ~= "string" or #buf < 3 or buf:find("%D") then return nil end
	return tonumber(buf:sub(1, 3) .. "." .. ((#buf > 3) and buf:sub(4) or "0"))
end
-- both radios again (frequency + volume): SRS started after DCS, or tuned in the overlay
function S.sync(t)
	if not ST.loaded then S.load() end
	for r = 2, 3 do tune(r); set_vol(r) end
	ST.sync_t = t
end
-- every device update: the first send a few seconds after the cockpit starts
function S.tick(t)
	if ST.started or not send then return end
	ST.t0 = ST.t0 or t
	if t - ST.t0 >= (CFG.srs_start_delay or 3) then
		ST.started = true
		if enabled() then S.sync(nil) end
	end
end

-- for the page
function S.channel(r) return ST.ch[r] end
function S.freq(r, k) return ST.list[r][k or ST.ch[r]] end
function S.vol(r) return ST.vol[r] end
function S.is_edited(r) return ST.edited[r] end
function S.on() return enabled() end
