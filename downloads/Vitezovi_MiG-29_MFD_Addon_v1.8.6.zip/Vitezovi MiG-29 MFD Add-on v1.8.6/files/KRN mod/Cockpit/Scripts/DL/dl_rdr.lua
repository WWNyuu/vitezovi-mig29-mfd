-----------------------------------------------------------------------
-- MiG-29 DL add-on: radar cone on the SA page (round 39, 19 Nov 2026)
-- DL_RDR_ON = 1 while the radar is on (dl_page.lua draws the cone).
-- The MiG-29 gives the radar state neither to the export nor as cockpit
-- values; it is read from cockpit argument 296 = the radar switch
-- (-1 OFF, 0 STBY, 1 ON; found with the probe in DCS, 19 Nov 2026):
--   rdr_arg (296), rdr_on_min / rdr_on_max (0.5 / 1.5) = "on" range
--   rdr_arg = false: no switch; rdr_always = true then shows the cone always
-- rdr_probe = true (with rdr_arg = false): writes every cockpit argument
-- that changes to Saved Games\DCS\Logs\mig29dl_argprobe.log.
-----------------------------------------------------------------------
DL_RDR = {on = false}
local CFG = DL_CFG or {}
local H = nil
local arg_fn = get_cockpit_draw_argument_value

-- the probe: sweeps args 0..PMAX-1, PSTEP per update, logs changes
local PMAX, PSTEP = CFG.rdr_probe_max or 3000, CFG.rdr_probe_step or 500
local P = {last = {}, cnt = {}, i = 0, lines = 0, fh = nil, sweeps = 0}
local function plog(s)
	if P.lines >= (CFG.rdr_probe_lines or 6000) then return end
	if not P.fh then
		local ok, l = pcall(require, "lfs")
		if not (ok and l and l.writedir) then P.lines = 1e9; return end
		P.fh = io.open(l.writedir() .. "Logs/mig29dl_argprobe.log", "w")
		if not P.fh then P.lines = 1e9; return end
	end
	P.lines = P.lines + 1
	P.fh:write(os.date("%H:%M:%S "), s, "\n")
	if P.lines % 20 == 0 then P.fh:flush() end
end
local function probe(t)
	if not arg_fn then return end
	if P.i == 0 and P.sweeps == 0 then plog(string.format("START t=%.1f  args 0-%d  (format: clock t arg old -> new; radar switch = arg 296)", t, PMAX - 1)) end
	local stop = math.min(P.i + PSTEP, PMAX)
	for a = P.i, stop - 1 do
		local ok, v = pcall(arg_fn, a)
		if ok and type(v) == "number" then
			local o = P.last[a]
			if o == nil then
				P.last[a] = v
			elseif math.abs(v - o) > 0.004 then
				local c = (P.cnt[a] or 0) + 1
				P.cnt[a] = c
				P.last[a] = v
				if P.sweeps > 0 then
					if c <= 40 then plog(string.format("%.1f %d %.3f -> %.3f", t, a, o, v))
					elseif c == 41 then plog(string.format("%.1f %d NOISY (changes all the time, not logged any more)", t, a)) end
				end
			end
		end
	end
	P.i = stop
	if P.i >= PMAX then
		P.i = 0; P.sweeps = P.sweeps + 1
		if P.sweeps == 1 then
			-- first full sweep: the starting values of everything not 0
			local s, n = {}, 0
			for a = 0, PMAX - 1 do
				local v = P.last[a]
				if v and v ~= 0 then n = n + 1; s[#s + 1] = a .. "=" .. string.format("%.3f", v) end
				if #s >= 12 then plog("INIT " .. table.concat(s, " ")); s = {} end
			end
			if #s > 0 then plog("INIT " .. table.concat(s, " ")) end
			plog(string.format("INIT done, %d args not 0; changes from here on", n))
		end
		if P.fh then P.fh:flush() end
	end
end

function DL_RDR.tick(t)
	arg_fn = arg_fn or get_cockpit_draw_argument_value
	if not H then H = {on = get_param_handle("DL_RDR_ON"), last = nil} end
	local on
	local a = CFG.rdr_arg
	if a == nil then a = 296 end
	if a and arg_fn then
		local v = arg_fn(a) or 0
		on = v >= (CFG.rdr_on_min or 0.5) and v <= (CFG.rdr_on_max or 1.5)
	else
		on = CFG.rdr_always == true
	end
	if CFG.rdr_probe then probe(t) end
	DL_RDR.on = on
	local n = on and 1 or 0
	if H.last ~= n then H.last = n; H.on:set(n) end
end

-- round 42: the cone is as long as the radar's range. The lower knob on the
-- radar panel (cockpit argument 295, 0 / 0.1 / 0.2 / 0.3, found with the
-- probe in DCS, 19 Nov 2026) picks the mode:
--   1 normal 100 km, 2 vertical scan 10 km, 3 head-on 150 km, 4 pursuit 50 km
-- rdr_mode_arg / rdr_mode_km (km by knob step 0..3) in settings.lua.
-- k = display units per metre, scl = metres per range unit, lbl = the SA
-- page's range label function: DL_RDR_R = cone length, DL_RDR_T = "100KM"
local MODE_KM = CFG.rdr_mode_km or {[0] = 100, [1] = 10, [2] = 150, [3] = 50}
local HD = nil
function DL_RDR.draw(k, scl, lbl)
	if not HD then HD = {r = get_param_handle("DL_RDR_R"), t = get_param_handle("DL_RDR_T"), last_t = nil} end
	if not DL_RDR.on then return end
	local km = MODE_KM[0]
	local ma = CFG.rdr_mode_arg
	if ma == nil then ma = 295 end
	if ma and arg_fn then
		local v = arg_fn(ma) or 0
		local i = math.floor(v * 10 + 0.5)
		if i < 0 then i = 0 elseif i > 3 then i = 3 end
		km = MODE_KM[i] or km
	end
	DL_RDR.km = km
	HD.r:set(km * 1000 * k)
	local txt = lbl(km * 1000 / scl, "%d%s")
	if txt ~= HD.last_t then HD.last_t = txt; HD.t:set(txt) end
end
