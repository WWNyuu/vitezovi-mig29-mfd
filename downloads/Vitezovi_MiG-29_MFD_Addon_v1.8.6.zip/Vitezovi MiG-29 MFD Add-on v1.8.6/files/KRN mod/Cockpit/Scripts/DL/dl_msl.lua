-----------------------------------------------------------------------
-- MiG-29 DL add-on: our missiles in flight on the SA page (round 37,
-- 19 Nov 2026). The export finds them in DCS's object list (a missile of
-- our coalition that first shows up next to our jet right after a store
-- left it) and sends a K line per missile:
--   K,id,x,z,y,vx,vz,age,tof     (m, m/s, s since the scan, s since launch)
-- Drawn: missile symbol turned to its course, dashed line ahead, and the
-- time to the hostile / unknown contact it flies at ("23S").
-- Elements: dl_page.lua (DL_MSL<n>_X/_Y/_V/_A/_T). Needs the object export
-- (no missiles on servers that block it, like the datalink picture).
-- msl_show = false: off.
-----------------------------------------------------------------------
DL_MSL = {list = {}, t = -100}
local CFG = DL_CFG or {}
local NM = CFG.msl_max or 4
local H = nil
local function handles()
	if H then return H end
	H = {}
	for n = 1, NM do
		local function P(s) return get_param_handle("DL_MSL" .. n .. "_" .. s) end
		H[n] = {x = P("X"), y = P("Y"), v = P("V"), a = P("A"), t = P("T"), last_t = nil, last_v = nil}
	end
	return H
end

-- one packet's K lines (fields as numbers, in order): replaces the list
function DL_MSL.rx(list, t)
	DL_MSL.list, DL_MSL.t = list, t
end
function DL_MSL.parse(f, t)
	-- f = {id, x, z, y, vx, vz, age, tof}
	if not (f[2] and f[3]) then return nil end
	return {id = f[1], x = f[2], z = f[3], y = f[4] or 0, vx = f[5] or 0, vz = f[6] or 0,
	        t0 = t - (f[7] or 0), tof0 = (f[8] or 0) - (f[7] or 0)}
end

-- time (s) to the hostile / unknown contact the missile flies at: the
-- nearest one within msl_cone_deg of its course that it closes on
local function tti(m, x, z, contacts, t)
	local sp = math.sqrt(m.vx * m.vx + m.vz * m.vz)
	if sp < 50 then return nil end
	local ux, uz = m.vx / sp, m.vz / sp
	local cone = math.cos(math.rad(CFG.msl_cone_deg or 30))
	local best = nil
	for _, c in ipairs(contacts or {}) do
		local b = (c[0] or 0) % 10
		if b == 2 or b == 3 then
			local age = math.max(0, math.min((c.t and (t - c.t)) or c[6] or 0, 10))
			local cx, cz = (c[1] or 0) + (c[4] or 0) * age, (c[2] or 0) + (c[5] or 0) * age
			local dx, dz = cx - x, cz - z
			local d = math.sqrt(dx * dx + dz * dz)
			if d > 1 and (dx * ux + dz * uz) / d > cone then
				local close = sp - ((c[4] or 0) * dx + (c[5] or 0) * dz) / d
				if close > 50 then
					local s = d / close
					if not best or s < best then best = s end
				end
			end
		end
	end
	return best
end

-- every SA update: place the missiles (dead-reckoned from the last scan)
-- to_screen(dE, dN) and vx0 / vz0: dl_device.lua's view; top = upper limit
function DL_MSL.draw(t, stale, to_screen, vx0, vz0, contacts, top)
	local h = handles()
	local n = 0
	if CFG.msl_show ~= false and not stale and (t - DL_MSL.t) < (CFG.msl_keep_s or 8) then
		for _, m in ipairs(DL_MSL.list) do
			if n >= NM then break end
			local age = math.min(math.max(t - m.t0, 0), CFG.msl_keep_s or 8)
			local x, z = m.x + m.vx * age, m.z + m.vz * age
			local sx, sy = to_screen(z - vz0, x - vx0)
			if math.abs(sx) < 1.15 and sy < (top or 1.0) and sy > -1.7 then
				n = n + 1
				local e = h[n]
				e.x:set(sx); e.y:set(sy)
				local dx, dy = to_screen(m.vz, m.vx)
				if dx * dx + dy * dy > 0 then e.a:set(-math.atan2(dx, dy)) end
				local s = tti(m, x, z, contacts, t)
				local txt = s and string.format("%dS", math.floor(s + 0.5)) or " "
				if txt ~= e.last_t then e.last_t = txt; e.t:set(txt) end
				if e.last_v ~= 1 then e.last_v = 1; e.v:set(1) end
			end
		end
	end
	for k = n + 1, NM do
		local e = h[k]
		if e.last_v ~= 0 then e.last_v = 0; e.v:set(0) end
	end
	return n
end
