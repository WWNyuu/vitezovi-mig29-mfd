-----------------------------------------------------------------------
-- MiG-29 DL add-on (v1.8.6): airfields on the SA page
-- Blue circle with a white line along each runway (as on DCS's F10 map),
-- from DL_AIRFIELDS (dl_airfields.lua, ED's airfield list per theatre).
-- Runway designators are magnetic: the line is turned by the magnetic
-- variation at the jet (getMagneticHeading against getHeading).
-- Hidden from SYM 2 on (declutter). Elements: dl_page.lua (dl_af<n>).
-----------------------------------------------------------------------
DL_AF = {n = DL_CFG.af_max or 24}
local NAF = DL_AF.n
local h, th_loaded, list = nil, false, nil

-- v1.8.6 perf: a parameter that is only written when its value changed
local function ph(name)
	local p, last = get_param_handle(name), nil
	return function(v) if v ~= last then last = v; p:set(v) end end
end
local function handles()
	h = {}
	for i = 1, NAF do
		local p = "DL_AF" .. i
		h[i] = {x = ph(p .. "_X"), y = ph(p .. "_Y"), vis = ph(p .. "_VIS"), n = ph(p .. "_N"),
		        r = {ph(p .. "_R1"), ph(p .. "_R2"), ph(p .. "_R3")}}
	end
end

-- the theatre's airfields in map metres (once per theatre)
local function load(th)
	th_loaded, list = th, {}
	if type(DL_AIRFIELDS) ~= "table" or not th then return end
	local id = (DL_theatre_id and DL_theatre_id(th)) or th
	local src
	for k, v in pairs(DL_AIRFIELDS) do if k:lower() == tostring(id):lower() then src = v end end
	if not src then return end
	local ok, terr = pcall(require, "terrain")
	if not ok or type(terr) ~= "table" or not terr.convertLatLonToMeters then return end
	for _, a in ipairs(src) do
		local ok2, x, z = pcall(terr.convertLatLonToMeters, a[2], a[3])
		if ok2 and x and z then list[#list + 1] = {x = x, z = z, name = a[1], rwy = a[4]} end
	end
	if DL_dbg then DL_dbg("device", string.format("airfields: %d for %s", #list, tostring(id))) end
end

local function off()
	for i = 1, NAF do h[i].vis(0) end
end

-- magnetic variation = true - magnetic heading (clockwise). getHeading()
-- is counter-clockwise; getMagneticHeading() turned out not to be (the
-- first DCS test: runways turned with the jet), so both readings are
-- tried: the real variation is small (< 40 deg on every map), the wrong
-- reading swings with the heading. The convention is kept once it is clear.
local TWO_PI, LIM = 2 * math.pi, math.rad(40)
local function wrap(a) return (a + math.pi) % TWO_PI - math.pi end
local function upd_decl(sd)
	local m, hd = sd.getMagneticHeading(), sd.getHeading()
	if not (m and hd) then return end
	local d_cw  = wrap((TWO_PI - hd) - m)          -- magnetic clockwise
	local d_ccw = wrap(m - hd)                      -- magnetic counter-clockwise
	if not DL_AF.mag_cw_known then
		if math.abs(d_cw) < LIM and math.abs(d_ccw) > LIM then DL_AF.mag_cw, DL_AF.mag_cw_known = true, true
		elseif math.abs(d_ccw) < LIM and math.abs(d_cw) > LIM then DL_AF.mag_cw, DL_AF.mag_cw_known = false, true end
		if DL_AF.mag_cw_known and DL_dbg then
			DL_dbg("device", "airfields: magnetic heading is " .. (DL_AF.mag_cw and "clockwise" or "counter-clockwise")
				.. string.format(", variation %.1f deg", math.deg(DL_AF.mag_cw and d_cw or d_ccw)))
		end
	end
	if DL_AF.mag_cw_known then DL_AF.decl = DL_AF.mag_cw and d_cw or d_ccw
	else DL_AF.decl = (math.abs(d_cw) < math.abs(d_ccw)) and d_cw or d_ccw end
end

-- v1.8.6 perf: the candidate records are reused (no new tables per update)
local cand, pool = {}, {}
local function by_dist(p, q) return p.d < q.d end

-- on: drawn at all (SA page, SYM 1); to_screen(dE, dN) -> page units
-- from the view origin (vx0, vz0); oy = where the ownship sits (decentre)
function DL_AF.draw(sd, th, on, vx0, vz0, ox, oz, to_screen, oy)
	if not h then handles() end
	if not on then off(); return end
	if th ~= th_loaded then load(th) end
	if not list or #list == 0 then off(); return end
	pcall(upd_decl, sd)
	local decl = DL_AF.decl or 0
	-- the nearest ones that are on the scope
	for i = #cand, 1, -1 do pool[#pool + 1] = cand[i]; cand[i] = nil end
	for _, a in ipairs(list) do
		local sx, sy = to_screen(a.z - vz0, a.x - vx0)
		if math.abs(sx) < 1.0 and sy + oy > -1.2 and sy + oy < 1.3 then
			local dN, dE = a.x - ox, a.z - oz
			local c = table.remove(pool) or {}
			c.a, c.sx, c.sy, c.d = a, sx, sy, dN * dN + dE * dE
			cand[#cand + 1] = c
		end
	end
	table.sort(cand, by_dist)
	local x0, y0 = to_screen(0, 0)
	for i = 1, NAF do
		local c = cand[i]
		local e = h[i]
		if c then
			e.x(c.sx); e.y(c.sy); e.vis(1)
			local rw = c.a.rwy or {}
			e.n(#rw)
			for r = 1, 3 do
				if rw[r] then
					local tr = math.rad(rw[r]) + decl                -- true runway direction, clockwise from north
					local x1, y1 = to_screen(math.sin(tr), math.cos(tr))
					e.r[r](math.atan2(-(x1 - x0), y1 - y0))
				end
			end
		else
			e.vis(0)
		end
	end
end
