-----------------------------------------------------------------------
-- MiG-29 DL add-on (v1.8.6): brightness layer for KRN's radio display
-- (left side). A second display on the same place as KRN's Radio display
-- (device_init.lua, after KRN's displays), drawn over it: a black
-- see-through layer that follows the MFD's brightness (DL_UFCP_DIM).
-----------------------------------------------------------------------
dofile(LockOn_Options.common_script_path .. "devices_defs.lua")
indicator_type = indicator_types.COMMON
purposes = {render_purpose.GENERAL}
init_pageID = 1
pages = {{1}}
page_subsets = {[1] = LockOn_Options.script_path .. "DL/dl_radio_dim_page.lua"}
