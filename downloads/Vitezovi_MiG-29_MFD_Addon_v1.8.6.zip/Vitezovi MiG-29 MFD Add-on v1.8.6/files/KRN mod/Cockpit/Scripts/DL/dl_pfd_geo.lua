-----------------------------------------------------------------------
-- MiG-29 DL add-on: flight instrument (PFD) layouts, page units
-- (round 21). Read by both sides: dl_pages.lua draws with them
-- (DL_PFD_BUILD in dl_pfd.lua), dl_pfd_dev.lua moves tapes, ladder and
-- the VSI needle with the same scales.
--   mfi = MFI edition page 19 (NAV > PFD), "PFD2 tall" mockup
--   std = normal edition, top half of the HSI page (8)
-----------------------------------------------------------------------
DL_PFD_GEO = {
	mfi = {
		spd_x0 = -0.932, spd_x1 = -0.679, alt_x0 = 0.489, alt_x1 = 0.733, tape_y0 = -0.781, tape_y1 = 1.137,
		spd_k = 0.01086, spd_step = 50, alt_k = 0.002262, alt_step = 200, alt_kft = 0.000905, alt_step_ft = 500,
		adi_x0 = -0.606, adi_x1 = 0.416, adi_y0 = -0.555, adi_y1 = 0.893, ppd = 0.032, bank_r = 0.52, wing = 0.58,
		fd_max = 0.40,
		vsi_x0 = 0.760, vsi_x1 = 0.923, vsi_y0 = -0.645, vsi_y1 = 1.001,
		fma_x0 = -0.67, fma_x1 = 0.48, fma_y = 1.232,
		arc_x = -0.095, arc_y = -1.686, arc_r = 0.769, arc_clip = {-0.95, -1.21, 0.95, -0.80}, arc_txt_y = -1.15,
	},
	-- normal edition: top of the HSI page (mockup B), clear of the side key labels
	std = {
		spd_x0 = -0.86, spd_x1 = -0.60, alt_x0 = 0.60, alt_x1 = 0.86, tape_y0 = 0.33, tape_y1 = 1.22, box_ext = 0,
		spd_k = 0.00724, spd_step = 20, spd_n = 5, alt_k = 0.000995, alt_step = 200, alt_n = 4,
		alt_kft = 0.000398, alt_step_ft = 500,
		adi_x0 = -0.60, adi_x1 = 0.60, adi_y0 = 0.26, adi_y1 = 1.29, ppd = 0.028, bank_r = 0.42, wing = 0.26,
		fd_max = 0.30, ac = "yellow",
		colours = {tape = {12, 18, 34}, sky = {28, 62, 165}, gnd = {105, 55, 18}},
	},
}
-- VSI scale: page units from the middle for a vertical speed (m/s, log scale to 50)
function DL_PFD_VSI_DY(L, v)
	local hh = (L.vsi_y1 - L.vsi_y0) / 2 - 0.06
	local a = math.min(50, math.abs(v or 0))
	return ((v or 0) >= 0 and 1 or -1) * math.log10(1 + a) / math.log10(51) * hh
end
-- needle turn (rad) for a vertical speed: the needle's pivot is
-- vsi_pivot right of the scale box, the needle crosses the tick line
-- (vsi_x0 + 0.05) at the speed's height (see dl_pfd.lua)
function DL_PFD_VSI_ANG(L, v)
	local d = L.vsi_x1 + (L.vsi_pivot or 0.60) - (L.vsi_x0 + 0.05)
	return -math.atan(DL_PFD_VSI_DY(L, v) / d)
end
