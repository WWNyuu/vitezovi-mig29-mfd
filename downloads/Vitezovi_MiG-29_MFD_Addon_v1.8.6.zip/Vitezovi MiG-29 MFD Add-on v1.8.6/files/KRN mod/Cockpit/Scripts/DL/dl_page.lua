-----------------------------------------------------------------------
-- MiG-29 datalink SIT page (F-15 SIT style) : indicator elements
--
-- Loaded at the end of the KRN MFD's last page subset (one dofile line
-- added there), so it shares that indicator's scale, stencil and fonts
-- and draws on top of the KRN pages while it is switched on (MFD-3).
-- The map is DCS's own raster chart set for the theatre you are on
-- (see dl_theatres.lua / charts\*.lua), moved and turned every frame so
-- it stays under the aircraft, heading up.
-- All values come from DL/dl_device.lua through cockpit parameters.
-----------------------------------------------------------------------

dofile(LockOn_Options.script_path .. "DL/dl_config.lua")
dofile(LockOn_Options.script_path .. "DL/dl_theatres.lua")
pcall(dofile, LockOn_Options.script_path .. "DL/dl_geo.lua")
pcall(dofile, LockOn_Options.script_path .. "DL/dl_tac.lua")
pcall(dofile, LockOn_Options.script_path .. "DL/dl_debug.lua")

-- The whole build runs in a function under pcall: whatever goes wrong,
-- DCS's own CreateElement / Add are put back afterwards (they are wrapped
-- while our elements are built, see below), and the error is logged
-- instead of being lost in KRN's pcall around this file.
local DL_rawAdd, DL_rawCreate = Add, CreateElement
local function DL_build_page()
	local CFG   = DL_CFG
	local LVL   = MDF_DEFAULT_LEVEL or 9
	local CLIP  = h_clip_relations.COMPARE
	local OWN_Y = CFG.ownship_y
	local R     = CFG.range_radius
	-- DCS applies the indicator's SetCustomScale to vertices and init_pos, but
	-- NOT to offsets coming from controllers. The KRN MFD uses
	-- SetCustomScale(0.1 * MFD_SCALE), so controller offsets must be multiplied
	-- by that same factor to land in page units.
	local G     = CFG.move_gain or (0.1 * (MFD_SCALE or 0.45))
	local GL    = CFG.line_gain or G

	local ranges = (CFG.range_units == "nm") and CFG.ranges_nm or CFG.ranges_km
	local unit_m = (CFG.range_units == "nm") and 1852.0 or 1000.0

	-- v1.7.6 night palette (D/N switch at N, cockpit parameter DLP_NIGHT = 1):
	-- every element drawn in a known colour gets a "change colour" controller
	-- to its night colour. Data text goes softer and less white, threat red
	-- and amber keep their punch, the blue lines turn a dim grey.
	local NIGHT_PAL = {   -- day r g b -> night r g b
		{235, 235, 235, 150, 165, 145}, {170, 185, 175, 100, 110, 102}, {105, 110, 108,  62,  68,  64},
		{120, 230, 150,  95, 190, 115}, { 90, 215, 255,  80, 175, 205}, { 70, 130, 255,  75, 100, 130},
		{255, 170,  60, 255, 160,  45}, {240, 230, 110, 215, 200,  85}, {240, 100, 100, 255,  85,  75},
		{242, 160, 160, 220, 135, 130},
	}
	local NIGHT_MAT = {}       -- material / font -> {r, g, b} at night (0..1)
	local function night_of(r, g, b)
		if CFG.night_palette == false or r + g + b < 30 then return nil end   -- black stays black
		local best, bd = nil, 1e9
		for _, q in ipairs(NIGHT_PAL) do
			local d = (q[1] - r) ^ 2 + (q[2] - g) ^ 2 + (q[3] - b) ^ 2
			if d < bd then best, bd = q, d end
		end
		if bd <= 3600 then return {best[4] / 255, best[5] / 255, best[6] / 255} end
		return {r * 0.64 / 255, g * 0.70 / 255, b * 0.62 / 255}         -- any other colour: as white does
	end
	local function col(r, g, b, a)
		local m = MakeMaterial(nil, {r, g, b, a or 255})
		NIGHT_MAT[m] = night_of(r, g, b)
		return m
	end
	-- Every DL element is first built as a plain Lua table (CreateElement and
	-- Add are wrapped while our pages are built, put back at the end). DCS's
	-- own elements give their fields back as text, not as tables (seen in the
	-- sim, v1.7.6), so the night colour rule is added here, from our own
	-- tables, and only then is the real element made and handed to DCS.
	local NIGHT_CTRL = {}
	local rawAdd, rawCreate = Add, CreateElement
	local FIELD_ORDER = {"name", "primitivetype", "vertices", "indices", "tex_coords", "material", "init_pos", "init_rot",
		"alignment", "stringdefs", "formats", "value", "width", "parent_element", "h_clip_relation", "level",
		"isdraw", "isvisible", "use_mipfilter", "additive_alpha", "collimated", "element_params", "controllers"}
	local IN_ORDER = {}
	for _, k in ipairs(FIELD_ORDER) do IN_ORDER[k] = true end
	local night_err = false
	local function add_night(e)
		local c = NIGHT_MAT[e.material]
		if not c then return end
		local p, cs = {}, {}
		if type(e.element_params) == "table" then for i, v in ipairs(e.element_params) do p[i] = v end end
		if type(e.controllers) == "table" then for i, v in ipairs(e.controllers) do cs[i] = v end end
		local k = #p
		p[k + 1] = "DLP_NIGHT"
		local key = k .. "/" .. c[1] .. "/" .. c[2] .. "/" .. c[3]
		local cc = NIGHT_CTRL[key]
		if not cc then
			cc = {"change_color_when_parameter_equal_to_number", k, 1, c[1], c[2], c[3]}
			NIGHT_CTRL[key] = cc
		end
		cs[#cs + 1] = cc
		e.element_params, e.controllers = p, cs
	end
	CreateElement = function(cls) return {__dl_cls = cls} end
	Add = function(e)
		if type(e) ~= "table" or not e.__dl_cls then return rawAdd(e) end
		local ok, err = pcall(add_night, e)
		if not ok and not night_err then
			night_err = true
			if DL_dbg then DL_dbg("page", "night colours: " .. tostring(err)) end
		end
		local r = rawCreate(e.__dl_cls)
		for _, k in ipairs(FIELD_ORDER) do
			if e[k] ~= nil then r[k] = e[k] end
		end
		for k, v in pairs(e) do
			if k ~= "__dl_cls" and not IN_ORDER[k] then r[k] = v end
		end
		return rawAdd(r)
	end
	local FONT = CFG.font or "font_arial_13"
	-- page font: our thin monospaced texture font (dl_fonts.lua) or DCS's Arial
	local TEXF = CFG.font_style ~= "dcs"
	if TEXF then
		local ok_fd = pcall(dofile, LockOn_Options.script_path .. "DL/dl_font_desc.lua")
		if not ok_fd or not DL_FONT_ASPECT then TEXF = false end
	end
	local function fnt(r, g, b, name)
		local f
		if TEXF then f = "DL_F_" .. name else f = MakeFont({used_DXUnicodeFontData = FONT}, {r, g, b, 255}) end
		NIGHT_MAT[f] = night_of(r, g, b)
		return f
	end
	-- text sizes are given for Arial; the texture font gets the same capital height
	local FK  = (CFG.font_scale or 1.25)
	-- DCS sizes texture-font glyphs as height = defs[1], width = defs[2] x (glyph px width / height),
	-- so width = height keeps the letters' own proportions
	local FW  = (CFG.font_width or 1.0)
	local DEFS_CACHE = {}
	local function defs_of(d)
		if not TEXF then return d end
		local c = DEFS_CACHE[d]
		if not c then
			c = {d[1] * FK, d[1] * FK * FW, d[3] or 0, (d[4] or 0) * FK}
			DEFS_CACHE[d] = c
		end
		return c
	end
	-- width of one character in page units (monospaced font only)
	local function char_w(d) return defs_of(d)[2] * (TEXF and DL_FONT_ASPECT or 0.5) / G end

	-- F-15 SIT palette
	local C_GREEN, C_RED, C_YELLOW, C_CYAN = {120, 230, 150}, {240, 100, 100}, {240, 230, 110}, {90, 215, 255}
	local function colt(c, a) return col(c[1], c[2], c[3], a) end
	local M = {
		black   = col(0, 0, 0, 255),
		ring    = colt(C_GREEN),
		halo    = col(0, 0, 0, 235),
		white   = col(235, 235, 235, 255),
		route   = col(235, 235, 235, 220),
		wpt     = col(235, 235, 235, 255),
		own     = colt(C_CYAN),
		friend  = colt(C_GREEN),
		hostile = colt(C_RED),
		unknown = colt(C_YELLOW),
		wing    = colt(C_CYAN),
		blue    = col(70, 130, 255, 255),
		amber   = col(255, 170, 60, 255),
		amber_d = col(90, 55, 10, 255),
	}
	M.af_b = col(40, 95, 215, 255)     -- v1.8.6 airfield disc (blue, as DCS's F10 map)
	M.af_w = col(255, 255, 255, 255)   -- its runway lines
	M.af_k = col(0, 0, 0, 255)         -- fine black outline
	local F = {
		white   = fnt(235, 235, 235, "WHITE"),
		green   = fnt(C_GREEN[1], C_GREEN[2], C_GREEN[3], "GREEN"),
		red     = fnt(C_RED[1], C_RED[2], C_RED[3], "RED"),
		pink    = fnt(242, 160, 160, "PINK"),
		yellow  = fnt(C_YELLOW[1], C_YELLOW[2], C_YELLOW[3], "YELLOW"),
		amber   = fnt(255, 170, 60, "AMBER"),
		blue    = fnt(70, 130, 255, "BLUE"),
		cyan    = fnt(C_CYAN[1], C_CYAN[2], C_CYAN[3], "CYAN"),
		grey    = fnt(170, 185, 175, "GREY"),
		dim     = fnt(105, 110, 108, "DIM"),
		black   = fnt(0, 0, 0, "BLACK"),
	}
	local TXT       = {0.0044, 0.0013, 0, -0.0016}
	local TXT_SMALL = {0.0033, 0.0010, 0, -0.0012}
	local TXT_TINY  = {0.0028, 0.00085, 0, -0.0010}
	-- bezel button labels (left / right columns)
	local TXT_BTN   = CFG.btn_label_size and {CFG.btn_label_size, 0.0011, 0, -CFG.btn_label_size * 0.36} or {0.0036, 0.0011, 0, -0.0013}
	-- the map behind the scope is optional (F-15 SIT style = plain black)
	local SHOW_MAP  = (CFG.map_source or "none") ~= "none"
	-- black outline around texts: only needed over a map
	local OUTLINE   = SHOW_MAP and (CFG.text_outline or 0.006) or 0

	-- geometry helpers ---------------------------------------------------
	local function circle_fill(r, n)
		local v, idx = {{0, 0}}, {}
		n = n or 16
		for i = 0, n - 1 do
			local a = 2 * math.pi * i / n
			v[#v + 1] = {r * math.cos(a), r * math.sin(a)}
		end
		for i = 1, n do
			idx[#idx + 1] = 0
			idx[#idx + 1] = i
			idx[#idx + 1] = (i % n) + 1
		end
		return v, idx
	end
	local function poly_lines(pts)
		local idx = {}
		for i = 0, #pts - 1 do
			idx[#idx + 1] = i
			idx[#idx + 1] = (i + 1) % #pts
		end
		return pts, idx
	end

	-- thick outline between two closed outlines with the same vertex count
	local function band(outer, inner)
		local v, idx, n = {}, {}, #outer
		for k = 1, n do v[k] = outer[k]; v[n + k] = inner[k] end
		for k = 0, n - 1 do
			local a, b = k, (k + 1) % n
			idx[#idx + 1] = a; idx[#idx + 1] = b; idx[#idx + 1] = n + b
			idx[#idx + 1] = a; idx[#idx + 1] = n + b; idx[#idx + 1] = n + a
		end
		return v, idx
	end
	local function circle_pts(r, n)
		local v = {}
		for k = 0, n - 1 do
			local a = 2 * math.pi * k / n
			v[#v + 1] = {r * math.cos(a), r * math.sin(a)}
		end
		return v
	end
	local function circle_ring(r, t, n) return band(circle_pts(r, n or 20), circle_pts(r - t, n or 20)) end
	local function scaled(pts, f)
		local v = {}
		for k, p in ipairs(pts) do v[k] = {p[1] * f, p[2] * f} end
		return v
	end
	-- apothem = distance from centre to the edges (for an even band width)

	local function mesh(name, parent, prim, v, idx, mat, pos, params, ctrls)
		local e = CreateElement "ceMeshPoly"
		e.name            = name
		e.primitivetype   = prim
		e.vertices        = v
		e.indices         = idx
		e.material        = mat
		e.init_pos        = pos or {0, 0, 0}
		e.parent_element  = parent
		e.h_clip_relation = CLIP
		e.level           = LVL
		e.isdraw          = true
		e.isvisible       = true
		if params then e.element_params = params end
		if ctrls then e.controllers = ctrls end
		Add(e)
		return e
	end
	local function simple(name, parent, pos, params, ctrls)
		local e = CreateElement "ceSimple"
		e.name     = name
		e.init_pos = pos or {0, 0, 0}
		if parent then e.parent_element = parent end
		if params then e.element_params = params end
		if ctrls then e.controllers = ctrls end
		Add(e)
		return e
	end
	-- text with a thin black outline: 8 black copies around it, then the text.
	-- vis = {param, lo, hi} optionally limits when it is shown.
	local function text1(name, parent, pos, font, defs, align, value, param, vis)
		local e = CreateElement "ceStringPoly"
		e.name            = name
		e.material        = font
		e.init_pos        = pos
		e.alignment       = align or "CenterCenter"
		e.stringdefs      = defs_of(defs or TXT)
		e.parent_element  = parent
		e.h_clip_relation = CLIP
		e.level           = LVL
		local params, ctrls = {}, {}
		if param then
			e.formats = {"%s"}
			params[#params + 1] = param
			ctrls[#ctrls + 1] = {"text_using_parameter", #params - 1}
		else
			e.value = value
		end
		if vis then
			params[#params + 1] = vis[1]
			ctrls[#ctrls + 1] = {"parameter_in_range", #params - 1, vis[2], vis[3]}
		end
		if #params > 0 then
			e.element_params = params
			e.controllers    = ctrls
		end
		Add(e)
		return e
	end
	local OUT_DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {0.7, 0.7}, {-0.7, 0.7}, {0.7, -0.7}, {-0.7, -0.7}}
	local function text(name, parent, pos, font, defs, align, value, param, vis)
		if OUTLINE > 0 then
			for k, d in ipairs(OUT_DIRS) do
				text1(name .. "_o" .. k, parent, {pos[1] + d[1] * OUTLINE, pos[2] + d[2] * OUTLINE, 0},
					F.black, defs, align, value, param, vis)
			end
		end
		return text1(name, parent, pos, font, defs, align, value, param, vis)
	end
	local function line_obj(name, parent, mat, width, params, ctrls)
		local e = CreateElement "ceSimpleLineObject"
		e.name            = name
		e.material        = mat
		e.width           = width
		e.vertices        = {{0, 0}, {0, 0}}
		e.init_pos        = {0, 0, 0}
		e.parent_element  = parent
		e.use_mipfilter   = true
		e.additive_alpha  = false
		e.h_clip_relation = CLIP
		e.level           = LVL
		e.element_params  = params
		e.controllers     = ctrls
		Add(e)
		return e
	end

	-- page root (visible while DL_PAGE is 1 or 2) -------------------------
	-- the DL (situation) page: DL_MODE 1 (see dl_pages.lua for the others)
	simple("dl_root", nil, {0, 0, 0}, {"DL_PAGE", "DL_MODE"},
		{{"parameter_in_range", 0, 0.5, 2.5}, {"parameter_in_range", 1, 0.5, 1.5}})

	-- opaque background hiding the KRN page underneath
	mesh("dl_bg", "dl_root", "triangles",
		{{-1.1, 1.6}, {1.1, 1.6}, {1.1, -1.6}, {-1.1, -1.6}}, {0, 1, 2, 0, 2, 3}, M.black)

	-- ownship-centred frame
	simple("dl_own", "dl_root", {0, OWN_Y, 0}, {"DL_OWN_DY"}, {{"move_up_down_using_parameter", 0, G}})

	-- moving map: rotate about ownship by heading, then shift so that the
	-- ownship's world position sits at the origin
	simple("dl_rot", "dl_own", {0, 0, 0}, {"DL_MAP_ROT"}, {{"rotate_using_parameter", 0, 1}})
	simple("dl_shift", "dl_rot", {0, 0, 0}, {"DL_MAP_DX", "DL_MAP_DY"},
		{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})

	-- DCS's own raster charts for the theatre we are on. One quad per
	--     chart tile and range step; the device switches on only the tiles
	--     around the aircraft (DL_T<n> = range step), so DCS only loads
	--     those textures.
	if (CFG.map_source or "none") == "dcs" then
		local ok_d, theatre = pcall(DL_detect_theatre)
		local chart = ok_d and DL_load_chart(theatre) or nil
		local built = 0
		-- v1.7.8: only tiles within map_radius_km of the jet (all range
		-- steps), at most map_max_quads; without a position: the range
		-- budget (DL_chart_budget). The full chart made pages of up to
		-- 6720 quads, and DCS crashed building them at spawn.
		-- A chart built by INSTALL (DL/charts_gen) has only a few dozen
		-- big textures for the whole map: all of them are built.
		local area, how = nil, "none"
		local gen_keep = nil
		if chart then
			local px, pz
			px, pz, how = DL_map_pos(theatre)
			local rad = (CFG.map_radius_km or 300) * 1000
			local cap = CFG.map_max_quads or 600
			if chart.gen then
				-- v1.8.5 fix: the finest layer only around the spawn point
				-- (DL_gen_keep), with the next layer underneath
				local n_keep = #chart.tiles
				if DL_gen_keep and DL_gen_radius() > 0 and chart.fine then
					local live = DL_pos_live(how)
					gen_keep, n_keep = DL_gen_keep(chart, live and px or nil, live and pz or nil, DL_gen_radius())
				end
				how = "built charts, " .. n_keep .. " of " .. #chart.tiles .. " textures (" .. how .. ", finest layer " .. tostring(chart.fine) .. ")"
			elseif CFG.map_max_quads == 0 then
				how = how .. " (no limit)"
			elseif px then
				-- (v1.8.6: the rule is in dl_theatres.lua, so that
				-- dl_textures.lua loads just the textures these quads use)
				area = DL_raw_area(chart, px, pz, #ranges, rad, cap)
			else
				pcall(DL_chart_budget, chart)
			end
			local function quad(nm, ri, n, t, k)
				local x0, z0, x1, z1 = t[2] * k, t[3] * k, t[4] * k, t[5] * k
				local e = CreateElement "ceTexPoly"
				e.name            = nm
				e.primitivetype   = "triangles"
				e.vertices        = {{z0, x1}, {z1, x1}, {z1, x0}, {z0, x0}}
				e.indices         = {0, 1, 2, 0, 2, 3}
				e.tex_coords      = {{0, 0}, {1, 0}, {1, 1}, {0, 1}}
				e.material        = "DLT_" .. n
				e.init_pos        = {0, 0, 0}
				e.parent_element  = "dl_shift"
				e.h_clip_relation = CLIP
				e.level           = LVL
				e.element_params  = {"DL_T" .. n}
				e.controllers     = {{"parameter_in_range", 0, ri - 0.1, ri + 0.1}}
				Add(e)
				built = built + 1
			end
			-- v1.8.5 fix: underlay (next coarser layer) for the range steps
			-- that show the finest layer, drawn first so the sharp tiles
			-- cover it where they exist
			if gen_keep and chart.under then
				for ri, ui in pairs(chart.under) do
					local rng = ranges[ri]
					if rng then
						local k = R / (rng * unit_m)
						for n, t in ipairs(chart.tiles) do
							if t[6] == ui and gen_keep[n] then quad("dl_tu_" .. ri .. "_" .. n, ri, n, t, k) end
						end
					end
				end
			end
			for ri, ci in ipairs(chart.range_class) do
				local rng = ranges[ri]
				if ci and ci > 0 and rng then
					local k = R / (rng * unit_m)
					for n, t in ipairs(chart.tiles) do
						if gen_keep and not gen_keep[n] then
							-- v1.8.5 fix: texture not loaded (far from the spawn point)
						elseif t[6] == ci and (not area or area[ri .. "_" .. n]) then
							quad("dl_t_" .. ri .. "_" .. n, ri, n, t, k)
						end
					end
				end
			end
		end
		if DL_dbg then DL_dbg("page", "move_gain=" .. G .. " line_gain=" .. GL .. " theatre=" .. tostring(theatre) .. " (detect ok=" .. tostring(ok_d) .. ") chart quads built=" .. built .. " around=" .. tostring(how)) end
	end

	-- dim the chart so the symbols on top stay readable
	local dim = math.floor(255 * (CFG.map_dim or 0) + 0.5)
	if SHOW_MAP and dim > 0 then
		mesh("dl_dim", "dl_rot", "triangles",
			{{-3, 3}, {3, 3}, {3, -3}, {-3, -3}}, {0, 1, 2, 0, 2, 3}, col(0, 0, 0, dim))
	end
	-- v1.7.9: map dim steps (SA page B5, D/N switch): DL_MAP_DIM 0..9 tenths
	-- of black over the chart only (the symbols are drawn on top).
	-- v1.8.6: children of dl_rot (right after the chart tiles), not of
	-- dl_root: DCS draws an element's children with it, so a layer on
	-- dl_root came after the whole dl_own tree and dimmed the symbols too.
	-- Big enough to cover the display at any map rotation.
	if SHOW_MAP then
		for k = 1, 9 do
			mesh("dl_mdim_" .. k, "dl_rot", "triangles",
				{{-3, 3}, {3, 3}, {3, -3}, {-3, -3}}, {0, 1, 2, 0, 2, 3},
				col(0, 0, 0, math.floor(255 * k / 10 + 0.5)), nil, {"DL_MAP_DIM"}, {{"parameter_in_range", 0, k - 0.5, k + 0.5}})
		end
	end

	-------------------------------------------------------------------------
	-- geo drawings from the cartridge's .geo.txt (dl_geo.lua): pools of line
	-- pieces per colour and a few labels, all placed by the device in the
	-- ownship frame. Drawn under the scope, route, threats and contacts.
	-------------------------------------------------------------------------
	do
		local POOLS = DL_GEO_POOLS or {r = 72, p = 56, c = 150, g = 110}
		local GM = {r = col(240, 96, 95, 255), p = col(242, 160, 160, 255), c = col(111, 210, 230, 255), g = col(163, 171, 175, 255)}
		local GW = CFG.geo_line_width or 0.004
		for _, pool in ipairs({"g", "c", "p", "r"}) do
			for i = 1, (POOLS[pool] or 0) do
				local pre = "DL_GEO_" .. pool .. i .. "_"
				line_obj("dl_geo_" .. pool .. i, "dl_own", GM[pool], GW,
					{pre .. "X1", pre .. "Y1", pre .. "X2", pre .. "Y2", pre .. "V"},
					{{"line_object_set_point_using_parameters", 0, 0, 1, GL, GL},
					 {"line_object_set_point_using_parameters", 1, 2, 3, GL, GL},
					 {"parameter_in_range", 4, 0.5, 1.5}})
			end
		end
		-- labels: DL_GEO_L<n>_C = 1 red, 2 pink, 3 cyan, 4 grey (0 = off)
		local LF = {F.red, F.pink or F.red, F.cyan, F.grey}
		for n = 1, (DL_GEO_LABELS or 12) do
			local pre = "DL_GEO_L" .. n .. "_"
			simple("dl_geo_l" .. n, "dl_own", {0, 0, 0}, {pre .. "X", pre .. "Y", pre .. "C"},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
				 {"parameter_in_range", 2, 0.5, 4.5}})
			if OUTLINE > 0 then
				for k, d in ipairs(OUT_DIRS) do
					text1("dl_geo_l" .. n .. "_o" .. k, "dl_geo_l" .. n, {d[1] * OUTLINE, d[2] * OUTLINE, 0}, F.black, TXT_SMALL, "LeftCenter", nil, pre .. "T")
				end
			end
			for c, f in ipairs(LF) do
				text1("dl_geo_l" .. n .. "_" .. c, "dl_geo_l" .. n, {0, 0, 0}, f, TXT_SMALL, "LeftCenter", nil, pre .. "T", {pre .. "C", c - 0.1, c + 0.1})
			end
		end
	end

	-------------------------------------------------------------------------
	-- SIT-style scope: range circle, 30 deg ticks and compass letters that
	-- turn with heading, ownship in the middle
	-------------------------------------------------------------------------
	local LW = CFG.line_width or 0.007          -- line width of rings and symbols
	-- range circle, ticks and letters: hidden in the expanded (EXP) view
	simple("dl_scope", "dl_own", {0, 0, 0}, {"DL_EXP"}, {{"parameter_in_range", 0, -0.5, 0.5}})
	simple("dl_scope_rot", "dl_scope", {0, 0, 0}, {"DL_MAP_ROT"}, {{"rotate_using_parameter", 0, 1}})
	local v, i = circle_ring(R + LW / 2, LW, 96)
	mesh("dl_ring_full", "dl_scope", "triangles", v, i, M.ring)
	-- round 39 (from the MFI edition): radar cone while the radar is ON
	-- (DL_RDR_ON, dl_rdr.lua): +-60 deg out to the ring, dotted lines at
	-- +-30 deg split it into left / centre / right; heading-up = straight up
	if CFG.rdr_cone ~= false then
		local cw = CFG.rdr_cone_w or 0.010
		local half = math.rad(CFG.rdr_cone_az or 60)
		local split = math.rad(CFG.rdr_cone_split or 30)
		local cv, ci = {}, {}
		local function seg(x0, y0, x1, y1)
			local dx, dy = x1 - x0, y1 - y0
			local l = math.sqrt(dx * dx + dy * dy)
			local nx, ny = -dy / l * cw / 2, dx / l * cw / 2
			local k = #cv
			cv[k + 1] = {x0 + nx, y0 + ny}; cv[k + 2] = {x1 + nx, y1 + ny}
			cv[k + 3] = {x1 - nx, y1 - ny}; cv[k + 4] = {x0 - nx, y0 - ny}
			ci[#ci + 1] = k; ci[#ci + 1] = k + 1; ci[#ci + 1] = k + 2
			ci[#ci + 1] = k; ci[#ci + 1] = k + 2; ci[#ci + 1] = k + 3
		end
		local function pt(a, d) return d * math.sin(a), d * math.cos(a) end
		for _, a in ipairs({-half, half}) do local x, y = pt(a, R); seg(0, 0, x, y) end
		for k = 0, 47 do
			local x0, y0 = pt(-half + 2 * half * k / 48, R)
			local x1, y1 = pt(-half + 2 * half * (k + 1) / 48, R)
			seg(x0, y0, x1, y1)
		end
		local nd = CFG.rdr_cone_dashes or 13
		for _, a in ipairs({-split, split}) do
			for k = 0, nd - 1 do
				local x0, y0 = pt(a, R * (2 * k) / (2 * nd - 1))
				local x1, y1 = pt(a, R * (2 * k + 1) / (2 * nd - 1))
				seg(x0, y0, x1, y1)
			end
		end
		mesh("dl_rdr", "dl_scope", "triangles", cv, ci, col(60, 100, 175, 255), nil, {"DL_RDR_ON"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	end

	-- ticks every 30 deg (not at N/E/S/W, the letters sit there); drawn
	-- north-up and turned with the map rotation
	do
		local tv, ti = {}, {}
		for deg = 30, 330, 30 do
			if deg % 90 ~= 0 then
				local a  = math.rad(90 - deg)
				local ca, sa = math.cos(a), math.sin(a)
				local px, py = -sa * LW / 2, ca * LW / 2      -- half-width across the tick
				local r0, r1 = R - 0.06, R
				local k = #tv
				tv[k + 1] = {r0 * ca + px, r0 * sa + py}; tv[k + 2] = {r1 * ca + px, r1 * sa + py}
				tv[k + 3] = {r1 * ca - px, r1 * sa - py}; tv[k + 4] = {r0 * ca - px, r0 * sa - py}
				ti[#ti + 1] = k; ti[#ti + 1] = k + 1; ti[#ti + 1] = k + 2
				ti[#ti + 1] = k; ti[#ti + 1] = k + 2; ti[#ti + 1] = k + 3
			end
		end
		mesh("dl_ticks", "dl_scope_rot", "triangles", tv, ti, M.ring)
	end
	for _, c in ipairs({"N", "E", "S", "W"}) do
		simple("dl_card_" .. c, "dl_scope", {0, 0, 0}, {"DL_CARD_" .. c .. "_X", "DL_CARD_" .. c .. "_Y"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})
		text("dl_card_" .. c .. "_lbl", "dl_card_" .. c, {0, 0, 0}, F.green, TXT, "CenterCenter", c)
	end

	-- ownship (cyan, like the F-15 SIT)
	v, i = poly_lines({{0, 0.06}, {0.010, 0.026}, {0.048, 0.0}, {0.048, -0.010}, {0.009, 0.0},
		{0.007, -0.034}, {0.022, -0.047}, {0, -0.043}, {-0.022, -0.047}, {-0.007, -0.034},
		{-0.009, 0.0}, {-0.048, -0.010}, {-0.048, 0.0}, {-0.010, 0.026}})
	simple("dl_ownpos", "dl_own", {0, 0, 0}, {"DL_OWN_SX", "DL_OWN_SY"},
		{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})
	mesh("dl_ownship", "dl_ownpos", "lines", v, i, M.own)

	-- v1.8.6: airfields (blue disc, white line per runway, as DCS's F10 map), dl_af.lua
	--  DL_AF<n>_X/_Y/_VIS, _N = number of runway lines, _R1.._R3 = their angle
	if CFG.sa_airfields ~= false then
		for n = 1, (CFG.af_max or 24) do
			local b = "dl_af" .. n
			local p = "DL_AF" .. n
			simple(b, "dl_own", {0, 0, 0}, {p .. "_X", p .. "_Y", p .. "_VIS"},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
				 {"parameter_in_range", 2, 0.5, 1.5}})
			local R = CFG.mfi_af_radius or 0.045
			v, i = circle_ring(R, R, 24)
			mesh(b .. "_disc", b, "triangles", v, i, M.af_b)
			local OK = CFG.mfi_af_outline or 0.005
			if OK > 0 then
				v, i = circle_ring(R + OK, OK, 24)
				mesh(b .. "_rim", b, "triangles", v, i, M.af_k)
			end
			for r = 1, 3 do
				simple(b .. "_r" .. r, b, {0, 0, 0}, {p .. "_R" .. r, p .. "_N"},
					{{"rotate_using_parameter", 0, 1}, {"parameter_in_range", 1, r - 0.5, 9}})
				local hw, hl = 0.0055, R * 1.3
				if OK > 0 then
					local kw, kl = hw + OK * 0.8, hl + OK * 0.8
					mesh(b .. "_r" .. r .. "_k", b .. "_r" .. r, "triangles", {{-kw, kl}, {kw, kl}, {kw, -kl}, {-kw, -kl}}, {0, 1, 2, 0, 2, 3}, M.af_k)
				end
				mesh(b .. "_r" .. r .. "_l", b .. "_r" .. r, "triangles", {{-hw, hl}, {hw, hl}, {hw, -hl}, {-hw, -hl}}, {0, 1, 2, 0, 2, 3}, M.af_w)
			end
		end
	end

	-- route (the steerpoints loaded in the jet) ------------------------------
	--  DL_W<n>_VIS: 1 = steerpoint, 2 = active steerpoint
	for n = 1, DL_MAX_WPTS do
		if n > 1 then
			line_obj("dl_leg_" .. n, "dl_own", M.route, 0.005,
				{"DL_W" .. (n - 1) .. "_X", "DL_W" .. (n - 1) .. "_Y", "DL_W" .. n .. "_X", "DL_W" .. n .. "_Y", "DL_W" .. n .. "_SEG"},
				{{"line_object_set_point_using_parameters", 0, 0, 1, GL, GL},
				 {"line_object_set_point_using_parameters", 1, 2, 3, GL, GL},
				 {"parameter_in_range", 4, 0.5, 1.5}})
		end
		simple("dl_w" .. n, "dl_own", {0, 0, 0}, {"DL_W" .. n .. "_X", "DL_W" .. n .. "_Y", "DL_W" .. n .. "_VIS"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 3.5}})
		if SHOW_MAP then
			v, i = circle_ring(0.034, 0.018, 20)
			mesh("dl_w" .. n .. "_halo", "dl_w" .. n, "triangles", v, i, M.halo)
		end
		-- waypoint: circle (VIS 1), airfield: square (VIS 3)
		v, i = circle_ring(0.026, LW, 20)
		mesh("dl_w" .. n .. "_sym", "dl_w" .. n, "triangles", v, i, M.wpt, nil,
			{"DL_W" .. n .. "_VIS"}, {{"parameter_in_range", 0, 0.5, 2.5}})
		do
			local q = 0.024
			local av, ai = band({{-q, q}, {q, q}, {q, -q}, {-q, -q}}, {{-q + LW, q - LW}, {q - LW, q - LW}, {q - LW, -q + LW}, {-q + LW, -q + LW}})
			mesh("dl_w" .. n .. "_ad", "dl_w" .. n, "triangles", av, ai, M.wpt, nil,
				{"DL_W" .. n .. "_VIS"}, {{"parameter_in_range", 0, 2.5, 3.5}})
		end
		v, i = circle_ring(0.044, LW, 24)
		mesh("dl_w" .. n .. "_act", "dl_w" .. n, "triangles", v, i, M.unknown, nil,
			{"DL_W" .. n .. "_VIS"}, {{"parameter_in_range", 0, 1.5, 2.5}})
		text("dl_w" .. n .. "_lbl", "dl_w" .. n, {0.04, 0.03, 0}, F.white, TXT_SMALL, "LeftCenter", nil, "DL_W" .. n .. "_TXT")
	end
	-- markpoints M1..M5 (SA page B1 MARK): amber diamond with an X
	for n = 1, 5 do
		simple("dl_mk" .. n, "dl_own", {0, 0, 0}, {"DL_MK" .. n .. "_X", "DL_MK" .. n .. "_Y", "DL_MK" .. n .. "_VIS"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 1.5}})
		local q = 0.032
		local dv, di = band({{0, q}, {q, 0}, {0, -q}, {-q, 0}}, {{0, q - LW * 1.4}, {q - LW * 1.4, 0}, {0, -q + LW * 1.4}, {-q + LW * 1.4, 0}})
		mesh("dl_mk" .. n .. "_d", "dl_mk" .. n, "triangles", dv, di, M.amber)
		local xv, xi = poly_lines({{-0.012, 0.012}, {0.012, -0.012}})
		mesh("dl_mk" .. n .. "_x1", "dl_mk" .. n, "lines", xv, xi, M.amber)
		xv, xi = poly_lines({{-0.012, -0.012}, {0.012, 0.012}})
		mesh("dl_mk" .. n .. "_x2", "dl_mk" .. n, "lines", xv, xi, M.amber)
		text("dl_mk" .. n .. "_lbl", "dl_mk" .. n, {0.045, -0.03, 0}, F.amber, TXT_SMALL, "LeftCenter", "M" .. n)
	end
	-- the selected waypoint / airfield: yellow ring (also when it is not part
	-- of the drawn route, e.g. an airfield chosen on the NAV panel)
	simple("dl_act", "dl_own", {0, 0, 0}, {"DL_ACT_X", "DL_ACT_Y", "DL_ACT_VIS"},
		{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
		 {"parameter_in_range", 2, 0.5, 1.5}})
	v, i = circle_ring(0.046, LW, 24)
	mesh("dl_act_ring", "dl_act", "triangles", v, i, M.unknown)
	-- line from the aircraft to the active steerpoint. It starts at the
	-- aircraft symbol (DL_OWN_SX/SY), which is away from the scope centre in EXP
	line_obj("dl_to_active", "dl_own", M.unknown, 0.004, {"DL_OWN_SX", "DL_OWN_SY", "DL_WA_X", "DL_WA_Y", "DL_WA_VIS"},
		{{"line_object_set_point_using_parameters", 0, 0, 1, GL, GL},
		 {"line_object_set_point_using_parameters", 1, 2, 3, GL, GL}, {"parameter_in_range", 4, 0.5, 1.5}})

	-------------------------------------------------------------------------
	-- ground threats (enemy SAM / EWR picked up by a friendly aircraft):
	-- label at the site, ring = approximate lethal range.
	-- Yellow while you are outside the ring, red once you are inside it.
	-------------------------------------------------------------------------
	local NSEG = DL_RING_SEGMENTS or 24
	for g = 1, (DL_MAX_THREATS or 16) do
		local pre = "DL_G" .. g
		for j = 1, NSEG do
			local j2 = j % NSEG + 1
			for ci, cm in ipairs({M.unknown, M.hostile}) do
				line_obj("dl_g" .. g .. "_r" .. ci .. "_" .. j, "dl_own", cm, 0.004,
					{pre .. "_P" .. j .. "_X", pre .. "_P" .. j .. "_Y", pre .. "_P" .. j2 .. "_X", pre .. "_P" .. j2 .. "_Y", pre .. "_RING"},
					{{"line_object_set_point_using_parameters", 0, 0, 1, GL, GL},
					 {"line_object_set_point_using_parameters", 1, 2, 3, GL, GL},
					 {"parameter_in_range", 4, ci - 0.5, ci + 0.5}})
			end
		end
		simple("dl_g" .. g, "dl_own", {0, 0, 0}, {pre .. "_X", pre .. "_Y", pre .. "_VIS"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 1.5}})
		text1("dl_g" .. g .. "_lbl_y", "dl_g" .. g, {0, 0, 0}, F.yellow, TXT_SMALL, "CenterCenter", nil, pre .. "_TXT",
			{pre .. "_RING", -0.5, 1.5})
		text1("dl_g" .. g .. "_lbl_r", "dl_g" .. g, {0, 0, 0}, F.red, TXT_SMALL, "CenterCenter", nil, pre .. "_TXT",
			{pre .. "_RING", 1.5, 2.5})
	end

	-------------------------------------------------------------------------
	-- contacts, F-15 SIT symbology
	--   type 1 friendly  green circle          2 hostile  red triangle (nose = course)
	--        3 unknown   yellow square         4 AWACS    green circle + dot
	--        5 own flight cyan circle
	--   1..4 = given by the datalink -> DOTTED;  +10 = own radar holds it -> SOLID
	--   own flight is always solid. Short line = course. Number above = altitude.
	-------------------------------------------------------------------------
	-- contacts in the MFI edition's style (contact_style = "old": as before):
	-- 45 % bigger, hostile = red diamond turned with its course, the course
	-- line a little apart from its front corner and 50 % longer, labels in a
	-- thicker font (dl_device.lua LBL_UP / LBL_S follow S)
	local CS = CFG.contact_style ~= "old"
	local S  = (CFG.symbol_size or 0.045) * (CS and (CFG.contact_scale or 1.45) or 1)
	local HB = 0.012
	-- dashed version of band(): only every other piece of the outline
	local function dashed(outer, inner, sub)
		local v, idx, n = {}, {}, #outer
		local O, I = {}, {}
		for k = 1, n do
			local a, b = outer[k], outer[k % n + 1]
			local c, d = inner[k], inner[k % n + 1]
			for j = 0, sub - 1 do
				local t = j / sub
				O[#O + 1] = {a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t}
				I[#I + 1] = {c[1] + (d[1] - c[1]) * t, c[2] + (d[2] - c[2]) * t}
			end
		end
		local m = #O
		for k = 1, m do v[k] = O[k]; v[m + k] = I[k] end
		for k = 0, m - 1, 2 do
			local a, b = k, (k + 1) % m
			idx[#idx + 1] = a; idx[#idx + 1] = b; idx[#idx + 1] = m + b
			idx[#idx + 1] = a; idx[#idx + 1] = m + b; idx[#idx + 1] = m + a
		end
		return v, idx
	end
	-- distance from the origin to the nearest edge of a closed polygon
	local function inradius(pts)
		local best = 1e9
		for k = 1, #pts do
			local a, b = pts[k], pts[k % #pts + 1]
			local ex, ey = b[1] - a[1], b[2] - a[2]
			local d = math.abs(a[1] * ey - a[2] * ex) / math.sqrt(ex * ex + ey * ey)
			if d < best then best = d end
		end
		return best
	end
	local function outline(pts, w, dash, sub)
		local inner = scaled(pts, 1 - w / inradius(pts))
		if dash then return dashed(pts, inner, sub) end
		return band(pts, inner)
	end
	local tri = function(r) return {{0, r * 1.2}, {r * 0.9, -r * 0.75}, {-r * 0.9, -r * 0.75}} end
	local sqr = function(r) return {{-r, r}, {r, r}, {r, -r}, {-r, -r}} end
	local function grow(pts, d)
		local f = 1 + d / inradius(pts)
		return scaled(pts, f)
	end
	local rc, rs, rt = S * 0.85, S * 0.75, S * 0.9
	local CIRC  = circle_pts(rc, 24)
	local CIRCA = circle_pts(rc * 1.25, 28)
	local TRI   = tri(rt)
	local SQR   = sqr(rs)
	-- hostile = diamond (as the MFI edition); it turns with the course, so
	-- the course line leaves from its front corner, after a small gap
	local rd    = S * (CFG.host_diamond or 1.15)
	local DIA   = {{0, rd}, {rd, 0}, {0, -rd}, {-rd, 0}}
	local HOST, HOST_TURN = TRI, true
	if CS then HOST = DIA end
	-- v1.8.6 perf: the twelve contact codes (1-6 datalink, +10 own radar)
	-- draw only nine different symbols, and those only four different
	-- halos, so each is built once per contact (13 meshes, were 24). The
	-- device writes the symbol number to DL_C<n>_SHP (CONTACT_SHP in
	-- dl_device.lua), numbered so that one halo covers a range of them:
	-- [n] = {points, dotted?, turns with course?, material}
	--   1 friend dotted (codes 1, 6)  2 friend solid (11, 16)  3 own flight (5, 15)
	--   4 hostile dotted (2)  5 hostile solid (12)
	--   6 unknown dotted (3)  7 unknown solid (13)
	--   8 AWACS dotted (4)  9 AWACS solid (14)
	local shapes = {
		{CIRC,  true,  false, M.friend},  {CIRC, false, false, M.friend},  {CIRC, false, false, M.wing},
		{HOST,  true,  HOST_TURN, M.hostile}, {HOST, false, HOST_TURN, M.hostile},
		{SQR,   true,  false, M.unknown}, {SQR,  false, false, M.unknown},
		{CIRCA, true,  false, M.friend},  {CIRCA, false, false, M.friend},
	}
	-- halos: {points, turns?, first symbol, last symbol}
	local halos = {{CIRC, false, 1, 3}, {HOST, HOST_TURN, 4, 5}, {SQR, false, 6, 7}, {CIRCA, false, 8, 9}}
	local awacs_dot_v, awacs_dot_i = circle_fill(S * 0.25, 10)

	for n = 1, DL_MAX_CONTACTS do
		local base = "dl_c" .. n
		local pt   = "DL_C" .. n .. "_TYPE"
		simple(base, "dl_own", {0, 0, 0}, {"DL_C" .. n .. "_X", "DL_C" .. n .. "_Y", pt},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 99}})
		-- course: rotates the hostile triangle and the course line
		simple(base .. "_rot", base, {0, 0, 0}, {"DL_C" .. n .. "_HDG"}, {{"rotate_using_parameter", 0, 1}})

		local ps = "DL_C" .. n .. "_SHP"
		if SHOW_MAP then
			for k, hl in ipairs(halos) do
				local hv, hi = band(grow(hl[1], HB), scaled(hl[1], 1 - (LW + HB) / inradius(hl[1])))
				mesh(base .. "_h" .. k, hl[2] and (base .. "_rot") or base, "triangles", hv, hi, M.halo, nil,
					{ps}, {{"parameter_in_range", 0, hl[3] - 0.1, hl[4] + 0.1}})
			end
		end
		for k, sh in ipairs(shapes) do
			local sv, si = outline(sh[1], LW, sh[2], (sh[1] == DIA) and 4 or (#sh[1] > 8) and 1 or 3)
			mesh(base .. "_s" .. k, sh[3] and (base .. "_rot") or base, "triangles", sv, si, sh[4], nil,
				{ps}, {{"parameter_in_range", 0, k - 0.1, k + 0.1}})
		end
		-- AWACS / donor dot
		mesh(base .. "_awdot", base, "triangles", awacs_dot_v, awacs_dot_i, M.friend, nil,
			{pt}, {{"parameter_in_range", 0, 3.9, 4.1}})
		mesh(base .. "_awdot2", base, "triangles", awacs_dot_v, awacs_dot_i, M.friend, nil,
			{pt}, {{"parameter_in_range", 0, 13.9, 14.1}})
		mesh(base .. "_dndot", base, "triangles", awacs_dot_v, awacs_dot_i, M.friend, nil,
			{pt}, {{"parameter_in_range", 0, 5.9, 6.1}})
		mesh(base .. "_dndot2", base, "triangles", awacs_dot_v, awacs_dot_i, M.friend, nil,
			{pt}, {{"parameter_in_range", 0, 15.9, 16.1}})
		-- course line, in the contact's colour (DL_C<n>_COL 1 green 2 red 3 yellow 4 cyan)
		local L0, L1 = S * 0.9, S * 0.9 + (CFG.course_line or 0.07)
		local lv = {{-LW / 2, L0}, {LW / 2, L0}, {LW / 2, L1}, {-LW / 2, L1}}
		local cmats = {M.friend, M.hostile, M.unknown, M.wing}
		for ci, cm in ipairs(cmats) do
			local cv = lv
			if CS and ci == 2 then   -- red line of the hostile diamond: a small gap after its corner, 50 % longer
				local g0 = rd + (CFG.course_gap or 0.014)
				local hl = (L1 - L0) * (CFG.host_course_k or 1.5)
				cv = {{-LW / 2, g0}, {LW / 2, g0}, {LW / 2, g0 + hl}, {-LW / 2, g0 + hl}}
			end
			mesh(base .. "_crs" .. ci, base .. "_rot", "triangles", cv, {0, 1, 2, 0, 2, 3}, cm, nil,
				{"DL_C" .. n .. "_COL", "DL_C" .. n .. "_MOV"},
				{{"parameter_in_range", 0, ci - 0.1, ci + 0.1}, {"parameter_in_range", 1, 0.5, 1.5}})
		end
		-- altitude (and Mach) above the symbol, in the contact's colour.
		-- v1.7.6: the label hangs on its own point, which SYM 2 / 3 can move
		-- under or beside the symbol when labels would cover each other
		local lbl = base .. "_lbl"
		simple(lbl, base, {0, 0, 0}, {"DL_C" .. n .. "_TX", "DL_C" .. n .. "_TY"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})
		local tpos = {0, S * 1.35, 0}
		if OUTLINE > 0 then
			for k, d in ipairs(OUT_DIRS) do
				text1(base .. "_alt_o" .. k, lbl, {tpos[1] + d[1] * OUTLINE, tpos[2] + d[2] * OUTLINE, 0},
					F.black, TXT_SMALL, "CenterBottom", nil, "DL_C" .. n .. "_TXT")
			end
		end
		local cfonts = {F.green, F.red, F.yellow, F.cyan}
		-- labels in the thicker font (dl_fonts.lua DL_F_*_B; label_bold = false: thin)
		if CS and TEXF and CFG.label_bold ~= false then
			local bf = {"DL_F_GREEN_B", "DL_F_RED_B", "DL_F_YELLOW_B", "DL_F_CYAN_B"}
			for k = 1, 4 do NIGHT_MAT[bf[k]] = NIGHT_MAT[cfonts[k]] end
			cfonts = bf
		end
		for ci, cf in ipairs(cfonts) do
			text1(base .. "_alt" .. ci, lbl, tpos, cf, TXT_SMALL, "CenterBottom", nil, "DL_C" .. n .. "_TXT",
				{"DL_C" .. n .. "_COL", ci - 0.1, ci + 0.1})
		end
	end

	-- cursor: a full square (v1.7.6; was two short bars). A little smaller
	-- than the radar lock box, so cursor on a locked target = two squares.
	simple("dl_curs", "dl_own", {0, 0, 0}, {"DL_CURS_X", "DL_CURS_Y", "DL_CURS"},
		{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
		 {"parameter_in_range", 2, 0.5, 1.5}})
	do
		local b = S * (CFG.cursor_box or 1.45)
		local cv, ci = band(sqr(b), sqr(b - LW))
		mesh("dl_curs_sym", "dl_curs", "triangles", cv, ci, M.white)
	end
	-- radar lock marker: a box around the locked target
	simple("dl_lock", "dl_own", {0, 0, 0}, {"DL_LOCK_X", "DL_LOCK_Y", "DL_LOCK_VIS"},
		{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
		 {"parameter_in_range", 2, 0.5, 1.5}})
	do
		local b = S * 1.9
		local lv, li = band(sqr(b), sqr(b - LW))
		mesh("dl_lock_box", "dl_lock", "triangles", lv, li, M.white)
	end
	-- round 37 (Lukas): our missiles in flight (dl_msl.lua): a missile turned
	-- to its course (DL_MSL<n>_A, CCW +), a dashed line ahead and the time to
	-- the target it flies at (DL_MSL<n>_T, e.g. "23S")
	do
		local MS = S * (CFG.msl_size or 1.3)
		local W2 = LW * 0.9
		local mv = {{-W2, -MS * 0.75}, {W2, -MS * 0.75}, {W2, MS * 0.55}, {-W2, MS * 0.55},     -- body
		            {-W2 * 1.6, MS * 0.55}, {W2 * 1.6, MS * 0.55}, {0, MS * 1.0},                 -- nose
		            {-MS * 0.38, -MS * 0.95}, {-W2, -MS * 0.45}, {-W2, -MS * 0.75},             -- left fin
		            {MS * 0.38, -MS * 0.95}, {W2, -MS * 0.45}, {W2, -MS * 0.75}}                -- right fin
		local mi = {0, 1, 2, 0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12}
		local dv, di = {}, {}
		local d0, dl, dg = MS * 1.25, (CFG.msl_line or 0.10) / 3, (CFG.msl_line or 0.10) / 6
		for j = 0, 2 do
			local a, b, q = d0 + j * (dl + dg), d0 + j * (dl + dg) + dl, #dv
			dv[q + 1] = {-LW / 2, a}; dv[q + 2] = {LW / 2, a}; dv[q + 3] = {LW / 2, b}; dv[q + 4] = {-LW / 2, b}
			for _, x in ipairs({0, 1, 2, 0, 2, 3}) do di[#di + 1] = q + x end
		end
		local mf = F.white
		for n = 1, (CFG.msl_max or 4) do
			local b = "dl_msl" .. n
			simple(b, "dl_own", {0, 0, 0}, {"DL_MSL" .. n .. "_X", "DL_MSL" .. n .. "_Y", "DL_MSL" .. n .. "_V"},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
				 {"parameter_in_range", 2, 0.5, 1.5}})
			simple(b .. "_rot", b, {0, 0, 0}, {"DL_MSL" .. n .. "_A"}, {{"rotate_using_parameter", 0, 1}})
			mesh(b .. "_sym", b .. "_rot", "triangles", mv, mi, M.white)
			mesh(b .. "_crs", b .. "_rot", "triangles", dv, di, M.white)
			text1(b .. "_t", b, {MS * 0.7, -MS * 0.5, 0}, mf, TXT_SMALL, "LeftTop", nil, "DL_MSL" .. n .. "_T")
		end
	end
	-------------------------------------------------------------------------
	-- intercept steering (dl_tac.lua, SA right 3 INTC): heading bar at the
	-- top with the collision course diamond, meeting point X, dashed lines
	-- jet -> X (yellow) and target -> X (red), readouts bottom left
	-------------------------------------------------------------------------
	do
		local IP = DL_INTC_POOL or {y = 34, r = 48}   -- (as in dl_tac.lua)
		for _, pm in ipairs({{"y", M.unknown}, {"r", M.hostile}}) do
			for i = 1, IP[pm[1]] do
				local pre = "DL_INTC_" .. pm[1] .. i .. "_"
				line_obj("dl_intc_" .. pm[1] .. i, "dl_own", pm[2], 0.004,
					{pre .. "X1", pre .. "Y1", pre .. "X2", pre .. "Y2", pre .. "V"},
					{{"line_object_set_point_using_parameters", 0, 0, 1, GL, GL},
					 {"line_object_set_point_using_parameters", 1, 2, 3, GL, GL},
					 {"parameter_in_range", 4, 0.5, 1.5}})
			end
		end
		-- the target: white ring (amber while the track is lost)
		simple("dl_intc_t", "dl_own", {0, 0, 0}, {"DL_INTC_TX", "DL_INTC_TY", "DL_INTC_TV"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 2.5}})
		local tv, ti = circle_ring(0.075, LW * 0.8, 28)
		mesh("dl_intc_t_w", "dl_intc_t", "triangles", tv, ti, M.white, nil, {"DL_INTC_TV"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		mesh("dl_intc_t_a", "dl_intc_t", "triangles", tv, ti, M.amber, nil, {"DL_INTC_TV"}, {{"parameter_in_range", 0, 1.5, 2.5}})
		-- meeting point X
		simple("dl_intc_x", "dl_own", {0, 0, 0}, {"DL_INTC_XX", "DL_INTC_XY", "DL_INTC_XV", "DL_INTC_ON"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 1.5}, {"parameter_in_range", 3, 0.5, 1.5}})
		do
			local q, w = 0.032, LW * 0.6
			local function bar(a)
				local ca, sa = math.cos(a), math.sin(a)
				local px, py = -sa * w, ca * w
				return {{-q * ca + px, -q * sa + py}, {q * ca + px, q * sa + py}, {q * ca - px, q * sa - py}, {-q * ca - px, -q * sa - py}}
			end
			local v1, v2 = bar(math.pi / 4), bar(-math.pi / 4)
			mesh("dl_intc_x1", "dl_intc_x", "triangles", v1, {0, 1, 2, 0, 2, 3}, M.unknown)
			mesh("dl_intc_x2", "dl_intc_x", "triangles", v2, {0, 1, 2, 0, 2, 3}, M.unknown)
		end
		-- v1.8.1 heading tape, F/A-18 style (does not turn with the map):
		-- +-25 deg at the top of the page between the H1-H5 labels and the
		-- BE / range line (hdg_tape_y, hdg_tape_scale page units per deg); ticks every 5 deg standing up from the tape
		-- (long ones every 10 deg), two-digit numbers above them, a caret
		-- under the middle and own heading boxed below. Shown on the SA page
		-- all the time (hdg_tape = false: only while an intercept runs);
		-- the intercept adds the collision course diamond on the tape.
		-- built by a function so that other pages (RWR, v1.8.1) get the same
		-- tape: same parameters, its own elements under that page's root
		local function hdg_tape(PRE, PAR, BYI)
			local PXD = CFG.hdg_tape_scale or 0.0165
			local Z = CFG.hdg_tape_size or 1.1   -- size of numbers, ticks, box and diamond
			local TW = LW * 1.4                     -- line width of the tape and ticks
			local HW = 25 * PXD
			local TXT_TAPE = {TXT_SMALL[1] * Z, TXT_SMALL[2] * Z, TXT_SMALL[3] * Z, TXT_SMALL[4] * Z}
			local TXT_TBOX = {TXT_SMALL[1] * Z * 1.1, TXT_SMALL[2] * Z * 1.1, TXT_SMALL[3] * Z * 1.1, TXT_SMALL[4] * Z * 1.1}
			simple(PRE, PAR, {0, BYI, 0}, {"DL_HDG_ON"}, {{"parameter_in_range", 0, 0.5, 1.5}})
			-- dark backing so the tape stays readable over the map and symbols
			mesh(PRE .. "_bg", PRE, "triangles", {{-HW - 0.05, 0.135 * Z}, {HW + 0.05, 0.135 * Z}, {HW + 0.05, -0.012}, {-HW - 0.05, -0.012}},
				{0, 1, 2, 0, 2, 3}, col(0, 0, 0, CFG.datablock_backing or 190))
			mesh(PRE .. "_bg2", PRE, "triangles", {{-0.12 * Z, -0.012}, {0.12 * Z, -0.012}, {0.12 * Z, -0.115 * Z}, {-0.12 * Z, -0.115 * Z}},
				{0, 1, 2, 0, 2, 3}, col(0, 0, 0, CFG.datablock_backing or 190))
			mesh(PRE .. "_bar", PRE, "triangles", {{-HW, TW * 0.5}, {HW, TW * 0.5}, {HW, -TW * 0.5}, {-HW, -TW * 0.5}}, {0, 1, 2, 0, 2, 3}, M.white)
			-- caret under the middle, pointing up at the tape
			mesh(PRE .. "_own", PRE, "triangles", {{0, -TW * 0.5}, {0.016 * Z, -0.032 * Z}, {-0.016 * Z, -0.032 * Z}}, {0, 1, 2}, M.white)
			-- own heading, boxed
			do
				local bx, y0, y1 = 0.105 * Z, -0.035 * Z, -0.11 * Z
				local bv, bi = band({{-bx, y0}, {bx, y0}, {bx, y1}, {-bx, y1}},
					{{-bx + LW * 0.8, y0 - LW * 0.8}, {bx - LW * 0.8, y0 - LW * 0.8}, {bx - LW * 0.8, y1 + LW * 0.8}, {-bx + LW * 0.8, y1 + LW * 0.8}})
				mesh(PRE .. "_box", PRE, "triangles", bv, bi, M.white)
				local e = CreateElement "ceStringPoly"
				e.name            = PRE .. "_hdg_t"
				e.material        = F.white
				e.init_pos        = {0, (y0 + y1) / 2, 0}
				e.alignment       = "CenterCenter"
				e.stringdefs      = defs_of(TXT_TBOX)
				e.formats         = {"%03.0f"}
				e.parent_element  = PRE
				e.h_clip_relation = CLIP
				e.level           = LVL
				e.element_params  = {"DL_HDG_T"}
				e.controllers     = {{"text_using_parameter", 0, 0}}
				Add(e)
			end
			-- ticks: K1..K11 (every 5 deg), long or short by DL_INTC_K<n>_V = 2 / 1
			for k = 1, 11 do
				simple(PRE .. "_k" .. k, PRE, {0, 0, 0}, {"DL_INTC_K" .. k .. "_X", "DL_INTC_K" .. k .. "_V"},
					{{"move_left_right_using_parameter", 0, G}, {"parameter_in_range", 1, 0.5, 2.5}})
				mesh(PRE .. "_k" .. k .. "_s", PRE .. "_k" .. k, "triangles",
					{{-TW * 0.5, 0.02 * Z}, {TW * 0.5, 0.02 * Z}, {TW * 0.5, 0}, {-TW * 0.5, 0}}, {0, 1, 2, 0, 2, 3}, M.white,
					nil, {"DL_INTC_K" .. k .. "_V"}, {{"parameter_in_range", 0, 0.5, 1.5}})
				mesh(PRE .. "_k" .. k .. "_l", PRE .. "_k" .. k, "triangles",
					{{-TW * 0.5, 0.038 * Z}, {TW * 0.5, 0.038 * Z}, {TW * 0.5, 0}, {-TW * 0.5, 0}}, {0, 1, 2, 0, 2, 3}, M.white,
					nil, {"DL_INTC_K" .. k .. "_V"}, {{"parameter_in_range", 0, 1.5, 2.5}})
			end
			-- numbers above the long ticks: heading / 10 as two digits (05 = 050)
			for j = 1, 6 do
				simple(PRE .. "_n" .. j, PRE, {0, 0.075 * Z, 0}, {"DL_INTC_N" .. j .. "_X", "DL_INTC_N" .. j .. "_V"},
					{{"move_left_right_using_parameter", 0, G}, {"parameter_in_range", 1, 0.5, 1.5}})
				-- a number formatted by the element (never a number-only string parameter)
				local e = CreateElement "ceStringPoly"
				e.name            = PRE .. "_n" .. j .. "_t"
				e.material        = F.white
				e.init_pos        = {0, 0, 0}
				e.alignment       = "CenterCenter"
				e.stringdefs      = defs_of(TXT_TAPE)
				e.formats         = {"%02.0f"}
				e.parent_element  = PRE .. "_n" .. j
				e.h_clip_relation = CLIP
				e.level           = LVL
				e.element_params  = {"DL_INTC_N" .. j .. "_T"}
				e.controllers     = {{"text_using_parameter", 0, 0}}
				Add(e)
			end
			-- collision course diamond, intercept only (amber when it is off the end of the tape)
			simple(PRE .. "_d", PRE, {0, 0, 0}, {"DL_INTC_DX", "DL_INTC_ON"},
				{{"move_left_right_using_parameter", 0, G}, {"parameter_in_range", 1, 0.5, 1.5}})
			do
				local q = 0.034 * Z
				local dv, di = band({{0, q}, {q, 0}, {0, -q}, {-q, 0}}, {{0, q - LW * 1.6}, {q - LW * 1.6, 0}, {0, -q + LW * 1.6}, {-q + LW * 1.6, 0}})
				mesh(PRE .. "_dg", PRE .. "_d", "triangles", dv, di, M.friend, nil, {"DL_INTC_DP"}, {{"parameter_in_range", 0, 0.5, 1.5}})
				mesh(PRE .. "_da", PRE .. "_d", "triangles", dv, di, M.amber, nil, {"DL_INTC_DP"}, {{"parameter_in_range", 0, 1.5, 2.5}})
			end
		end
		DL_HDG_TAPE_FN = hdg_tape
		hdg_tape("dl_intc", "dl_root", CFG.hdg_tape_y or 1.13)
		-- readouts: bottom right, in place of the cursor datablock
		local BYL0 = (CFG.text_bottom_y or -1.35) + 0.05
		local XR = CFG.text_right_x
		simple("dl_intc_txt", "dl_root", {0, 0, 0}, {"DL_INTC_ON"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		if SHOW_MAP then
			-- dark backing over the moving map (drawn before the texts)
			simple("dl_intc_txt_bg", "dl_intc_txt", {0, 0, 0}, {"DL_MAP_ON"}, {{"parameter_in_range", 0, 0.5, 1.5}})
			mesh("dl_intc_txt_bg_m", "dl_intc_txt_bg", "triangles", {{0.06, BYL0 + 0.53}, {0.92, BYL0 + 0.53}, {0.92, BYL0 + 0.11}, {0.06, BYL0 + 0.11}},
				{0, 1, 2, 0, 2, 3}, col(0, 0, 0, CFG.datablock_backing or 190))
		end
		text("dl_intc_t1", "dl_intc_txt", {XR, BYL0 + 0.47, 0}, F.red, TXT_SMALL, "RightCenter", nil, "DL_INTC_T1")
		text("dl_intc_t2", "dl_intc_txt", {XR, BYL0 + 0.37, 0}, F.white, TXT_SMALL, "RightCenter", nil, "DL_INTC_T2")
		text("dl_intc_t3", "dl_intc_txt", {XR, BYL0 + 0.27, 0}, F.white, TXT_SMALL, "RightCenter", nil, "DL_INTC_T3")
		for ci, cf in ipairs({F.green, F.amber, F.red, F.grey}) do
			text1("dl_intc_t4_" .. ci, "dl_intc_txt", {XR, BYL0 + 0.17, 0}, cf, TXT_SMALL, "RightCenter", nil, "DL_INTC_T4",
				{"DL_INTC_C4", ci - 0.1, ci + 0.1})
		end
	end

	-- readouts: bottom left = cursor bearing / range from the jet,
	-- bottom right = what is under the cursor
	local BYL = (CFG.text_bottom_y or -1.35) + 0.05
	-- cursor readout sits above the MARK / DEL labels (bottom row B1 / B2)
	-- over the moving map the datablocks get a dark backing panel and an outline
	if SHOW_MAP then
		local PB = col(0, 0, 0, CFG.datablock_backing or 190)
		simple("dl_db_bg", "dl_root", {0, 0, 0}, {"DL_MAP_ON"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		mesh("dl_db_bg_c", "dl_db_bg", "triangles", {{-0.92, BYL + 0.23}, {-0.30, BYL + 0.23}, {-0.30, BYL + 0.11}, {-0.92, BYL + 0.11}},
			{0, 1, 2, 0, 2, 3}, PB, nil, {"DL_CURS"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		local hb0 = (CFG.contact_style ~= "old" and CFG.hov_bra_first ~= false and not CFG.hov_id) and 0.21 or 0.11   -- (round 24: no ID line = one line less)
		-- round 40 (squad): the target box 15 % bigger (hov_k), grown from its bottom right corner
		local hk = CFG.hov_k or 1.15
		local function hy(y) return BYL + hb0 + (y - hb0) * hk end
		mesh("dl_db_bg_h", "dl_db_bg", "triangles", {{0.92 - 0.82 * hk, hy(0.53)}, {0.92, hy(0.53)}, {0.92, BYL + hb0}, {0.92 - 0.82 * hk, BYL + hb0}},
			{0, 1, 2, 0, 2, 3}, PB, nil, {"DL_HOV_COL"}, {{"parameter_in_range", 0, 0.5, 4.5}})
	end
	text("dl_cbra", "dl_root", {CFG.text_left_x, BYL + 0.17, 0}, F.white, TXT_SMALL, "LeftCenter", nil, "DL_CURS_BRA",
		{"DL_CURS", 0.5, 1.5})
	local hov_fonts = {F.green, F.red, F.yellow, F.cyan}
	for ci, cf in ipairs(hov_fonts) do
		local vis = {"DL_HOV_COL", ci - 0.1, ci + 0.1}
		-- round 24 (as the MFI edition): BRA first, then altitude / Mach, then
		-- bullseye; no ID line (hov_bra_first = false / hov_id = true: as before)
		local yb, ya, ye, yi = 0.17, 0.27, 0.47, 0.37
		local NEWB = CFG.contact_style ~= "old" and CFG.hov_bra_first ~= false
		if NEWB then yb, ya, ye, yi = 0.47, 0.37, 0.27, 0.17 end
		if NEWB and not CFG.hov_id then yb, ya, ye = 0.47, 0.37, 0.27 end
		-- round 40 (squad, as the MFI edition): bold and 15 % bigger (hov_k / hov_bold),
		-- grown from the box's bottom right corner
		local hk = CFG.hov_k or 1.15
		local ay = BYL + ((NEWB and not CFG.hov_id) and 0.21 or 0.11)
		local hx = 0.92 - (0.92 - CFG.text_right_x) * hk
		local function hy(y) return ay + (BYL + y - ay) * hk end
		local hs = {TXT_SMALL[1] * hk, TXT_SMALL[2] * hk, TXT_SMALL[3], TXT_SMALL[4] * hk}
		local hf = cf
		if TEXF and CFG.hov_bold ~= false then hf = ({"DL_F_GREEN_B", "DL_F_RED_B", "DL_F_YELLOW_B", "DL_F_CYAN_B"})[ci] end
		text("dl_hov_be" .. ci, "dl_root", {hx, hy(ye), 0}, hf, hs, "RightCenter", nil, "DL_HOV_BE", vis)
		if not NEWB or CFG.hov_id then
			text("dl_hov_id" .. ci, "dl_root", {hx, hy(yi), 0}, hf, hs, "RightCenter", nil, "DL_HOV_ID", vis)
		end
		text("dl_hov_alt" .. ci, "dl_root", {hx, hy(ya), 0}, hf, hs, "RightCenter", nil, "DL_HOV_ALT", vis)
		text("dl_hov_bra" .. ci, "dl_root", {hx, hy(yb), 0}, hf, hs, "RightCenter", nil, "DL_HOV_BRA", vis)
	end

	-- header / footer texts ---------------------------------------------
	-- v1.8.1: header lower and smaller (hdr_y, hdr_range_scale,
	-- hdr_be_scale) to make room for the bigger heading tape above it
	-- v1.8.1 (layout 3): range scale and own bullseye top left / right under the H row
	-- (hdr_corner_x / hdr_corner_y), steerpoint + status at hdr_y under the tape
	local TY = CFG.hdr_y or 1.02
	local CX, CY = CFG.hdr_corner_x or 0.88, CFG.hdr_corner_y or 1.26
	local function scaled(d, f) return {d[1] * f, d[2] * f, d[3] * f, d[4] * f} end
	local TXT_RNG = scaled(TXT, CFG.hdr_range_scale or 0.8)
	local TXT_BE = scaled(TXT_SMALL, CFG.hdr_be_scale or 0.85)
	text("dl_rng", "dl_root", {CX, CY, 0}, F.green, TXT_RNG, "RightCenter", nil, "DL_RANGE_TXT")
	-- header (v1.6): own bullseye left, range + steerpoint right; the
	-- datalink status line only when something is wrong (NO DL / DL OFF).
	-- Heading, source and DTC lines are gone. Hidden at SYM 5 (MIN).
	simple("dl_hdr", "dl_root", {0, 0, 0}, {"DL_SYM_HDR"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	text("dl_ownbe", "dl_hdr", {-CX, CY, 0}, F.green, TXT_BE, "LeftCenter", nil, "DL_OWN_BE")
	text("dl_steer", "dl_hdr", {CFG.text_right_x, TY, 0}, F.yellow, TXT_SMALL, "RightCenter", nil, "DL_STEER_TXT")
	text("dl_stat", "dl_hdr", {CFG.text_right_x, TY - 0.10, 0}, F.amber, TXT_SMALL, "RightCenter", nil, "DL_STATUS_TXT")
	-- a banner while choosing a cartridge (UFCP 3)
	simple("dl_dtc_ban", "dl_root", {0, 0, 0}, {"DL_DTC_BAN"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	mesh("dl_dtc_ban_bg", "dl_dtc_ban", "triangles", {{-0.9, 0.62}, {0.9, 0.62}, {0.9, 0.42}, {-0.9, 0.42}}, {0, 1, 2, 0, 2, 3}, M.black)
	text1("dl_dtc_ban_t", "dl_dtc_ban", {0, 0.52, 0}, F.yellow, TXT, "CenterCenter", nil, "DL_DTC_BAN_TXT")

	-- bezel button labels (left row: MFD-3, MFD-4, MFD-5) -------------------
	local BX = CFG.btn_label_x or -1.02
	local BY = CFG.btn_label_y or {0.878, 0.448, 0.014, -0.462, -0.879}
	local BYR = CFG.btn_label_y_right or {0.877, 0.452, 0.035, -0.430, -0.832}
	local ROWT = CFG.btn_row_x or {-0.635, -0.307, 0.021, 0.351, 0.684}
	local ROWB = CFG.btn_row_x_bottom or {-0.61, -0.285, 0.048, 0.370, 0.695}
	local YB8 = CFG.btn8_label_y or -1.25
	local YT8 = CFG.btn_top_label_y or 1.37
	-- SA page side labels: smaller than the old Arial-sized ones, rows
	-- nudged onto the buttons (same per-row offsets as the other pages)
	local TXT_SAB, BYSA, BYRSA
	do
		local SS = CFG.sa_btn_label_scale or 0.75
		TXT_SAB = {TXT_BTN[1] * SS, TXT_BTN[2] * SS, TXT_BTN[3] * SS, TXT_BTN[4] * SS}
		local DYL = CFG.sub_btn_dy_left or {0, 0, 0, 0, 0}
		local DYR = CFG.sub_btn_dy_right or {0, 0, 0, 0, 0}
		BYSA, BYRSA = {}, {}
		for k = 1, 5 do BYSA[k] = BY[k] + (DYL[k] or 0); BYRSA[k] = BYR[k] + (DYR[k] or 0) end
	end
	-- always_on = false (the page opened from the KRN menu) is gone since the
	-- page became the MFD's only one: the setting is ignored (see dl_device.lua)
	local ALWAYS_ON = true
	if ALWAYS_ON then
		text("dl_btn1", "dl_root", {BX, BYSA[1], 0}, F.white, TXT_SAB, "LeftCenter", nil, "DL_BTN1_TXT")
		-- B4 (bottom row, 4th): expand; top row: the 5 nearest hostiles
		text("dl_btn8", "dl_root", {ROWB[4], YB8, 0}, F.white, TXT_SMALL, "CenterCenter", nil, "DL_EXP_TXT")
		text("dl_btn_b1", "dl_root", {ROWB[1], YB8, 0}, F.white, TXT_SMALL, "CenterCenter", "MARK")
		if CFG.opt_map == true then
			-- B5 MAP: white = map shown, grey = map off
			text("dl_btn_b5", "dl_root", {ROWB[5], YB8, 0}, F.white, TXT_SMALL, "CenterCenter", "MAP", nil, {"DL_MAP_ON", 0.5, 1.5})
			text("dl_btn_b5o", "dl_root", {ROWB[5], YB8, 0}, F.grey, TXT_SMALL, "CenterCenter", "MAP", nil, {"DL_MAP_ON", -0.5, 0.5})
		end
		text("dl_btn_b2", "dl_root", {ROWB[2], YB8, 0}, F.white, TXT_SMALL, "CenterCenter", "DEL", nil, {"DL_MK_ANY", 0.5, 1.5})
		for k = 1, 5 do
			text("dl_btn_t" .. k, "dl_root", {ROWT[k], YT8, 0}, F.red, TXT_SMALL, "CenterCenter", "H" .. k)
		end
	end
	-- right 1 GEO: drawings of the cartridge's .geo.txt shown (white) / hidden (grey);
	-- no label without drawings
	text("dl_btn_r1", "dl_root", {-BX, BYRSA[1], 0}, F.white, TXT_SAB, "RightCenter", "GEO", nil, {"DL_GEO_BTN", 0.5, 1.5})
	text("dl_btn_r1o", "dl_root", {-BX, BYRSA[1], 0}, F.grey, TXT_SAB, "RightCenter", "GEO", nil, {"DL_GEO_BTN", 1.5, 2.5})
	-- right 2 PIC (picture page), right 3 INTC (intercept steering; green while it runs)
	text("dl_btn_r2", "dl_root", {-BX, BYRSA[2], 0}, F.white, TXT_SAB, "RightCenter", "PIC")
	text("dl_btn_r3", "dl_root", {-BX, BYRSA[3], 0}, F.white, TXT_SAB, "RightCenter", "INTC", nil, {"DL_INTC_ON", -0.5, 0.5})
	text("dl_btn_r3g", "dl_root", {-BX, BYRSA[3], 0}, F.green, TXT_SAB, "RightCenter", "INTC", nil, {"DL_INTC_ON", 0.5, 1.5})
	text("dl_btn2", "dl_root", {BX, BYSA[2], 0}, F.white, TXT_SAB, "LeftCenter", nil, "DL_BTN2_TXT")
	-- MFD-3 / MFD-4: range
	text("dl_btn3", "dl_root", {BX, BYSA[3], 0}, F.white, TXT_SAB, "LeftCenter", "RNG\n +")
	text("dl_btn4", "dl_root", {BX, BYSA[4], 0}, F.white, TXT_SAB, "LeftCenter", "RNG\n -")
	if not ALWAYS_ON then
		text("dl_btn5", "dl_root", {BX, BYSA[5], 0}, F.white, TXT_SAB, "LeftCenter", "NAV")
	else
		text("dl_btn5", "dl_root", {BX, BYSA[5], 0}, F.white, TXT_SAB, "LeftCenter", "NEXT")
	end

	-- "DL" on MFD-4 while a KRN page is showing (main menu or NAV) and the
	-- DL page is off
	-- the other MFD pages (menu, DTC, ENG, FUEL, RADIO, FPLN, RSBN, HSI)
	DLH = {text = text, text1 = text1, mesh = mesh, simple = simple, line_obj = line_obj, circle_ring = circle_ring,
	       circle_pts = circle_pts, circle_fill = circle_fill, band = band, poly_lines = poly_lines, col = col,
	       M = M, F = F, TXT = TXT, TXT_SMALL = TXT_SMALL, TXT_BTN = TXT_BTN, G = G, LW = LW, BX = BX, BY = BY, CFG = CFG,
	       LVL = LVL, CLIP = CLIP, FONT = FONT, BYR = BYR, ROWT = ROWT, ROWB = ROWB, YB8 = YB8, YT8 = YT8,
	       char_w = char_w, TEXF = TEXF, hdg_tape = DL_HDG_TAPE_FN}
	local ok_p, err_p = pcall(dofile, LockOn_Options.script_path .. "DL/dl_pages.lua")
	if not ok_p and DL_dbg then DL_dbg("page", "dl_pages.lua: " .. tostring(err_p)) end

	for _, kp in ipairs(ALWAYS_ON and {} or {"MM_MFD_PAGE_MAIN_MENU", "MM_MFD_PAGE_BMAP"}) do
		local root = "dl_entry_" .. kp
		simple(root, nil, {0, 0, 0}, {kp}, {{"parameter_in_range", 0, 0.9, 1.1}})
		text(root .. "_lbl", root, {BX, BY[4], 0}, F.white, TXT_BTN, "LeftCenter", "DL", nil, {"DL_PAGE", -0.5, 0.5})
	end
end
local DL_ok, DL_err = pcall(DL_build_page)
Add, CreateElement = DL_rawAdd, DL_rawCreate   -- our wrappers end here, also after an error
if not DL_ok and DL_dbg then DL_dbg("page", "dl_page.lua: " .. tostring(DL_err)) end
