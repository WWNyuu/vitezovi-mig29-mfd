-----------------------------------------------------------------------
-- MiG-29 DL page: textures (loaded from materials.lua)
--
-- Works out which theatre is loaded and registers DCS's own raster
-- aeronautical charts for it (Mods\terrains\<theatre>\RasterCharts) as
-- cockpit textures "DLT_<n>". The chart archives are also mounted into the
-- texture file system in case the terrain has not done so itself.
-- Nothing is copied: the textures are read straight from your DCS install.
-----------------------------------------------------------------------

dofile(LockOn_Options.script_path .. "DL/dl_config.lua")
dofile(LockOn_Options.script_path .. "DL/dl_theatres.lua")

materials["DL_MAP_WHITE"] = {255, 255, 255, 255}
-- the chart is tinted (multiplied) by this colour: map_brightness 1 = as printed
local b = DL_CFG.map_brightness or 0.30
if b < 0 then b = 0 elseif b > 1 then b = 1 end
local g = math.floor(255 * b + 0.5)
materials["DL_MAP_TINT"] = {g, g, g, 255}

-- squadron badge for the MFD main menu (tinted by logo_brightness)
do
	local lb = DL_CFG.logo_brightness or 1.0
	if lb < 0 then lb = 0 elseif lb > 1 then lb = 1 end
	local lg = math.floor(255 * lb + 0.5)
	materials["DL_LOGO_TINT"] = {lg, lg, lg, 255}
	textures["MIG29_DL_LOGO"] = {IND_TEX_PATH .. "mig29_dl_logo.dds", materials["DL_LOGO_TINT"]}
end

local src = DL_CFG.map_source or "none"
if src == "dcs" then
	local theatre = DL_detect_theatre()
	local chart = DL_load_chart(theatre)
	if chart then
		-- mount the chart archives (absolute path from the DCS folder when we can get it)
		local root = ""
		local ok_lfs, lfs_mod = pcall(require, "lfs")
		if ok_lfs and lfs_mod and lfs_mod.currentdir then
			root = lfs_mod.currentdir()
			if root:sub(-1) ~= "/" and root:sub(-1) ~= "\\" then root = root .. "/" end
			-- DCS normally runs from its install folder; if we are in bin/ step up
			if root:lower():match("[/\\]bin[/\\]$") or root:lower():match("[/\\]bin%-mt[/\\]$") then
				root = root:gsub("[^/\\]+[/\\]$", "")
			end
		end
		if mount_vfs_texture_path and DL_CFG.mount_chart_archives ~= false then
			for _, z in ipairs(chart.zips) do
				pcall(mount_vfs_texture_path, root .. z)
			end
		end
		-- v1.7.8: textures built by INSTALL are files in DL/charts_gen/<theatre>/
		local dir = chart.gen and (LockOn_Options.script_path .. chart.dir) or ""
		-- v1.8.5 fix: of a built chart's finest layer only the textures
		-- around the spawn point (DL_gen_keep; 50 km more than the page
		-- builds, so every quad the page builds has its texture). Without
		-- the jet's position here: all of them (as v1.8.5).
		local keep, n_keep, how = nil, #chart.tiles, "all"
		if not chart.gen and DL_raw_keep then
			-- v1.8.6 perf: a chart of DCS's own tiles (no INSTALL build):
			-- only the textures the page's quads around the jet use
			local okp, px, pz, src = pcall(DL_map_pos, theatre)
			if okp and px and DL_pos_live(src) then
				local okk, k, c = pcall(DL_raw_keep, chart, px, pz, 50000)
				if okk then
					keep, n_keep = k, c
					how = k and ("around the jet (" .. tostring(src):match("^%S+") .. ")") or "all (map_max_quads = 0)"
				end
			else
				how = "all (no jet position here: " .. tostring(okp and src or px) .. ")"
			end
		elseif chart.gen then
			local okp, px, pz, src = pcall(DL_map_pos, theatre)
			if okp and px and DL_pos_live(src) and DL_gen_radius() > 0 then
				keep, n_keep = DL_gen_keep(chart, px, pz, DL_gen_radius() + 50000)
				how = "around the jet (" .. tostring(src):match("^%S+") .. ")"
			else
				how = "all (no jet position here: " .. tostring(okp and src or px) .. ")"
			end
		end
		for i, t in ipairs(chart.tiles) do
			if not keep or keep[i] then
				textures["DLT_" .. i] = {dir .. t[1], materials["DL_MAP_TINT"]}
			end
		end
		pcall(dofile, LockOn_Options.script_path .. "DL/dl_debug.lua")
		if DL_dbg then
			DL_dbg("textures", "theatre=" .. tostring(theatre) .. " chart textures " .. n_keep .. " of " .. #chart.tiles ..
				" (" .. how .. ", finest layer " .. tostring(chart.fine) .. ", " .. (chart.gen and "built" or "DCS tiles") ..
				", units " .. tostring(DL_CFG.range_units) .. ")")
		end
	end
end
