-----------------------------------------------------------------------
-- MiG-29 DL add-on (v1.8.6): the radio display's brightness layer
-- (see dl_radio_dim_init.lua). Same units as KRN's Radio\base_page.lua.
-----------------------------------------------------------------------
dofile(LockOn_Options.common_script_path .. "elements_defs.lua")
SetScale(MILLYRADIANS)
if not DL_CFG then pcall(dofile, LockOn_Options.script_path .. "DL/dl_config.lua") end
local B = (DL_CFG and type(DL_CFG.radio_dim_box) == "table" and DL_CFG.radio_dim_box) or {-40, 46, -22, 22}
if DL_CFG and DL_CFG.ufcp_follow_brightness == false then return end

local root = CreateElement "ceSimple"
root.name           = "dl_rdim"
root.init_pos       = {0, 0, 0}
root.element_params = {"UFCP_POWER"}
root.controllers    = {{"parameter_in_range", 0, 0.5, 1.5}}
Add(root)
for k = 1, 10 do
	local m = CreateElement "ceMeshPoly"
	m.name           = "dl_rdim_" .. k
	m.primitivetype  = "triangles"
	m.vertices       = {{B[1], B[4]}, {B[2], B[4]}, {B[2], B[3]}, {B[1], B[3]}}
	m.indices        = {0, 1, 2, 0, 2, 3}
	m.material       = MakeMaterial(nil, {0, 0, 0, k == 10 and math.floor(255 * (1 - math.max(0, math.min(0.1, tonumber(DL_CFG and DL_CFG.nvg_light) or 0.03))) + 0.5) or math.floor(255 * k / 10 + 0.5)})
	m.init_pos       = {0, 0, 0}
	m.element_params = {"DL_UFCP_DIM"}
	m.controllers    = {{"parameter_in_range", 0, k - 0.5, k + 0.5}}
	m.parent_element = root.name
	Add(m)
end
