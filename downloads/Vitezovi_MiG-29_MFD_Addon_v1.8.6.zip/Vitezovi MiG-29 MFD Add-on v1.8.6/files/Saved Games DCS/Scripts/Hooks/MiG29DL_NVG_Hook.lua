-- Vitezovi MiG-29 MFD add-on: night vision goggles (GUI hook, v1.8.6)
-- ED's MiG-29A has no goggles. They are two lines at the end of ED's
--   <DCS>\Mods\aircraft\MiG-29-Fulcrum\Cockpit\Scripts\devices.lua
--   <DCS>\Mods\aircraft\MiG-29-Fulcrum\Cockpit\Scripts\device_init.lua
-- One switch: Options > Special > MIG-29AM > "Night vision goggles".
--  * DCS start: the switch is set back to OFF. The cockpit files are NOT
--    touched while DCS runs, unless you tick the switch: any change to them
--    during a session (even putting ED's files back) makes servers with
--    "pure scripts" flag you until DCS restarts.
--  * Ticked: the lines go in when the next mission loads (that session is
--    then flagged on pure-scripts servers).
--  * DCS closing: the lines are taken out again (ED's files), so the next
--    DCS start is clean. After a DCS crash with the goggles on, start and
--    close DCS once before multiplayer.
-- Log: Saved Games\DCS\Logs\mig29dl_nvg.log

local VNVG = {}
VNVG.PLUGIN = "mig_29am"      -- KRN mod's options tab (holds the MFD add-on's options)
VNVG.KEY = "mig29dl_nvg"
VNVG.REL = "Mods\\aircraft\\MiG-29-Fulcrum\\Cockpit\\Scripts\\"
VNVG.BEGIN = "-- VITEZOVI NVG BEGIN (Vitezovi MiG-29 MFD add-on: Special Options > MIG-29AM > Night vision goggles; taken out when DCS closes)"
VNVG.END = "-- VITEZOVI NVG END"
VNVG.ADD = {
	["devices.lua"]     = 'devices["HELMET_DEVICE"]				= counter()',
	["device_init.lua"] = 'creators[devices.HELMET_DEVICE] = {"avNightVisionGoggles"}',
}
-- what each file must contain before we touch it (guards against a changed ED file)
VNVG.MUST = {
	["devices.lua"]     = 'devices["KRU"]',
	["device_init.lua"] = 'creators[devices.KRU]',
}

local lfs = require("lfs")

local function log(s)
	pcall(function()
		local f = io.open(lfs.writedir() .. "Logs\\mig29dl_nvg.log", "a")
		if f then f:write(os.date("%Y-%m-%d %H:%M:%S ") .. s .. "\n"); f:close() end
	end)
end

local function readall(p)
	local f = io.open(p, "rb"); if not f then return nil end
	local s = f:read("*a"); f:close(); return s
end

local function writeall(p, s)
	local f, err = io.open(p, "wb")
	if not f then return false, err end
	-- (DCS's io returns nothing from write: check by reading back)
	f:write(s)
	f:close()
	if readall(p) ~= s then return false, "read-back differs" end
	return true
end

-- DCS install folder: written by INSTALL.bat, else the folder DCS runs in
local function dcs_dir()
	for _, f in ipairs({ "Vitezovi-MFD-Addon\\dcs_path.txt", "Vitezovi-NVG-test\\dcs_path.txt" }) do
		local s = readall(lfs.writedir() .. f)
		if s then
			s = s:gsub("^%s+", ""):gsub("%s+$", "")
			if s ~= "" and s:sub(-1) ~= "\\" then s = s .. "\\" end
			if s ~= "" and lfs.attributes(s .. VNVG.REL .. "devices.lua") then return s end
		end
	end
	local c = lfs.currentdir()
	if c:sub(-1) ~= "\\" then c = c .. "\\" end
	return c
end

-- remove every "-- VITEZOVI NVG ... BEGIN" .. "-- VITEZOVI NVG ... END" block
-- (also the v0.3 test's "-- VITEZOVI NVG TEST BEGIN/END")
function VNVG.strip(s)
	while true do
		local a = nil
		local p = 1
		while true do
			local i = s:find("-- VITEZOVI NVG", p, true)
			if not i then break end
			if i == 1 or s:sub(i - 1, i - 1) == "\n" then
				local eol = s:find("\n", i, true) or #s
				if s:sub(i, eol):find("BEGIN", 1, true) then a = i; break end
			end
			p = i + 1
		end
		if not a then return s end
		local e = s:find("\n-- VITEZOVI NVG", a, true)
		while e do
			local eol = s:find("\n", e + 1, true) or #s
			if s:sub(e + 1, eol):find("END", 1, true) then break end
			e = s:find("\n-- VITEZOVI NVG", e + 1, true)
		end
		if not e then return s end   -- no END: leave it alone
		local z = s:find("\n", e + 1, true) or #s
		s = s:sub(1, a - 1) .. s:sub(z + 1)
	end
end

function VNVG.add(s, line)
	local eol = s:find("\r\n", 1, true) and "\r\n" or "\n"
	if s ~= "" and s:sub(-1) ~= "\n" then s = s .. eol end
	return s .. VNVG.BEGIN .. eol .. line .. eol .. VNVG.END .. eol
end

-- want = true: NVG lines in; false: ED's files
function VNVG.apply(want, why)
	local dir = dcs_dir() .. VNVG.REL
	local res = {}
	for _, name in ipairs({ "devices.lua", "device_init.lua" }) do
		local p = dir .. name
		local s = readall(p)
		if not s then
			res[#res + 1] = name .. " not found (" .. p .. ")"
		elseif not s:find(VNVG.MUST[name], 1, true) then
			res[#res + 1] = name .. " left alone (not ED's usual file)"
		else
			local base = VNVG.strip(s)
			local new = base
			if want then new = VNVG.add(base, VNVG.ADD[name]) end
			if new == s then
				res[#res + 1] = name .. (want and " NVG already in" or " already ED's")
			else
				local ok, err = writeall(p, new)
				if ok then res[#res + 1] = name .. (want and " NVG added" or " back to ED's")
				else res[#res + 1] = name .. " NOT changed (" .. tostring(err) .. ")" end
			end
		end
	end
	log(why .. ": NVG " .. (want and "on" or "off") .. " -> " .. table.concat(res, ", "))
end


local function options_file() return lfs.writedir() .. "Config\\options.lua" end

-- the switch as saved in Saved Games\DCS\Config\options.lua
function VNVG.switch_on()
	local on = false
	pcall(function()
		local f = loadfile(options_file())
		if not f then return end
		local env = {}
		setfenv(f, env)
		f()
		local o = env.options and env.options.plugins and env.options.plugins[VNVG.PLUGIN]
		if o and o[VNVG.KEY] == true then on = true end
	end)
	return on
end

-- set the switch back to OFF in options.lua. This runs while DCS starts,
-- before its options page reads the file, so the box shows unticked.
-- (DCS 2.9's Options.Data in hooks cannot change a plugin option.)
function VNVG.reset_switch()
	local file = "already off"
	local s = readall(options_file())
	if not s then file = "not found"
	else
		local n, c = s:gsub('(%["' .. VNVG.KEY .. '"%]%s*=%s*)true', "%1false")
		if c > 0 then
			local w, e = writeall(options_file(), n)
			file = w and "set to off" or ("NOT written (" .. tostring(e) .. ")")
		end
	end
	return file
end

-- lines still in from a DCS crash: say so (taking them out now would itself
-- flag this session; they go out when DCS closes)
function VNVG.leftover()
	local dir = dcs_dir() .. VNVG.REL
	for _, name in ipairs({ "devices.lua", "device_init.lua" }) do
		local s = readall(dir .. name)
		if s and VNVG.strip(s) ~= s then return true end
	end
	return false
end

local cb = {}
-- every mission load (single player, multiplayer client or host)
function cb.onMissionLoadBegin()
	pcall(function()
		if VNVG.switch_on() then
			VNVG.apply(true, "mission loading, switch on")
		else
			log("mission loading, switch off: cockpit files not touched")
		end
	end)
end

-- DCS closing: when DCS shuts this Lua state down, the finalizer below puts
-- ED's files back (only if the lines are in).
function VNVG.on_close()
	pcall(VNVG.apply, false, "DCS closing")
end
VITEZOVI_NVG_CLOSER = newproxy(true)
getmetatable(VITEZOVI_NVG_CLOSER).__gc = function() VNVG.on_close() end

if DCS and DCS.setUserCallbacks then
	DCS.setUserCallbacks(cb)
	local ok, r = pcall(VNVG.reset_switch)
	log("hook loaded (add-on v1.8.6), DCS folder " .. dcs_dir() .. ", switch reset: " .. tostring(r))
	local ok2, left = pcall(VNVG.leftover)
	if ok2 and left then
		log("WARNING: NVG lines are still in the cockpit files (DCS crashed last time?). A MiG-29 flown now has goggles and pure-scripts servers flag you; they are taken out when DCS closes.")
	end
end

return VNVG
