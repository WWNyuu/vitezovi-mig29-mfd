-----------------------------------------------------------------------
-- MiG29DL_Hook.lua  --  mission data for the MiG-29 MFD pages
-- (Saved Games\DCS\Scripts\Hooks)
--
-- While YOU sit in a full-fidelity MiG-29 (unit type "MiG-29 Fulcrum") on
-- this PC, every few seconds over UDP to 127.0.0.1:42888 (the MFD cockpit
-- device):
--   * both coalitions' bullseye                          (SA page)
--   * the map name, the data cartridge stored with YOUR MiG-29 in the
--     mission and its radio presets ("MSN DTC" on the PLAN page; .dtc
--     files from Saved Games\DCS\DTC are picked with PLAN > LOAD). Sent
--     again for the new jet when you change slots; the P line names the
--     unit so the cockpit knows it is a different one.
--   * which player sits in which aircraft               (FLT page)
-- Does nothing where nobody flies a MiG-29 on this PC (dedicated server,
-- spectators, other aircraft). The mission is read at most once per
-- mission (reading it is expensive in big missions), and only when the
-- slot is a MiG-29 or its type cannot be told otherwise.
-----------------------------------------------------------------------
local DL_PORT = 42888
-- every datagram stays below this (contract with the cockpit device)
local MAX_PACKET = 7500

-- LuaSocket is shared with other hooks: one already loaded is used as it
-- is; otherwise our path is added to package.path / cpath once, and a
-- failed require is retried at most every 30 s (each try searches the disk)
local sock = {udp = nil, paths = false, fail_t = nil}
local function add_path(field, entry)
	local p = package[field] or ""
	if not p:find(entry, 1, true) then package[field] = p .. ";" .. entry end
end
local function get_udp()
	if sock.udp then return sock.udp end
	if sock.fail_t and math.abs(os.time() - sock.fail_t) < 30 then return nil end
	local socket = package.loaded["socket"]
	if type(socket) ~= "table" then
		if not sock.paths then
			sock.paths = true
			local ok_lfs, lfs_mod = pcall(require, "lfs")
			local root = (ok_lfs and lfs_mod and lfs_mod.currentdir and lfs_mod.currentdir()) or "."
			add_path("path", root .. "/LuaSocket/?.lua")
			add_path("cpath", root .. "/LuaSocket/?.dll")
		end
		local ok, s = pcall(require, "socket")
		socket = ok and type(s) == "table" and s or nil
	end
	local ok, u = pcall(function() return socket and socket.udp() end)
	if not ok or not u then sock.fail_t = os.time(); return nil end
	sock.fail_t = nil
	u:settimeout(0)
	sock.udp = u
	return u
end
local function send(u, data)
	pcall(function() u:sendto(data, "127.0.0.1", DL_PORT) end)
end

-- Saved Games\DCS\Logs\mig29dl_hook.log: new file each DCS start, a few lines
local log_n = 0
local function log(msg)
	if log_n >= 50 then return end
	log_n = log_n + 1
	pcall(function()
		local l = require("lfs")
		local f = io.open(l.writedir() .. "Logs/mig29dl_hook.log", (log_n == 1) and "w" or "a")
		if f then f:write(os.date("%H:%M:%S ") .. tostring(msg) .. "\n"); f:close() end
	end)
end

-- the full-fidelity MiG-29 reports the type "MiG-29 Fulcrum"; the FC3
-- MiG-29A / MiG-29S / MiG-29G have no add-on cockpit and must not match.
-- Tolerant of case, spaces, dashes and underscores ("MiG-29_Fulcrum").
local ff_cache = {}
local function is_ff_mig29(name)
	if type(name) ~= "string" then return false end
	local c = ff_cache[name]
	if c == nil then
		local n = name:lower():gsub("[^%w]", "")
		c = n:find("^mig29") ~= nil and n:find("fulcrum", 6, true) ~= nil
		ff_cache[name] = c
	end
	return c
end

-----------------------------------------------------------------------
-- names that go to the cockpit (unit, player and type names): the MFD
-- font only has ASCII 32-126 and the packet fields are separated by "," and
-- "|". Common accented / Cyrillic letters are transliterated, everything
-- else non-ASCII becomes "?", separators and control characters a space.
-- Long names are cut to 24 characters keeping the start and the end
-- ("[127th] Vitezovi~ani 1-1"), so numbered units stay apart and a packet
-- stays small.
-- KEEP clean() IDENTICAL IN MiG29DL_Export.lua: the cockpit matches the
-- unit names of the export's F lines against these player lists.
-----------------------------------------------------------------------
local TR = {}   -- UTF-8 two-byte letter -> ASCII
do
	local function map(first, list)
		local cp = first
		for w in list:gmatch("%S+") do
			-- "?" = no ASCII form, "-" = dropped (Cyrillic hard / soft sign)
			if w ~= "?" then TR[string.char(192 + math.floor(cp / 64), 128 + cp % 64)] = (w == "-") and "" or w end
			cp = cp + 1
		end
	end
	map(0x00C0, "A A A A A A AE C E E E E I I I I D N O O O O O x O U U U U Y TH ss " ..
	            "a a a a a a ae c e e e e i i i i d n o o o o o ? o u u u u y th y")
	map(0x0100, "A a A a A a C c C c C c C c D d Dj dj E e E e E e E e E e G g G g " ..
	            "G g G g H h H h I i I i I i I i I i IJ ij J j K k k L l L l L l L " ..
	            "l L l N n N n N n n N n O o O o O o OE oe R r R r R r S s S s S s " ..
	            "S s T t T t T t U u U u U u U u U u U u W w Y y Y Z z Z z Z z s")
	map(0x0400, "E E Dj G E Dz I I J Lj Nj C K I U Dz A B V G D E Zh Z I J K L M N O P " ..
	            "R S T U F H C Ch Sh Shch - Y - E Yu Ya a b v g d e zh z i j k l m n o p " ..
	            "r s t u f h c ch sh shch - y - e yu ya e e dj g e dz i i j lj nj c k i u dz")
	map(0x0490, "G g")
	TR["\194\160"] = " "   -- no-break space
end
local function tr_char(ch) return TR[ch] or "?" end
local function ascii(v)
	local s = tostring(v or ""):gsub("[\128-\255][\128-\191]*", tr_char)
	s = s:gsub("[%c,|;]", " ")
	return (s:gsub("^ +", ""):gsub(" +$", ""))
end
local clean_cache, clean_n = {}, 0
local function clean(v)
	local s = tostring(v or "")
	local c = clean_cache[s]
	if c then return c end
	c = ascii(s)
	if #c > 24 then c = c:sub(1, 16) .. "~" .. c:sub(-7) end
	-- the cache only holds the names of one mission; a mission that keeps
	-- spawning new units must not grow it without end
	if clean_n >= 4000 then clean_cache, clean_n = {}, 0 end
	clean_cache[s], clean_n = c, clean_n + 1
	return c
end

-- add one line to a packet unless that would make it larger than
-- MAX_PACKET. Once full, nothing more is added, so the order in which
-- lines are added is their priority.
local function put(out, line)
	if out.full then return false end
	local sz = (out.size or -1) + #line + 1
	if sz > MAX_PACKET then out.full = true; return false end
	out[#out + 1] = line
	out.size = sz
	return true
end

-- a list of points with x / y map coordinates
local function is_route(t)
	return type(t) == "table" and type(t[1]) == "table" and tonumber(t[1].x) and tonumber(t[1].y)
end

-- find a cartridge route inside a table (mission unit or .dtc data)
local function has_points(p)
	return type(p) == "table" and (is_route(p.Route) or is_route(p.Waypoints) or is_route(p.Airdromes))
end
local function route_in_cartridge(d)
	if type(d) ~= "table" then return nil end
	local data = d.data or d
	local prog = data.SelectedProgram and data[data.SelectedProgram]
	if has_points(prog) then return prog, data.SelectedProgram end
	if has_points(data.Program_1) then return data.Program_1, "Program_1" end
	return nil
end

local function search(t, depth, seen)
	if type(t) ~= "table" or depth > 7 or seen[t] then return nil end
	seen[t] = true
	local r, p = route_in_cartridge(t)
	if r then return r, p end
	for k, v in pairs(t) do
		if type(v) == "table" then
			local kk = string.lower(tostring(k))
			if depth < 2 or kk:find("dtc") or kk:find("cartridge") or kk:find("program") or kk:find("data") then
				local r2, p2 = search(v, depth + 1, seen)
				if r2 then return r2, p2 end
			end
		end
	end
	return nil
end

local function tbl(t) return type(t) == "table" and t or {} end

-----------------------------------------------------------------------
-- per-mission state; reset at every simulation start AND stop, so a new
-- mission (model time starting at 0 again) begins with nothing remembered
-----------------------------------------------------------------------
local S = {}
local function reset(running)
	S.running = running     -- between onSimulationStart and onSimulationStop
	S.last = -100           -- last 5 s check
	S.players_last = -100   -- last MIG29DLW (10 s)
	S.brief_last = -100     -- last MIG29DLM (10 s)
	S.msn = nil             -- what we need from the mission, read once (false = unreadable)
	S.slot = nil            -- the player's slot at the last check
	S.mig = nil             -- that slot is a MiG-29 Fulcrum (nil = not checked yet)
	S.unit = nil            -- its mission unit (false = not in the mission, e.g. dynamic spawn)
	S.route_msg = nil       -- MIG29DLR for that unit
	clean_cache, clean_n = {}, 0
end
reset(false)

local function is_mp() return DCS.isMultiplayer and DCS.isMultiplayer() end
-- the mission environment can only be asked where the mission runs
local function mission_here()
	return not is_mp() or (DCS.isServer and DCS.isServer())
end
local function my_id()
	local ok, id = pcall(net.get_my_player_id)
	return ok and id or nil
end

-- the player's slot on this PC: nil when nobody flies here (dedicated
-- server, spectator). Multiplayer: the slot id (the mission unitId for
-- editor slots; dynamic-spawn slots can be other strings). Single player
-- has one player unit: "SP".
local function my_slot()
	if not is_mp() then return "SP" end
	local ok, slot = pcall(function() return net.get_player_info(net.get_my_player_id(), "slot") end)
	if not ok or slot == nil or slot == "" or slot == 0 or slot == "0" then return nil end
	return tostring(slot)
end

-- type of the slot without reading the mission (nil if DCS cannot tell)
local function slot_type(slot)
	local id = slot
	if slot == "SP" then
		local ok, pu = pcall(DCS.getPlayerUnit)
		if not ok or pu == nil or pu == "" then return nil end
		id = pu
	end
	local ok, ty = pcall(DCS.getUnitType, id)
	if ok and type(ty) == "string" and ty ~= "" then return ty end
	return nil
end

-- read the mission once: map, bullseyes and all client / player slots
-- (MiG-29 Fulcrum units keep their mission table for the cartridge)
local function read_mission()
	if S.msn ~= nil then return S.msn end
	S.msn = false
	local ok, m = pcall(DCS.getCurrentMission)
	if not ok or type(m) ~= "table" then return false end
	local mis = m.mission or m
	local d = {theatre = (tostring(mis.theatre or ""):gsub("[%c,]", "")), units = {}, slots = {}, player = nil, be = nil}
	local c = mis.coalition
	if type(c) == "table" then
		local function be(side)
			local b = type(c[side]) == "table" and c[side].bullseye
			if type(b) == "table" and tonumber(b.x) and tonumber(b.y) then return string.format("%.1f,%.1f", b.x, b.y) end
			return "0,0"
		end
		d.be = "MIG29DLB\nB," .. be("blue") .. "," .. be("red")
	end
	for sname, side in pairs(tbl(c)) do
		local sid = (sname == "red" and 1) or (sname == "blue" and 2) or 0
		for _, ctry in pairs(tbl(type(side) == "table" and side.country)) do
			for _, cat in ipairs({"plane", "helicopter"}) do
				local cc = type(ctry) == "table" and ctry[cat]
				for _, grp in pairs(tbl(type(cc) == "table" and cc.group)) do
					for _, u in pairs(tbl(type(grp) == "table" and grp.units)) do
						if type(u) == "table" and (u.skill == "Client" or u.skill == "Player") then
							local info = {id = tostring(u.unitId), name = tostring(u.name or ""), type = tostring(u.type or ""), side = sid}
							if is_ff_mig29(info.type) then info.raw = u end
							d.slots[#d.slots + 1] = info
							if u.unitId ~= nil then d.units[info.id] = info end
							if u.skill == "Player" and not d.player then d.player = info end
						end
					end
				end
			end
		end
	end
	S.msn = d
	log("mission read: " .. #d.slots .. " client / player slots, map " .. d.theatre)
	return d
end

-- the mission unit of the player's slot (nil: not in the mission)
local function find_unit(d, slot)
	if slot == "SP" then
		-- the unit DCS says we fly (a Client slot taken in single player, also
		-- in a mission that has a Player unit as well), else the Player unit
		local ok, pu = pcall(DCS.getPlayerUnit)
		local u = ok and pu ~= nil and d.units[tostring(pu)] or nil
		return u or d.player
	end
	local u = d.units[slot]
	if u then return u end
	-- the same id as a number ("21" / 21 / "21.0")
	local n = tonumber(slot)
	if n then
		for id, x in pairs(d.units) do
			if tonumber(id) == n then return x end
		end
	end
	return nil
end

-- is the player's slot a MiG-29 Fulcrum? Reads the mission only if so (or
-- when DCS cannot tell the type of the slot)
local function check_slot(slot)
	local ty = slot_type(slot)
	if ty and not is_ff_mig29(ty) then return false end
	local d = read_mission()
	local u = d and find_unit(d, slot) or nil
	ty = ty or (u and u.type)
	if not is_ff_mig29(ty) then return false end
	S.unit = u or false
	log("player in a MiG-29: " .. (u and ("unit " .. ascii(u.name)) or ("slot " .. tostring(slot) .. " (not in the mission)")))
	return true
end

-- 1. cartridge stored with the player's own MiG-29 in the mission,
-- 2. its radio presets (mission editor), for the COM/NAV page.
-- P names the unit (stable for the slot): the cockpit replaces its mission
-- cartridge and presets when it changes. Sent also when the unit has no
-- cartridge or presets (then the cockpit forgets the old ones).
local function build_route(d, u, slot)
	local out = {}
	put(out, "MIG29DLR")
	put(out, "T," .. d.theatre)
	put(out, "P," .. ascii((u and u.name ~= "" and u.name) or ("slot " .. tostring(slot))):sub(1, 80))
	local raw = u and u.raw
	if not raw then return table.concat(out, "\n") end
	local prog, src = search(raw, 0, {})
	if prog then
		local function add(tag, list)
			for i, w in ipairs(tbl(list)) do
				if type(w) == "table" and tonumber(w.x) and tonumber(w.y) then
					local num = ascii(w.num or w.name or i):gsub("[^%w]", ""):sub(1, 16)
					if not put(out, string.format("%s,%.1f,%.1f,%s", tag, tonumber(w.x), tonumber(w.y), num)) then return end
				end
			end
		end
		add("R", prog.Route); add("W", prog.Waypoints); add("A", prog.Airdromes)
		log("mission DTC of " .. ascii(u.name) .. ": " .. tostring(src))
	else
		log("no DTC stored with " .. ascii(u.name) .. " in this mission")
	end
	local r1 = type(raw.Radio) == "table" and type(raw.Radio[1]) == "table" and raw.Radio[1].channels
	local chs = {}
	for ch, f in pairs(tbl(r1)) do
		if tonumber(ch) and tonumber(f) then chs[#chs + 1] = tonumber(ch) end
	end
	table.sort(chs)
	for _, ch in ipairs(chs) do
		put(out, string.format("C,%d,%.3f", ch, tonumber(r1[ch])))
	end
	return table.concat(out, "\n")
end

-- own coalition: 1 red, 2 blue (from the own unit, else from the server)
local function my_side()
	if S.unit and (S.unit.side == 1 or S.unit.side == 2) then return S.unit.side end
	local ok, side = pcall(function() return net.get_player_info(net.get_my_player_id(), "side") end)
	return ok and tonumber(side) or 0
end

-----------------------------------------------------------------------
-- player names of the friendly aircraft (FLIGHT page remembers members by
-- player name). Asked from the mission itself, so this only runs where the
-- mission runs: single player, or a player hosting from his own PC.
-- Only coalition.getPlayers is used, every 10 s: almost no load. The
-- mission side only keeps the line format intact; names are cleaned here.
-----------------------------------------------------------------------
local PLAYERS_CODE = [==[
local side = %d
local out = {}
local function f(v) return (tostring(v or ""):gsub("[|\n\r]", " ")) end
-- only the player-flown aircraft: cheap for the server even in big missions
for _, u in ipairs(coalition.getPlayers(side) or {}) do
	if u and u:isExist() then
		out[#out + 1] = table.concat({f(u:getName()), f(u:getPlayerName() or ""), f(u:getTypeName())}, "|")
		if #out >= 400 then break end
	end
end
return table.concat(out, "\n")
]==]
local function send_players(u, t)
	if t - S.players_last < 10 then return end
	S.players_last = t
	if not mission_here() then return end
	local side = my_side()
	if side ~= 1 and side ~= 2 then return end
	local ok, res = pcall(net.dostring_in, "mission", string.format(PLAYERS_CODE, side))
	if not ok or type(res) ~= "string" or res == "" then return end
	local out = {}
	put(out, "MIG29DLW")
	for line in res:gmatch("[^\n]+") do
		local un, pl, ty = line:match("^([^|]*)|([^|]*)|([^|]*)")
		if un and not put(out, table.concat({clean(un), clean(pl), clean(ty), "", "", ""}, "|")) then break end
	end
	if #out > 1 then send(u, table.concat(out, "\n")) end
end

-----------------------------------------------------------------------
-- who flies which editor slot (any multiplayer client): the occupied
-- client slots by unit name, with the player sitting in each; own
-- coalition first, as many as fit into one packet
-----------------------------------------------------------------------
local function send_brief(u, t, d)
	if t - S.brief_last < 10 then return end
	S.brief_last = t
	-- who sits in which slot (slot = the mission unit id for editor slots)
	local pilot = {}
	pcall(function()
		for _, id in ipairs(net.get_player_list() or {}) do
			local info = net.get_player_info(id) or {}
			if info.slot and info.name and info.name ~= "" then pilot[tostring(info.slot)] = info.name end
		end
	end)
	local side = my_side()
	local occ = {}
	for _, b in ipairs(d.slots) do
		if pilot[b.id] then occ[#occ + 1] = b end
	end
	table.sort(occ, function(a, b)
		local oa, ob = a.side == side, b.side == side
		if oa ~= ob then return oa end
		return a.name < b.name
	end)
	local out = {}
	put(out, "MIG29DLM")
	for _, b in ipairs(occ) do
		if not put(out, table.concat({clean(b.name), clean(pilot[b.id]), clean(b.type), "", "", ""}, "|")) then break end
	end
	send(u, table.concat(out, "\n"))
end

local cb = {}
function cb.onSimulationStart()
	reset(true)
end
function cb.onSimulationStop()
	reset(false)
end
-- our own slot changed: look again at the next frame (the 5 s check
-- below notices it too)
function cb.onPlayerChangeSlot(id)
	if S.running and id ~= nil and id == my_id() then S.last = -100 end
end
function cb.onSimulationFrame()
	if not S.running then return end
	local t = DCS.getModelTime and DCS.getModelTime() or 0
	if t - S.last < 5 and t >= S.last then return end
	S.last = t
	local slot = my_slot()
	-- Single player: the slot is always "SP", but in a mission with Client
	-- slots the jet flown can change (or not be chosen yet at the first
	-- check). So the unit flown is part of what we remember: another unit
	-- is looked at again like another slot.
	local key, sp_unit = slot, nil
	if slot == "SP" then
		local ok, pu = pcall(DCS.getPlayerUnit)
		if ok and pu ~= nil and pu ~= "" then sp_unit = tostring(pu) end
		key = "SP:" .. (sp_unit or "?")
	end
	if key ~= S.slot then
		-- new or other slot: forget what we knew about the old one
		S.slot, S.mig, S.unit, S.route_msg = key, nil, nil, nil
		S.players_last, S.brief_last = -100, -100
	end
	if not slot then return end            -- dedicated server / spectator
	if S.mig == nil then
		local ok, r = pcall(check_slot, slot)
		if not ok then log("slot check error: " .. tostring(r)) end
		S.mig = ok and r or false
		-- single player and DCS names no unit yet (no slot chosen): a "no"
		-- is not final, ask again at the next check
		if not S.mig and slot == "SP" and not sp_unit then S.mig = nil; return end
	end
	if not S.mig then return end           -- not a MiG-29: nothing to send
	local d = S.msn
	if not d then return end
	if S.route_msg == nil then
		local ok, rm = pcall(build_route, d, S.unit, slot)
		if not ok then log("route error: " .. tostring(rm)) end
		S.route_msg = ok and rm or false
	end
	local u = get_udp()
	if not u then return end
	if d.be then send(u, d.be) end
	if S.route_msg then send(u, S.route_msg) end
	pcall(send_players, u, t)
	pcall(send_brief, u, t, d)
end
-----------------------------------------------------------------------
-- v1.7.5 timing log: off unless Saved Games\DCS\Vitezovi-MFD-Addon\
-- settings.lua has perf_log = true. Every 30 s one block in
-- Saved Games\DCS\Logs\mig29dl_hook_perf.log: calls, average and worst time, calls of
-- 1 ms or more, Lua memory created per call. os.clock steps in 1 ms on
-- Windows: single short calls read 0 or 1 ms, the average over many calls
-- is still right. Every step in a pcall: it can never stop the script.
-----------------------------------------------------------------------
local PERF = {on = false, file = "mig29dl_hook_perf.log", period = 30, max_blocks = 480}
local function perf_read_setting()
	PERF.on = false
	pcall(function()
		local l = require("lfs")
		local f = loadfile(l.writedir() .. "Vitezovi-MFD-Addon/settings.lua")
		if not f then return end
		local cfg = {}
		local G = _G
		local env = setmetatable({DL_CFG = cfg}, {
			__index = function(_, k)
				if cfg[k] ~= nil then return cfg[k] end
				if G[k] ~= nil then return G[k] end
				local t = {}; cfg[k] = t; return t      -- "ranges_km[1] = 10" and the like
			end,
			__newindex = function(_, k, v) cfg[k] = v end})
		setfenv(f, env)
		pcall(f)
		local own = rawget(env, "DL_CFG")
		PERF.on = (cfg.perf_log == true) or (type(own) == "table" and own.perf_log == true)
	end)
	if PERF.on and not PERF.st then
		PERF.st = {b = {}, order = {}, p0 = os.clock(), frames = 0, blocks = 0, opened = false}
	end
end
local function perf_kb()
	local ok, v = pcall(collectgarbage, "count")
	return (ok and type(v) == "number") and v or nil
end
local function perf_write(lines)
	pcall(function()
		local l = require("lfs")
		local path = l.writedir() .. "Logs/" .. PERF.file
		local st = PERF.st
		local mode = "a"
		if not st.opened then
			st.opened = true
			local old = path:gsub("%.log$", ".old.log")
			pcall(os.remove, old); pcall(os.rename, path, old)
			mode = "w"
		end
		local fh = io.open(path, mode)
		if fh then fh:write(table.concat(lines, "\n") .. "\n"); fh:close() end
	end)
end
-- start of a measured step: clock and memory now
local function perf_begin() return os.clock(), perf_kb() end
-- end of step k (begun at c0 / m0); returns the clock / memory now, so
-- the next step can start from there
local function perf_add(k, c0, m0)
	local c1, m1 = os.clock(), perf_kb()
	pcall(function()
		local st = PERF.st
		local b = st.b[k]
		if not b then b = {n = 0, sum = 0, max = 0, n1 = 0, n4 = 0, n16 = 0, asum = 0, an = 0}; st.b[k] = b; st.order[#st.order + 1] = k end
		local d = c1 - c0
		b.n = b.n + 1; b.sum = b.sum + d
		if d > b.max then b.max = d end
		if d >= 0.001 then b.n1 = b.n1 + 1 end
		if d >= 0.004 then b.n4 = b.n4 + 1 end
		if d >= 0.016 then b.n16 = b.n16 + 1 end
		if m0 and m1 and m1 >= m0 then b.asum = b.asum + (m1 - m0); b.an = b.an + 1 end
	end)
	return c1, m1
end
-- once per frame: writes the block when the period is over
local function perf_frame()
	pcall(function()
		local st = PERF.st
		if st.blocks >= PERF.max_blocks then return end
		st.frames = st.frames + 1
		local now = os.clock()
		local dt = now - st.p0
		if dt < PERF.period then return end
		st.blocks = st.blocks + 1
		local L = {}
		if st.blocks == 1 then
			L[#L + 1] = "Vitezovi MiG-29 MFD timing log (" .. PERF.file .. ")  " .. os.date("%Y-%m-%d %H:%M:%S")
			L[#L + 1] = "  one block every " .. PERF.period .. " s; avg is per call; 'of the time' = share of one CPU core"
		end
		local mem = perf_kb()
		L[#L + 1] = string.format("%s  %.0f s  %d frames (%.1f/s)  Lua memory %s KB", os.date("%H:%M:%S"), dt, st.frames, st.frames / dt,
			mem and string.format("%.0f", mem) or "?")
		for _, k in ipairs(st.order) do
			local b = st.b[k]
			if b.n > 0 then
				L[#L + 1] = string.format("  %-9s %6d calls  avg %.3f ms  worst %.3f ms  >=1ms %d  >=4ms %d  >=16ms %d  alloc %s KB/call  %.2f%% of the time",
					k, b.n, 1000 * b.sum / b.n, 1000 * b.max, b.n1, b.n4, b.n16,
					(b.an > 0) and string.format("%.2f", b.asum / b.an) or "?", 100 * b.sum / dt)
			end
			st.b[k] = {n = 0, sum = 0, max = 0, n1 = 0, n4 = 0, n16 = 0, asum = 0, an = 0}
		end
		if st.blocks == PERF.max_blocks then L[#L + 1] = "(log full: nothing more is written until DCS restarts)" end
		perf_write(L)
		st.p0, st.frames = now, 0
	end)
end
perf_read_setting()

-- v1.7.5: the frame function, timed while perf_log is on
do
	local frame = cb.onSimulationFrame
	cb.onSimulationFrame = function()
		if not PERF.on then return frame() end
		local c0, m0 = perf_begin()
		local ok, err = pcall(frame)
		perf_add("hook", c0, m0)
		perf_frame()
		if not ok then error(err, 0) end
	end
	local start = cb.onSimulationStart
	cb.onSimulationStart = function(...)
		perf_read_setting()
		return start(...)
	end
end
DCS.setUserCallbacks(cb)
