-----------------------------------------------------------------------
-- MiG-29 DL add-on: MFD page system (device side)
--
-- DL_MODE  0 MENU   1 SA (situation page)   4 FPAS (fuel + engines)   16 SNAKE (v1.7.4)
--          5 COM/NAV (radio, RSBN, ILS)    6 PLAN (flight plan + DTC)
--          8 HSI    9 FLIGHT   10 RWR   11 SMS (stores)   12 NAV (route steering)
--          13 RTE (pick the route points to fly, from the NAV page)
-- MFD-8 (bottom centre) goes to the MENU; on the MENU it goes back.
-- MFD-8 (bottom centre) goes back to MENU from every page.
-- The UFCP keypad types numbers on the HSI page (HDG / CRS / TACAN).
-- All values reach the indicator through cockpit parameters DLP_*.
-----------------------------------------------------------------------

DL_PAGES = {mode = 0, marks = {n = 0, last = {}}}

local M = {}             -- module state
local H = {}             -- parameter handles
-- parameter handles that only write when the value changed (saves the
-- cockpit a lot of work: most values stay the same between updates)
local function P(n)
	local h = get_param_handle(n)
	local last = nil
	return {
		set = function(_, v) if v ~= last then last = v; h:set(v) end end,
		get = function() return h:get() end,
	}
end
local CFG = DL_CFG or {}

local function fmt_brg(rad)
	if type(rad) ~= "number" or rad ~= rad or rad == math.huge or rad == -math.huge then return 0 end   -- (never "%03d" of nan)
	return (math.floor(math.deg(rad) + 0.5) + 359) % 360 + 1
end
local function bra(ox, oz, x, z, unit_m, unit_lbl)
	local dN, dE = x - ox, z - oz
	return fmt_brg(math.atan2(dE, dN)), math.sqrt(dN * dN + dE * dE) / unit_m
end
local function mmss(sec)
	if not sec or sec ~= sec or sec < 0 or sec > 99 * 3600 then return "--:--" end
	local h = math.floor(sec / 3600)
	local m = math.floor((sec % 3600) / 60)
	if h > 0 then return string.format("%d:%02d H", h, m) end
	return string.format("%d:%02d MIN", m, math.floor(sec % 60))
end
-- v1.7.2: a number that can be printed (not nil, nan or inf). "%d" of nan /
-- inf prints -9223372036854775808 (or -2147483648), "%f" prints nan / inf.
local function fin(v) return type(v) == "number" and v == v and v > -math.huge and v < math.huge end
local function rnd(v) return fin(v) and math.floor(v + 0.5) or nil end

-- v1.7.2: printable ASCII only (the MFD font has ASCII 32-126): common
-- accented letters become plain ones (C with caron -> C, u umlaut -> u,
-- sharp s -> ss ...), any other character "?". For every text from the
-- map, the mission, cartridges or players (names of route points, plans,
-- beacons, units, players, stores, emitters).
local TRL = {}
do
	-- U+00C0 .. U+017F, one letter each ("_" = see TRX)
	local base = "AAAAAA_CEEEEIIIIDNOOOOOxOUUUUY__aaaaaa_ceeeeiiiidnooooo?ouuuuy_y" ..
		"AaAaAaCcCcCcCcDdDdEeEeEeEeEeGgGgGgGgHhHhIiIiIiIiIi__JjKkkLlLlLlL" ..
		"lLlNnNnNnnNnOoOoOo__RrRrRrSsSsSsSsTtTtTtUuUuUuUuUuUuWwYyYZzZzZzs"
	local TRX = {[0xC6] = "AE", [0xDE] = "TH", [0xDF] = "ss", [0xE6] = "ae", [0xFE] = "th",
	             [0x132] = "IJ", [0x133] = "ij", [0x152] = "OE", [0x153] = "oe"}
	for cp = 0xC0, 0x17F do
		local ch = string.char(0xC0 + math.floor(cp / 64), 0x80 + cp % 64)
		TRL[ch] = TRX[cp] or base:sub(cp - 0xC0 + 1, cp - 0xC0 + 1)
	end
	TRL["\194\160"] = " "                                   -- no-break space
	TRL["\226\128\147"], TRL["\226\128\148"] = "-", "-"     -- en / em dash
	TRL["\226\128\152"], TRL["\226\128\153"] = "'", "'"     -- quotes
	TRL["\226\128\156"], TRL["\226\128\157"] = '"', '"'
end
local function ascii(s)
	if s == nil then return "" end
	s = tostring(s)
	if not s:find("[^\10\32-\126]") then return s end
	s = s:gsub("[\192-\255][\128-\191]*", function(ch) return TRL[ch] or "?" end):gsub("\t", " ")
	return (s:gsub("[^\10\32-\126]", "?"))
end
DL_PAGES.ascii = ascii                -- (dl_geo.lua uses it for the drawing names)
local function up(s) return string.upper(ascii(s)) end

-- text values must always contain a letter (DCS crash on number-like text)
-- texts: never empty and never a bare number (DCS would treat it as a number)
-- v1.7.2: also printable ASCII only, and a number that went wrong (nan /
-- inf) never shows as such (the values are checked where they are made;
-- this is the last line of defence)
local function T(h, s)
	s = tostring(s or "")
	if s:find("[^\10\32-\126]") then s = ascii(s) end
	-- (texts are upper case: a lower case letter or "#" is rare, so this is cheap)
	if s:find("[a-z#]") or s:find("775808") or s:find("483648") then
		s = s:gsub("%-?%f[%w]nan%f[%W]", "--"):gsub("%-?%f[%w]inf%f[%W]", "--"):gsub("%-?1%.#[%u]+%d*", "--")
		     :gsub("%-9223372036854775808", "--"):gsub("%-2147483648", "--")
	end
	if s == "" then s = " " elseif tonumber(s) then s = s .. " -" end
	h:set(s)
end

-----------------------------------------------------------------------
-- map beacons (TACAN / RSBN / PRMG) from Mods\terrains\<map>\Beacons.lua
-----------------------------------------------------------------------
local BEACONS = nil
local function load_beacons(theatre)
	BEACONS = {tacan = {}, rsbn = {}, prmg = {}, vor = {}}
	-- v1.7.2: C.theatre is DCS's theatre id when the hook sends it (GermanyCW,
	-- SinaiMap, MarianaIslandsWWII ...); the terrain folder can be named
	-- differently (dl_theatres.lua, loaded after this file: looked up here)
	local folder = (type(DL_theatre_folder) == "function") and DL_theatre_folder(theatre) or theatre
	if not folder or folder == "" then return end
	local f = loadfile("Mods/terrains/" .. folder .. "/Beacons.lua")
	if not f then return end
	local env = setmetatable({
		dofile = function() end,
		_ = function(s) return s end,
		require = function() return {translate = function(s) return s end} end,
	}, {__index = function(_, k)
		if type(k) == "string" and k:find("^BEACON_TYPE_") then return k end
		return _G[k]
	end})
	setfenv(f, env)
	if not pcall(f) or type(env.beacons) ~= "table" then return end
	for _, b in ipairs(env.beacons) do
		local p = b.position
		if type(p) == "table" and p[1] then
			local e = {name = ascii(b.display_name), cs = ascii(b.callsign), ch = tonumber(b.channel),
			           x = p[1], z = p[3], y = tonumber(p[2]) or 0}
			if b.type == "BEACON_TYPE_TACAN" or b.type == "BEACON_TYPE_VORTAC" then BEACONS.tacan[#BEACONS.tacan + 1] = e end
			if b.type == "BEACON_TYPE_RSBN" then BEACONS.rsbn[#BEACONS.rsbn + 1] = e end
			if b.type == "BEACON_TYPE_PRMG_LOCALIZER" then BEACONS.prmg[#BEACONS.prmg + 1] = e end
			if b.type == "BEACON_TYPE_VOR" or b.type == "BEACON_TYPE_VORTAC" then BEACONS.vor[#BEACONS.vor + 1] = e end
		end
	end
	table.sort(BEACONS.rsbn, function(a, b) return (a.ch or 0) < (b.ch or 0) end)
	table.sort(BEACONS.prmg, function(a, b) return (a.ch or 0) < (b.ch or 0) end)
	table.sort(BEACONS.tacan, function(a, b) return (a.ch or 0) < (b.ch or 0) end)
end
local function beacon_by_ch(list, ch)
	for _, b in ipairs(list or {}) do if b.ch == ch then return b end end
	return nil
end
-- the map's beacons, loaded again when the theatre changes
local function need_beacons(C)
	if not BEACONS or M.beacon_map ~= C.theatre then load_beacons(C.theatre); M.beacon_map = C.theatre end
end

-----------------------------------------------------------------------
function DL_PAGES.init(dbg)
	M.dbg = dbg or function() end
	DL_PAGES.mode = (CFG.start_page == "DL") and 1 or 0
	M.hdg_bug, M.crs, M.tcn = 0, 0, CFG.default_tacan_channel
	M.entry, M.buf = nil, ""
	M.dtc_page = 1
	-- display brightness (1..10) for day and night, D/N switch picks which
	M.night = false
	M.brt = {day = CFG.brightness_day or 10, night = CFG.brightness_night or 4}
	M.brt_t = -100
	-- SA page declutter (SYM rocker): 1 FULL 2 GROUP 3 ALT 4 CLEAN 5 MIN
	-- (v1.7.6: from 2 on, close contacts share a label and labels keep apart)
	DL_PAGES.sym = 1
	H.mode = P("DL_MODE")
	H.dim = P("DLP_DIM")
	H.night = P("DLP_NIGHT")   -- v1.7.6: 1 = night palette (dl_page.lua)
	H.brt_show = P("DLP_BRT_SHOW")
	H.brt_txt = P("DLP_BRT_TXT")
	local names = {
		"MENU_STAT", "DTC_TITLE", "DTC_PAGE", "FUEL_ENG", "FUEL_EGT",
		"FUEL_TOT", "FUEL_INT", "FUEL_FLOW", "FUEL_TO", "FUEL_TO_RNG", "FUEL_SR",
		"FUEL_B1", "FUEL_B2", "FUEL_B3", "FUEL_B4", "FUEL_RES",
		"FUEL_BNG", "FUEL_HOME", "FUEL_NEED", "FUEL_HARR", "BINGO_TXT",
		"RWR_STAT", "RWR_CM", "SMS_GUN", "SMS_CM", "SMS_TOT", "SMS_SEL",
		"RDO_FREQ", "RDO_SRC", "RDO_ADF", "RDO_KRU",
		"FPL_SRC", "RSBN_SEL", "RSBN_ILS",
		"HSI_HDG", "HSI_STP1", "HSI_STP2", "HSI_TCN1", "HSI_TCN2", "HSI_BUG", "HSI_CRS", "HSI_ENTRY",
		"HSI_NX1", "HSI_NX2", "HSI_NX3",
	}
	for _, n in ipairs(names) do H[n] = P("DLP_" .. n) end
	H.dtc = {}
	for i = 1, 5 do H.dtc[i] = {txt = P("DLP_DTC_I" .. i), mark = P("DLP_DTC_M" .. i)} end
	H.dtcd = {}
	for i = 1, 6 do H.dtcd[i] = P("DLP_DTC_D" .. i) end
	H.egt_w = P("DLP_FUEL_EGTW")
	H.plan_view = P("DLP_PLAN_VIEW")
	M.plan_view = 0
	H.rdo = {}
	for i = 1, 20 do H.rdo[i] = {txt = P("DLP_RDO_C" .. i), sel = P("DLP_RDO_S" .. i)} end
	H.fpl = {}
	for i = 1, 10 do H.fpl[i] = {txt = P("DLP_FPL_L" .. i), act = P("DLP_FPL_A" .. i), tot = P("DLP_FPL_T" .. i)} end
	-- time on target (PLAN page)
	H.tot = {on = P("DLP_TOT_ON"), hint = P("DLP_TOT_HINT"), l1 = P("DLP_TOT_L1"), st = P("DLP_TOT_ST"), c = P("DLP_TOT_C"),
	         spd = P("DLP_TOT_SPD"), thn = P("DLP_TOT_THEN"), rx = P("DLP_TOT_RX"), gx = P("DLP_TOT_GX"), rv = P("DLP_TOT_RV"), gv = P("DLP_TOT_GV"), fuel = P("DLP_TOT_FUEL"), fc = P("DLP_TOT_FC")}
	M.tots, M.tot_pt, M.gs_hist = {}, nil, {}      -- M.tots[route index] = seconds of day
	-- RWR: emitter symbols and the list under the scope
	H.rw = {}
	for i = 1, 12 do H.rw[i] = {x = P("DLP_RW" .. i .. "_X"), y = P("DLP_RW" .. i .. "_Y"), s = P("DLP_RW" .. i .. "_S"), t = P("DLP_RW" .. i .. "_T"),
	                            n = P("DLP_RW" .. i .. "_N"), k = P("DLP_RW" .. i .. "_K")} end
	H.rwl = {}
	for i = 1, 6 do H.rwl[i] = {txt = P("DLP_RWR_L" .. i), c = P("DLP_RWR_C" .. i)} end
	H.launch = P("DLP_LAUNCH")
	H.bingo_show = P("DLP_BINGO_SHOW")
	H.bingo_warn = P("DLP_BINGO_WARN")
	-- SMS: one line per station
	H.sms = {}   -- v1.7.6: per station: store shape, name, how many, colour
	for i = 1, 7 do
		H.sms[i] = {ico = P("DLP_SMS_I" .. i), nm = P("DLP_SMS_N" .. i), ct = P("DLP_SMS_C" .. i), sel = P("DLP_SMS_A" .. i)}
	end
	M.bingo = CFG.bingo_default_kg or 0
	M.bingo_t, M.bingo_armed = -100, true
	M.home_i = 1
	H.rsbn = {}
	for i = 1, 5 do H.rsbn[i] = {txt = P("DLP_RSBN_L" .. i), act = P("DLP_RSBN_A" .. i)} end
	H.hsi = {rot = P("DLP_HSI_ROT"), bug = P("DLP_HSI_BUGR"), crs = P("DLP_HSI_CRSR"), cdi = P("DLP_HSI_CDI"),
	         b1 = P("DLP_HSI_B1R"), b1v = P("DLP_HSI_B1V"), b2 = P("DLP_HSI_B2R"), b2v = P("DLP_HSI_B2V"), lbl = {}}
	for k = 0, 11 do H.hsi.lbl[k] = {x = P("DLP_HSI_L" .. k .. "_X"), y = P("DLP_HSI_L" .. k .. "_Y")} end
	-- NAV page
	H.nav = {src = P("DLP_NAV_SRC"), stp = P("DLP_NAV_STP"), brg = P("DLP_NAV_BRG"), time = P("DLP_NAV_TIME"),
	         leg = P("DLP_NAV_LEG"), cmd = P("DLP_NAV_CMD"), steer = P("DLP_NAV_STEER"), sv = P("DLP_NAV_SV"),
	         auto = P("DLP_NAV_AUTO"), seq = P("DLP_NAV_SEQ"), rows = {}}
	for i = 1, 5 do H.nav.rows[i] = {txt = P("DLP_NAV_L" .. i), c = P("DLP_NAV_C" .. i), tot = P("DLP_NAV_T" .. i)} end
	H.rte = {title = P("DLP_RTE_TITLE"), sum = P("DLP_RTE_SUM"), mem = P("DLP_RTE_MEM"), pg = P("DLP_RTE_PG"), rows = {}, m = {}}
	for k = 1, 5 do H.rte.rows[k] = {txt = P("DLP_RTE_R" .. k), c = P("DLP_RTE_C" .. k)} end
	for k = 1, 4 do H.rte.m[k] = P("DLP_RTE_M" .. k) end
	M.rte_sel, M.rte_page = {}, 1
	-- v1.7.2 EDIT page (route editor, from NAV bottom 4)
	H.wed = {title = P("DLP_WED_TITLE"), sel = P("DLP_WED_SEL"), ll = P("DLP_WED_LL"), mg = P("DLP_WED_MG"),
	         msg = P("DLP_WED_MSG"), msgc = P("DLP_WED_MSGC"), pg = P("DLP_WED_PG"), rows = {}}
	for k = 1, 5 do H.wed.rows[k] = {txt = P("DLP_WED_R" .. k), c = P("DLP_WED_C" .. k)} end
	M.ed_i, M.ed_w = 1, nil
	H.nav.view = P("DLP_NAV_VIEW")
	H.nav.add  = P("DLP_NAV_ADD")             -- 1 = the bottom line is the ADD entry / a message             -- bottom block: 0 TOT, 1 RSBN
	H.nav.rsel = P("DLP_NAV_RSEL")
	H.nav.rs = {}
	for i = 1, 4 do H.nav.rs[i] = {txt = P("DLP_NAV_R" .. i), c = P("DLP_NAV_RC" .. i)} end
	M.nav_view = 0
	-- FLIGHT page
	H.flt = {view = P("DLP_FLT_VIEW"), title = P("DLP_FLT_TITLE"), pg = P("DLP_FLT_PG"),
	         l1 = P("DLP_FLT_L1"), l2 = P("DLP_FLT_L2"), rows = {}, d = {}}
	for k = 1, 5 do H.flt.rows[k] = {txt = P("DLP_FLT_R" .. k), sub = P("DLP_FLT_S" .. k), mark = P("DLP_FLT_M" .. k)} end
	H.flt.c = {}
	for i = 1, 14 do H.flt.d[i] = P("DLP_FLT_D" .. i); H.flt.c[i] = P("DLP_FLT_C" .. i) end
	M.seen = {}
	M.flt_view, M.flt_sel, M.flt_page = 0, 1, 1
	M.flight = DL_PAGES.load_flight()
end

-----------------------------------------------------------------------
-- flight members (FLIGHT page). A member is remembered by player name
-- when the host's feed gives it (survives respawns / dynamic slots),
-- otherwise by unit name. Kept in Saved Games\DCS\MiG29-DL-Addon\flight.txt
-----------------------------------------------------------------------
local function flight_file()
	local ok, lfs_mod = pcall(require, "lfs")
	if not ok or not lfs_mod then return nil end
	local dir = lfs_mod.writedir() .. "MiG29-DL-Addon/"
	pcall(lfs_mod.mkdir, dir)
	return dir .. "flight.txt"
end
function DL_PAGES.load_flight()
	local list = {}
	local fn = flight_file()
	local fh = fn and io.open(fn, "r")
	if fh then
		for l in fh:lines() do
			l = l:gsub("[\r\n]", "")
			if l ~= "" and #list < 5 then list[#list + 1] = l end
		end
		fh:close()
	end
	return list
end
local function save_flight()
	local fn = flight_file()
	local fh = fn and io.open(fn, "w")
	if fh then fh:write(table.concat(M.flight, "\n") .. "\n"); fh:close() end
end
local function key_of(a) return (a.player and a.player ~= "") and a.player or a.unit end
local function name_of(a) return ascii((a.player and a.player ~= "") and a.player or a.unit) end
local function in_flight(a)
	for i, k in ipairs(M.flight or {}) do
		if k == a.unit or (a.player and a.player ~= "" and k == a.player) then return i end
	end
	return nil
end
DL_PAGES.in_flight = function(unit, player) return in_flight({unit = unit, player = player}) ~= nil end
-- friendly aircraft from the export (F lines) with the player flying each
-- (live list when hosting / single player, else the mission's client slots)
local function aircraft(C)
	local out = {}
	local w = C.feed.wpn or {}
	local br = C.feed.brief or {}
	local live = C.feed.wpn_t and ((C.t or 0) - C.feed.wpn_t) < 30
	for _, f in ipairs(C.feed.fr or {}) do
		local x = live and w[f.unit] or br[f.unit]
		f.player = (x and x.player ~= "" and x.player) or (br[f.unit] and br[f.unit].player ~= "" and br[f.unit].player) or f.player
		if fin(f.x) and fin(f.z) then out[#out + 1] = f end      -- (no position: nothing to show)
	end
	return out
end

-----------------------------------------------------------------------
-- buttons
--   b: "M1".."M5" (left column), "M8", "B1" "B2" "B4" "B5" (bottom),
--      "R1".."R5" (right), "T1".."T5" (top), "K0".."K9", "CLR", "ENT"
-----------------------------------------------------------------------
-- the route of the plan in use (route points, without the airfields);
-- TOTs, ETAs and fuel are worked out along it
local function route_pts(C)
	local p = C.plan
	if not p then return {} end
	if not p._rt then
		local r = {}
		for i = 1, (p.nrt or #p.pts) do r[i] = p.pts[i] end
		p._rt = r
	end
	return p._rt
end
-- v1.7.2: index of the selected steerpoint in a plan's point list. Our own
-- STP selection is a route index (C.nav.stp_i), else the point itself,
-- else the first point at the same place (NAV panel waypoints are copies;
-- KRN's / the NAV panel's number is tried first when that point is there).
-- v1.7.1 matched by position only: on a closed-loop route (last point =
-- first point) or with two points on one spot it took the wrong one
-- (TOT "NO TOT AHEAD", the TOT cursor jumping, the wrong NAV line lit).
local function act_index(C, pts)
	local act = C.act
	if not act or not pts then return nil end
	local nav = C.nav or {}
	local si = nav.src == "stp" and nav.stp_i
	if si and pts[si] == act then return si end
	for i, w in ipairs(pts) do if w == act then return i end end
	local hint = (nav.src == "krn" and tonumber(nav.last_krn)) or
		(nav.src == "nav" and type(nav.last_nav) == "string" and nav.last_nav:sub(1, 1) == "W" and tonumber(nav.last_nav:sub(2))) or nil
	local w = hint and pts[hint]
	if w and w.x == act.x and w.z == act.z then return hint end
	for i, p in ipairs(pts) do if p.x == act.x and p.z == act.z then return i end end
	return nil
end
local function start_entry(kind)
	if M.entry == kind then
		-- pressing the same button again applies what was typed
		DL_PAGES.apply_entry()
		return
	end
	M.entry, M.buf = kind, ""
end
-- typed-in waypoint: "LL" = N DDMMmm E DDDMMmm (hemispheres of the jet's
-- own position), "MGRS" = easting + northing (2-10 digits) in the jet's
-- own 100 km square. Adds the point to the route (dl_device PL.add_user).
local function own_ll(C)
	local ok, terr = pcall(require, "terrain")
	if not ok or type(terr) ~= "table" or not terr.convertMetersToLatLon then return nil end
	local ok2, lat, lon = pcall(terr.convertMetersToLatLon, C.ox, C.oz)
	if ok2 and lat then return lat, lon, terr end
	return nil
end
-- the typed coordinates as map metres, or nil and what is wrong
local function parse_point(kind, b)
	local C = M.cref
	if not C then return nil, nil, "NO PLAN" end
	local lat0, lon0, terr = own_ll(C)
	if not lat0 or not terr.convertLatLonToMeters then return nil, nil, "NO COORDINATES" end
	local lat, lon
	if kind == "LL" then
		if #b ~= 13 then return nil, nil, "TYPE ALL 13 DIGITS" end
		local la_d, la_m = tonumber(b:sub(1, 2)), tonumber(b:sub(3, 6)) / 100
		local lo_d, lo_m = tonumber(b:sub(7, 9)), tonumber(b:sub(10, 13)) / 100
		if la_d > 89 or lo_d > 179 or la_m >= 60 or lo_m >= 60 then return nil, nil, "NO SUCH POSITION" end
		lat = (la_d + la_m / 60) * ((lat0 < 0) and -1 or 1)
		lon = (lo_d + lo_m / 60) * ((lon0 < 0) and -1 or 1)
	else
		if #b < 2 or #b % 2 ~= 0 then return nil, nil, "EVEN NUMBER OF DIGITS" end
		local k = #b / 2
		local cell = 10 ^ (5 - k)
		local de = tonumber(b:sub(1, k)) * cell + ((k < 5) and cell / 2 or 0)
		local dn = tonumber(b:sub(k + 1)) * cell + ((k < 5) and cell / 2 or 0)
		local zone, e0, n0 = DL_PLAN.ll_to_utm(lat0, lon0)
		local e = math.floor(e0 / 100000) * 100000 + de
		local n = math.floor(n0 / 100000) * 100000 + dn
		local south = lat0 < 0
		lat, lon = DL_PLAN.utm_to_ll(zone, e, south and (n - 10000000) + 10000000 or n, not south)
	end
	local ok, x, z = pcall(terr.convertLatLonToMeters, lat, lon)
	if not ok or not x then return nil, nil, "NO SUCH POSITION" end
	if (x - C.ox) ^ 2 + (z - C.oz) ^ 2 > (CFG.add_max_km or 1500) ^ 2 * 1e6 then return nil, nil, "TOO FAR (OTHER MAP?)" end
	return x, z
end
-- v1.7.2: TOTs, the TOT cursor and the EDIT cursor stay with their points
-- through a change of the working route. before = its points before.
local function follow_points(C, before)
	local L = (C and C.nav and C.nav.wp_list) and C.nav.wp_list() or {}
	local at = {}
	for i, w in ipairs(L) do at[w] = i end
	local t = {}
	for i, v in pairs(M.tots) do local w = before[i]; local j = w and at[w]; if j then t[j] = v end end
	M.tots = t
	if M.tot_pt then local w = before[M.tot_pt]; M.tot_pt = w and at[w] or nil end
	if M.ed_w and at[M.ed_w] then M.ed_i = at[M.ed_w] end
	M.ed_i = math.max(1, math.min(M.ed_i or 1, #L))
	M.ed_w = L[M.ed_i]
end
local function snapshot(C)
	local before = {}
	if C and C.nav and C.nav.wp_list then for i, w in ipairs(C.nav.wp_list()) do before[i] = w end end
	return before
end
-- ENT on a typed position: NAV ADD (after the active steerpoint, flown
-- direct to), EDIT ADD (after the EDIT cursor) or EDIT POS (new place
-- for the point under the EDIT cursor)
local function add_point(kind, b)
	local C = M.cref
	local nav = C and C.nav
	if not nav or not nav.add_user then return "NO PLAN" end
	local x, z, err = parse_point(kind, b)
	if not x then return err end
	local before = snapshot(C)
	local what = M.entry_for or "NAV"
	local j
	if what == "POS" then
		if not (M.ed_w and nav.wp_set(M.ed_i, x, z)) then return "NO POINT SELECTED" end
		j = M.ed_i
	elseif what == "EDADD" then
		j = nav.wp_insert(M.ed_w and M.ed_i or #before, x, z)
		if not j then return "NO PLAN" end
		M.ed_i, M.ed_w = j, nav.wp_list()[j]
	else
		j = nav.add_user(x, z)
		if not j then return "NO PLAN" end
	end
	follow_points(C, before)
	if what == "EDADD" then M.ed_i, M.ed_w = j, nav.wp_list()[j] end
	M.dbg(string.format("waypoint typed (%s %s %s): %.0f %.0f, route position %d", what, kind, b, x, z, j))
	return nil
end
function DL_PAGES.apply_entry()
	local n = tonumber(M.buf)
	if M.entry == "LL" or M.entry == "MGRS" then
		local err = add_point(M.entry, M.buf)
		M.nav_msg, M.nav_msg_t = err or ((M.entry_for == "POS") and "WAYPOINT MOVED" or "WAYPOINT ADDED"), M.now or 0
		M.entry, M.buf, M.entry_for = nil, "", nil
		return
	end
	if M.entry == "TOT" then
		-- HHMM or HHMMSS, mission time of day
		local b = M.buf
		local hh, mm, ss = tonumber(b:sub(1, 2)), tonumber(b:sub(3, 4)), (#b == 6) and tonumber(b:sub(5, 6)) or 0
		if (#b == 4 or #b == 6) and hh and mm and ss and hh < 24 and mm < 60 and ss < 60 then
			local i = M.tot_pt or 1
			M.tots[i] = hh * 3600 + mm * 60 + ss
			M.dbg(string.format("TOT set: point %d at %02d:%02d:%02d", i, hh, mm, ss))
		end
		M.entry, M.buf = nil, ""
		return
	end
	if n then
		if M.entry == "BNG" then M.bingo = n; M.bingo_armed = true
		elseif M.entry == "HDG" then M.hdg_bug = n % 360
		elseif M.entry == "CRS" then M.crs = n % 360
		elseif M.entry == "TCN" and n >= 1 and n <= 126 then M.tcn = n end
		M.dbg(tostring(M.entry) .. " set to " .. n)
	end
	M.entry, M.buf = nil, ""
end

-- lat / long entry, pressed again = MGRS entry, again = cancel; for = what
-- ENT does with it (NAV = NAV ADD, EDADD / POS = the EDIT page)
local function coord_entry(what)
	if M.entry_for == what and M.entry == "LL" then M.entry, M.buf = "MGRS", ""
	elseif M.entry_for == what and M.entry == "MGRS" then M.entry, M.buf, M.entry_for = nil, "", nil
	else M.entry, M.buf, M.entry_for = "LL", "", what end
end
-- returns true when the button was used here
function DL_PAGES.command(b, C)
	local mode = DL_PAGES.mode
	-- brightness rocker and D/N switch: on every page
	if b == "BRT+" or b == "BRT-" or b == "DAY" or b == "NIGHT" then
		local k = M.night and "night" or "day"
		if b == "BRT+" then M.brt[k] = math.min(10, M.brt[k] + 1)
		elseif b == "BRT-" then M.brt[k] = math.max(1, M.brt[k] - 1)
		elseif b == "DAY" then M.night = false
		else M.night = true end
		M.brt_t = C.t or 0
		M.toast = nil
		return true
	end
	-- SYM rocker: SA page declutter (left click less, right click more)
	if b == "SYM+" or b == "SYM-" then
		if mode == 1 then
			DL_PAGES.sym = math.max(1, math.min(5, (DL_PAGES.sym or 1) + ((b == "SYM+") and 1 or -1)))
			M.toast = string.format("SYM %d  %s", DL_PAGES.sym, ({"FULL", "GROUP", "ALT", "CLEAN", "MIN"})[DL_PAGES.sym])
			M.brt_t = C.t or 0
		end
		return true
	end
	-- v1.7.4 SNAKE (dl_snake.lua, page 16): every button is the game's;
	-- CLR back to where it was opened, MENU to the MENU
	if mode == 16 then
		local go = "back"
		if DL_SNAKE then go = DL_SNAKE.key(b, C.t) end
		if go == "back" then DL_PAGES.mode = M.snake_from or 0
		elseif go == "menu" then M.last_mode = M.snake_from; DL_PAGES.mode = 0 end
		return true
	end
	-- keypad
	if b:sub(1, 1) == "K" or b == "CLR" or b == "ENT" then
		-- S N A K E typed as on a button phone (7777 66 2 55 33) opens SNAKE
		if DL_SNAKE then
			if b:sub(1, 1) ~= "K" then DL_SNAKE.forget()
			elseif DL_SNAKE.digit(b:sub(2)) then
				M.entry, M.buf, M.entry_for = nil, "", nil
				M.snake_from = mode
				DL_PAGES.mode = 16
				DL_SNAKE.new(C.t)
				M.dbg("SNAKE opened")
				return true
			end
		end
		if not M.entry then return false end
		if b == "CLR" then
			if M.buf == "" then M.entry = nil else M.buf = M.buf:sub(1, -2) end
		elseif b == "ENT" then
			DL_PAGES.apply_entry()
		elseif #M.buf < (({BNG = 4, TOT = 6, LL = 13, MGRS = 10})[M.entry] or 3) then
			M.buf = M.buf .. b:sub(2)
			local full = ({TOT = 6, LL = 13, MGRS = 10})[M.entry]
			if (#M.buf == 3 and not full and M.entry ~= "TCN" and M.entry ~= "BNG") or (full and #M.buf == full) then
				DL_PAGES.apply_entry()
			end
		end
		return true
	end
	-- MFD-8: to the MENU; on the MENU, back to the page you came from
	if b == "M8" then
		M.entry = nil
		if mode ~= 0 then M.last_mode = mode; DL_PAGES.mode = 0
		elseif M.last_mode then DL_PAGES.mode = M.last_mode end
		return true
	end
	-- the cartridge list of the PLAN page (left 1 LOAD)
	local function open_dtc()
		M.plan_view = 1
		M.dtc_opts = C.dtc_opts()
		M.dtc_page = math.floor(((C.dtc_sel() or 1) - 1) / 5) + 1
	end
	if mode == 0 then
		-- left: SA, NAV (route, TOT, cartridges), HSI, COM/NAV   right: FPAS, SMS, FLT, RWR
		local go = {M1 = 1, M2 = 12, M3 = 8, M4 = 5, R1 = 4, R2 = 11, R3 = 9, R4 = 10}
		if CFG.opt_rwr == false then go.R4 = nil end
		if go[b] then
			DL_PAGES.mode = go[b]
			if go[b] == 12 then M.plan_view = 0 end
		end
		return true
	elseif mode == 6 then
		if M.plan_view == 0 then
			local nw = #route_pts(C)
			if b == "M1" then open_dtc()
			elseif b == "M2" and nw > 0 then
				-- TOT for the TOT point (default: the selected steerpoint)
				M.tot_pt = math.min(M.tot_pt or M.act_i or 1, nw)
				start_entry("TOT")
			elseif b == "M3" and nw > 0 then
				-- PT: move the cursor to the next steerpoint
				M.tot_pt = ((M.tot_pt or M.act_i or 1) % nw) + 1
			elseif b == "M4" then
				-- CLR: remove the TOT of the point under the cursor
				M.entry = nil
				if M.tot_pt then M.tots[M.tot_pt] = nil end
			end
			return true
		end
		local opts = M.dtc_opts or C.dtc_opts()
		M.dtc_opts = opts
		local pages = math.max(1, math.ceil(#opts / 5))
		if b == "B1" then M.dtc_page = math.max(1, M.dtc_page - 1)
		elseif b == "B2" then M.dtc_page = math.min(pages, M.dtc_page + 1)
		elseif b == "M1" then M.plan_view = 0
		elseif b == "M2" then M.dtc_opts = C.dtc_opts()
		elseif b:match("^R%d$") then
			local i = (M.dtc_page - 1) * 5 + tonumber(b:sub(2))
			-- (a LOAD reads the cartridge's .geo.txt again: it may have been edited)
			if opts[i] then C.dtc_load(i); M.plan_view = 0; if DL_GEO and DL_GEO.reload then DL_GEO.reload() end end
		end
		-- the cartridge list was opened from the NAV page: back there
		if M.plan_view == 0 then DL_PAGES.mode = 12 end
		return true
	elseif mode == 9 then
		if CFG.opt_datalink == false then return true end
		if M.flt_view == 0 then
			if b == "M1" then M.flt_view, M.flt_page = 1, 1
			elseif b == "M2" and M.flight[M.flt_sel] then
				table.remove(M.flight, M.flt_sel); save_flight()
				M.flt_sel = math.max(1, math.min(M.flt_sel, #M.flight))
			elseif b:match("^R%d$") then
				local k = tonumber(b:sub(2))
				if M.flight[k] then M.flt_sel = k end
			end
		else
			local list = M.flt_list or {}
			local pages = math.max(1, math.ceil(#list / 5))
			if b == "M1" then M.flt_view = 0
			elseif b == "B1" then M.flt_page = math.max(1, M.flt_page - 1)
			elseif b == "B2" then M.flt_page = math.min(pages, M.flt_page + 1)
			elseif b:match("^R%d$") then
				local a = list[(M.flt_page - 1) * 5 + tonumber(b:sub(2))]
				if a then
					local i = in_flight(a)
					if i then table.remove(M.flight, i)
					elseif #M.flight < 5 then M.flight[#M.flight + 1] = key_of(a) end
					save_flight()
				end
			end
		end
		return true
	elseif mode == 4 then
		-- FPAS: M1 bingo (typed on the UFCP keypad, kg), M2 next home field
		if b == "M1" then start_entry("BNG")
		elseif b == "M2" then M.home_i = M.home_i + 1 end
		return true
	elseif mode == 5 then
		-- COM / NAV is read-only: the MiG-29 keeps its preset frequencies
		-- (tested: set_frequency on device 51 is ignored), presets come from DTC / mission
		return true
	elseif mode == 12 then
		-- NAV  left: PREV / NEXT steerpoint, AUTO / MAN sequencing, DIR (direct-to)
		--      right: LOAD cartridge, TOT (keypad), PT (TOT point), CLR (its TOT)
		local nav = C.nav
		local nw = #route_pts(C)
		if b == "M1" and C.stp_step then C.stp_step(-1)
		elseif b == "M2" and C.stp_step then C.stp_step(1)
		elseif b == "M3" and nav then nav.auto = (nav.auto == false)
		elseif b == "M4" and nav and nav.act then nav.direct(C.ox, C.oz)
		elseif b == "R1" then DL_PAGES.mode = 6; open_dtc()
		elseif b == "M5" and nav and nav.base then
			-- RTE: pick the route points to fly (starts from the route in use)
			M.rte_sel = {}
			for _, i in ipairs((nav.rte_for == nav.base.name and nav.rte) or {}) do M.rte_sel[#M.rte_sel + 1] = i end
			M.rte_page = 1
			M.entry = nil
			DL_PAGES.mode = 13
		elseif b == "R2" and nw > 0 then
			M.nav_view = 0
			M.tot_pt = math.min(M.tot_pt or M.act_i or 1, nw)
			start_entry("TOT")
		elseif b == "R5" then
			M.nav_view = (M.nav_view == 1) and 0 or 1
		elseif b == "B1" then
			-- ADD: lat / long entry, again = MGRS entry, again = cancel
			coord_entry("NAV")
		elseif b == "B2" and nav then
			-- DEL: the active steerpoint (v1.7.2: any route point, from the
			-- working route only - the cartridge file is not changed)
			local before = snapshot(C)
			local i = nav.del_user and nav.del_user()
			if i then
				follow_points(C, before)
				M.nav_msg, M.nav_msg_t = "WAYPOINT DELETED", C.t or 0
			else
				M.nav_msg, M.nav_msg_t = "DEL: SELECT A ROUTE STEERPOINT", C.t or 0
			end
		elseif b == "B4" and nav and nav.get_work and nav.get_work() then
			-- EDIT: the route editor, on the active steerpoint
			M.entry, M.buf, M.entry_for = nil, "", nil
			local L = nav.wp_list()
			local i = (nav.src == "stp" and nav.stp_i and nav.stp_i <= #L) and nav.stp_i or 1
			M.ed_i, M.ed_w = i, L[i]
			DL_PAGES.mode = 15
		elseif b == "R3" and nw > 0 then
			M.tot_pt = ((M.tot_pt or M.act_i or 1) % nw) + 1
			M.tot_t = C.t
		elseif b == "R4" then
			M.entry = nil
			if M.tot_pt then M.tots[M.tot_pt] = nil end
		end
		return true
	elseif mode == 15 then
		-- EDIT (route editor): its own cursor, the active steerpoint stays.
		--   right 1-5: put the cursor on that point; bottom 1 / 2: PREV /
		--   NEXT page; left 1 MV UP / 2 MV DN: move the point one place;
		--   left 3 POS: new position (lat/long, again MGRS, again cancel);
		--   left 4 ADD: a new point after the cursor (same entry); left 5
		--   DONE (back to NAV); bottom 4 DEL (press twice); bottom 5 STP:
		--   fly to the point under the cursor
		local nav = C.nav
		if not (nav and nav.get_work and nav.get_work()) then
			if b == "M5" then DL_PAGES.mode = 12 end
			return true
		end
		local L = nav.wp_list()
		local n = #L
		if M.ed_w and L[M.ed_i] ~= M.ed_w then
			for k, w in ipairs(L) do if w == M.ed_w then M.ed_i = k; break end end
		end
		M.ed_i = math.max(1, math.min(M.ed_i or 1, n))
		local i = M.ed_i
		local first = math.floor((i - 1) / 5) * 5
		if b ~= "B4" then M.ed_del = nil end
		if b:match("^R%d$") then
			local k = first + tonumber(b:sub(2))
			if L[k] then M.ed_i = k end
		elseif b == "B1" or b == "B2" then
			-- PREV / NEXT page: the cursor goes to the same row there
			local pages = math.max(1, math.ceil(n / 5))
			local pg = math.floor((i - 1) / 5) + 1
			pg = (b == "B1") and math.max(1, pg - 1) or math.min(pages, pg + 1)
			M.ed_i = math.max(1, math.min((pg - 1) * 5 + (i - 1) % 5 + 1, math.max(n, 1)))
		elseif (b == "M1" or b == "M2") and L[i] then
			local before = snapshot(C)
			local j = nav.wp_move(i, (b == "M1") and -1 or 1)
			if j then follow_points(C, before); M.ed_i = j end
		elseif b == "M3" and L[i] then coord_entry("POS")
		elseif b == "M4" then coord_entry("EDADD")
		elseif b == "M5" then
			M.entry, M.buf, M.entry_for = nil, "", nil
			DL_PAGES.mode = 12
		elseif b == "B4" and L[i] then
			if M.ed_del and M.ed_del.w == L[i] and (C.t or 0) - M.ed_del.t < 3 then
				local before = snapshot(C)
				if nav.wp_delete(i) then
					follow_points(C, before)
					M.nav_msg, M.nav_msg_t = "WAYPOINT DELETED", C.t or 0
				end
				M.ed_del = nil
			else
				M.ed_del = {w = L[i], t = C.t or 0}
				M.nav_msg, M.nav_msg_t = "DEL AGAIN TO DELETE " .. ascii(L[i].lbl), C.t or 0
			end
		elseif b == "B5" and L[i] then
			nav.src, nav.stp_i, nav.dir_i, nav.leg_key = "stp", i, nil, nil
			M.nav_msg, M.nav_msg_t = "STEERPOINT " .. ascii(L[i].lbl), C.t or 0
			DL_PAGES.dirty = true
		end
		M.ed_w = L[M.ed_i]
		return true
	elseif mode == 14 then
		-- PICTURE: right 1-5 pick a group, left 2 CALL BULL / BRAA, 4 INTC on
		-- the group (back to SA), 5 SA with the cursor on it; bottom 1 / 2 plot
		-- range +/-, 4 AUTO range, 5 SHOW hostile / friendly / all
		if b:match("^R%d$") then
			local g = M.pic_groups and M.pic_groups[tonumber(b:sub(2))]
			if g then M.pic_sel = tonumber(b:sub(2)); M.pic_sel_pos = {g.x, g.z} end
		elseif b == "B1" or b == "B2" then
			local steps = {25, 50, 100, 200, 400}
			local cur = M.pic_scale or M.pic_auto_scale or 100
			local i = 3
			for k2, v in ipairs(steps) do if v == cur then i = k2 end end
			i = math.max(1, math.min(#steps, i + ((b == "B1") and 1 or -1)))
			M.pic_scale = steps[i]
		elseif b == "B4" then M.pic_scale = nil
		elseif b == "B5" then M.pic_show = ({HOSTILE = "FRIENDLY", FRIENDLY = "ALL", ALL = "HOSTILE"})[M.pic_show or "HOSTILE"]
		elseif b == "M2" then M.pic_call = (M.pic_call == "BRAA") and "BULL" or "BRAA"
		elseif b == "M4" or b == "M5" then
			local g = M.pic_groups and M.pic_groups[M.pic_sel or 0]
			if g and C.cursor_to then C.cursor_to(g.x, g.z) end
			-- (only on a contact of the group's side: not on a friendly next to a hostile group)
			if g and b == "M4" and DL_TAC then DL_TAC.intc_start(C.contacts, C.t or 0, g.x, g.z, g.n, g.friend and "F" or "H") end
			DL_PAGES.mode = 1
		end
		return true
	elseif mode == 13 then
		-- RTE  right 1-5: add / remove that point (the route is flown in the
		--      order the points were picked); left 1-4: flight member n
		--      (points tagged n, plus untagged ones); left 5 DONE
		--      bottom: 1 PREV / 2 NEXT page, 4 CLR, 5 ALL (whole route)
		local nav = C.nav
		local base = nav and nav.base
		local nrt = (base and base.nrt) or 0
		local pages = math.max(1, math.ceil(nrt / 5))
		local function find(i) for k, v in ipairs(M.rte_sel) do if v == i then return k end end end
		if b:match("^R%d$") then
			local i = (M.rte_page - 1) * 5 + tonumber(b:sub(2))
			if i <= nrt then
				local k = find(i)
				if k then table.remove(M.rte_sel, k) else M.rte_sel[#M.rte_sel + 1] = i end
			end
		elseif b == "B1" then M.rte_page = math.max(1, M.rte_page - 1)
		elseif b == "B2" then M.rte_page = math.min(pages, M.rte_page + 1)
		elseif b == "B4" then M.rte_sel = {}
		elseif b == "B5" then
			if nav then nav.set_rte(DL_PLAN.all_order(base)) end
			DL_PAGES.mode = 12
		elseif b:match("^M[1-4]$") and base then
			local m = DL_PLAN.members(base)[tonumber(b:sub(2))]
			if m then
				M.rte_sel = {}
				for i = 1, nrt do
					local t = base.pts[i].tags
					if not t or t[m] then M.rte_sel[#M.rte_sel + 1] = i end
				end
			end
		elseif b == "M5" then
			if nav then nav.set_rte((#M.rte_sel > 0) and M.rte_sel or DL_PLAN.all_order(base)) end
			DL_PAGES.mode = 12
		end
		return true
	elseif mode == 8 then
		if b == "M1" then start_entry("HDG")
		elseif b == "M2" then start_entry("CRS")
		elseif b == "M3" then start_entry("TCN")
		elseif b == "M4" and M.stp_brg then M.crs = M.stp_brg
		elseif b == "M5" then M.hdg_bug = math.floor(math.deg(fin(C.hdg) and C.hdg or 0) + 0.5) % 360
		elseif b == "R1" then M.tcn = nil; if M.entry == "TCN" then M.entry, M.buf = nil, "" end end
		return true
	end
	return mode ~= 1
end

-----------------------------------------------------------------------
-- per-frame values
-----------------------------------------------------------------------
local function upd_menu(C)
	local sd = C.sd
	local fuel = sd and sd.getTotalFuelWeight and tonumber(sd.getTotalFuelWeight()) or 0
	if not fin(fuel) then fuel = 0 end
	T(H.MENU_STAT, string.format("FUEL %dKG   %s", math.floor(fuel + 0.5), C.dl_status or "--"))
end

local function upd_dtc(C)
	local opts = M.dtc_opts or C.dtc_opts()
	M.dtc_opts = opts
	local pages = math.max(1, math.ceil(#opts / 5))
	if M.dtc_page > pages then M.dtc_page = pages end
	-- the theatre as DCS names it (the .dtc files use that id too)
	local th = C.theatre
	if type(DL_theatre_id) == "function" then th = DL_theatre_id(th) end
	T(H.DTC_TITLE, "DATA CARTRIDGE  MAP " .. up(th or "?"))
	T(H.DTC_PAGE, string.format("PG %d/%d", M.dtc_page, pages))
	local cur = C.dtc_sel()
	for k = 1, 5 do
		local i = (M.dtc_page - 1) * 5 + k
		local o = opts[i]
		if o then
			local nm = ascii((type(o) == "table") and o.name or o)
			if nm == "MSN" then nm = "MSN (MISSION)" elseif nm == "OFF" then nm = "OFF (NO PLAN)" end
			T(H.dtc[k].txt, nm)
			H.dtc[k].mark:set((i == cur) and 2 or 1)
		else
			T(H.dtc[k].txt, "")
			H.dtc[k].mark:set(0)
		end
	end
	local p = C.plan
	local lines = {"LOADED: " .. ascii(p and p.name or "--")}
	if p then
		local nr = 0; for _ in pairs(p.radio or {}) do nr = nr + 1 end
		lines[#lines + 1] = string.format("WPT %d  AD %d  RADIO %d  RSBN %d  ADF %d",
			#(p.wps or {}), #(p.ads or {}), nr, #(p.rsbn or {}), #(p.adf or {}))
	end
	lines[#lines + 1] = C.route_on and "FLIGHT PLAN SHOWN ON SA PAGE" or "FLIGHT PLAN HIDDEN ON SA PAGE"
	for i = 1, 6 do T(H.dtcd[i], lines[i] or "") end
end

-----------------------------------------------------------------------
-- fuel flow measured from the fuel quantity (works whatever units the
-- sim reports engine consumption in); sampled on every page
-----------------------------------------------------------------------
local FS = {}
local function sample_fuel(C)
	local sd = C.sd
	if not sd then return end
	local ok, fuel = pcall(sd.getTotalFuelWeight)
	fuel = ok and tonumber(fuel) or nil
	local t = C.t or 0
	if not fin(fuel) then return end
	local last = FS[#FS]
	if last and (fuel > last.f + 5 or last.f - fuel > 40 * math.max(1, t - last.t)) then FS = {} last = nil end   -- refuelled / tanks dropped
	if not last or t - last.t >= 1 then FS[#FS + 1] = {t = t, f = fuel} end
	while #FS > 2 and FS[#FS].t - FS[1].t > (CFG.fuel_flow_window_s or 20) do table.remove(FS, 1) end
end
local function measured_flow()             -- kg/h, nil until there are a few seconds of data
	local a, b = FS[1], FS[#FS]
	if not a or not b or b.t - a.t < 4 then return nil end
	return math.max(0, (a.f - b.f) / (b.t - a.t) * 3600)
end

-- engine values: export (LoGetEngineInfo) first, then the cockpit's sensor data
local function engines(C)
	local sd = C.sd or {}
	local e = C.feed.e or {}
	local function g(f) if not f then return 0 end local ok, v = pcall(f); v = ok and tonumber(v); return fin(v) and v or 0 end
	local function pct(v) v = v or 0; if v > 0 and v <= 1.5 then v = v * 100 end return v end
	local L = {rpm = pct((e.rpm_l or 0) > 0 and e.rpm_l or g(sd.getEngineLeftRPM)),
	           egt = (e.t_l or 0) > 0 and e.t_l or g(sd.getEngineLeftTemperatureBeforeTurbine),
	           ffr = (e.ff_l or 0) > 0 and e.ff_l or g(sd.getEngineLeftFuelConsumption)}
	local R = {rpm = pct((e.rpm_r or 0) > 0 and e.rpm_r or g(sd.getEngineRightRPM)),
	           egt = (e.t_r or 0) > 0 and e.t_r or g(sd.getEngineRightTemperatureBeforeTurbine),
	           ffr = (e.ff_r or 0) > 0 and e.ff_r or g(sd.getEngineRightFuelConsumption)}
	-- fuel flow: the measured total, split by the engines' own figures
	local tot = measured_flow()
	local raw = L.ffr + R.ffr
	if tot then
		if raw > 0 then L.ff, R.ff = tot * L.ffr / raw, tot * R.ffr / raw
		elseif L.rpm + R.rpm > 0 then L.ff, R.ff = tot * L.rpm / (L.rpm + R.rpm), tot * R.rpm / (L.rpm + R.rpm)
		else L.ff, R.ff = tot / 2, tot / 2 end
	elseif raw > 0 then
		local k = (raw < 20) and 3600 or 1             -- kg/s -> kg/h
		L.ff, R.ff, tot = L.ffr * k, R.ffr * k, raw * k
	end
	return L, R, tot
end

-- rough MiG-29A cruise figures (estimates, not from the flight manual)
local function best_figures(alt_m)
	local a = math.max(0, math.min(alt_m / 1000, 12))
	local sr = 0.12 + 0.022 * math.min(a, 11)            -- km per kg at best-range speed
	local mach = (a > 8) and 0.80 or (0.62 + 0.0225 * a)
	return sr, mach
end

local function upd_fuel(C)
	local sd = C.sd
	if not sd then return end
	-- (values that are not real numbers count as 0: nothing prints "nan")
	local function g(f) local ok, v = pcall(f); v = ok and tonumber(v); return fin(v) and v or 0 end
	local q = C.feed.q or {}
	local fext = fin(q.fext) and q.fext or 0
	local fint = fin(q.fint) and q.fint or nil
	local fuel = g(sd.getTotalFuelWeight)
	local _, _, ff = engines(C)
	local measuring = not ff
	ff = ff or 0
	local tas = g(sd.getTrueAirSpeed)                    -- m/s
	if tas < 1 and fin(q.mach) and q.mach > 0 then         -- from Mach when the sim gives no TAS
		tas = q.mach * math.max(295, 340.3 - 0.0039 * (C.alt or 0))
	end
	local res = CFG.fuel_reserve_kg or 500
	local unit_m, ul = C.unit_m, C.unit_lbl
	T(H.FUEL_TOT, string.format("%d KG", math.floor(fuel + 0.5)))
	if fint and fint > 0 and fint <= 1.5 then            -- the sim gives tank fractions
		T(H.FUEL_INT, string.format("INT %d%%  EXT %d%%", math.floor(fint * 100 + 0.5), math.floor(fext * 100 + 0.5)))
	elseif fint and fint > 1.5 then
		T(H.FUEL_INT, string.format("INT %d  EXT %d KG", math.floor(fint + 0.5), math.floor(fext + 0.5)))
	else
		T(H.FUEL_INT, "INT -- EXT --")
	end
	T(H.FUEL_FLOW, measuring and "FLOW MEASURING..." or string.format("FLOW %d KG/H", math.floor(ff + 0.5)))
	local usable = math.max(0, fuel - res)
	local secs = (ff > 50) and usable / ff * 3600 or nil
	T(H.FUEL_TO, string.format("TO %d KG  %s", res, mmss(secs)))
	T(H.FUEL_TO_RNG, secs and string.format("RANGE %d %s", math.floor(tas * secs / unit_m + 0.5), ul) or "RANGE --")
	T(H.FUEL_SR, (ff > 50) and string.format("NOW %.2f %s/KG", (tas * 3.6) / ff * (1000 / unit_m), ul) or "NOW --")
	local alt = C.alt or 0
	local sr_here, m_here = best_figures(alt)
	local sr_opt, m_opt = best_figures(11000)
	T(H.FUEL_B1, string.format("THIS ALT  M%.2f  %d %s", m_here, math.floor(usable * sr_here * 1000 / unit_m + 0.5), ul))
	T(H.FUEL_B2, string.format("OPT 11KM  M%.2f  %d %s", m_opt, math.floor(usable * sr_opt * 1000 / unit_m + 0.5), ul))
	local end_ff = CFG.endurance_flow_kgh or 1900
	T(H.FUEL_B3, string.format("ENDURANCE M0.55 6-8KM  %s", mmss(usable / end_ff * 3600)))
	T(H.FUEL_B4, string.format("THROTTLE ~%d%% RPM BEST RANGE", (alt > 8000) and 86 or 82))
	T(H.FUEL_RES, string.format("RESERVE %d KG   ESTIMATES", res))
	-- engines (RPM from the export, EGT from the cockpit sensors)
	local EL, ER = engines(C)
	T(H.FUEL_ENG, string.format("RPM %d / %d %%", math.floor(EL.rpm + 0.5), math.floor(ER.rpm + 0.5)))
	T(H.FUEL_EGT, string.format("EGT %d / %d C", math.floor(EL.egt + 0.5), math.floor(ER.egt + 0.5)))
	local egt_warn = CFG.egt_warn or 900
	H.egt_w:set((EL.egt > egt_warn or ER.egt > egt_warn) and 1 or 0)
	-- bingo and the fuel needed to get home (at this altitude's best range)
	T(H.FUEL_BNG, (M.entry == "BNG") and ("BINGO " .. M.buf .. "_ KG  (ENT)") or (M.bingo or 0) > 0 and string.format("BINGO %d KG%s", M.bingo, (fuel < M.bingo) and "  REACHED" or "") or "BINGO OFF")
	H.bingo_warn:set(((M.bingo or 0) > 0 and fuel < M.bingo) and 1 or 0)
	local h = DL_PAGES.home(C)
	if h then
		local b, d = bra(C.ox, C.oz, h.x, h.z, unit_m)
		local nm = up(h.name):sub(1, 12)
		if nm == ascii(h.lbl) then nm = "" end
		T(H.FUEL_HOME, string.format("HOME %s %s  %03d/%d%s", ascii(h.lbl), nm, b, math.floor(d + 0.5), ul))
		local need = math.floor((d * unit_m / 1000) / sr_here + (CFG.home_approach_kg or 150) + 0.5)
		T(H.FUEL_NEED, string.format("TO HOME ~%d KG  (+%d RES)", need, res))
		local arr = math.floor(fuel - need + 0.5)
		T(H.FUEL_HARR, string.format("ARRIVE WITH %d KG", arr))
		M.home_short = arr < res
	else
		T(H.FUEL_HOME, "HOME --  (NO AIRFIELD / MARK)")
		T(H.FUEL_NEED, ""); T(H.FUEL_HARR, "")
		M.home_short = false
	end
end

-- home field for FPAS: the plan's airfields, then markpoints (M2 cycles)
function DL_PAGES.home(C)
	local opts = {}
	for _, a in ipairs(C.plan and C.plan.ads or {}) do opts[#opts + 1] = a end
	for j = 1, 5 do if DL_PAGES.marks[j] then opts[#opts + 1] = DL_PAGES.marks[j] end end
	if #opts == 0 then return nil end
	if M.home_i > #opts then M.home_i = 1 end
	return opts[M.home_i]
end

-- bingo: short alert when the fuel drops below it (all pages, and UFCP)
local function check_bingo(C)
	local sd = C.sd
	if not sd or (M.bingo or 0) <= 0 then H.bingo_show:set(0); return end
	local ok, fuel = pcall(sd.getTotalFuelWeight)
	fuel = ok and tonumber(fuel) or nil
	if not fin(fuel) then return end
	local t = C.t or 0
	if fuel < M.bingo and M.bingo_armed then M.bingo_armed = false; M.bingo_t = t; M.dbg("BINGO at " .. math.floor(fuel) .. " kg") end
	if fuel > M.bingo + 100 then M.bingo_armed = true end
	local on = (t - M.bingo_t) < (CFG.bingo_alert_s or 8)
	H.bingo_show:set(on and 1 or 0)
	T(H.BINGO_TXT, string.format("BINGO FUEL  %d KG", math.floor(fuel + 0.5)))
end

-----------------------------------------------------------------------
-- RWR (SPO picture from the export, LoGetTWSInfo)
-----------------------------------------------------------------------
local RWR_NAMES = {   -- {pattern in lower case, symbol}
	{"tornado", "TO"}, {"tor", "15"}, {"9a331", "15"}, {"s%-125", "3"},
	{"s%-300", "10"}, {"40b6", "10"}, {"64h6", "BB"}, {"buk", "11"}, {"9a310", "11"}, {"9s18", "SD"},
	{"kub", "6"}, {"1s91", "6"}, {"osa", "8"}, {"9a33", "8"},
	{"tunguska", "19"}, {"2s6", "19"}, {"strela", "13"}, {"snr", "2"}, {"p%-19", "FF"},
	{"5n62", "5"}, {"s%-200", "5"}, {"zsu", "A"}, {"shilka", "A"}, {"gepard", "A"},
	{"hawk", "HK"}, {"patriot", "PT"}, {"nasams", "NS"}, {"roland", "RO"}, {"rapier", "RA"}, {"hq%-7", "HQ"},
	{"1l13", "EW"}, {"55g6", "EW"}, {"fps%-117", "EW"}, {"ewr", "EW"}, {"dog ear", "DE"},
	{"a%-50", "50"}, {"e%-3", "E3"}, {"e%-2", "E2"}, {"mirage", "M2"}, {"rafale", "RF"}, {"typhoon", "EF"},
	{"gripen", "39"}, {"harrier", "AV"}, {"av8", "AV"},
}
local function rwr_sym(e)
	local n = string.lower(ascii(e.name))
	if e.l1 == 4 then return "M" end
	local sa = n:match("sa%-(%d+)")
	if sa then return sa end
	for _, r in ipairs(RWR_NAMES) do if n:find(r[1]) then return r[2] end end
	local d = n:match("%-(%d%d)") or n:match("(%d%d)")
	if d then return d end
	if e.l1 == 3 then return "SH" end
	if e.l1 == 2 then return "U" end
	return "U"
end
local RWR_STATE = {"SCAN", "TRACK", "LOCK", "LAUNCH"}
-- SPO-15 (full-fidelity MiG-29): lamps -> the main threat and the other sectors
--   sectors: L70 L50 L30 L10 R10 R30 R50 R70, then the two rear sectors
local SPO_AZ = {-70, -50, -30, -10, 10, 30, 50, 70, 150, -150}
local SPO_TYPES = {"P", "Z", "H", "N", "F", "S"}
local function spo_state(C)
	local s = C.feed.spo
	if not s or ((C.t or 0) - (C.feed.spo_t or -100)) > 2 then return nil end
	return s
end
local function lit(bits) local t = {} for k = 1, #bits do if bits:sub(k, k) == "1" then t[#t + 1] = k end end return t end
local function sector_az(idx)
	-- one or two neighbouring lamps: the middle of them
	if #idx == 0 then return nil end
	if CFG.rwr_swap_rear then for k, i in ipairs(idx) do if i == 9 then idx[k] = 10 elseif i == 10 then idx[k] = 9 end end end
	local sx, sy = 0, 0
	for _, i in ipairs(idx) do local a = math.rad(SPO_AZ[i]); sx = sx + math.sin(a); sy = sy + math.cos(a) end
	return math.atan2(sx, sy)
end
local function spo_emitters(s)
	local out = {}
	if not s.on then return out end
	local mt = lit(s.mtyp)
	local msym = mt[1] and SPO_TYPES[mt[1]] or "U"
	local maz = sector_az(lit(s.msec))
	if maz then
		out[#out + 1] = {az = maz, pw = (s.pl or 0) / 15, st = s.launch and 4 or (s.lock and 3 or 2), sym = msym, name = "MAIN"}
	end
	-- other sectors: every lit lamp not next to the main threat's
	local types = {}
	for _, k in ipairs(lit(s.typ)) do if SPO_TYPES[k] ~= msym then types[#types + 1] = SPO_TYPES[k] end end
	local osym = (#types == 1) and types[1] or "?"
	for _, i in ipairs(lit(s.sec)) do
		local a = math.rad(SPO_AZ[(CFG.rwr_swap_rear and (i == 9 and 10 or (i == 10 and 9 or i))) or i])
		local near = maz and math.abs(math.atan2(math.sin(a - maz), math.cos(a - maz))) < math.rad(25)
		if not near then out[#out + 1] = {az = a, pw = 0, st = 1, sym = osym, name = "OTHER"} end
	end
	return out
end
local function rwr_list(C)
	local s = spo_state(C)
	if s then return spo_emitters(s) end
	local r = C.feed.rwr
	if not r or ((C.t or 0) - (C.feed.rwr_t or -100)) > 2 then return {} end
	return r
end
local function deg_txt(az)
	local deg = (math.floor(math.deg(az) + 0.5) + 360) % 360
	return (deg == 0) and "NOSE" or ((deg <= 180) and string.format("R%03d", deg) or string.format("L%03d", 360 - deg))
end
local function check_launch(C)
	local launch = false
	if CFG.opt_rwr ~= false and CFG.opt_launch ~= false then
		for _, e in ipairs(rwr_list(C)) do if e.st == 4 then launch = true end end
	end
	local t = C.t or 0
	H.launch:set((launch and (math.floor(t * 4) % 2 == 0)) and 1 or 0)
	M.launch = launch
end
local function upd_rwr(C)
	local list = {}
	local no_launch = CFG.opt_launch == false            -- launches shown as a plain lock
	for _, e in ipairs(rwr_list(C)) do
		if no_launch and e.st == 4 then e = {az = e.az, pw = e.pw, st = 3, l1 = e.l1, name = e.name, sym = e.sym} end
		if fin(e.az) then list[#list + 1] = e end          -- (an azimuth that is not a number cannot be drawn)
	end
	-- most dangerous first: launch, lock, track, scan, then strongest
	table.sort(list, function(a, b) if a.st ~= b.st then return a.st > b.st end return a.pw > b.pw end)
	local R = CFG.rwr_radius or 0.68
	-- rwr_azimuth_sign mirrors the export's emitter azimuths (LoGetTWSInfo).
	-- The SPO-15 lamps already say left / right: no sign there (v1.7.1 mirrored
	-- the SPO symbols but not the SPO text)
	local spo = spo_state(C)
	local sign = spo and 1 or (CFG.rwr_azimuth_sign or 1)
	local blink = math.floor((C.t or 0) * 4) % 2 == 0
	for i = 1, 12 do
		local e = list[i]
		local h = H.rw[i]
		if e then
			local pw = math.max(0, math.min(1, e.pw or 0))
			local r = R * (0.25 + 0.70 * (1 - pw))         -- stronger = closer to the centre
			h.x:set(sign * r * math.sin(e.az)); h.y:set(r * math.cos(e.az))
			h.s:set((e.st == 4 and not blink) and 3 or e.st)
			local sym = e.sym or rwr_sym(e)
			local num = tonumber(sym)
			if num then h.n:set(num); h.k:set(1) else T(h.t, sym); h.k:set(0) end
		else
			h.s:set(0)
		end
	end
	if spo then
		local L, CC = {}, {}
		local function add(t, c) L[#L + 1] = t; CC[#L] = c or 0 end
		if not spo.on then add("SPO-15 OFF", 0)
		else
			local m = list[1] and list[1].name == "MAIN" and list[1] or nil
			if m then
				local st = (m.st == 4 and "LAUNCH") or (m.st == 3 and "LOCK") or ""
				add(string.format("MAIN  %s  %s  PWR %d/15  %s", m.sym, deg_txt(m.az), spo.pl or 0, st), m.st >= 3 and 2 or 1)
			end
			local ty = {}
			for _, k in ipairs(lit(spo.typ)) do ty[#ty + 1] = SPO_TYPES[k] end
			if #ty > 0 then add("TYPES " .. table.concat(ty, " "), 0) end
			local oth = {}
			for _, e in ipairs(list) do if e.name == "OTHER" then oth[#oth + 1] = deg_txt(e.az) end end
			if #oth > 0 then add("OTHER " .. table.concat(oth, " "), 0) end
			if spo.above then add("MAIN THREAT ABOVE", 0) elseif spo.below then add("MAIN THREAT BELOW", 0) end
		end
		for i = 1, 6 do T(H.rwl[i].txt, L[i] or ""); H.rwl[i].c:set(CC[i] or 0) end
		local n = #list
		T(H.RWR_STAT, (not spo.on) and "SPO-15 OFF" or ((n > 0) and string.format("SPO-15  %d SECTOR%s", n, n > 1 and "S" or "") or "CLEAR"))
		local sn = C.feed.snares
		T(H.RWR_CM, sn and string.format("CHF %d  FLR %d", sn.chaff or 0, sn.flare or 0) or "CHF --  FLR --")
		return
	end
	for i = 1, 6 do
		local e = list[i]
		if e then
			local deg = (math.floor(math.deg(e.az * sign) + 0.5) + 360) % 360
			local side = (deg == 0) and "NOSE" or ((deg <= 180) and string.format("R%03d", deg) or string.format("L%03d", 360 - deg))
			T(H.rwl[i].txt, string.format("%-3s %-6s %s  %s", rwr_sym(e), RWR_STATE[e.st] or "?", side,
				up(e.name):sub(1, 12)))
			H.rwl[i].c:set(e.st >= 3 and 2 or (e.st == 2 and 1 or 0))
		else
			T(H.rwl[i].txt, ""); H.rwl[i].c:set(0)
		end
	end
	T(H.RWR_STAT, (#list > 0) and string.format("%d EMITTER%s", #list, #list > 1 and "S" or "") or "CLEAR")
	local sn = C.feed.snares
	T(H.RWR_CM, sn and string.format("CHF %d  FLR %d", sn.chaff or 0, sn.flare or 0) or "CHF --  FLR --")
end

-----------------------------------------------------------------------
-- SMS: what is on each station (LoGetPayloadInfo)
-----------------------------------------------------------------------
-- v1.7.6: which shape the STORES page draws for a store (dl_pages.lua):
-- 1 small AAM, 2 R-27, 3 fuel tank, 4 bomb / dispenser, 5 rocket pod, 6 other
local function store_kind(nm)
	if nm:match("^PTB") or nm:find("FUEL") then return 3 end
	if nm:match("^R%-27") then return 2 end
	if nm:match("^R%-%d") then return 1 end
	if nm:match("^B%-8") or nm:match("^UB%-") or nm:match("^S%-%d") or nm:find("ROCKET") then return 5 end
	for _, b in ipairs({"FAB", "RBK", "BETAB", "ODAB", "KAB", "ZAB", "SAB", "KMGU", "BOMB", "MBD"}) do
		if nm:find(b, 1, true) then return 4 end
	end
	return 6
end
-- short name under the station: "R-27ER", "PTB-1500", "B-8M1", "FAB-500"
local function store_short(nm, k)
	local tank = nm:match("^PTB[_%-]?(%d+)")
	if tank then return "PTB-" .. tank end
	nm = nm:gsub(" %(.-%)", "")
	-- type and model, without the version after it: FAB-500M-62 -> FAB-500M
	nm = (nm:match("^(%a+%-%d+%a*%d*)") or nm:match("^(%S+)") or nm):sub(1, 9)
	if not nm:find("%a") then nm = "ST" .. k .. " " .. nm end   -- never a bare number (DCS)
	return nm
end
local function upd_sms(C)
	local st = C.feed.stores or {}
	local sn = C.feed.snares or {}
	local n, tot, any = 0, 0, false
	for i, s in pairs(st) do
		any = true
		if s.n > 0 then tot = tot + s.n; n = n + 1 end
	end
	-- selected stations (v1.7.7): the MiG-29 picks a PAIR of pylons with the
	-- External Stores switch (cockpit argument 29): INBD (0) = the inner pair
	-- 3 / 5; OUTBD (1) = the middle pair 2 / 6, and the outer pair 1 / 7 once
	-- nothing is left on 2 / 6. Tanks are never "selected". DCS's own
	-- CurrentStation (0 in the MiG-29) wins when it names a station.
	local SEL = {}
	local function loaded(i)
		local s = st[i]
		return s and s.n > 0 and s.name and s.name ~= ""
	end
	local function armed(i) return loaded(i) and store_kind(up(st[i].name)) ~= 3 end
	local pos
	if sn.cur and sn.cur > 0 then
		SEL[sn.cur] = true
	else
		local ok, a = pcall(get_cockpit_draw_argument_value, CFG.sms_switch_arg or 29)
		local outbd = ok and (tonumber(a) or 0) > 0.5
		pos = outbd and "OUTBD" or "INBD"
		local pairs_ = outbd and {{2, 6}, {1, 7}} or {{3, 5}}
		for _, pr in ipairs(pairs_) do
			if loaded(pr[1]) or loaded(pr[2]) then
				for _, i in ipairs(pr) do if armed(i) then SEL[i] = true end end
				break
			end
		end
	end
	local sel_st, sel_nm = {}, {}
	for i = 1, 7 do
		local s = st[i]
		local h = H.sms[i]
		local nm = s and up(s.name) or ""
		if s and s.n > 0 and nm ~= "" then
			local sel = SEL[i] == true
			local short = store_short(nm, i)
			T(h.nm, short)
			T(h.ct, (s.n > 1) and ("x" .. s.n) or " ")
			h.ico:set(store_kind(nm) + (sel and 10 or 0))
			h.sel:set(sel and 2 or 1)
			if sel then
				sel_st[#sel_st + 1] = tostring(i)
				if sel_nm[#sel_nm] ~= short and not (#sel_nm == 1 and sel_nm[1] == short) then sel_nm[#sel_nm + 1] = short end
			end
		else
			T(h.nm, " "); T(h.ct, " "); h.ico:set(0); h.sel:set(0)
		end
	end
	local sel_txt
	if #sel_st > 0 then
		sel_txt = string.format("SELECTED  ST%s  %s", table.concat(sel_st, "+"), table.concat(sel_nm, "/"))
	else
		sel_txt = "SELECTED  " .. (pos and (pos .. "  EMPTY") or "--")
	end
	T(H.SMS_SEL, (not any) and "NO STORES DATA" or sel_txt)
	T(H.SMS_GUN, sn.gun and string.format("GUN GSh-30  %d RDS", sn.gun) or "GUN --")
	T(H.SMS_CM, sn.chaff and string.format("CHAFF %d   FLARE %d", sn.chaff, sn.flare or 0) or "CHAFF --  FLARE --")
	T(H.SMS_TOT, string.format("%d STORES ON %d STATIONS", tot, n))
end

-- the R-862 is cockpit device 51 (the same one SRS reads)
local RADIO_DEV = CFG.radio_device or 51
local function radio()
	local ok, d = pcall(GetDevice, RADIO_DEV)
	return ok and d or nil
end
local function radio_freq()
	local d = radio()
	if not d then return nil end
	local ok, f = pcall(function() return d:get_frequency() end)
	return ok and tonumber(f) and f > 0 and f / 1e6 or nil
end
local function upd_comnav(C)
	need_beacons(C)
	local x = C.feed.x or {}
	-- R-862: frequency, channel and the presets (DTC, else the mission's)
	local ch = M.rdo_cur
	local presets = (C.plan and C.plan.radio and next(C.plan.radio)) and C.plan.radio or C.feed.msn_radio or {}
	local src = (C.plan and C.plan.radio and next(C.plan.radio)) and ("PRESETS DTC " .. ascii(C.plan.name)) or (next(C.feed.msn_radio or {}) and "MISSION PRESETS" or "NO PRESETS")
	local f = radio_freq()
	if not f then
		local ok, v = pcall(function() return get_param_handle("VHF_UHF_AM_FREQ"):get() end)
		f = ok and tonumber(v) or nil
	end
	if (not f or f == 0) and ch then f = presets[ch] end
	if not fin(f) then f = nil end
	T(H.RDO_FREQ, string.format("R-862  CH %s  %s", ch and tostring(ch - 1) or "--", f and string.format("%.3f MHZ", f) or "--"))
	T(H.RDO_SRC, src)
	for i = 1, 20 do
		local fr = presets[i]
		if not fin(fr) then fr = nil end
		T(H.rdo[i].txt, fr and string.format("CH%02d %7.3f", i - 1, fr) or string.format("CH%02d  --", i - 1))
		H.rdo[i].sel:set((ch == i) and 1 or 0)
	end
	-- RSBN / ILS (PRMG): the selected channels and their stations
	local function station(kind, chn, b)
		if not chn then return kind .. " --" end
		if not b then return string.format("%s %d  NO STATION", kind, chn) end
		local br, d = bra(C.ox, C.oz, b.x, b.z, C.unit_m)
		return string.format("%s %d  %s %s  %03d/%d%s", kind, chn, up(b.name):sub(1, 12), ascii(b.cs), br, math.floor(d + 0.5), C.unit_lbl)
	end
	local rch = fin(x.rsbn) and (math.floor(x.rsbn / 0.005 + 0.5) + 1) or nil
	local ils = fin(x.ils) and (math.floor(x.ils / 0.01 + 0.5) + 1) or nil
	T(H.RSBN_SEL, station("RSBN", rch, rch and beacon_by_ch(BEACONS.rsbn, rch)))
	T(H.RSBN_ILS, station("ILS", ils, ils and beacon_by_ch(BEACONS.prmg, ils)))
	local adf = fin(x.adf) and (math.floor(x.adf / 0.1 + 0.5)) or nil
	T(H.RDO_ADF, adf and ("ADF CHANNEL " .. ((adf >= 5) and "P" or tostring(adf))) or "ADF --")
	local kru = (fin(x.kru_t) and fin(x.kru_u)) and (math.floor(x.kru_t * 10 + 0.5) * 10 + math.floor(x.kru_u * 10 + 0.5)) or nil
	T(H.RDO_KRU, kru and string.format("GCI (KRU) CHANNEL %d", kru) or "GCI --")
	-- the nearest RSBN / PRMG stations
	local rows = {}
	for _, r in ipairs(BEACONS.rsbn) do rows[#rows + 1] = {"RSBN", r, (r.x - C.ox) ^ 2 + (r.z - C.oz) ^ 2} end
	for _, r in ipairs(BEACONS.prmg) do rows[#rows + 1] = {"PRMG", r, (r.x - C.ox) ^ 2 + (r.z - C.oz) ^ 2} end
	table.sort(rows, function(a, b) return a[3] < b[3] end)
	for i = 1, 5 do
		local r = rows[i]
		if r then
			local br, d = bra(C.ox, C.oz, r[2].x, r[2].z, C.unit_m)
			T(H.rsbn[i].txt, string.format("%s %2d %-3s %-12s %03d %d%s", r[1], r[2].ch or 0, ascii(r[2].cs), up(r[2].name):sub(1, 12), br, math.floor(d + 0.5), C.unit_lbl))
			local on = (r[1] == "RSBN" and r[2].ch == rch) or (r[1] == "PRMG" and r[2].ch == ils)
			H.rsbn[i].act:set(on and 2 or 1)
		else
			T(H.rsbn[i].txt, ""); H.rsbn[i].act:set(0)
		end
	end
end

-----------------------------------------------------------------------
-- time on target: ETA / fuel along the route, the speed for the TOT
-----------------------------------------------------------------------
local function time_of_day(C)
	local t = get_absolute_model_time and get_absolute_model_time() or (C.t or 0)
	return t % 86400
end
local function hms(sec)
	if not fin(sec) then return "--:--:--" end
	sec = math.floor(sec + 0.5) % 86400
	return string.format("%02d:%02d:%02d", math.floor(sec / 3600), math.floor(sec / 60) % 60, sec % 60)
end
-- ground speed (m/s) from the jet's own track over the last few seconds
local function ground_speed(C)
	local h, t = M.gs_hist, C.t or 0
	local last = h[#h]
	if last and t - last.t > 2 then h = {}; M.gs_hist = h; last = nil end   -- page was closed: start over
	if not last or t - last.t >= 0.5 then h[#h + 1] = {t = t, x = C.ox, z = C.oz} end
	while #h > 2 and h[#h].t - h[1].t > 4 do table.remove(h, 1) end
	local a, b = h[1], h[#h]
	if not a or b.t - a.t < 1.5 then return nil end
	local d = math.sqrt((b.x - a.x) ^ 2 + (b.z - a.z) ^ 2)
	if not fin(d) then M.gs_hist = {}; return nil end
	if d / (b.t - a.t) > 1500 then M.gs_hist = {}; return nil end     -- respawn / teleport
	return d / (b.t - a.t)
end
-- m/s -> 812, "KM/H" / 438, "KT" (nil, unit when v is not a real number)
local function spd_fmt(v, C)
	if C.unit_lbl == "NM" then return rnd(fin(v) and v * 1.94384), "KT" end
	return rnd(fin(v) and v * 3.6), "KM/H"
end
-- fuel flow at another speed (estimate). The measured flow at the current
-- speed calibrates it (weight, stores, drag index); drag ~ q + q_md^2 / q
-- (q = dynamic pressure, q_md at the minimum-drag speed, x a transonic
-- drag rise above ~M0.88); thrust beyond
-- the engines' dry maximum at this altitude is burned at afterburner SFC.
-- Returns kg/h and true when the speed needs afterburner.
local function air_density(h)
	h = math.max(0, h or 0)
	if h < 11000 then return 1.225 * (1 - 2.2558e-5 * h) ^ 4.2559 end
	return 0.3639 * math.exp(-(h - 11000) / 6341.6)
end
local function flow_at(v, flow_now, v_now, h)
	if not (v and flow_now and v_now) or v < 30 or v_now < 30 then return flow_now, false end
	local rho = air_density(h)
	local q_md = 0.5 * 1.225 * (CFG.fuel_vmd_eas or 135) ^ 2
	local snd = math.sqrt(401.874 * (288.15 - 0.0065 * math.min(math.max(h or 0, 0), 11000)))
	local function drag(vv)
		local q = 0.5 * rho * vv * vv
		local m = vv / snd                                       -- transonic drag rise above ~M0.88
		local wave = math.min(2.2, 1 + 25 * math.max(0, m - 0.88) ^ 2)
		return q * wave + q_md * q_md / q
	end
	local sfc_dry, sfc_ab = CFG.fuel_sfc_dry or 0.77, CFG.fuel_sfc_ab or 2.05      -- kg per kgf per hour
	local t_max = (CFG.fuel_dry_thrust_kgf or 10080) * (rho / 1.225) ^ 0.75          -- both engines, max dry
	local ff_max = t_max * sfc_dry
	local t_now = (flow_now <= ff_max) and flow_now / sfc_dry or t_max + (flow_now - ff_max) / sfc_ab
	local t_req = t_now * drag(v) / drag(v_now)
	if t_req <= t_max then return t_req * sfc_dry, false end
	return ff_max + (t_req - t_max) * sfc_ab, true
end
-- route timing: per steerpoint ETA (s of day) and fuel, plus the TOT solution
local function tot_calc(C)
	local wps = route_pts(C)
	local sd = C.sd
	local fuel = sd and sd.getTotalFuelWeight and tonumber(sd.getTotalFuelWeight()) or nil
	if not fin(fuel) then fuel = nil end
	local flow = measured_flow()             -- kg/h
	local gs = ground_speed(C)
	local tod = time_of_day(C)
	-- the selected steerpoint is the next one; the ones before it are flown.
	-- An airfield selected (after the route): the whole route is flown.
	-- Not on the route (or nothing selected): all of it is ahead.
	local a = 1
	local ai = act_index(C, C.plan and C.plan.pts)
	if ai and ai <= #wps then a = ai
	elseif (ai and ai > #wps) or (C.act and C.act.ad) then a = #wps + 1 end
	M.act_i = a
	local R = {gs = gs, tod = tod, fuel = fuel, flow = flow, act = a, cum = {}}
	local cum = 0
	for i = a, #wps do
		local px, pz = (i == a) and C.ox or wps[i - 1].x, (i == a) and C.oz or wps[i - 1].z
		cum = cum + math.sqrt((wps[i].x - px) ^ 2 + (wps[i].z - pz) ^ 2)
		R.cum[i] = cum
	end
	local function fuel_after(sec) if fuel and flow and sec then return fuel - flow * sec / 3600 end end
	R.fuel_at = fuel_after
	local tas = sd and sd.getTrueAirSpeed and tonumber(sd.getTrueAirSpeed()) or 0
	if not fin(tas) then tas = 0 end
	local v_now = (tas > 30) and tas or gs
	local fuelp = {}               -- [i] = planned fuel on arrival, each leg at its own fuel flow
	local function until_(sec) return ((sec - tod + 43200) % 86400) - 43200 end   -- s until a time of day (- = passed)
	-- the TOTs ahead split the route into legs, each flown at its own speed:
	-- distance since the previous TOT (or the jet) / time since it
	local plan = {}                -- [i] = planned s from now
	local legs = {}                -- {i, left, d, req} per TOT ahead, in route order
	local p_cum, p_left, ok = 0, 0, true
	local p_fuel = (fuel and flow) and fuel or nil
	for i = a, #wps do
		local tt = M.tots[i]
		if tt then
			local left, d = until_(tt), R.cum[i]
			local lg = {i = i, left = left, d = d - p_cum}
			if ok and lg.d < 1 and left > 0 and left >= p_left then
				-- v1.7.2: nothing to fly (two TOTs on one spot, e.g. a hold over
				-- the target): wait there until the TOT. v1.7.1 divided by a
				-- required speed of 0 (nan ETAs and fuel, "THEN .. 0 KM/H").
				-- The points before it on the same spot are reached at the
				-- start of the hold; fuel at the flow measured now.
				lg.hold = true
				lg.ff = flow
				for j = i, a, -1 do
					if j < i and M.tots[j] then break end
					plan[j] = (j == i) and left or p_left
					if p_fuel and flow then fuelp[j] = p_fuel - flow * (plan[j] - p_left) / 3600 end
				end
				p_fuel = fuelp[i]
			elseif left > p_left + 1 and ok then
				lg.req = lg.d / (left - p_left)
				local ff
				ff, lg.ab = flow_at(lg.req, flow, v_now, C.alt)
				lg.ff = ff
				for j = i, a, -1 do
					if j < i and M.tots[j] then break end
					plan[j] = p_left + (R.cum[j] - p_cum) / lg.req
					if p_fuel and ff then fuelp[j] = p_fuel - ff * (plan[j] - p_left) / 3600 end
				end
				p_fuel = fuelp[i]
			else
				lg.bad = true; ok = false                 -- passed, or before the previous TOT
			end
			legs[#legs + 1] = lg
			p_cum, p_left = d, left
		end
	end
	-- after the last TOT (or without one): the current ground speed
	local ff_rest = flow_at(gs, flow, v_now, C.alt)
	for i = a, #wps do
		if not plan[i] and ok and gs and gs > 30 and R.cum[i] >= p_cum then
			plan[i] = p_left + (R.cum[i] - p_cum) / gs
			if p_fuel and ff_rest then fuelp[i] = p_fuel - ff_rest * (plan[i] - p_left) / 3600 end
		end
	end
	R.fuelp = fuelp
	R.eta = function(i) local v = plan[i]; if fin(v) then return v end end
	R.legs = legs
	-- the TOT we are flying to now, and how early / late at this ground speed
	local nx = legs[1]
	if nx then
		local s = {pt = wps[nx.i], i = nx.i, left = nx.left, req = nx.req, ab = nx.ab, hold = nx.hold}
		if nx.bad then s.state = (nx.left <= 0) and "TOT PASSED" or "CANNOT MAKE"
		else
			if gs and gs > 30 then s.err = R.cum[nx.i] / gs - nx.left end   -- + late, - early
			s.fuel_tot = fuelp[nx.i]
			s.fuel_home = fuelp[#wps]
		end
		local n2 = legs[2]
		if n2 then s.next = {pt = wps[n2.i], i = n2.i, req = n2.req, bad = n2.bad, ab = n2.ab, hold = n2.hold} end
		R.tot = s
	end
	M.ti = R
	return R
end
local function tot_text(C, R)
	local s = R and R.tot
	local lbl = s and ascii(s.pt.lbl or ("W" .. s.i)) or ""
	if not s then return nil end
	local st, col = "--", 1
	if s.state then st, col = s.state, 3
	elseif s.req and s.req * 3.6 > (CFG.tot_max_kmh or 1500) then st, col = "CANNOT MAKE", 3
	elseif s.err then
		local e = math.floor(math.abs(s.err) + 0.5)
		local es = (e >= 100) and string.format("%d:%02d", math.floor(e / 60), e % 60) or string.format("%d S", e)
		if e <= (CFG.tot_on_time_s or 5) then st, col = "ON TIME", 1
		elseif s.err < 0 then st, col = es .. " EARLY", (e <= 30) and 1 or 2
		else st, col = es .. " LATE", (e <= 30) and 2 or 3 end
	end
	return lbl, st, col
end
local function upd_tot(C, R)
	local h = H.tot
	local s = R and R.tot
	if M.entry == "TOT" then
		local wps = route_pts(C)
		local w = wps[M.tot_pt or 1]
		local b = M.buf .. string.rep("-", 6 - #M.buf)
		T(h.hint, string.format("TOT %s  %s:%s:%s  (ENT)", ascii(w and w.lbl or "--"), b:sub(1, 2), b:sub(3, 4), b:sub(5, 6)))
		h.on:set(0)
		return
	end
	if not s then
		T(h.hint, next(M.tots) and "NO TOT AHEAD   PT, TOT" or "TOT: SET TIME ON TARGET  (PT = POINT)")
		h.on:set(0)
		return
	end
	h.on:set(1)
	local lbl, st, col = tot_text(C, R)
	h.c:set(col)
	local tt = hms(M.tots[s.i] or 0)
	local ffmt = function(v) local r = rnd(v); return r and string.format("%d", r) or "--" end
	local low = (s.fuel_home and ((M.bingo or 0) > 0 and s.fuel_home < M.bingo or s.fuel_home < (CFG.fuel_reserve_kg or 500)))
	h.fc:set(low and 2 or 1)
	local gv, gu = spd_fmt(R.gs, C)
	local rq = s.req and spd_fmt(s.req, C) or nil
	local rt = route_pts(C)
	local last = #rt
	-- PLAN page
	T(h.l1, string.format("TOT %s %s", lbl, tt))
	T(h.st, st)
	if rq then T(h.spd, string.format("REQ %d %s%s   GS %s", rq, gu, s.ab and " AB" or "", gv and tostring(gv) or "--"))
	else T(h.spd, (s.hold and "HOLD   GS " or "GS ") .. (gv and (gv .. " " .. gu) or "--")) end
	if s.next then
		local n = s.next
		local nv = n.req and spd_fmt(n.req, C)
		T(h.thn, string.format("THEN %s %s  %s", ascii(n.pt.lbl or ("W" .. n.i)), hms(M.tots[n.i] or 0),
			n.bad and "CANNOT MAKE" or (n.hold and "HOLD") or (nv and string.format("%d %s%s", nv, gu, n.ab and "  AB" or "") or "--")))
	else
		T(h.thn, "")
	end
	local lo, hi = 500 / 3.6, 1300 / 3.6                       -- scale: 500 .. 1300 km/h
	local function sx(v) return -0.70 + 1.40 * math.max(0, math.min(1, (v - lo) / (hi - lo))) end
	local rok, gok = fin(s.req), fin(R.gs)
	h.rx:set(rok and sx(s.req) or 0); h.rv:set(rok and 1 or 0)
	h.gx:set(gok and sx(R.gs) or 0); h.gv:set(gok and 1 or 0)
	T(h.fuel, string.format("FUEL AT %s %s KG   AT %s %s%s", lbl, ffmt(s.fuel_tot), ascii(last > 0 and rt[last].lbl or "END"),
		ffmt(s.fuel_home), (M.bingo or 0) > 0 and string.format("   BINGO %d", M.bingo) or ""))
end

local function upd_fpl(C)
	local p = C.plan
	T(H.FPL_SRC, "PLAN " .. ascii(p and p.name or "--") .. (C.route_on and "" or "  (OFF)"))
	local R = M.ti or tot_calc(C)
	local rows = {}
	for i, w in ipairs(route_pts(C)) do rows[#rows + 1] = {w = w, i = i} end
	local mk = DL_PAGES.marks
	for j = 1, 5 do if mk[j] then rows[#rows + 1] = {w = mk[j]} end end
	for _, a in ipairs(p and p.ads or {}) do rows[#rows + 1] = {w = a} end
	-- the selected one: the route point by its index (not every point at the
	-- same place), else the airfield / mark itself
	local ai = act_index(C, p and p.pts)
	local ap = ai and p.pts[ai]
	for i = 1, 10 do
		local r = rows[i]
		if r then
			local w = r.w
			local nm = up(w.name)
			if nm == ascii(w.lbl) then nm = "" end
			local sec
			if r.i then sec = R.eta(r.i)
			elseif R.gs and R.gs > 30 then sec = math.sqrt((w.x - C.ox) ^ 2 + (w.z - C.oz) ^ 2) / R.gs end   -- marks / airfields: direct
			local passed = r.i and r.i < R.act
			local eta = passed and "--:--:--" or (sec and hms(R.tod + sec) or "--:--:--")
			local f = (not passed) and (r.i and R.fuelp[r.i] or (not r.i and R.fuel_at(sec))) or nil
			f = rnd(f)
			T(H.fpl[i].txt, string.format("%-3s %-10s %8s %5s", ascii(w.lbl), nm:sub(1, 10), eta, f and string.format("%d", f) or "--"))
			local act = (r.i and r.i == ai) or (not r.i and (w == C.act or w == ap))
			H.fpl[i].act:set(act and 2 or ((tostring(w.lbl or "")):match("^M%d$") and 3 or (passed and 4 or 1)))
			H.fpl[i].tot:set(((r.i and M.tots[r.i]) and 1 or 0) + ((r.i and r.i == M.tot_pt) and 2 or 0))
		else
			T(H.fpl[i].txt, ""); H.fpl[i].act:set(0); H.fpl[i].tot:set(0)
		end
	end
end

local function upd_hsi(C)
	need_beacons(C)
	local hdg = fin(C.hdg) and C.hdg or 0
	local hd = fmt_brg(hdg)
	T(H.HSI_HDG, string.format("%03d", hd) .. "T")
	H.hsi.rot:set(hdg)
	-- compass labels every 30 deg, upright, on the rose
	local R = CFG.hsi_label_radius or 0.6
	for k = 0, 11 do
		local a = math.rad(k * 30) - hdg            -- clockwise from the top of the screen
		H.hsi.lbl[k].x:set(R * math.sin(a))
		H.hsi.lbl[k].y:set(R * math.cos(a))
	end
	H.hsi.bug:set(-(math.rad(M.hdg_bug) - hdg))
	H.hsi.crs:set(-(math.rad(M.crs) - hdg))
	T(H.HSI_BUG, string.format("HDG %03d", M.hdg_bug))
	T(H.HSI_CRS, string.format("CRS %03d", M.crs))
	-- pointer 1: the selected steerpoint / airfield
	local act = C.act
	if act then
		local dN, dE = act.x - C.ox, act.z - C.oz
		local brg = math.atan2(dE, dN)
		local d = math.sqrt(dN * dN + dE * dE)
		M.stp_brg = fmt_brg(brg) % 360
		H.hsi.b1:set(-(brg - hdg)); H.hsi.b1v:set(1)
		T(H.HSI_STP1, "STP " .. ascii(act.lbl) .. " " .. up(act.name):sub(1, 10))
		-- text from the shared steering solution (same numbers as SA / NAV / UFCP)
		local sb, sd = brg, d
		if C.nav and C.nav.steer_to then sb, sd = C.nav.steer_to(act, C.ox, C.oz) else sb = fmt_brg(brg) end
		T(H.HSI_STP2, string.format("%03d  %d%s", sb, math.floor(sd / C.unit_m + 0.5), C.unit_lbl))
		-- course deviation: steerpoint left / right of the selected course line
		local xtk = d * math.sin(brg - math.rad(M.crs))
		local full = CFG.hsi_cdi_full_m or 5000
		H.hsi.cdi:set(math.max(-1, math.min(1, xtk / full)))
	else
		M.stp_brg = nil
		H.hsi.b1v:set(0); H.hsi.cdi:set(0)
		T(H.HSI_STP1, "STP --"); T(H.HSI_STP2, "")
	end
	-- v1.7.6: the steerpoint and the next two route points under the rose,
	-- with the NAV list's numbers (bearing / distance from the jet, ETA along
	-- the route); blank while a HDG / CRS / TCN number is being typed
	H.hsi_nx = H.hsi_nx or {H.HSI_NX1, H.HSI_NX2, H.HSI_NX3}
	local plan = C.nav and C.nav.cur
	local pts = (plan and plan.pts) or {}
	local ai = (act and not M.entry) and act_index(C, pts) or nil
	local nrt = (plan and plan.nrt) or #pts
	local gs, tod, R = ground_speed(C), time_of_day(C), M.ti
	local run = nil
	for k = 1, 3 do
		local i = ai and (ai + k - 1)
		local w = i and pts[i]
		if w and (k == 1 or i <= nrt) then
			local dN, dE = w.x - C.ox, w.z - C.oz
			local dd = math.sqrt(dN * dN + dE * dE)
			if i <= nrt then
				run = (k == 1) and dd or ((run or 0) + math.sqrt((w.x - pts[i - 1].x) ^ 2 + (w.z - pts[i - 1].z) ^ 2))
			end
			-- ETA: the route timing's own clock (R.tod) plus its seconds; else
			-- straight on at the present ground speed from now
			local sec = (i <= nrt and R and R.eta) and R.eta(i) or nil
			local base = (sec and R.tod) or tod
			if not sec and gs and gs > 30 then sec = ((i <= nrt) and run or dd) / gs end
			local v = dd / C.unit_m
			T(H.hsi_nx[k], string.format("%-3s %-6s %03dT %5s %s", ascii(w.lbl):sub(1, 3), up(w.name):sub(1, 6),
				fmt_brg(math.atan2(dE, dN)), fin(v) and ((v < 99.95) and string.format("%.1f", v) or tostring(math.floor(v + 0.5))) or "--",
				(sec and base) and hms(base + sec):sub(1, 5) or "--:--"))
		else
			T(H.hsi_nx[k], " ")
		end
	end
	-- pointer 2: TACAN station (channel typed on the UFCP keypad, X band)
	H.hsi_tcnon = H.hsi_tcnon or P("DLP_HSI_TCNON")
	H.hsi_tcnon:set(M.tcn and 1 or 0)
	local tb = M.tcn and beacon_by_ch(BEACONS.tacan, M.tcn)
	if tb then
		local dN, dE = tb.x - C.ox, tb.z - C.oz
		local brg = math.atan2(dE, dN)
		H.hsi.b2:set(-(brg - hdg)); H.hsi.b2v:set(1)
		T(H.HSI_TCN1, string.format("TCN %dX %s", M.tcn, ascii(tb.cs)))
		T(H.HSI_TCN2, string.format("%03d  %d%s", fmt_brg(brg), math.floor(math.sqrt(dN * dN + dE * dE) / C.unit_m + 0.5), C.unit_lbl))
	else
		H.hsi.b2v:set(0)
		T(H.HSI_TCN1, M.tcn and string.format("TCN %dX NO STATION", M.tcn) or "TCN OFF")
		T(H.HSI_TCN2, "")
	end
end

-----------------------------------------------------------------------
-- NAV page: steering to the selected steerpoint along the route leg,
-- and the route list with leg course, distance and ETA
-----------------------------------------------------------------------
-- RSBN on the NAV page: the cartridge's stations (RSBN 1-3), then the
-- nearest map stations; bearing / range worked out from the coordinates,
-- "NO RX" beyond the radio horizon (and the RSBN's own range)
local function upd_nav_rsbn(C)
	local h = H.nav
	need_beacons(C)
	local x = (C.feed and C.feed.x) or {}
	local rch = fin(x.rsbn) and (math.floor(x.rsbn / 0.005 + 0.5) + 1) or nil
	local magn, mv = false, 0                 -- true bearings, see upd_nav
	local list, seen = {}, {}
	for i, r in ipairs((C.plan and C.plan.rsbn) or {}) do
		if r.x and r.z and i <= 3 then
			list[#list + 1] = {tag = "R" .. i, ch = r.channel, name = r.name, x = r.x, z = r.z}
			seen[tostring(r.channel) .. ":" .. math.floor(r.x / 2000)] = true
		end
	end
	local near = {}
	for _, b in ipairs(BEACONS.rsbn or {}) do
		if not seen[tostring(b.ch) .. ":" .. math.floor(b.x / 2000)] then
			near[#near + 1] = {tag = "MAP", ch = b.ch, name = b.name, x = b.x, z = b.z, y = b.y, d2 = (b.x - C.ox) ^ 2 + (b.z - C.oz) ^ 2}
		end
	end
	table.sort(near, function(a, b) return a.d2 < b.d2 end)
	for _, n in ipairs(near) do if #list < 4 then list[#list + 1] = n end end
	local function elev(st)
		if st.y then return st.y end
		for _, b in ipairs(BEACONS.rsbn or {}) do
			if b.ch == st.ch and (b.x - st.x) ^ 2 + (b.z - st.z) ^ 2 < 4e6 then return b.y end
		end
		return CFG.rsbn_default_elev_m or 100
	end
	local function rx_km(st)
		-- radio horizon, antenna about 10 m above the station
		local ha = math.max(0, (C.alt or 0) - elev(st))
		return math.min(CFG.rsbn_max_km or 380, 4.12 * (math.sqrt(ha) + math.sqrt(10)))
	end
	local function row(st)
		local dN, dE = st.x - C.ox, st.z - C.oz
		local d = math.sqrt(dN * dN + dE * dE)
		local brg = (math.floor(math.deg(math.atan2(dE, dN)) - mv + 0.5) + 359) % 360 + 1
		local rx = d / 1000 <= rx_km(st)
		return string.format("%-3s %2s %-10s %03d%s %4d%s%s", st.tag, tostring(st.ch or "--"), up(st.name):sub(1, 10),
			brg, magn and "M" or "T", math.floor(d / C.unit_m + 0.5), C.unit_lbl, rx and "" or " NO RX"), rx
	end
	local sel = nil
	for i = 1, 4 do
		local st, r = list[i], h.rs[i]
		if st then
			local txt, rx = row(st)
			T(r.txt, txt)
			local on = rch and st.ch == rch
			if on and not sel then sel = st end
			r.c:set(on and 2 or (rx and 1 or 4))
		else
			T(r.txt, " "); r.c:set(0)
		end
	end
	-- the channel set on the jet's RSBN knob
	if not rch then T(h.rsel, "RSBN KNOB --")
	else
		if not sel then
			local b = beacon_by_ch(BEACONS.rsbn, rch)
			if b then sel = {tag = "MAP", ch = b.ch, name = b.name, x = b.x, z = b.z, y = b.y} end
		end
		if sel then
			local txt, rx = row(sel)
			T(h.rsel, "KNOB " .. txt:gsub("^%S+%s+", ""))
		else
			T(h.rsel, string.format("KNOB CH %d  NO STATION", rch))
		end
	end
end

local function upd_nav(C)
	local h, nav = H.nav, C.nav or {}
	local plan, act = nav.cur, C.act
	-- v1.6: true bearings ("T") like the SA, HSI, PICTURE and UFCP; the
	-- steerpoint line uses the same solution as SA / UFCP (nav.steer_to)
	local U = "T"
	local function mag(deg) if not fin(deg) then return 0 end return (math.floor(deg + 0.5) + 359) % 360 + 1 end
	local function dist(m)
		local v = fin(m) and m / C.unit_m
		if not fin(v) then return "--" end
		return (v < 99.95) and string.format("%.1f", v) or tostring(math.floor(v + 0.5))
	end
	local gs = ground_speed(C)
	local tod = time_of_day(C)
	h.view:set(M.nav_view or 0)
	if M.nav_view == 1 then upd_nav_rsbn(C) end
	T(h.src, plan and ("PLAN " .. up(plan.name)) or "NO PLAN")
	h.auto:set((nav.auto == false) and 0 or 1)
	if M.entry == "LL" or M.entry == "MGRS" then
		T(h.seq, DL_PAGES.add_text(false)); h.add:set(1)
	elseif M.nav_msg and (C.t or 0) - (M.nav_msg_t or 0) < 4 then
		T(h.seq, M.nav_msg); h.add:set(1)
	else
		T(h.seq, (nav.auto == false) and "SEQ MAN" or string.format("SEQ AUTO  %s%s", dist(CFG.nav_seq_radius_m or 3000), C.unit_lbl))
		h.add:set(0)
	end
	local hdg = math.deg(fin(C.hdg) and C.hdg or 0)
	if act then
		local brg, d = nav.steer_to(act, C.ox, C.oz)
		T(h.stp, "STP " .. ascii(act.lbl) .. "  " .. up(act.name):sub(1, 12))
		T(h.brg, string.format("BRG %03d%s   RNG %s %s", mag(brg), U, dist(d), C.unit_lbl))
		local ttg = (gs and gs > 30) and d / gs or nil
		T(h.time, ttg and string.format("TTG %s   ETA %s", mmss(ttg), hms(tod + ttg)) or "TTG --:--   ETA --:--:--")
		-- leg: desired track and cross-track error; command track intercepts the leg
		local cmd = brg
		local s = nav.leg_start and nav.leg_start(C.ox, C.oz)
		local lN, lE = s and (act.x - s.x) or 0, s and (act.z - s.z) or 0
		local L = math.sqrt(lN * lN + lE * lE)
		if s and L > 500 then
			local dtk = math.deg(math.atan2(lE, lN))
			local xtk = (lN * (C.oz - s.z) - lE * (C.ox - s.x)) / L      -- + = right of the leg
			local full = CFG.nav_xtk_full_m or 5000
			cmd = dtk - math.max(-45, math.min(45, xtk / full * 45))
			local direct = (nav.dir_i ~= nil and nav.dir_i == nav.stp_i) or not (nav.src == "stp" and (nav.stp_i or 0) > 1)
			T(h.leg, string.format("%s %03d%s   XTK %s%s %s", direct and "DIR" or "DTK", mag(dtk), U, dist(math.abs(xtk)),
				C.unit_lbl, (math.abs(xtk) < 50) and "" or ((xtk > 0) and "R" or "L")))
		else
			T(h.leg, "DIR " .. string.format("%03d%s", mag(brg), U))
		end
		local err = ((cmd - hdg) + 180) % 360 - 180
		if not fin(err) then err = 0 end
		h.steer:set(math.max(-1, math.min(1, err / 45))); h.sv:set(1)
		T(h.cmd, string.format("CMD %03d%s   %s %d", mag(cmd), U, (err < 0) and "L" or "R", math.floor(math.abs(err) + 0.5)))
	else
		T(h.stp, "STP --"); T(h.brg, "SELECT A STEERPOINT"); T(h.time, " "); T(h.leg, " "); T(h.cmd, " ")
		h.sv:set(0); h.steer:set(0)
	end
	-- route list (route points, then airfields), scrolled to the selected one
	local pts = (plan and plan.pts) or {}
	local ai = act_index(C, pts)
	local nrt = plan and plan.nrt or #pts
	local NR = #h.rows
	-- keep the TOT point cursor in view while it is being moved
	local focus = (M.entry == "TOT" or (M.tot_pt and M.tot_t and (C.t or 0) - M.tot_t < 4)) and M.tot_pt or ai
	local first = math.max(1, math.min((focus or 1) - 1, #pts - NR + 1))
	local R = M.ti
	-- distance along the route from the jet to each point ahead (route points)
	local cum, prev, run = {}, nil, nil
	if ai and ai <= nrt then
		run = math.sqrt((pts[ai].x - C.ox) ^ 2 + (pts[ai].z - C.oz) ^ 2)
		cum[ai] = run
		for i = ai + 1, nrt do
			run = run + math.sqrt((pts[i].x - pts[i - 1].x) ^ 2 + (pts[i].z - pts[i - 1].z) ^ 2)
			cum[i] = run
		end
	end
	for k = 1, NR do
		local i = first + k - 1
		local w, r = pts[i], h.rows[k]
		if w then
			-- bearing and distance from the jet, the same as the SA page shows
			-- (ETA is still flown along the route)
			local dd = math.sqrt((w.x - C.ox) ^ 2 + (w.z - C.oz) ^ 2)
			local dtk = string.format("%03d%s", mag(math.deg(math.atan2(w.z - C.oz, w.x - C.ox))), U)
			-- ETA along the route (flown at the TOT speeds when TOTs are set), airfields direct
			local sec = (i <= nrt and R and R.eta) and R.eta(i) or nil
			if not sec and gs and gs > 30 and (cum[i] or i > nrt) then sec = (cum[i] or dd) / gs end
			local eta = sec and hms(tod + sec):sub(1, 5) or "--:--"
			T(r.txt, string.format("%-4s %-8s %s %6s %s", ascii(w.lbl):sub(1, 4), up(w.name):sub(1, 8),
				dtk, dist(dd), eta))
			r.c:set((i == ai) and 2 or ((i > nrt) and 3 or ((ai and i < ai and ai <= nrt) and 4 or 1)))
			r.tot:set(((i <= nrt and M.tots[i]) and 1 or 0) + ((i == M.tot_pt) and 2 or 0))
		else
			T(r.txt, " "); r.c:set(0); r.tot:set(0)
		end
	end
end

-- RTE page: the full route of the plan with the picked points numbered
-- in the order they will be flown
local function upd_rte(C)
	local h, nav = H.rte, C.nav or {}
	local base = nav.base
	local nrt = (base and base.nrt) or 0
	local pages = math.max(1, math.ceil(nrt / 5))
	if M.rte_page > pages then M.rte_page = pages end
	T(h.title, "ROUTE  " .. up(base and base.name or "NO PLAN"))
	T(h.pg, string.format("PG %d/%d", M.rte_page, pages))
	local order = {}
	for k, i in ipairs(M.rte_sel) do order[i] = k end
	local lbls = {}
	for _, i in ipairs(M.rte_sel) do local w = base and base.pts[i]; if w then lbls[#lbls + 1] = ascii(w.lbl) end end
	local sum = (#lbls == 0) and "NONE PICKED = ALL" or table.concat(lbls, " ")
	if #sum > 34 then sum = sum:sub(1, 31) .. "..." end
	T(h.sum, string.format("RTE %d/%d  %s", #M.rte_sel, nrt, sum))
	local mem = base and DL_PLAN.members(base) or {}
	T(h.mem, (#mem > 0) and "MEMBER ROUTES: LEFT 1-4" or "NO MEMBER TAGS IN THE NOTES")
	for k = 1, 4 do T(h.m[k], mem[k] and ("FLT " .. tostring(mem[k])) or " ") end
	for k = 1, 5 do
		local i = (M.rte_page - 1) * 5 + k
		local w = base and i <= nrt and base.pts[i]
		local r = h.rows[k]
		if w then
			local tg = {}
			for m in pairs(w.tags or {}) do tg[#tg + 1] = ascii(m) end
			table.sort(tg)
			T(r.txt, string.format("%-4s %-8s %-4s %s", ascii(w.lbl):sub(1, 4), up(w.name):sub(1, 8),
				table.concat(tg), order[i] and string.format("[%d]", order[i]) or "[ ]"))
			r.c:set(order[i] and 2 or 1)
		else
			T(r.txt, " "); r.c:set(0)
		end
	end
end

-- EDIT page: the working route with its own cursor (v1.7.2)
local function ll_text(x, z)
	local ok, terr = pcall(require, "terrain")
	if not ok or type(terr) ~= "table" or not terr.convertMetersToLatLon then return nil end
	local ok2, lat, lon = pcall(terr.convertMetersToLatLon, x, z)
	if not ok2 or not fin(lat) or not fin(lon) then return nil end
	local function dm(v, f)
		local a = math.abs(v)
		local d = math.floor(a)
		local m = (a - d) * 60
		if m >= 59.995 then d, m = d + 1, 0 end
		return string.format(f, d, m)
	end
	local ll = ((lat < 0) and "S " or "N ") .. dm(lat, "%02d %05.2f") .. "   " .. ((lon < 0) and "W " or "E ") .. dm(lon, "%03d %05.2f")
	local zone, e, n = DL_PLAN.ll_to_utm(lat, lon)
	local mg = DL_PLAN.mgrs_square(lat, zone, e, n) .. string.format(" %05d %05d", math.floor(e % 100000), math.floor(n % 100000))
	return ll, mg
end
local function upd_wed(C)
	local h, nav = H.wed, C.nav or {}
	local L = nav.wp_list and nav.wp_list() or {}
	local n = #L
	if M.ed_w and L[M.ed_i] ~= M.ed_w then
		for k, w in ipairs(L) do if w == M.ed_w then M.ed_i = k; break end end
	end
	M.ed_i = math.max(1, math.min(M.ed_i or 1, math.max(n, 1)))
	local i = M.ed_i
	M.ed_w = L[i]
	local plan = nav.cur
	T(h.title, "EDIT ROUTE  " .. up(plan and (plan.label or plan.name) or "NO PLAN"):sub(1, 20))
	T(h.pg, (n > 0) and string.format("PG %d/%d  PT %d/%d", math.floor((i - 1) / 5) + 1, math.ceil(n / 5), i, n) or "PT 0/0")
	local ai = (nav.src == "stp" and nav.stp_i and nav.stp_i <= n) and nav.stp_i or nil
	local w = L[i]
	if w then
		T(h.sel, string.format("%s %s%s%s", ascii(w.lbl):sub(1, 4), up(w.name):sub(1, 8), w.moved and " *" or "", (i == ai) and " STP" or ""))
		local ll, mg = ll_text(w.x, w.z)
		T(h.ll, ll or "NO COORDINATES")
		T(h.mg, mg or " ")
	else
		T(h.sel, "NO ROUTE POINTS - LEFT 4 ADD"); T(h.ll, " "); T(h.mg, " ")
	end
	if M.entry == "LL" or M.entry == "MGRS" then
		T(h.msg, DL_PAGES.add_text(false)); h.msgc:set(1)
	elseif M.nav_msg and (C.t or 0) - (M.nav_msg_t or 0) < 4 then
		T(h.msg, M.nav_msg); h.msgc:set(1)
	else
		T(h.msg, "THIS FLIGHT ONLY - DTC FILE UNCHANGED"); h.msgc:set(0)
	end
	local first = math.floor((i - 1) / 5) * 5
	for k = 1, 5 do
		local j = first + k
		local p, r = L[j], h.rows[k]
		if p then
			T(r.txt, string.format("%2d %-4s %-8s %s", j, ascii(p.lbl):sub(1, 4), up(p.name):sub(1, 8), (j == ai) and "STP" or "   "))
			r.c:set((j == i) and 2 or ((j == ai) and 3 or 1))
		else
			T(r.txt, " "); r.c:set(0)
		end
	end
end

local function upd_flt(C)
	local list = aircraft(C)
	local hf = H.flt
	if CFG.opt_datalink == false then
		-- no datalink picture: nothing to show about the flight
		hf.view:set(0)
		T(hf.title, "FLIGHT"); T(hf.pg, ""); T(hf.l1, ""); T(hf.l2, "")
		for k = 1, 5 do T(hf.rows[k].txt, ""); T(hf.rows[k].sub, ""); hf.rows[k].mark:set(0) end
		for i = 1, 14 do T(hf.d[i], ""); hf.c[i]:set(4) end
		T(hf.d[1], "DATALINK OFF"); hf.c[1]:set(3)
		T(hf.d[3], "SWITCH IT ON IN", 4); T(hf.d[4], "OPTIONS > SPECIAL"); T(hf.d[5], "MIG-29AM")
		return
	end
	hf.view:set(M.flt_view)
	local function sub_of(a)
		local br, d = bra(C.ox, C.oz, a.x, a.z, C.unit_m)
		return string.format("%03d/%d%s", br, math.floor(d + 0.5), C.unit_lbl)
	end
	if M.flt_view == 1 then
		-- every friendly aircraft in range, players first
		M.flt_list = list
		local pages = math.max(1, math.ceil(#list / 5))
		if M.flt_page > pages then M.flt_page = pages end
		T(hf.title, "ADD TO FLIGHT  (PLAYERS FIRST)")
		T(hf.pg, string.format("PG %d/%d", M.flt_page, pages))
		T(hf.l1, "BACK"); T(hf.l2, "")
		for k = 1, 5 do
			local a = list[(M.flt_page - 1) * 5 + k]
			local r = hf.rows[k]
			if a then
				T(r.txt, (a.human and "* " or "") .. name_of(a):sub(1, 14))
				T(r.sub, ascii(a.type):sub(1, 10) .. "  " .. sub_of(a))
				r.mark:set(in_flight(a) and 2 or 1)
			else
				T(r.txt, ""); T(r.sub, ""); r.mark:set(0)
			end
		end
		for i = 1, 14 do T(hf.d[i], ""); hf.c[i]:set(4) end
		if #list == 0 then T(hf.d[1], "NO FRIENDLY AIRCRAFT"); T(hf.d[2], "IN RANGE") end
		T(hf.d[13], "AMBER = IN FLIGHT")
		T(hf.d[14], "* = PLAYER  MAX 5")
		return
	end
	-- the flight: members on R1-R5, details of the selected one on the left
	T(hf.title, string.format("FLIGHT  %d/5", #M.flight))
	T(hf.pg, ""); T(hf.l1, "ADD"); T(hf.l2, #M.flight > 0 and "REM" or "")
	if M.flt_sel > #M.flight then M.flt_sel = math.max(1, #M.flight) end
	local t = C.t or 0
	local found = {}
	for k = 1, 5 do
		local key = M.flight[k]
		local r = hf.rows[k]
		if key then
			local a = nil
			for _, x in ipairs(list) do if x.unit == key or x.player == key then a = x; break end end
			found[k] = a
			local tag = ""
			if a then tag = (a.radar and " RDR" or "") .. (a.jam and " JAM" or "")
			else tag = M.seen[key] and "LOST" or "NOT SEEN" end
			T(r.txt, ascii(key):sub(1, 14))
			T(r.sub, a and (sub_of(a) .. tag) or tag)
			r.mark:set((k == M.flt_sel) and 2 or 1)
		else
			T(r.txt, ""); T(r.sub, ""); r.mark:set(0)
		end
	end
	-- detail lines with a colour each: 0 white, 1 green, 2 red, 3 amber, 4 grey
	local L, COL = {}, {}
	local function add(txt, c) L[#L + 1] = txt; COL[#L] = c or 0 end
	local key = M.flight[M.flt_sel]
	local a = found[M.flt_sel]
	if not key then
		add("NO FLIGHT MEMBERS", 4); add(""); add("ADD: PICK FRIENDLY", 4); add("AIRCRAFT TO TRACK", 4)
	elseif not a then
		local sn = M.seen[key]
		add(ascii(key):sub(1, 18), 3)
		add("")
		if sn then
			add("STATUS  LOST", 2)
			add("LAST SEEN " .. mmss(t - sn.t):gsub(" MIN", ""):gsub(" H", "H") .. " AGO", 2)
			local br, d = bra(C.ox, C.oz, sn.x, sn.z, C.unit_m)
			add(string.format("AT %03d %d %s", br, math.floor(d + 0.5), C.unit_lbl), 4)
			add(string.format("ALT %dM", math.floor((sn.y or 0) / 10 + 0.5) * 10), 4)
		else
			add("STATUS  NOT SEEN", 4)
			add("NOT SPAWNED OR", 4)
			add("OUT OF RANGE", 4)
		end
	else
		local br, d = bra(C.ox, C.oz, a.x, a.z, C.unit_m)
		local gs = math.sqrt((a.vx or 0) ^ 2 + (a.vz or 0) ^ 2) * 3.6
		if not fin(gs) then gs = 0 end
		add(name_of(a):sub(1, 18), 3)
		add(ascii(a.type):sub(1, 18))
		add("STATUS  ALIVE", 1)
		add(a.radar and "RADAR   ON" or "RADAR   OFF", a.radar and 1 or 4)
		add(a.jam and "JAMMER  ON" or "JAMMER  OFF", a.jam and 3 or 4)
		add("")
		add(string.format("BRG %03d  %d %s", br, math.floor(d + 0.5), C.unit_lbl))
		add(string.format("ALT %dM", math.floor((fin(a.y) and a.y or 0) / 10 + 0.5) * 10))
		add(string.format("HDG %03d", (math.floor(math.deg(fin(a.hdg) and a.hdg or 0) + 0.5) % 360)))
		add(string.format("GS %d KM/H", math.floor(gs + 0.5)))
	end
	for i = 1, 14 do T(hf.d[i], L[i] or ""); hf.c[i]:set(COL[i] or 0) end
end

-- remember where each flight member was last seen (for LOST)
local function track_flight(C)
	if not M.flight or #M.flight == 0 then return end
	for _, f in ipairs(C.feed.fr or {}) do
		for _, key in ipairs(M.flight) do
			if (f.unit == key or (f.player and f.player == key)) and fin(f.x) and fin(f.z) then
				M.seen[key] = {t = C.t or 0, x = f.x, z = f.z, y = fin(f.y) and f.y or 0}
			end
		end
	end
end

-- UFCP line while typing (HDG 27_)
-- the typed-in waypoint as it is being typed: full text for the NAV page,
-- 8 characters for the UFCP line
local function fill(b, from, n) local s = b:sub(from, from + n - 1); return s .. string.rep("-", n - #s) end
function DL_PAGES.add_text(short)
	local b, C = M.buf, M.cref or {}
	local lat0, lon0 = own_ll(C)
	local ns, ew = (lat0 and lat0 < 0) and "S" or "N", (lon0 and lon0 < 0) and "W" or "E"
	if M.entry == "LL" then
		local la, lo = fill(b, 1, 6), fill(b, 7, 7)
		if short then
			if #b < 6 then return ns .. la:sub(1, 4) .. "." .. la:sub(5, 6) end
			return ew .. lo
		end
		return string.format("%s %s %s %s.%s  %s %s %s.%s", (M.entry_for == "POS") and "POS" or "ADD", ns, la:sub(1, 2), la:sub(3, 4), la:sub(5, 6), ew, lo:sub(1, 3), lo:sub(4, 5), lo:sub(6, 7))
	elseif M.entry == "MGRS" then
		local sq = "--- --"
		if lat0 then local z, e, n = DL_PLAN.ll_to_utm(lat0, lon0); sq = DL_PLAN.mgrs_square(lat0, z, e, n) end
		-- v1.7.2: the digits split in half, as ENT uses them (2 digits =
		-- 10 km, 4 = 1 km ... 10 = 1 m); an odd count shows the missing digit
		-- as "-". v1.7.1 always showed 5 + 5, so "1234" looked like
		-- easting 12340 while it means E 12 N 34.
		local pre = (M.entry_for == "POS") and "POS" or "ADD"
		if #b == 0 then return short and "MGRS _" or string.format("%s MGRS %s  ----- -----", pre, sq) end
		local k = math.ceil(#b / 2)
		local en = fill(b, 1, k) .. " " .. fill(b, k + 1, k)
		if short then
			if #b <= 6 then return en end                  -- the UFCP line has 8 characters
			return "N" .. fill(b, k + 1, k)
		end
		return string.format("%s MGRS %s  %s", pre, sq, en)
	end
	return nil
end
function DL_PAGES.ufcp_text()
	if not M.entry then return nil end
	if M.entry == "LL" or M.entry == "MGRS" then
		-- (dl_device sets this text directly: never number-like)
		local s = DL_PAGES.add_text(true) or " "
		if tonumber(s) then s = s .. "-" end
		return s
	end
	return M.entry .. " " .. M.buf .. "_"
end

-----------------------------------------------------------------------
-- 14 PICTURE: hostile groups (DL_TAC.groups), sorted by range or by
-- threat (time until they reach us), bullseye / BRAA, the call
-----------------------------------------------------------------------
local function upd_pic(C)
	if not H.pic then
		H.pic = {hdr = P("DLP_PIC_HDR"), sort = P("DLP_PIC_SORT"), pr = P("DLP_PIC_PR"), be = P("DLP_PIC_BE"), l2 = P("DLP_PIC_L2"),
		         bx = P("DLP_PIC_BX"), by = P("DLP_PIC_BY"), auto = P("DLP_PIC_AUTO"), show = P("DLP_PIC_SHOW"),
		         ox = P("DLP_PIC_OX"), oy = P("DLP_PIC_OY"), ov = P("DLP_PIC_OV"), oh = P("DLP_PIC_OH"), r = {}, k = {}, g = {}}
		for k = 1, 5 do
			H.pic.r[k] = {txt = P("DLP_PIC_R" .. k), s = P("DLP_PIC_S" .. k), rv = P("DLP_PIC_RV" .. k), c = P("DLP_PIC_C" .. k)}
			H.pic.g[k] = {x = P("DLP_PIC_G" .. k .. "_X"), y = P("DLP_PIC_G" .. k .. "_Y"), v = P("DLP_PIC_G" .. k .. "_V"), h = P("DLP_PIC_G" .. k .. "_H")}
		end
		for k = 1, 2 do H.pic.k[k] = P("DLP_PIC_K" .. k) end
	end
	local h = H.pic
	local t, ox, oz = C.t or 0, C.ox or 0, C.oz or 0
	local unit_m = C.unit_m or 1000
	-- which side: M.pic_show HOSTILE / FRIENDLY / ALL (bottom 5); always by range
	M.pic_show = M.pic_show or "HOSTILE"
	local gs = {}
	if DL_TAC and C.contacts then
		if M.pic_show ~= "FRIENDLY" then gs = DL_TAC.groups(C.contacts, t, ox, oz, "H") end
		if M.pic_show ~= "HOSTILE" then
			for _, g in ipairs(DL_TAC.groups(C.contacts, t, ox, oz, "F")) do gs[#gs + 1] = g end
		end
	end
	M.pic_call = M.pic_call or "BULL"
	table.sort(gs, function(a, b) return a.d2 < b.d2 end)
	local n_all = #gs
	while #gs > 5 do table.remove(gs) end
	M.pic_groups = gs
	-- keep the selected group selected while the list re-sorts
	local sel = nil
	if M.pic_sel_pos then
		local bd = (CFG.pic_keep_m or 20000) ^ 2
		for k, g in ipairs(gs) do
			local d = (g.x - M.pic_sel_pos[1]) ^ 2 + (g.z - M.pic_sel_pos[2]) ^ 2
			if d < bd then sel, bd = k, d end
		end
	end
	if not sel and #gs > 0 then sel = 1 end
	M.pic_sel = sel
	if sel then M.pic_sel_pos = {gs[sel].x, gs[sel].z} end
	local be = C.be
	local bx, bz = be and be[1], be and be[2]
	if not (fin(bx) and fin(bz)) then be, bx, bz = nil, nil, nil end
	local function brg_rng(fx, fz, x, z, um)
		local b, d = bra(fx, fz, x, z, um)
		return string.format("%03d/%d", b, math.floor(d + 0.5))
	end
	-- v1.7.2: bullseye ranges in bullseye_units and altitudes in alt_units,
	-- the same as the SA page (v1.7.1 always used the range units / metres)
	local be_um = (CFG.bullseye_units == "nm" and 1852) or (CFG.bullseye_units == "km" and 1000) or unit_m
	local be_ul = (CFG.bullseye_units == "nm" and "NM") or (CFG.bullseye_units == "km" and "KM") or (C.unit_lbl or "KM")
	local alt_txt = (DL_TAC and DL_TAC.alt_txt) or function(y) return tostring(math.floor((y or 0) / 100 + 0.5) * 100) end
	local status = C.dl_status or ""
	if status:find("NO DL") or status:find("DL OFF") then
		T(h.hdr, status)
	else
		T(h.hdr, string.format("%d GROUP%s%s", n_all, (n_all == 1) and "" or "S", be and "   BULLSEYE" or "   NO BULLSEYE"))
	end
	T(h.sort, M.pic_show)
	T(h.show, ({HOSTILE = "HOST", FRIENDLY = "FRND", ALL = "ALL"})[M.pic_show])
	T(h.l2, (M.pic_call == "BRAA" or not be) and "CALL\nBRAA" or "CALL\nBULL")
	for k = 1, 5 do
		local g, r = gs[k], h.r[k]
		if g then
			local size = (g.n > 1) and string.format("%d %s", g.n, g.type or "?") or ("1 " .. (g.type or "?"))
			T(r.txt, string.format("%-3d %-7s %-9s %5s %-8s %s", k, be and brg_rng(bx, bz, g.x, g.z, be_um) or "---",
				brg_rng(ox, oz, g.x, g.z, unit_m), alt_txt(g.y), size:sub(1, 8), DL_TAC.aspect(g, ox, oz)))
			r.s:set((k == sel) and 1 or 0)
			r.rv:set(1)
			r.c:set(g.friend and 2 or 1)
		else
			T(r.txt, " "); r.s:set(0); r.rv:set(0)
		end
	end
	-- the call for the selected group (the box in the list says which one)
	local braa = (M.pic_call == "BRAA") or not be
	if #gs == 0 then
		-- (no datalink: old contacts are not listed, so "clean" would be wrong)
		local nodl = status:find("NO DL")
		T(h.k[1], nodl and "NO DL - NO CURRENT PICTURE." or "PICTURE CLEAN."); T(h.k[2], " ")
	else
		local g = gs[sel]
		local alt = alt_txt(g.y)
		local asp = DL_TAC.aspect(g, ox, oz)
		-- (with the range unit, as the SA page's BE readout: the two can differ)
		if braa then
			T(h.k[1], string.format("BRAA %s%s, %s, %s,", brg_rng(ox, oz, g.x, g.z, unit_m), C.unit_lbl or "KM", alt, asp))
		else
			T(h.k[1], string.format("BULLS %s%s, %s, %s,", brg_rng(bx, bz, g.x, g.z, be_um), be_ul, alt, asp))
		end
		local sz = (g.n == 1) and "SINGLE" or ((g.n >= 3) and string.format("HEAVY, %d SHIP", g.n) or string.format("%d SHIP", g.n))
		T(h.k[2], string.format("%s, %s%s.", g.friend and "FRIENDLY" or "HOSTILE", sz, g.type and (" " .. g.type) or ""))
	end
	-- plot: north up around the bullseye (CALL BULL) or the jet (CALL BRAA), range to fit
	local cx, cz = ox, oz
	if not braa then cx, cz = bx, bz end
	local far = 0
	for _, g in ipairs(gs) do far = math.max(far, math.sqrt((g.x - cx) ^ 2 + (g.z - cz) ^ 2)) end
	far = math.max(far, math.sqrt((ox - cx) ^ 2 + (oz - cz) ^ 2))
	if be then far = math.max(far, math.sqrt((bx - cx) ^ 2 + (bz - cz) ^ 2)) end
	-- plot range: AUTO = fit everything, else the step picked with RNG+ / RNG-
	local scale = 400
	for _, sc in ipairs({25, 50, 100, 200, 400}) do if far * 1.1 <= sc * unit_m then scale = sc; break end end
	if M.pic_scale then scale = M.pic_scale else M.pic_auto_scale = scale end
	h.auto:set(M.pic_scale and 0 or 1)
	T(h.pr, string.format("%d%s", scale, C.unit_lbl or "KM"))
	local PR = CFG.pic_plot_r or 0.40
	local kk = PR / (scale * unit_m)
	h.be:set(be and 1 or 0)
	if be then h.bx:set((bz - cz) * kk); h.by:set((bx - cx) * kk) end
	h.ox:set((oz - cz) * kk); h.oy:set((ox - cx) * kk); h.ov:set(1); h.oh:set(-(fin(C.hdg) and C.hdg or 0))
	for k = 1, 5 do
		local g, e = gs[k], h.g[k]
		if g then
			e.x:set((g.z - cz) * kk); e.y:set((g.x - cx) * kk)
			e.h:set(-math.atan2(g.vz, g.vx))
			e.v:set((g.friend and 2 or 0) + ((k == sel) and 2 or 1))
		else
			e.v:set(0)
		end
	end
end

-- v1.7.2: the first error of each page (and of the TOT parts) is logged;
-- v1.7.1 logged only the very first error of the session. Bounded: one
-- line per page, at most 20.
local function log_err(what, e)
	M.err_logged = M.err_logged or {n = 0}
	local L = M.err_logged
	if L[what] or L.n >= 20 then return end
	L[what], L.n = true, L.n + 1
	M.dbg(what .. ": " .. tostring(e))
end
function DL_PAGES.update(C)
	H.mode:set(DL_PAGES.mode)
	local lvl = M.brt[M.night and "night" or "day"]
	H.dim:set(10 - lvl)                                   -- 0 = full brightness
	H.night:set(M.night and 1 or 0)
	H.brt_show:set(((C.t or 0) - M.brt_t) < 2.5 and 1 or 0)
	T(H.brt_txt, M.toast or string.format("%s  BRT %d/10", M.night and "NIGHT" or "DAY", lvl))
	local m = DL_PAGES.mode
	if m == 6 and M.plan_view ~= 1 then DL_PAGES.mode = 12; m = 12 end     -- the old PLAN page is part of NAV now
	if m ~= 8 and not (m == 4 and M.entry == "BNG") and not ((m == 12 or m == 15) and (M.entry == "TOT" or M.entry == "LL" or M.entry == "MGRS")) then M.entry = nil end
	if (M.entry == "LL" or M.entry == "MGRS") and ((m == 12) ~= (M.entry_for == "NAV" or M.entry_for == nil)) then M.entry = nil end
	if not M.entry then M.entry_for = nil end
	T(H.HSI_ENTRY, M.entry and (M.entry .. " " .. M.buf .. "_") or "")
	pcall(sample_fuel, C)
	DL_PAGES.ff, DL_PAGES.bingo = measured_flow(), M.bingo     -- for the intercept readout (dl_tac)
	pcall(track_flight, C)
	pcall(check_bingo, C)
	pcall(check_launch, C)
	-- TOTs belong to one plan: a different plan starts without them
	local pk = C.plan and (tostring(C.plan.name) .. "/" .. tostring(C.plan.nrt_base or C.plan.nrt) .. "/" .. tostring(C.plan.rte_sig or "")) or ""
	if M.tot_key ~= pk then M.tot_key, M.tots, M.tot_pt = pk, {}, nil end
	if m == 12 then
		local okt, R = pcall(tot_calc, C)
		if okt then
			local okd, e = pcall(upd_tot, C, R)
			if not okd then log_err("tot display", e) end
		else log_err("tot calc", R) end
	elseif (m == 8 or (m == 6 and M.plan_view ~= 1)) and (C.t or 0) >= (M.ti_next or 0) then
		-- HSI route strip and FPL list: route timing (M.ti) fresh once a
		-- second here too (it used to be worked out on the NAV page only)
		M.ti_next = (C.t or 0) + 1
		local okt, R = pcall(tot_calc, C)
		if not okt then log_err("tot calc", R) end
	end
	M.now = C.t
	M.cref = C
	do local x = C.feed.x or {}; M.rdo_cur = fin(x.radio_ch) and (math.floor(x.radio_ch / 0.05 + 0.5) + 1) or nil end
	local ok, err = pcall(function()
		if m == 0 then upd_menu(C)
		elseif m == 4 then upd_fuel(C)
		elseif m == 5 then upd_comnav(C)
		elseif m == 6 then
			H.plan_view:set(M.plan_view)
			if M.plan_view == 1 then upd_dtc(C) else upd_fpl(C) end
		elseif m == 8 then upd_hsi(C)
		elseif m == 12 then upd_nav(C)
		elseif m == 13 then upd_rte(C)
		elseif m == 15 then upd_wed(C)
		elseif m == 14 then upd_pic(C)
		elseif m == 9 then upd_flt(C)
		elseif m == 10 then upd_rwr(C)
		elseif m == 11 then upd_sms(C)
		elseif m == 16 and DL_SNAKE then DL_SNAKE.update(C.t) end
	end)
	if not ok then log_err("page error (mode " .. m .. ")", err) end
end
