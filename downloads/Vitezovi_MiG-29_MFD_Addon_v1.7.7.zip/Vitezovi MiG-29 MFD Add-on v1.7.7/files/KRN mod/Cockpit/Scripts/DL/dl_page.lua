-----------------------------------------------------------------------
-- MiG-29 datalink SIT page (F-15 SIT style) : indicator elements
--
-- Loaded at the end of the KRN MFD's last page subset (one dofile line
-- added there), so it shares that indicator's scale, stencil and fonts
-- and draws on top of the KRN pages while it is switched on (MFD-3).
-- The map is DCS's own raster chart set for the theatre you are on
-- (see dl_theatres.lua / charts\*.lua), moved and turned every frame so
-- it stays under the aircraft, heading up.
-- All values come from DL/dl_device.lua through cockpit parameters.
-----------------------------------------------------------------------

dofile(LockOn_Options.script_path .. "DL/dl_config.lua")
dofile(LockOn_Options.script_path .. "DL/dl_theatres.lua")
pcall(dofile, LockOn_Options.script_path .. "DL/dl_geo.lua")
pcall(dofile, LockOn_Options.script_path .. "DL/dl_tac.lua")
pcall(dofile, LockOn_Options.script_path .. "DL/dl_debug.lua")

-- The whole build runs in a function under pcall: whatever goes wrong,
-- DCS's own CreateElement / Add are put back afterwards (they are wrapped
-- while our elements are built, see below), and the error is logged
-- instead of being lost in KRN's pcall around this file.
local DL_rawAdd, DL_rawCreate = Add, CreateElement
local function DL_build_page()
	local CFG   = DL_CFG
	local LVL   = MDF_DEFAULT_LEVEL or 9
	local CLIP  = h_clip_relations.COMPARE
	local OWN_Y = CFG.ownship_y
	local R     = CFG.range_radius
	-- DCS applies the indicator's SetCustomScale to vertices and init_pos, but
	-- NOT to offsets coming from controllers. The KRN MFD uses
	-- SetCustomScale(0.1 * MFD_SCALE), so controller offsets must be multiplied
	-- by that same factor to land in page units.
	local G     = CFG.move_gain or (0.1 * (MFD_SCALE or 0.45))
	local GL    = CFG.line_gain or G

	local ranges = (CFG.range_units == "nm") and CFG.ranges_nm or CFG.ranges_km
	local unit_m = (CFG.range_units == "nm") and 1852.0 or 1000.0

	-- v1.7.6 night palette (D/N switch at N, cockpit parameter DLP_NIGHT = 1):
	-- every element drawn in a known colour gets a "change colour" controller
	-- to its night colour. Data text goes softer and less white, threat red
	-- and amber keep their punch, the blue lines turn a dim grey.
	local NIGHT_PAL = {   -- day r g b -> night r g b
		{235, 235, 235, 150, 165, 145}, {170, 185, 175, 100, 110, 102}, {105, 110, 108,  62,  68,  64},
		{120, 230, 150,  95, 190, 115}, { 90, 215, 255,  80, 175, 205}, { 70, 130, 255,  75, 100, 130},
		{255, 170,  60, 255, 160,  45}, {240, 230, 110, 215, 200,  85}, {240, 100, 100, 255,  85,  75},
		{242, 160, 160, 220, 135, 130},
	}
	local NIGHT_MAT = {}       -- material / font -> {r, g, b} at night (0..1)
	local function night_of(r, g, b)
		if CFG.night_palette == false or r + g + b < 30 then return nil end   -- black stays black
		local best, bd = nil, 1e9
		for _, q in ipairs(NIGHT_PAL) do
			local d = (q[1] - r) ^ 2 + (q[2] - g) ^ 2 + (q[3] - b) ^ 2
			if d < bd then best, bd = q, d end
		end
		if bd <= 3600 then return {best[4] / 255, best[5] / 255, best[6] / 255} end
		return {r * 0.64 / 255, g * 0.70 / 255, b * 0.62 / 255}         -- any other colour: as white does
	end
	local function col(r, g, b, a)
		local m = MakeMaterial(nil, {r, g, b, a or 255})
		NIGHT_MAT[m] = night_of(r, g, b)
		return m
	end
	-- Every DL element is first built as a plain Lua table (CreateElement and
	-- Add are wrapped while our pages are built, put back at the end). DCS's
	-- own elements give their fields back as text, not as tables (seen in the
	-- sim, v1.7.6), so the night colour rule is added here, from our own
	-- tables, and only then is the real element made and handed to DCS.
	local NIGHT_CTRL = {}
	local rawAdd, rawCreate = Add, CreateElement
	local FIELD_ORDER = {"name", "primitivetype", "vertices", "indices", "tex_coords", "material", "init_pos", "init_rot",
		"alignment", "stringdefs", "formats", "value", "width", "parent_element", "h_clip_relation", "level",
		"isdraw", "isvisible", "use_mipfilter", "additive_alpha", "collimated", "element_params", "controllers"}
	local IN_ORDER = {}
	for _, k in ipairs(FIELD_ORDER) do IN_ORDER[k] = true end
	local night_err = false
	local function add_night(e)
		local c = NIGHT_MAT[e.material]
		if not c then return end
		local p, cs = {}, {}
		if type(e.element_params) == "table" then for i, v in ipairs(e.element_params) do p[i] = v end end
		if type(e.controllers) == "table" then for i, v in ipairs(e.controllers) do cs[i] = v end end
		local k = #p
		p[k + 1] = "DLP_NIGHT"
		local key = k .. "/" .. c[1] .. "/" .. c[2] .. "/" .. c[3]
		local cc = NIGHT_CTRL[key]
		if not cc then
			cc = {"change_color_when_parameter_equal_to_number", k, 1, c[1], c[2], c[3]}
			NIGHT_CTRL[key] = cc
		end
		cs[#cs + 1] = cc
		e.element_params, e.controllers = p, cs
	end
	CreateElement = function(cls) return {__dl_cls = cls} end
	Add = function(e)
		if type(e) ~= "table" or not e.__dl_cls then return rawAdd(e) end
		local ok, err = pcall(add_night, e)
		if not ok and not night_err then
			night_err = true
			if DL_dbg then DL_dbg("page", "night colours: " .. tostring(err)) end
		end
		local r = rawCreate(e.__dl_cls)
		for _, k in ipairs(FIELD_ORDER) do
			if e[k] ~= nil then r[k] = e[k] end
		end
		for k, v in pairs(e) do
			if k ~= "__dl_cls" and not IN_ORDER[k] then r[k] = v end
		end
		return rawAdd(r)
	end
	local FONT = CFG.font or "font_arial_13"
	-- page font: our thin monospaced texture font (dl_fonts.lua) or DCS's Arial
	local TEXF = CFG.font_style ~= "dcs"
	if TEXF then
		local ok_fd = pcall(dofile, LockOn_Options.script_path .. "DL/dl_font_desc.lua")
		if not ok_fd or not DL_FONT_ASPECT then TEXF = false end
	end
	local function fnt(r, g, b, name)
		local f
		if TEXF then f = "DL_F_" .. name else f = MakeFont({used_DXUnicodeFontData = FONT}, {r, g, b, 255}) end
		NIGHT_MAT[f] = night_of(r, g, b)
		return f
	end
	-- text sizes are given for Arial; the texture font gets the same capital height
	local FK  = (CFG.font_scale or 1.25)
	-- DCS sizes texture-font glyphs as height = defs[1], width = defs[2] x (glyph px width / height),
	-- so width = height keeps the letters' own proportions
	local FW  = (CFG.font_width or 1.0)
	local DEFS_CACHE = {}
	local function defs_of(d)
		if not TEXF then return d end
		local c = DEFS_CACHE[d]
		if not c then
			c = {d[1] * FK, d[1] * FK * FW, d[3] or 0, (d[4] or 0) * FK}
			DEFS_CACHE[d] = c
		end
		return c
	end
	-- width of one character in page units (monospaced font only)
	local function char_w(d) return defs_of(d)[2] * (TEXF and DL_FONT_ASPECT or 0.5) / G end

	-- F-15 SIT palette
	local C_GREEN, C_RED, C_YELLOW, C_CYAN = {120, 230, 150}, {240, 100, 100}, {240, 230, 110}, {90, 215, 255}
	local function colt(c, a) return col(c[1], c[2], c[3], a) end
	local M = {
		black   = col(0, 0, 0, 255),
		ring    = colt(C_GREEN),
		halo    = col(0, 0, 0, 235),
		white   = col(235, 235, 235, 255),
		route   = col(235, 235, 235, 220),
		wpt     = col(235, 235, 235, 255),
		own     = colt(C_CYAN),
		friend  = colt(C_GREEN),
		hostile = colt(C_RED),
		unknown = colt(C_YELLOW),
		wing    = colt(C_CYAN),
		blue    = col(70, 130, 255, 255),
		amber   = col(255, 170, 60, 255),
		amber_d = col(90, 55, 10, 255),
	}
	local F = {
		white   = fnt(235, 235, 235, "WHITE"),
		green   = fnt(C_GREEN[1], C_GREEN[2], C_GREEN[3], "GREEN"),
		red     = fnt(C_RED[1], C_RED[2], C_RED[3], "RED"),
		pink    = fnt(242, 160, 160, "PINK"),
		yellow  = fnt(C_YELLOW[1], C_YELLOW[2], C_YELLOW[3], "YELLOW"),
		amber   = fnt(255, 170, 60, "AMBER"),
		blue    = fnt(70, 130, 255, "BLUE"),
		cyan    = fnt(C_CYAN[1], C_CYAN[2], C_CYAN[3], "CYAN"),
		grey    = fnt(170, 185, 175, "GREY"),
		dim     = fnt(105, 110, 108, "DIM"),
		black   = fnt(0, 0, 0, "BLACK"),
	}
	local TXT       = {0.0044, 0.0013, 0, -0.0016}
	local TXT_SMALL = {0.0033, 0.0010, 0, -0.0012}
	local TXT_TINY  = {0.0028, 0.00085, 0, -0.0010}
	-- bezel button labels (left / right columns)
	local TXT_BTN   = CFG.btn_label_size and {CFG.btn_label_size, 0.0011, 0, -CFG.btn_label_size * 0.36} or {0.0036, 0.0011, 0, -0.0013}
	-- the map behind the scope is optional (F-15 SIT style = plain black)
	local SHOW_MAP  = (CFG.map_source or "none") ~= "none"
	-- black outline around texts: only needed over a map
	local OUTLINE   = SHOW_MAP and (CFG.text_outline or 0.006) or 0

	-- geometry helpers ---------------------------------------------------
	local function circle_fill(r, n)
		local v, idx = {{0, 0}}, {}
		n = n or 16
		for i = 0, n - 1 do
			local a = 2 * math.pi * i / n
			v[#v + 1] = {r * math.cos(a), r * math.sin(a)}
		end
		for i = 1, n do
			idx[#idx + 1] = 0
			idx[#idx + 1] = i
			idx[#idx + 1] = (i % n) + 1
		end
		return v, idx
	end
	local function poly_lines(pts)
		local idx = {}
		for i = 0, #pts - 1 do
			idx[#idx + 1] = i
			idx[#idx + 1] = (i + 1) % #pts
		end
		return pts, idx
	end

	-- thick outline between two closed outlines with the same vertex count
	local function band(outer, inner)
		local v, idx, n = {}, {}, #outer
		for k = 1, n do v[k] = outer[k]; v[n + k] = inner[k] end
		for k = 0, n - 1 do
			local a, b = k, (k + 1) % n
			idx[#idx + 1] = a; idx[#idx + 1] = b; idx[#idx + 1] = n + b
			idx[#idx + 1] = a; idx[#idx + 1] = n + b; idx[#idx + 1] = n + a
		end
		return v, idx
	end
	local function circle_pts(r, n)
		local v = {}
		for k = 0, n - 1 do
			local a = 2 * math.pi * k / n
			v[#v + 1] = {r * math.cos(a), r * math.sin(a)}
		end
		return v
	end
	local function circle_ring(r, t, n) return band(circle_pts(r, n or 20), circle_pts(r - t, n or 20)) end
	local function scaled(pts, f)
		local v = {}
		for k, p in ipairs(pts) do v[k] = {p[1] * f, p[2] * f} end
		return v
	end
	-- apothem = distance from centre to the edges (for an even band width)

	local function mesh(name, parent, prim, v, idx, mat, pos, params, ctrls)
		local e = CreateElement "ceMeshPoly"
		e.name            = name
		e.primitivetype   = prim
		e.vertices        = v
		e.indices         = idx
		e.material        = mat
		e.init_pos        = pos or {0, 0, 0}
		e.parent_element  = parent
		e.h_clip_relation = CLIP
		e.level           = LVL
		e.isdraw          = true
		e.isvisible       = true
		if params then e.element_params = params end
		if ctrls then e.controllers = ctrls end
		Add(e)
		return e
	end
	local function simple(name, parent, pos, params, ctrls)
		local e = CreateElement "ceSimple"
		e.name     = name
		e.init_pos = pos or {0, 0, 0}
		if parent then e.parent_element = parent end
		if params then e.element_params = params end
		if ctrls then e.controllers = ctrls end
		Add(e)
		return e
	end
	-- text with a thin black outline: 8 black copies around it, then the text.
	-- vis = {param, lo, hi} optionally limits when it is shown.
	local function text1(name, parent, pos, font, defs, align, value, param, vis)
		local e = CreateElement "ceStringPoly"
		e.name            = name
		e.material        = font
		e.init_pos        = pos
		e.alignment       = align or "CenterCenter"
		e.stringdefs      = defs_of(defs or TXT)
		e.parent_element  = parent
		e.h_clip_relation = CLIP
		e.level           = LVL
		local params, ctrls = {}, {}
		if param then
			e.formats = {"%s"}
			params[#params + 1] = param
			ctrls[#ctrls + 1] = {"text_using_parameter", #params - 1}
		else
			e.value = value
		end
		if vis then
			params[#params + 1] = vis[1]
			ctrls[#ctrls + 1] = {"parameter_in_range", #params - 1, vis[2], vis[3]}
		end
		if #params > 0 then
			e.element_params = params
			e.controllers    = ctrls
		end
		Add(e)
		return e
	end
	local OUT_DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {0.7, 0.7}, {-0.7, 0.7}, {0.7, -0.7}, {-0.7, -0.7}}
	local function text(name, parent, pos, font, defs, align, value, param, vis)
		if OUTLINE > 0 then
			for k, d in ipairs(OUT_DIRS) do
				text1(name .. "_o" .. k, parent, {pos[1] + d[1] * OUTLINE, pos[2] + d[2] * OUTLINE, 0},
					F.black, defs, align, value, param, vis)
			end
		end
		return text1(name, parent, pos, font, defs, align, value, param, vis)
	end
	local function line_obj(name, parent, mat, width, params, ctrls)
		local e = CreateElement "ceSimpleLineObject"
		e.name            = name
		e.material        = mat
		e.width           = width
		e.vertices        = {{0, 0}, {0, 0}}
		e.init_pos        = {0, 0, 0}
		e.parent_element  = parent
		e.use_mipfilter   = true
		e.additive_alpha  = false
		e.h_clip_relation = CLIP
		e.level           = LVL
		e.element_params  = params
		e.controllers     = ctrls
		Add(e)
		return e
	end

	-- page root (visible while DL_PAGE is 1 or 2) -------------------------
	-- the DL (situation) page: DL_MODE 1 (see dl_pages.lua for the others)
	simple("dl_root", nil, {0, 0, 0}, {"DL_PAGE", "DL_MODE"},
		{{"parameter_in_range", 0, 0.5, 2.5}, {"parameter_in_range", 1, 0.5, 1.5}})

	-- opaque background hiding the KRN page underneath
	mesh("dl_bg", "dl_root", "triangles",
		{{-1.1, 1.6}, {1.1, 1.6}, {1.1, -1.6}, {-1.1, -1.6}}, {0, 1, 2, 0, 2, 3}, M.black)

	-- ownship-centred frame
	simple("dl_own", "dl_root", {0, OWN_Y, 0}, {"DL_OWN_DY"}, {{"move_up_down_using_parameter", 0, G}})

	-- moving map: rotate about ownship by heading, then shift so that the
	-- ownship's world position sits at the origin
	simple("dl_rot", "dl_own", {0, 0, 0}, {"DL_MAP_ROT"}, {{"rotate_using_parameter", 0, 1}})
	simple("dl_shift", "dl_rot", {0, 0, 0}, {"DL_MAP_DX", "DL_MAP_DY"},
		{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})

	-- DCS's own raster charts for the theatre we are on. One quad per
	--     chart tile and range step; the device switches on only the tiles
	--     around the aircraft (DL_T<n> = range step), so DCS only loads
	--     those textures.
	if (CFG.map_source or "none") == "dcs" then
		local ok_d, theatre = pcall(DL_detect_theatre)
		local chart = ok_d and DL_load_chart(theatre) or nil
		local built = 0
		if chart then
			for ri, ci in ipairs(chart.range_class) do
				local rng = ranges[ri]
				if ci and ci > 0 and rng then
					local k = R / (rng * unit_m)
					for n, t in ipairs(chart.tiles) do
						if t[6] == ci then
							local x0, z0, x1, z1 = t[2] * k, t[3] * k, t[4] * k, t[5] * k
							local e = CreateElement "ceTexPoly"
							e.name            = "dl_t_" .. ri .. "_" .. n
							e.primitivetype   = "triangles"
							e.vertices        = {{z0, x1}, {z1, x1}, {z1, x0}, {z0, x0}}
							e.indices         = {0, 1, 2, 0, 2, 3}
							e.tex_coords      = {{0, 0}, {1, 0}, {1, 1}, {0, 1}}
							e.material        = "DLT_" .. n
							e.init_pos        = {0, 0, 0}
							e.parent_element  = "dl_shift"
							e.h_clip_relation = CLIP
							e.level           = LVL
							e.element_params  = {"DL_T" .. n}
							e.controllers     = {{"parameter_in_range", 0, ri - 0.1, ri + 0.1}}
							Add(e)
							built = built + 1
						end
					end
				end
			end
		end
		if DL_dbg then DL_dbg("page", "move_gain=" .. G .. " line_gain=" .. GL .. " theatre=" .. tostring(theatre) .. " (detect ok=" .. tostring(ok_d) .. ") chart quads built=" .. built) end
	end

	-- dim the chart so the symbols on top stay readable
	local dim = math.floor(255 * (CFG.map_dim or 0) + 0.5)
	if SHOW_MAP and dim > 0 then
		mesh("dl_dim", "dl_root", "triangles",
			{{-1.1, 1.6}, {1.1, 1.6}, {1.1, -1.6}, {-1.1, -1.6}}, {0, 1, 2, 0, 2, 3}, col(0, 0, 0, dim))
	end

	-------------------------------------------------------------------------
	-- geo drawings from the cartridge's .geo.txt (dl_geo.lua): pools of line
	-- pieces per colour and a few labels, all placed by the device in the
	-- ownship frame. Drawn under the scope, route, threats and contacts.
	-------------------------------------------------------------------------
	do
		local POOLS = DL_GEO_POOLS or {r = 72, p = 56, c = 150, g = 110}
		local GM = {r = col(240, 96, 95, 255), p = col(242, 160, 160, 255), c = col(111, 210, 230, 255), g = col(163, 171, 175, 255)}
		local GW = CFG.geo_line_width or 0.004
		for _, pool in ipairs({"g", "c", "p", "r"}) do
			for i = 1, (POOLS[pool] or 0) do
				local pre = "DL_GEO_" .. pool .. i .. "_"
				line_obj("dl_geo_" .. pool .. i, "dl_own", GM[pool], GW,
					{pre .. "X1", pre .. "Y1", pre .. "X2", pre .. "Y2", pre .. "V"},
					{{"line_object_set_point_using_parameters", 0, 0, 1, GL, GL},
					 {"line_object_set_point_using_parameters", 1, 2, 3, GL, GL},
					 {"parameter_in_range", 4, 0.5, 1.5}})
			end
		end
		-- labels: DL_GEO_L<n>_C = 1 red, 2 pink, 3 cyan, 4 grey (0 = off)
		local LF = {F.red, F.pink or F.red, F.cyan, F.grey}
		for n = 1, (DL_GEO_LABELS or 12) do
			local pre = "DL_GEO_L" .. n .. "_"
			simple("dl_geo_l" .. n, "dl_own", {0, 0, 0}, {pre .. "X", pre .. "Y", pre .. "C"},
				{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
				 {"parameter_in_range", 2, 0.5, 4.5}})
			if OUTLINE > 0 then
				for k, d in ipairs(OUT_DIRS) do
					text1("dl_geo_l" .. n .. "_o" .. k, "dl_geo_l" .. n, {d[1] * OUTLINE, d[2] * OUTLINE, 0}, F.black, TXT_SMALL, "LeftCenter", nil, pre .. "T")
				end
			end
			for c, f in ipairs(LF) do
				text1("dl_geo_l" .. n .. "_" .. c, "dl_geo_l" .. n, {0, 0, 0}, f, TXT_SMALL, "LeftCenter", nil, pre .. "T", {pre .. "C", c - 0.1, c + 0.1})
			end
		end
	end

	-------------------------------------------------------------------------
	-- SIT-style scope: range circle, 30 deg ticks and compass letters that
	-- turn with heading, ownship in the middle
	-------------------------------------------------------------------------
	local LW = CFG.line_width or 0.007          -- line width of rings and symbols
	-- range circle, ticks and letters: hidden in the expanded (EXP) view
	simple("dl_scope", "dl_own", {0, 0, 0}, {"DL_EXP"}, {{"parameter_in_range", 0, -0.5, 0.5}})
	simple("dl_scope_rot", "dl_scope", {0, 0, 0}, {"DL_MAP_ROT"}, {{"rotate_using_parameter", 0, 1}})
	local v, i = circle_ring(R + LW / 2, LW, 96)
	mesh("dl_ring_full", "dl_scope", "triangles", v, i, M.ring)

	-- ticks every 30 deg (not at N/E/S/W, the letters sit there); drawn
	-- north-up and turned with the map rotation
	do
		local tv, ti = {}, {}
		for deg = 30, 330, 30 do
			if deg % 90 ~= 0 then
				local a  = math.rad(90 - deg)
				local ca, sa = math.cos(a), math.sin(a)
				local px, py = -sa * LW / 2, ca * LW / 2      -- half-width across the tick
				local r0, r1 = R - 0.06, R
				local k = #tv
				tv[k + 1] = {r0 * ca + px, r0 * sa + py}; tv[k + 2] = {r1 * ca + px, r1 * sa + py}
				tv[k + 3] = {r1 * ca - px, r1 * sa - py}; tv[k + 4] = {r0 * ca - px, r0 * sa - py}
				ti[#ti + 1] = k; ti[#ti + 1] = k + 1; ti[#ti + 1] = k + 2
				ti[#ti + 1] = k; ti[#ti + 1] = k + 2; ti[#ti + 1] = k + 3
			end
		end
		mesh("dl_ticks", "dl_scope_rot", "triangles", tv, ti, M.ring)
	end
	for _, c in ipairs({"N", "E", "S", "W"}) do
		simple("dl_card_" .. c, "dl_scope", {0, 0, 0}, {"DL_CARD_" .. c .. "_X", "DL_CARD_" .. c .. "_Y"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})
		text("dl_card_" .. c .. "_lbl", "dl_card_" .. c, {0, 0, 0}, F.green, TXT, "CenterCenter", c)
	end

	-- ownship (cyan, like the F-15 SIT)
	v, i = poly_lines({{0, 0.06}, {0.010, 0.026}, {0.048, 0.0}, {0.048, -0.010}, {0.009, 0.0},
		{0.007, -0.034}, {0.022, -0.047}, {0, -0.043}, {-0.022, -0.047}, {-0.007, -0.034},
		{-0.009, 0.0}, {-0.048, -0.010}, {-0.048, 0.0}, {-0.010, 0.026}})
	simple("dl_ownpos", "dl_own", {0, 0, 0}, {"DL_OWN_SX", "DL_OWN_SY"},
		{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})
	mesh("dl_ownship", "dl_ownpos", "lines", v, i, M.own)

	-- route (the steerpoints loaded in the jet) ------------------------------
	--  DL_W<n>_VIS: 1 = steerpoint, 2 = active steerpoint
	for n = 1, DL_MAX_WPTS do
		if n > 1 then
			line_obj("dl_leg_" .. n, "dl_own", M.route, 0.005,
				{"DL_W" .. (n - 1) .. "_X", "DL_W" .. (n - 1) .. "_Y", "DL_W" .. n .. "_X", "DL_W" .. n .. "_Y", "DL_W" .. n .. "_SEG"},
				{{"line_object_set_point_using_parameters", 0, 0, 1, GL, GL},
				 {"line_object_set_point_using_parameters", 1, 2, 3, GL, GL},
				 {"parameter_in_range", 4, 0.5, 1.5}})
		end
		simple("dl_w" .. n, "dl_own", {0, 0, 0}, {"DL_W" .. n .. "_X", "DL_W" .. n .. "_Y", "DL_W" .. n .. "_VIS"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 3.5}})
		if SHOW_MAP then
			v, i = circle_ring(0.034, 0.018, 20)
			mesh("dl_w" .. n .. "_halo", "dl_w" .. n, "triangles", v, i, M.halo)
		end
		-- waypoint: circle (VIS 1), airfield: square (VIS 3)
		v, i = circle_ring(0.026, LW, 20)
		mesh("dl_w" .. n .. "_sym", "dl_w" .. n, "triangles", v, i, M.wpt, nil,
			{"DL_W" .. n .. "_VIS"}, {{"parameter_in_range", 0, 0.5, 2.5}})
		do
			local q = 0.024
			local av, ai = band({{-q, q}, {q, q}, {q, -q}, {-q, -q}}, {{-q + LW, q - LW}, {q - LW, q - LW}, {q - LW, -q + LW}, {-q + LW, -q + LW}})
			mesh("dl_w" .. n .. "_ad", "dl_w" .. n, "triangles", av, ai, M.wpt, nil,
				{"DL_W" .. n .. "_VIS"}, {{"parameter_in_range", 0, 2.5, 3.5}})
		end
		v, i = circle_ring(0.044, LW, 24)
		mesh("dl_w" .. n .. "_act", "dl_w" .. n, "triangles", v, i, M.unknown, nil,
			{"DL_W" .. n .. "_VIS"}, {{"parameter_in_range", 0, 1.5, 2.5}})
		text("dl_w" .. n .. "_lbl", "dl_w" .. n, {0.04, 0.03, 0}, F.white, TXT_SMALL, "LeftCenter", nil, "DL_W" .. n .. "_TXT")
	end
	-- markpoints M1..M5 (SA page B1 MARK): amber diamond with an X
	for n = 1, 5 do
		simple("dl_mk" .. n, "dl_own", {0, 0, 0}, {"DL_MK" .. n .. "_X", "DL_MK" .. n .. "_Y", "DL_MK" .. n .. "_VIS"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 1.5}})
		local q = 0.032
		local dv, di = band({{0, q}, {q, 0}, {0, -q}, {-q, 0}}, {{0, q - LW * 1.4}, {q - LW * 1.4, 0}, {0, -q + LW * 1.4}, {-q + LW * 1.4, 0}})
		mesh("dl_mk" .. n .. "_d", "dl_mk" .. n, "triangles", dv, di, M.amber)
		local xv, xi = poly_lines({{-0.012, 0.012}, {0.012, -0.012}})
		mesh("dl_mk" .. n .. "_x1", "dl_mk" .. n, "lines", xv, xi, M.amber)
		xv, xi = poly_lines({{-0.012, -0.012}, {0.012, 0.012}})
		mesh("dl_mk" .. n .. "_x2", "dl_mk" .. n, "lines", xv, xi, M.amber)
		text("dl_mk" .. n .. "_lbl", "dl_mk" .. n, {0.045, -0.03, 0}, F.amber, TXT_SMALL, "LeftCenter", "M" .. n)
	end
	-- the selected waypoint / airfield: yellow ring (also when it is not part
	-- of the drawn route, e.g. an airfield chosen on the NAV panel)
	simple("dl_act", "dl_own", {0, 0, 0}, {"DL_ACT_X", "DL_ACT_Y", "DL_ACT_VIS"},
		{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
		 {"parameter_in_range", 2, 0.5, 1.5}})
	v, i = circle_ring(0.046, LW, 24)
	mesh("dl_act_ring", "dl_act", "triangles", v, i, M.unknown)
	-- line from the aircraft to the active steerpoint
	line_obj("dl_to_active", "dl_own", M.unknown, 0.004, {"DL_WA_X", "DL_WA_Y", "DL_WA_VIS"},
		{{"line_object_set_point_using_parameters", 1, 0, 1, GL, GL}, {"parameter_in_range", 2, 0.5, 1.5}})

	-------------------------------------------------------------------------
	-- ground threats (enemy SAM / EWR picked up by a friendly aircraft):
	-- label at the site, ring = approximate lethal range.
	-- Yellow while you are outside the ring, red once you are inside it.
	-------------------------------------------------------------------------
	local NSEG = DL_RING_SEGMENTS or 24
	for g = 1, (DL_MAX_THREATS or 16) do
		local pre = "DL_G" .. g
		for j = 1, NSEG do
			local j2 = j % NSEG + 1
			for ci, cm in ipairs({M.unknown, M.hostile}) do
				line_obj("dl_g" .. g .. "_r" .. ci .. "_" .. j, "dl_own", cm, 0.004,
					{pre .. "_P" .. j .. "_X", pre .. "_P" .. j .. "_Y", pre .. "_P" .. j2 .. "_X", pre .. "_P" .. j2 .. "_Y", pre .. "_RING"},
					{{"line_object_set_point_using_parameters", 0, 0, 1, GL, GL},
					 {"line_object_set_point_using_parameters", 1, 2, 3, GL, GL},
					 {"parameter_in_range", 4, ci - 0.5, ci + 0.5}})
			end
		end
		simple("dl_g" .. g, "dl_own", {0, 0, 0}, {pre .. "_X", pre .. "_Y", pre .. "_VIS"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 1.5}})
		text1("dl_g" .. g .. "_lbl_y", "dl_g" .. g, {0, 0, 0}, F.yellow, TXT_SMALL, "CenterCenter", nil, pre .. "_TXT",
			{pre .. "_RING", -0.5, 1.5})
		text1("dl_g" .. g .. "_lbl_r", "dl_g" .. g, {0, 0, 0}, F.red, TXT_SMALL, "CenterCenter", nil, pre .. "_TXT",
			{pre .. "_RING", 1.5, 2.5})
	end

	-------------------------------------------------------------------------
	-- contacts, F-15 SIT symbology
	--   type 1 friendly  green circle          2 hostile  red triangle (nose = course)
	--        3 unknown   yellow square         4 AWACS    green circle + dot
	--        5 own flight cyan circle
	--   1..4 = given by the datalink -> DOTTED;  +10 = own radar holds it -> SOLID
	--   own flight is always solid. Short line = course. Number above = altitude.
	-------------------------------------------------------------------------
	local S  = CFG.symbol_size or 0.045
	local HB = 0.012
	-- dashed version of band(): only every other piece of the outline
	local function dashed(outer, inner, sub)
		local v, idx, n = {}, {}, #outer
		local O, I = {}, {}
		for k = 1, n do
			local a, b = outer[k], outer[k % n + 1]
			local c, d = inner[k], inner[k % n + 1]
			for j = 0, sub - 1 do
				local t = j / sub
				O[#O + 1] = {a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t}
				I[#I + 1] = {c[1] + (d[1] - c[1]) * t, c[2] + (d[2] - c[2]) * t}
			end
		end
		local m = #O
		for k = 1, m do v[k] = O[k]; v[m + k] = I[k] end
		for k = 0, m - 1, 2 do
			local a, b = k, (k + 1) % m
			idx[#idx + 1] = a; idx[#idx + 1] = b; idx[#idx + 1] = m + b
			idx[#idx + 1] = a; idx[#idx + 1] = m + b; idx[#idx + 1] = m + a
		end
		return v, idx
	end
	-- distance from the origin to the nearest edge of a closed polygon
	local function inradius(pts)
		local best = 1e9
		for k = 1, #pts do
			local a, b = pts[k], pts[k % #pts + 1]
			local ex, ey = b[1] - a[1], b[2] - a[2]
			local d = math.abs(a[1] * ey - a[2] * ex) / math.sqrt(ex * ex + ey * ey)
			if d < best then best = d end
		end
		return best
	end
	local function outline(pts, w, dash, sub)
		local inner = scaled(pts, 1 - w / inradius(pts))
		if dash then return dashed(pts, inner, sub) end
		return band(pts, inner)
	end
	local tri = function(r) return {{0, r * 1.2}, {r * 0.9, -r * 0.75}, {-r * 0.9, -r * 0.75}} end
	local sqr = function(r) return {{-r, r}, {r, r}, {r, -r}, {-r, -r}} end
	local function grow(pts, d)
		local f = 1 + d / inradius(pts)
		return scaled(pts, f)
	end
	local rc, rs, rt = S * 0.85, S * 0.75, S * 0.9
	local CIRC  = circle_pts(rc, 24)
	local CIRCA = circle_pts(rc * 1.25, 28)
	local TRI   = tri(rt)
	local SQR   = sqr(rs)
	-- [code] = {points, dotted?, turns with course?}
	local shapes = {
		[1]  = {CIRC,  true,  false}, [11] = {CIRC,  false, false},
		[2]  = {TRI,   true,  true},  [12] = {TRI,   false, true},
		[3]  = {SQR,   true,  false}, [13] = {SQR,   false, false},
		[4]  = {CIRCA, true,  false}, [14] = {CIRCA, false, false},
		[5]  = {CIRC,  false, false}, [15] = {CIRC,  false, false},
		[6]  = {CIRC,  true,  false}, [16] = {CIRC,  false, false},   -- datalink fighter (donor)
	}
	local mats = {[1] = M.friend, [2] = M.hostile, [3] = M.unknown, [4] = M.friend, [5] = M.wing, [6] = M.friend}
	local awacs_dot_v, awacs_dot_i = circle_fill(S * 0.25, 10)

	for n = 1, DL_MAX_CONTACTS do
		local base = "dl_c" .. n
		local pt   = "DL_C" .. n .. "_TYPE"
		simple(base, "dl_own", {0, 0, 0}, {"DL_C" .. n .. "_X", "DL_C" .. n .. "_Y", pt},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 99}})
		-- course: rotates the hostile triangle and the course line
		simple(base .. "_rot", base, {0, 0, 0}, {"DL_C" .. n .. "_HDG"}, {{"rotate_using_parameter", 0, 1}})

		for code, sh in pairs(shapes) do
			local parent = sh[3] and (base .. "_rot") or base
			local vis = {{"parameter_in_range", 0, code - 0.1, code + 0.1}}
			if SHOW_MAP then
				local hv, hi = band(grow(sh[1], HB), scaled(sh[1], 1 - (LW + HB) / inradius(sh[1])))
				mesh(base .. "_h" .. code, parent, "triangles", hv, hi, M.halo, nil, {pt}, vis)
			end
			local sv, si = outline(sh[1], LW, sh[2], (#sh[1] > 8) and 1 or 3)
			mesh(base .. "_s" .. code, parent, "triangles", sv, si, mats[code % 10], nil, {pt}, vis)
		end
		-- AWACS / donor dot
		mesh(base .. "_awdot", base, "triangles", awacs_dot_v, awacs_dot_i, M.friend, nil,
			{pt}, {{"parameter_in_range", 0, 3.9, 4.1}})
		mesh(base .. "_awdot2", base, "triangles", awacs_dot_v, awacs_dot_i, M.friend, nil,
			{pt}, {{"parameter_in_range", 0, 13.9, 14.1}})
		mesh(base .. "_dndot", base, "triangles", awacs_dot_v, awacs_dot_i, M.friend, nil,
			{pt}, {{"parameter_in_range", 0, 5.9, 6.1}})
		mesh(base .. "_dndot2", base, "triangles", awacs_dot_v, awacs_dot_i, M.friend, nil,
			{pt}, {{"parameter_in_range", 0, 15.9, 16.1}})
		-- course line, in the contact's colour (DL_C<n>_COL 1 green 2 red 3 yellow 4 cyan)
		local L0, L1 = S * 0.9, S * 0.9 + (CFG.course_line or 0.07)
		local lv = {{-LW / 2, L0}, {LW / 2, L0}, {LW / 2, L1}, {-LW / 2, L1}}
		local cmats = {M.friend, M.hostile, M.unknown, M.wing}
		for ci, cm in ipairs(cmats) do
			mesh(base .. "_crs" .. ci, base .. "_rot", "triangles", lv, {0, 1, 2, 0, 2, 3}, cm, nil,
				{"DL_C" .. n .. "_COL", "DL_C" .. n .. "_MOV"},
				{{"parameter_in_range", 0, ci - 0.1, ci + 0.1}, {"parameter_in_range", 1, 0.5, 1.5}})
		end
		-- altitude (and Mach) above the symbol, in the contact's colour.
		-- v1.7.6: the label hangs on its own point, which SYM 2 / 3 can move
		-- under or beside the symbol when labels would cover each other
		local lbl = base .. "_lbl"
		simple(lbl, base, {0, 0, 0}, {"DL_C" .. n .. "_TX", "DL_C" .. n .. "_TY"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G}})
		local tpos = {0, S * 1.35, 0}
		if OUTLINE > 0 then
			for k, d in ipairs(OUT_DIRS) do
				text1(base .. "_alt_o" .. k, lbl, {tpos[1] + d[1] * OUTLINE, tpos[2] + d[2] * OUTLINE, 0},
					F.black, TXT_SMALL, "CenterBottom", nil, "DL_C" .. n .. "_TXT")
			end
		end
		local cfonts = {F.green, F.red, F.yellow, F.cyan}
		for ci, cf in ipairs(cfonts) do
			text1(base .. "_alt" .. ci, lbl, tpos, cf, TXT_SMALL, "CenterBottom", nil, "DL_C" .. n .. "_TXT",
				{"DL_C" .. n .. "_COL", ci - 0.1, ci + 0.1})
		end
	end

	-- cursor: a full square (v1.7.6; was two short bars). A little smaller
	-- than the radar lock box, so cursor on a locked target = two squares.
	simple("dl_curs", "dl_own", {0, 0, 0}, {"DL_CURS_X", "DL_CURS_Y", "DL_CURS"},
		{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
		 {"parameter_in_range", 2, 0.5, 1.5}})
	do
		local b = S * (CFG.cursor_box or 1.45)
		local cv, ci = band(sqr(b), sqr(b - LW))
		mesh("dl_curs_sym", "dl_curs", "triangles", cv, ci, M.white)
	end
	-- radar lock marker: a box around the locked target
	simple("dl_lock", "dl_own", {0, 0, 0}, {"DL_LOCK_X", "DL_LOCK_Y", "DL_LOCK_VIS"},
		{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
		 {"parameter_in_range", 2, 0.5, 1.5}})
	do
		local b = S * 1.9
		local lv, li = band(sqr(b), sqr(b - LW))
		mesh("dl_lock_box", "dl_lock", "triangles", lv, li, M.white)
	end
	-------------------------------------------------------------------------
	-- intercept steering (dl_tac.lua, SA right 3 INTC): heading bar at the
	-- top with the collision course diamond, meeting point X, dashed lines
	-- jet -> X (yellow) and target -> X (red), readouts bottom left
	-------------------------------------------------------------------------
	do
		local IP = DL_INTC_POOL or {y = 30, r = 20}
		for _, pm in ipairs({{"y", M.unknown}, {"r", M.hostile}}) do
			for i = 1, IP[pm[1]] do
				local pre = "DL_INTC_" .. pm[1] .. i .. "_"
				line_obj("dl_intc_" .. pm[1] .. i, "dl_own", pm[2], 0.004,
					{pre .. "X1", pre .. "Y1", pre .. "X2", pre .. "Y2", pre .. "V"},
					{{"line_object_set_point_using_parameters", 0, 0, 1, GL, GL},
					 {"line_object_set_point_using_parameters", 1, 2, 3, GL, GL},
					 {"parameter_in_range", 4, 0.5, 1.5}})
			end
		end
		-- the target: white ring (amber while the track is lost)
		simple("dl_intc_t", "dl_own", {0, 0, 0}, {"DL_INTC_TX", "DL_INTC_TY", "DL_INTC_TV"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 2.5}})
		local tv, ti = circle_ring(0.075, LW * 0.8, 28)
		mesh("dl_intc_t_w", "dl_intc_t", "triangles", tv, ti, M.white, nil, {"DL_INTC_TV"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		mesh("dl_intc_t_a", "dl_intc_t", "triangles", tv, ti, M.amber, nil, {"DL_INTC_TV"}, {{"parameter_in_range", 0, 1.5, 2.5}})
		-- meeting point X
		simple("dl_intc_x", "dl_own", {0, 0, 0}, {"DL_INTC_XX", "DL_INTC_XY", "DL_INTC_XV", "DL_INTC_ON"},
			{{"move_left_right_using_parameter", 0, G}, {"move_up_down_using_parameter", 1, G},
			 {"parameter_in_range", 2, 0.5, 1.5}, {"parameter_in_range", 3, 0.5, 1.5}})
		do
			local q, w = 0.032, LW * 0.6
			local function bar(a)
				local ca, sa = math.cos(a), math.sin(a)
				local px, py = -sa * w, ca * w
				return {{-q * ca + px, -q * sa + py}, {q * ca + px, q * sa + py}, {q * ca - px, q * sa - py}, {-q * ca - px, -q * sa - py}}
			end
			local v1, v2 = bar(math.pi / 4), bar(-math.pi / 4)
			mesh("dl_intc_x1", "dl_intc_x", "triangles", v1, {0, 1, 2, 0, 2, 3}, M.unknown)
			mesh("dl_intc_x2", "dl_intc_x", "triangles", v2, {0, 1, 2, 0, 2, 3}, M.unknown)
		end
		-- heading tape (does not turn with the map), +-20 deg, at the top of
		-- the page between the H1-H5 labels and the HDG / range line;
		-- ticks hang down, numbers under the tape, own heading = mark above
		local BYI = CFG.intc_bar_y or 1.275
		local HW = 20 * (CFG.intc_bar_scale or 0.012)
		simple("dl_intc", "dl_root", {0, BYI, 0}, {"DL_INTC_ON"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		-- dark backing so the tape stays readable over the map and symbols
		mesh("dl_intc_bg", "dl_intc", "triangles", {{-HW - 0.07, 0.055}, {HW + 0.07, 0.055}, {HW + 0.07, -0.115}, {-HW - 0.07, -0.115}},
			{0, 1, 2, 0, 2, 3}, col(0, 0, 0, CFG.datablock_backing or 190))
		mesh("dl_intc_bar", "dl_intc", "triangles", {{-HW, LW * 0.5}, {HW, LW * 0.5}, {HW, -LW * 0.5}, {-HW, -LW * 0.5}}, {0, 1, 2, 0, 2, 3}, M.white)
		mesh("dl_intc_own", "dl_intc", "triangles", {{0, 0.006}, {0.014, 0.034}, {-0.014, 0.034}}, {0, 1, 2}, M.white)
		for k = 1, 7 do
			simple("dl_intc_k" .. k, "dl_intc", {0, 0, 0}, {"DL_INTC_K" .. k .. "_X", "DL_INTC_K" .. k .. "_V"},
				{{"move_left_right_using_parameter", 0, G}, {"parameter_in_range", 1, 0.5, 1.5}})
			mesh("dl_intc_k" .. k .. "_m", "dl_intc_k" .. k, "triangles",
				{{-LW * 0.4, 0}, {LW * 0.4, 0}, {LW * 0.4, -0.028}, {-LW * 0.4, -0.028}}, {0, 1, 2, 0, 2, 3}, M.white)
		end
		for j = 1, 3 do
			simple("dl_intc_n" .. j, "dl_intc", {0, -0.07, 0}, {"DL_INTC_N" .. j .. "_X", "DL_INTC_N" .. j .. "_V"},
				{{"move_left_right_using_parameter", 0, G}, {"parameter_in_range", 1, 0.5, 1.5}})
			-- a number formatted by the element (never a number-only string parameter)
			local e = CreateElement "ceStringPoly"
			e.name            = "dl_intc_n" .. j .. "_t"
			e.material        = F.white
			e.init_pos        = {0, 0, 0}
			e.alignment       = "CenterCenter"
			e.stringdefs      = defs_of(TXT_SMALL)
			e.formats         = {"%03.0f"}
			e.parent_element  = "dl_intc_n" .. j
			e.h_clip_relation = CLIP
			e.level           = LVL
			e.element_params  = {"DL_INTC_N" .. j .. "_T"}
			e.controllers     = {{"text_using_parameter", 0, 0}}
			Add(e)
		end
		-- collision course diamond (amber when it is off the end of the bar)
		simple("dl_intc_d", "dl_intc", {0, 0, 0}, {"DL_INTC_DX"}, {{"move_left_right_using_parameter", 0, G}})
		do
			local q = 0.036
			local dv, di = band({{0, q}, {q, 0}, {0, -q}, {-q, 0}}, {{0, q - LW * 1.6}, {q - LW * 1.6, 0}, {0, -q + LW * 1.6}, {-q + LW * 1.6, 0}})
			mesh("dl_intc_dg", "dl_intc_d", "triangles", dv, di, M.friend, nil, {"DL_INTC_DP"}, {{"parameter_in_range", 0, 0.5, 1.5}})
			mesh("dl_intc_da", "dl_intc_d", "triangles", dv, di, M.amber, nil, {"DL_INTC_DP"}, {{"parameter_in_range", 0, 1.5, 2.5}})
		end
		-- readouts: bottom right, in place of the cursor datablock
		local BYL0 = (CFG.text_bottom_y or -1.35) + 0.05
		local XR = CFG.text_right_x
		simple("dl_intc_txt", "dl_root", {0, 0, 0}, {"DL_INTC_ON"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		if SHOW_MAP then
			-- dark backing over the moving map (drawn before the texts)
			simple("dl_intc_txt_bg", "dl_intc_txt", {0, 0, 0}, {"DL_MAP_ON"}, {{"parameter_in_range", 0, 0.5, 1.5}})
			mesh("dl_intc_txt_bg_m", "dl_intc_txt_bg", "triangles", {{0.06, BYL0 + 0.53}, {0.92, BYL0 + 0.53}, {0.92, BYL0 + 0.11}, {0.06, BYL0 + 0.11}},
				{0, 1, 2, 0, 2, 3}, col(0, 0, 0, CFG.datablock_backing or 190))
		end
		text("dl_intc_t1", "dl_intc_txt", {XR, BYL0 + 0.47, 0}, F.red, TXT_SMALL, "RightCenter", nil, "DL_INTC_T1")
		text("dl_intc_t2", "dl_intc_txt", {XR, BYL0 + 0.37, 0}, F.white, TXT_SMALL, "RightCenter", nil, "DL_INTC_T2")
		text("dl_intc_t3", "dl_intc_txt", {XR, BYL0 + 0.27, 0}, F.white, TXT_SMALL, "RightCenter", nil, "DL_INTC_T3")
		for ci, cf in ipairs({F.green, F.amber, F.red, F.grey}) do
			text1("dl_intc_t4_" .. ci, "dl_intc_txt", {XR, BYL0 + 0.17, 0}, cf, TXT_SMALL, "RightCenter", nil, "DL_INTC_T4",
				{"DL_INTC_C4", ci - 0.1, ci + 0.1})
		end
	end

	-- readouts: bottom left = cursor bearing / range from the jet,
	-- bottom right = what is under the cursor
	local BYL = (CFG.text_bottom_y or -1.35) + 0.05
	-- cursor readout sits above the MARK / DEL labels (bottom row B1 / B2)
	-- over the moving map the datablocks get a dark backing panel and an outline
	if SHOW_MAP then
		local PB = col(0, 0, 0, CFG.datablock_backing or 190)
		simple("dl_db_bg", "dl_root", {0, 0, 0}, {"DL_MAP_ON"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		mesh("dl_db_bg_c", "dl_db_bg", "triangles", {{-0.92, BYL + 0.23}, {-0.30, BYL + 0.23}, {-0.30, BYL + 0.11}, {-0.92, BYL + 0.11}},
			{0, 1, 2, 0, 2, 3}, PB, nil, {"DL_CURS"}, {{"parameter_in_range", 0, 0.5, 1.5}})
		mesh("dl_db_bg_h", "dl_db_bg", "triangles", {{0.10, BYL + 0.53}, {0.92, BYL + 0.53}, {0.92, BYL + 0.11}, {0.10, BYL + 0.11}},
			{0, 1, 2, 0, 2, 3}, PB, nil, {"DL_HOV_COL"}, {{"parameter_in_range", 0, 0.5, 4.5}})
	end
	text("dl_cbra", "dl_root", {CFG.text_left_x, BYL + 0.17, 0}, F.white, TXT_SMALL, "LeftCenter", nil, "DL_CURS_BRA",
		{"DL_CURS", 0.5, 1.5})
	local hov_fonts = {F.green, F.red, F.yellow, F.cyan}
	for ci, cf in ipairs(hov_fonts) do
		local vis = {"DL_HOV_COL", ci - 0.1, ci + 0.1}
		text("dl_hov_be" .. ci, "dl_root", {CFG.text_right_x, BYL + 0.47, 0}, cf, TXT_SMALL, "RightCenter", nil, "DL_HOV_BE", vis)
		text("dl_hov_id" .. ci, "dl_root", {CFG.text_right_x, BYL + 0.37, 0}, cf, TXT_SMALL, "RightCenter", nil, "DL_HOV_ID", vis)
		text("dl_hov_alt" .. ci, "dl_root", {CFG.text_right_x, BYL + 0.27, 0}, cf, TXT_SMALL, "RightCenter", nil, "DL_HOV_ALT", vis)
		text("dl_hov_bra" .. ci, "dl_root", {CFG.text_right_x, BYL + 0.17, 0}, cf, TXT_SMALL, "RightCenter", nil, "DL_HOV_BRA", vis)
	end

	-- header / footer texts ---------------------------------------------
	local TY = CFG.text_top_y or 1.15
	text("dl_rng", "dl_root", {CFG.text_right_x, TY, 0}, F.green, TXT, "RightCenter", nil, "DL_RANGE_TXT")
	-- header (v1.6): own bullseye left, range + steerpoint right; the
	-- datalink status line only when something is wrong (NO DL / DL OFF).
	-- Heading, source and DTC lines are gone. Hidden at SYM 5 (MIN).
	simple("dl_hdr", "dl_root", {0, 0, 0}, {"DL_SYM_HDR"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	text("dl_ownbe", "dl_hdr", {CFG.text_left_x, TY, 0}, F.green, TXT_SMALL, "LeftCenter", nil, "DL_OWN_BE")
	text("dl_steer", "dl_hdr", {CFG.text_right_x, TY - 0.11, 0}, F.yellow, TXT_SMALL, "RightCenter", nil, "DL_STEER_TXT")
	text("dl_stat", "dl_hdr", {CFG.text_right_x, TY - 0.22, 0}, F.amber, TXT_SMALL, "RightCenter", nil, "DL_STATUS_TXT")
	-- a banner while choosing a cartridge (UFCP 3)
	simple("dl_dtc_ban", "dl_root", {0, 0, 0}, {"DL_DTC_BAN"}, {{"parameter_in_range", 0, 0.5, 1.5}})
	mesh("dl_dtc_ban_bg", "dl_dtc_ban", "triangles", {{-0.9, 0.62}, {0.9, 0.62}, {0.9, 0.42}, {-0.9, 0.42}}, {0, 1, 2, 0, 2, 3}, M.black)
	text1("dl_dtc_ban_t", "dl_dtc_ban", {0, 0.52, 0}, F.yellow, TXT, "CenterCenter", nil, "DL_DTC_BAN_TXT")

	-- bezel button labels (left row: MFD-3, MFD-4, MFD-5) -------------------
	local BX = CFG.btn_label_x or -1.02
	local BY = CFG.btn_label_y or {0.878, 0.448, 0.014, -0.462, -0.879}
	local BYR = CFG.btn_label_y_right or {0.877, 0.452, 0.035, -0.430, -0.832}
	local ROWT = CFG.btn_row_x or {-0.635, -0.307, 0.021, 0.351, 0.684}
	local ROWB = CFG.btn_row_x_bottom or {-0.61, -0.285, 0.048, 0.370, 0.695}
	local YB8 = CFG.btn8_label_y or -1.25
	local YT8 = CFG.btn_top_label_y or 1.37
	-- SA page side labels: smaller than the old Arial-sized ones, rows
	-- nudged onto the buttons (same per-row offsets as the other pages)
	local TXT_SAB, BYSA, BYRSA
	do
		local SS = CFG.sa_btn_label_scale or 0.75
		TXT_SAB = {TXT_BTN[1] * SS, TXT_BTN[2] * SS, TXT_BTN[3] * SS, TXT_BTN[4] * SS}
		local DYL = CFG.sub_btn_dy_left or {0, 0, 0, 0, 0}
		local DYR = CFG.sub_btn_dy_right or {0, 0, 0, 0, 0}
		BYSA, BYRSA = {}, {}
		for k = 1, 5 do BYSA[k] = BY[k] + (DYL[k] or 0); BYRSA[k] = BYR[k] + (DYR[k] or 0) end
	end
	local ALWAYS_ON = CFG.always_on ~= false
	if ALWAYS_ON then
		text("dl_btn1", "dl_root", {BX, BYSA[1], 0}, F.white, TXT_SAB, "LeftCenter", nil, "DL_BTN1_TXT")
		-- B4 (bottom row, 4th): expand; top row: the 5 nearest hostiles
		text("dl_btn8", "dl_root", {ROWB[4], YB8, 0}, F.white, TXT_SMALL, "CenterCenter", nil, "DL_EXP_TXT")
		text("dl_btn_b1", "dl_root", {ROWB[1], YB8, 0}, F.white, TXT_SMALL, "CenterCenter", "MARK")
		if CFG.opt_map == true then
			-- B5 MAP: white = map shown, grey = map off
			text("dl_btn_b5", "dl_root", {ROWB[5], YB8, 0}, F.white, TXT_SMALL, "CenterCenter", "MAP", nil, {"DL_MAP_ON", 0.5, 1.5})
			text("dl_btn_b5o", "dl_root", {ROWB[5], YB8, 0}, F.grey, TXT_SMALL, "CenterCenter", "MAP", nil, {"DL_MAP_ON", -0.5, 0.5})
		end
		text("dl_btn_b2", "dl_root", {ROWB[2], YB8, 0}, F.white, TXT_SMALL, "CenterCenter", "DEL", nil, {"DL_MK_ANY", 0.5, 1.5})
		for k = 1, 5 do
			text("dl_btn_t" .. k, "dl_root", {ROWT[k], YT8, 0}, F.red, TXT_SMALL, "CenterCenter", "H" .. k)
		end
	end
	-- right 1 GEO: drawings of the cartridge's .geo.txt shown (white) / hidden (grey);
	-- no label without drawings
	text("dl_btn_r1", "dl_root", {-BX, BYRSA[1], 0}, F.white, TXT_SAB, "RightCenter", "GEO", nil, {"DL_GEO_BTN", 0.5, 1.5})
	text("dl_btn_r1o", "dl_root", {-BX, BYRSA[1], 0}, F.grey, TXT_SAB, "RightCenter", "GEO", nil, {"DL_GEO_BTN", 1.5, 2.5})
	-- right 2 PIC (picture page), right 3 INTC (intercept steering; green while it runs)
	text("dl_btn_r2", "dl_root", {-BX, BYRSA[2], 0}, F.white, TXT_SAB, "RightCenter", "PIC")
	text("dl_btn_r3", "dl_root", {-BX, BYRSA[3], 0}, F.white, TXT_SAB, "RightCenter", "INTC", nil, {"DL_INTC_ON", -0.5, 0.5})
	text("dl_btn_r3g", "dl_root", {-BX, BYRSA[3], 0}, F.green, TXT_SAB, "RightCenter", "INTC", nil, {"DL_INTC_ON", 0.5, 1.5})
	text("dl_btn2", "dl_root", {BX, BYSA[2], 0}, F.white, TXT_SAB, "LeftCenter", nil, "DL_BTN2_TXT")
	-- MFD-3 / MFD-4: range
	text("dl_btn3", "dl_root", {BX, BYSA[3], 0}, F.white, TXT_SAB, "LeftCenter", "RNG\n +")
	text("dl_btn4", "dl_root", {BX, BYSA[4], 0}, F.white, TXT_SAB, "LeftCenter", "RNG\n -")
	if not ALWAYS_ON then
		text("dl_btn5", "dl_root", {BX, BYSA[5], 0}, F.white, TXT_SAB, "LeftCenter", "NAV")
	else
		text("dl_btn5", "dl_root", {BX, BYSA[5], 0}, F.white, TXT_SAB, "LeftCenter", "NEXT")
	end

	-- "DL" on MFD-4 while a KRN page is showing (main menu or NAV) and the
	-- DL page is off
	-- the other MFD pages (menu, DTC, ENG, FUEL, RADIO, FPLN, RSBN, HSI)
	DLH = {text = text, text1 = text1, mesh = mesh, simple = simple, line_obj = line_obj, circle_ring = circle_ring,
	       circle_pts = circle_pts, circle_fill = circle_fill, band = band, poly_lines = poly_lines, col = col,
	       M = M, F = F, TXT = TXT, TXT_SMALL = TXT_SMALL, TXT_BTN = TXT_BTN, G = G, LW = LW, BX = BX, BY = BY, CFG = CFG,
	       LVL = LVL, CLIP = CLIP, FONT = FONT, BYR = BYR, ROWT = ROWT, ROWB = ROWB, YB8 = YB8, YT8 = YT8,
	       char_w = char_w, TEXF = TEXF}
	local ok_p, err_p = pcall(dofile, LockOn_Options.script_path .. "DL/dl_pages.lua")
	if not ok_p and DL_dbg then DL_dbg("page", "dl_pages.lua: " .. tostring(err_p)) end

	for _, kp in ipairs(ALWAYS_ON and {} or {"MM_MFD_PAGE_MAIN_MENU", "MM_MFD_PAGE_BMAP"}) do
		local root = "dl_entry_" .. kp
		simple(root, nil, {0, 0, 0}, {kp}, {{"parameter_in_range", 0, 0.9, 1.1}})
		text(root .. "_lbl", root, {BX, BY[4], 0}, F.white, TXT_BTN, "LeftCenter", "DL", nil, {"DL_PAGE", -0.5, 0.5})
	end
end
local DL_ok, DL_err = pcall(DL_build_page)
Add, CreateElement = DL_rawAdd, DL_rawCreate   -- our wrappers end here, also after an error
if not DL_ok and DL_dbg then DL_dbg("page", "dl_page.lua: " .. tostring(DL_err)) end
